#!/usr/bin/env python3
"""
Flux Media (FluxTV) — recording live TV.

A recording downloads the channel's live stream (MPEG-TS, the same thing
the player plays) straight into a .ts file, from a start time to a stop
time, on a worker thread. If the provider drops the connection part way
through, it reconnects and carries on appending to the same file.

The list of recordings (scheduled, recording, done, failed) is kept in
recordings.json in the settings folder; the files go to
"<Videos>/Flux Media Recordings" unless Settings says otherwise.

Flux Media has to be running for a scheduled recording to happen.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time

import requests

from fluxtv_core import APP_DIR, _write_json

LIST_FILE = os.path.join(APP_DIR, "recordings.json")
PAD_BEFORE = 60            # start a minute early
PAD_AFTER = 120            # and run two minutes over (programmes overrun)
_lock = threading.Lock()


def default_folder():
    home = os.path.expanduser("~")
    videos = os.path.join(home, "Videos")
    return os.path.join(videos if os.path.isdir(videos) else home, "Flux Media Recordings")


def load():
    try:
        with open(LIST_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [r for r in data if isinstance(r, dict) and r.get("id")] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save(items):
    with _lock:
        _write_json(LIST_FILE, items)


def _safe(text):
    text = re.sub(r'[\\/:*?"<>|\r\n\t]+', " ", text or "").strip()
    return re.sub(r"\s+", " ", text)[:80] or "Recording"


def new_recording(channel_name, stream_id, title, start, stop, folder=None):
    """A recording entry (not yet saved). start/stop are UNIX times."""
    folder = folder or default_folder()
    stamp = time.strftime("%Y-%m-%d %H.%M", time.localtime(start))
    name = f"{_safe(title)} - {_safe(channel_name)} - {stamp}.ts"
    return {"id": os.urandom(5).hex(), "channel": channel_name, "stream_id": stream_id,
            "title": title or channel_name, "start": float(start), "stop": float(stop),
            "file": os.path.join(folder, name), "status": "scheduled", "bytes": 0,
            "error": ""}


def add(entry):
    items = load()
    items.append(entry)
    items.sort(key=lambda r: r["start"])
    save(items)
    return entry


def update(rid, **changes):
    items = load()
    for r in items:
        if r["id"] == rid:
            r.update(changes)
    save(items)


def remove(rid, delete_file=False):
    items = load()
    for r in items:
        if r["id"] == rid and delete_file:
            try:
                os.remove(r["file"])
            except OSError:
                pass
    save([r for r in items if r["id"] != rid])


def overlaps(entry, items=None):
    """Other scheduled/active recordings at the same time (most providers
    allow only one or two streams at once)."""
    items = load() if items is None else items
    return [r for r in items if r["id"] != entry["id"] and r["status"] in ("scheduled", "recording")
            and r["start"] < entry["stop"] and entry["start"] < r["stop"]]


class Recorder(threading.Thread):
    """Downloads one recording. stop_event ends it early."""

    CHUNK = 32 * 1024

    def __init__(self, entry, url, on_progress=None, on_done=None, headers=None):
        super().__init__(daemon=True)
        self.entry = entry
        self.url = url
        self.on_progress = on_progress
        self.on_done = on_done
        self.headers = headers or {"User-Agent": "VLC/3.0.20 LibVLC/3.0.20"}
        self.stop_event = threading.Event()
        self.written = 0

    def stop(self):
        self.stop_event.set()

    def run(self):
        e = self.entry
        error = ""
        fails = 0
        try:
            os.makedirs(os.path.dirname(e["file"]), exist_ok=True)
            with open(e["file"], "ab") as out:
                while not self.stop_event.is_set() and time.time() < e["stop"] + PAD_AFTER:
                    try:
                        with requests.get(self.url, headers=self.headers, stream=True,
                                          timeout=(10, 30)) as r:
                            r.raise_for_status()
                            fails = 0
                            for chunk in r.iter_content(self.CHUNK):
                                if self.stop_event.is_set() or time.time() >= e["stop"] + PAD_AFTER:
                                    break
                                if chunk:
                                    out.write(chunk)
                                    self.written += len(chunk)
                                    if self.on_progress:
                                        self.on_progress(e["id"], self.written)
                    except requests.RequestException as err:
                        fails += 1
                        error = f"{err.__class__.__name__}"
                        if fails >= 8:
                            break
                        self.stop_event.wait(min(30, 3 * fails))     # then reconnect
        except OSError as err:
            error = f"Couldn't write the file ({err.strerror or err})"
        ok = self.written > 0
        if self.on_done:
            self.on_done(e["id"], ok, "" if ok else (error or "Nothing was received"),
                         self.written)
