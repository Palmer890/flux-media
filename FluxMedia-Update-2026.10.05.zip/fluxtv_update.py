#!/usr/bin/env python3
"""
Flux Media (FluxTV) — installing updates from an update file.

An update is a zip ("FluxMedia-Update-<version>.zip") holding the app's
files plus a manifest.json: {"app": "Flux Media", "version": ..., "files":
{name: sha256}}. Installing one:

  1. checks the zip is a Flux Media update and every file matches its
     checksum (a half-copied or wrong zip is refused, nothing touched);
  2. checks every Python file at least compiles;
  3. backs up the files it will replace into the settings folder
     (backups/<old version>), keeping the last few;
  4. writes each new file next to the old one and swaps it in.

"Undo last update" puts the newest backup back. The app restarts itself
afterwards (FluxTV.restart_app).
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import zipfile

from fluxtv_core import APP_DIR

VERSION = "2026.10.05"
APP_NAME = "Flux Media"
HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(APP_DIR, "backups")
KEEP_BACKUPS = 4
ALLOWED = (".py", ".png", ".ico", ".svg", ".txt", ".json")
REQUIRED = ("iptv.py", "fluxtv_core.py", "fluxtv_player.py", "fluxtv_style.py")


class UpdateError(Exception):
    pass


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _version_key(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def read_update(path):
    """(manifest, {name: bytes}) from an update zip, fully checked."""
    try:
        zf = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile):
        raise UpdateError("That isn't a valid update file (not a zip).")
    with zf:
        names = [n for n in zf.namelist() if not n.endswith("/")]
        # Files may sit at the top or inside one folder.
        prefix = ""
        if "manifest.json" not in names:
            tops = {n.split("/", 1)[0] for n in names if "/" in n}
            if len(tops) == 1 and f"{next(iter(tops))}/manifest.json" in names:
                prefix = next(iter(tops)) + "/"
            else:
                raise UpdateError("That zip isn't a Flux Media update (no manifest.json).")
        try:
            manifest = json.loads(zf.read(prefix + "manifest.json").decode("utf-8"))
        except (ValueError, KeyError):
            raise UpdateError("The update's manifest is damaged.")
        if manifest.get("app") != APP_NAME or not isinstance(manifest.get("files"), dict):
            raise UpdateError("That zip isn't a Flux Media update.")
        files = {}
        for name, digest in manifest["files"].items():
            if os.path.basename(name) != name or not name.endswith(ALLOWED):
                raise UpdateError(f"The update contains an unexpected file: {name}")
            try:
                data = zf.read(prefix + name)
            except KeyError:
                raise UpdateError(f"The update is incomplete ({name} is missing).")
            if _sha256(data) != digest:
                raise UpdateError(f"The update is damaged ({name} doesn't match). "
                                  "Copy it again and retry.")
            files[name] = data
    missing = [r for r in REQUIRED if r not in files]
    if missing:
        raise UpdateError("The update is incomplete (" + ", ".join(missing) + " missing).")
    for name, data in files.items():
        if name.endswith(".py"):
            try:
                compile(data, name, "exec")
            except SyntaxError as error:
                raise UpdateError(f"The update has a broken file ({name}, line {error.lineno}).")
    return manifest, files


def install_update(path, app_dir=HERE):
    """Install an update zip over the running copy. Returns its version."""
    manifest, files = read_update(path)
    version = str(manifest.get("version") or "?")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = os.path.join(BACKUP_DIR, f"{VERSION}_{stamp}")
    os.makedirs(backup, exist_ok=True)
    replaced = []
    for name in files:
        current = os.path.join(app_dir, name)
        if os.path.exists(current):
            shutil.copy2(current, os.path.join(backup, name))
            replaced.append(name)
    with open(os.path.join(backup, "backup.json"), "w", encoding="utf-8") as f:
        json.dump({"version": VERSION, "replaced": replaced, "added": [
            n for n in files if n not in replaced], "made": stamp}, f)
    for name, data in files.items():
        target = os.path.join(app_dir, name)
        temp = target + ".new"
        with open(temp, "wb") as f:
            f.write(data)
        os.replace(temp, target)
        if name.endswith(".sh"):
            os.chmod(target, 0o755)
    _prune_backups()
    return version


def backups():
    """Newest first: [(folder, info)]."""
    out = []
    try:
        for entry in os.listdir(BACKUP_DIR):
            folder = os.path.join(BACKUP_DIR, entry)
            try:
                with open(os.path.join(folder, "backup.json"), encoding="utf-8") as f:
                    out.append((folder, json.load(f)))
            except (OSError, ValueError):
                continue
    except OSError:
        pass
    out.sort(key=lambda item: item[1].get("made", ""), reverse=True)
    return out


def undo_last_update(app_dir=HERE):
    """Put the newest backup back. Returns the version restored."""
    found = backups()
    if not found:
        raise UpdateError("There's no earlier version saved to go back to.")
    folder, info = found[0]
    for name in info.get("replaced", []):
        shutil.copy2(os.path.join(folder, name), os.path.join(app_dir, name))
    for name in info.get("added", []):
        try:
            os.remove(os.path.join(app_dir, name))
        except OSError:
            pass
    shutil.rmtree(folder, ignore_errors=True)
    return info.get("version", "?")


def _prune_backups():
    for folder, _info in backups()[KEEP_BACKUPS:]:
        shutil.rmtree(folder, ignore_errors=True)


def is_newer(version):
    return _version_key(version) > _version_key(VERSION)


def make_update_zip(source_dir, out_dir, version=VERSION):
    """Build FluxMedia-Update-<version>.zip from the app files in
    source_dir (used when preparing an update, not by the app itself)."""
    names = sorted(n for n in os.listdir(source_dir)
                   if n.endswith(ALLOWED) and (n == "iptv.py" or n.startswith("fluxtv_"))
                   and os.path.isfile(os.path.join(source_dir, n)))
    files = {}
    for n in names:
        with open(os.path.join(source_dir, n), "rb") as f:
            files[n] = f.read()
    manifest = {"app": APP_NAME, "version": version,
                "files": {n: _sha256(d) for n, d in files.items()}}
    path = os.path.join(out_dir, f"FluxMedia-Update-{version}.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=1))
        for n, d in files.items():
            zf.writestr(n, d)
    return path


# ══════════════════════════════════════════════════════════════════
# Online updates
# ══════════════════════════════════════════════════════════════════
# The "feed" says where updates are published:
#   "github:owner/repo"  -> the newest release on GitHub that has a
#                           FluxMedia-Update-<version>.zip attached
#   "https://.../latest.json" -> {"version": ..., "url": ..., "notes": ...}
DOWNLOAD_DIR = os.path.join(APP_DIR, "updates")
# Where Flux Media looks for updates unless Settings says otherwise.
DEFAULT_FEED = "github:Palmer890/flux-media"


def check_online(feed, timeout=20):
    """{"version", "url", "notes"} for the newest published update, or
    None if there isn't one (or no feed is set)."""
    import requests
    feed = (feed or "").strip()
    if not feed:
        return None
    headers = {"User-Agent": "FluxMedia-Updater/1.0"}
    if feed.startswith("github:"):
        repo = feed.split(":", 1)[1].strip("/")
        r = requests.get(f"https://api.github.com/repos/{repo}/releases/latest",
                         headers={**headers, "Accept": "application/vnd.github+json"}, timeout=timeout)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        release = r.json()
        for asset in release.get("assets") or []:
            name = asset.get("name") or ""
            if name.startswith("FluxMedia-Update-") and name.endswith(".zip"):
                return {"version": name[len("FluxMedia-Update-"):-4],
                        "url": asset.get("browser_download_url"),
                        "notes": (release.get("body") or "").strip()[:600]}
        return None
    r = requests.get(feed, headers=headers, timeout=timeout)
    r.raise_for_status()
    info = r.json()
    if not isinstance(info, dict) or not info.get("version") or not info.get("url"):
        return None
    return {"version": str(info["version"]), "url": info["url"],
            "notes": str(info.get("notes") or "")[:600]}


def newer_online(feed):
    """The online update if it's newer than this copy, else None."""
    info = check_online(feed)
    return info if info and is_newer(info["version"]) else None


def download(info, timeout=120):
    """Fetch an update zip; returns its local path (checked later by
    install_update like any update file)."""
    import requests
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    path = os.path.join(DOWNLOAD_DIR, f"FluxMedia-Update-{info['version']}.zip")
    with requests.get(info["url"], stream=True, timeout=timeout,
                      headers={"User-Agent": "FluxMedia-Updater/1.0"}) as r:
        r.raise_for_status()
        with open(path + ".part", "wb") as f:
            for chunk in r.iter_content(256 * 1024):
                f.write(chunk)
    os.replace(path + ".part", path)
    read_update(path)                 # refuse a damaged download straight away
    return path
