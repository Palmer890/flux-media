#!/usr/bin/env python3
"""
FluxTV — line icons for the app chrome (navigation rail, top bar).

Drawn with QPainter on a 24-unit grid rather than using Unicode glyphs,
which render as inconsistent emoji on many systems. Stroke weight and
rounded caps follow Stremio's own outline icon set.
"""

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QPushButton, QWidget

from fluxtv_style import C, font


def draw_icon(p, kind, rect, color):
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    u = min(rect.width(), rect.height()) / 24.0
    ox = rect.center().x() - 12 * u
    oy = rect.center().y() - 12 * u

    def P(x, y):
        return QPointF(ox + x * u, oy + y * u)

    pen = QPen(color, max(1.5, 1.9 * u), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)

    def poly(*pts):
        path = QPainterPath(P(*pts[0]))
        for pt in pts[1:]:
            path.lineTo(P(*pt))
        p.drawPath(path)

    def rrect(x0, y0, x1, y1, r):
        p.drawRoundedRect(QRectF(P(x0, y0), P(x1, y1)), r * u, r * u)

    if kind == "home":
        poly((3, 11), (12, 3.5), (21, 11))
        poly((5.5, 9.2), (5.5, 20.5), (18.5, 20.5), (18.5, 9.2))
        poly((10, 20.5), (10, 15), (14, 15), (14, 20.5))
    elif kind == "live":
        rrect(2.5, 6.5, 21.5, 18.5, 2.5)
        poly((8, 2.5), (12, 6.5), (16, 2.5))
        poly((8.5, 21.5), (15.5, 21.5))
    elif kind == "guide":
        rrect(3, 4.5, 21, 20.5, 2.5)
        poly((3, 9.5), (21, 9.5))
        poly((7.5, 2.5), (7.5, 6))
        poly((16.5, 2.5), (16.5, 6))
        poly((7, 13.5), (12, 13.5))
        poly((14.5, 13.5), (17, 13.5))
        poly((7, 17), (10, 17))
        poly((12.5, 17), (17, 17))
    elif kind == "sport":
        cup = QPainterPath(P(7, 4))
        cup.lineTo(P(17, 4))
        cup.lineTo(P(17, 9))
        cup.cubicTo(P(17, 12.8), P(14.8, 15), P(12, 15))
        cup.cubicTo(P(9.2, 15), P(7, 12.8), P(7, 9))
        cup.closeSubpath()
        p.drawPath(cup)
        left = QPainterPath(P(7, 6))
        left.cubicTo(P(3, 6), P(3, 11), P(7.6, 11.4))
        p.drawPath(left)
        right = QPainterPath(P(17, 6))
        right.cubicTo(P(21, 6), P(21, 11), P(16.4, 11.4))
        p.drawPath(right)
        poly((12, 15), (12, 19))
        poly((8, 20.5), (16, 20.5))
    elif kind == "movies":
        rrect(3, 4.5, 21, 19.5, 2.5)
        poly((7.5, 4.5), (7.5, 19.5))
        poly((16.5, 4.5), (16.5, 19.5))
        for y in (8.5, 12, 15.5):
            poly((3, y), (7.5, y))
            poly((16.5, y), (21, y))
    elif kind == "series":
        rrect(3, 8.5, 21, 20.5, 2.5)
        poly((5.5, 5.5), (18.5, 5.5))
        poly((8, 2.8), (16, 2.8))
        tri = QPainterPath(P(10.5, 11.8))
        tri.lineTo(P(14.8, 14.5))
        tri.lineTo(P(10.5, 17.2))
        tri.closeSubpath()
        p.drawPath(tri)
    elif kind == "favourites":
        heart = QPainterPath(P(12, 20))
        heart.cubicTo(P(12, 20), P(3, 14.2), P(3, 8.6))
        heart.cubicTo(P(3, 5.6), P(5.4, 3.6), P(8, 3.6))
        heart.cubicTo(P(10, 3.6), P(11.3, 4.8), P(12, 6.2))
        heart.cubicTo(P(12.7, 4.8), P(14, 3.6), P(16, 3.6))
        heart.cubicTo(P(18.6, 3.6), P(21, 5.6), P(21, 8.6))
        heart.cubicTo(P(21, 14.2), P(12, 20), P(12, 20))
        p.drawPath(heart)
    elif kind == "settings":
        import math
        c = P(12, 12)
        p.drawEllipse(c, 3.2 * u, 3.2 * u)
        p.drawEllipse(c, 7 * u, 7 * u)
        for i in range(8):
            a = math.radians(i * 45)
            p.drawLine(QPointF(c.x() + 7 * u * math.cos(a), c.y() + 7 * u * math.sin(a)),
                       QPointF(c.x() + 9.6 * u * math.cos(a), c.y() + 9.6 * u * math.sin(a)))
    elif kind == "discover":
        # Compass: ring plus a two-tone needle.
        p.drawEllipse(P(12, 12), 9 * u, 9 * u)
        needle = QPainterPath(P(15.6, 8.4))
        needle.lineTo(P(13.4, 13.4))
        needle.lineTo(P(8.4, 15.6))
        needle.lineTo(P(10.6, 10.6))
        needle.closeSubpath()
        p.setBrush(color)
        p.drawPath(needle)
        p.setBrush(Qt.NoBrush)
    elif kind == "music":
        # Two quavers joined by a beam.
        p.drawEllipse(P(6.5, 17.5), 2.6 * u, 2.2 * u)
        p.drawEllipse(P(17, 15.5), 2.6 * u, 2.2 * u)
        poly((9.1, 17.3), (9.1, 5.5), (19.6, 3.5), (19.6, 15.3))
        poly((9.1, 9), (19.6, 7))
    elif kind == "search":
        p.drawEllipse(P(10.5, 10.5), 6.5 * u, 6.5 * u)
        poly((15.3, 15.3), (20.5, 20.5))
    elif kind == "expand":
        poly((4, 9), (4, 4), (9, 4))
        poly((15, 4), (20, 4), (20, 9))
        poly((20, 15), (20, 20), (15, 20))
        poly((9, 20), (4, 20), (4, 15))
    elif kind == "close":
        poly((6, 6), (18, 18))
        poly((18, 6), (6, 18))
    p.restore()


class NavRailButton(QPushButton):
    """A tab on the left navigation rail: icon over a small label.

    At rest the icon is dimmed, hover adds Stremio's faint overlay, and
    the active tab takes the accent colour. The "active" dynamic property
    is set by FluxTV.go(); this widget paints from it directly.
    """

    def __init__(self, kind, label, parent=None):
        super().__init__(parent)
        self.kind = kind
        self.label = label
        self._hover = False
        self.setFixedSize(112, 86)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.setToolTip(label)

    def set_height(self, height):
        if height != self.height():
            self.setFixedSize(112, height)
            self.update()

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        active = bool(self.property("active"))
        if self._hover and not active:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 13))
            p.drawRoundedRect(QRectF(self.rect()).adjusted(2, 0, -2, 0), 12, 12)
        if active:
            color = QColor(C.cyan)
            text = QColor(C.cyan)
        else:
            color = QColor(C.paper)
            color.setAlphaF(0.75 if self._hover else 0.42)
            text = QColor(C.paper)
            text.setAlphaF(0.75 if self._hover else 0.45)
        # 36px icon over the label at full size; both shrink a little when
        # the rail squeezes the tabs on a short screen.
        size = 36 if self.height() >= 86 else max(24, self.height() * 0.42)
        top = max(2, (self.height() - size - 28) / 2)
        draw_icon(p, self.kind, QRectF(self.width() / 2 - size / 2, top, size, size), color)
        p.setPen(text)
        p.setFont(font(14, QFont.DemiBold))
        p.drawText(QRectF(0, top + size + 6, self.width(), 22), Qt.AlignHCenter | Qt.AlignTop,
                   self.label)
        p.end()


class ChromeIconButton(QPushButton):
    """Small icon button for the top bar (fullscreen, close)."""

    def __init__(self, kind, parent=None, danger=False, tip=""):
        super().__init__(parent)
        self.kind = kind
        self.danger = danger
        self._hover = False
        self.setFixedSize(44, 44)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.setToolTip(tip)

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self._hover:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(C.onair) if self.danger else QColor(255, 255, 255, 18))
            p.drawRoundedRect(QRectF(self.rect()), 12, 12)
        color = QColor(C.paper)
        if not self._hover:
            color.setAlphaF(0.6)
        draw_icon(p, self.kind, QRectF(12, 12, 20, 20), color)
        p.end()


class IconGlyph(QWidget):
    """A fixed-size, non-interactive icon (e.g. the magnifier in search)."""

    def __init__(self, kind, size=20, parent=None, alpha=0.6):
        super().__init__(parent)
        self.kind = kind
        self.alpha = alpha
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setStyleSheet("background: transparent;")

    def paintEvent(self, event):
        p = QPainter(self)
        color = QColor(C.paper)
        color.setAlphaF(self.alpha)
        draw_icon(p, self.kind, QRectF(self.rect()), color)
        p.end()
