#!/usr/bin/env python3
"""
FluxTV — Stremio add-on client (no Qt, no widgets).

Stremio add-ons are plain HTTP services described by a manifest.json. Their
protocol is public: a client asks an add-on for a catalog (rows of titles),
a meta (one title's details and episode list) or streams (playable links for
one film or episode), each as a JSON document under the add-on's base URL:

    {base}/catalog/{type}/{id}.json
    {base}/catalog/{type}/{id}/{extra}.json        e.g. skip=100, search=...
    {base}/meta/{type}/{id}.json
    {base}/stream/{type}/{id}.json                 series ids: tt123:1:2

Cinemeta (Stremio's own metadata add-on) is installed by default. Debrid
add-ons such as Torrentio or Debridio configured with a TorBox key answer
stream requests with direct HTTPS links, which FluxTV's player plays as is.
Plain torrent results (infoHash with no URL) need a torrent engine and are
skipped.

Add-on URLs usually contain the user's debrid API key, so addons.json is
written owner-only like the rest of FluxTV's account data.
"""

from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlsplit

import requests

from fluxtv_core import APP_DIR, _write_json

ADDONS_FILE = os.path.join(APP_DIR, "addons.json")
CINEMETA_URL = "https://v3-cinemeta.strem.io/manifest.json"

_session = requests.Session()
_session.headers["User-Agent"] = "FluxTV/1.0 (Stremio add-on client)"
_cache: dict[str, tuple[float, object]] = {}
_cache_lock = threading.Lock()


# ══════════════════════════════════════════════════════════════════
# HTTP
# ══════════════════════════════════════════════════════════════════
def _get_json(url, ttl=1800, timeout=20):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(url)
        if hit and now - hit[0] < ttl:
            return hit[1]
    response = _session.get(url, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    with _cache_lock:
        _cache[url] = (now, data)
    return data


def normalise_url(text):
    """Accept what people paste: stremio:// links, links without the
    manifest suffix, or a configure page link."""
    url = (text or "").strip()
    if url.startswith("stremio://"):
        url = "https://" + url[len("stremio://"):]
    if not url.startswith(("http://", "https://")):
        raise ValueError("That doesn't look like an add-on link (it should start with https://).")
    url = url.split("#", 1)[0]
    if url.endswith("/configure"):
        url = url[: -len("/configure")]
    if not url.endswith("/manifest.json"):
        url = url.rstrip("/") + "/manifest.json"
    return url


# ══════════════════════════════════════════════════════════════════
# Add-ons
# ══════════════════════════════════════════════════════════════════
class Addon:
    def __init__(self, url, manifest=None):
        self.url = url
        self.base = url[: -len("/manifest.json")] if url.endswith("/manifest.json") else url
        self.manifest = manifest or {}

    @property
    def id(self):
        return self.manifest.get("id") or self.url

    @property
    def name(self):
        return self.manifest.get("name") or urlsplit(self.url).hostname or "Add-on"

    @property
    def description(self):
        return self.manifest.get("description") or ""

    @property
    def version(self):
        return self.manifest.get("version") or ""

    @property
    def host(self):
        """Where it lives, without the path — the path is often the
        configuration, including the user's API key."""
        return urlsplit(self.url).hostname or ""

    def _resources(self):
        out = []
        for res in self.manifest.get("resources") or []:
            if isinstance(res, str):
                out.append({"name": res, "types": None, "idPrefixes": None})
            elif isinstance(res, dict) and res.get("name"):
                out.append({"name": res["name"], "types": res.get("types"),
                            "idPrefixes": res.get("idPrefixes")})
        return out

    def resource_names(self):
        return [r["name"] for r in self._resources()]

    def supports(self, resource, type_, id_=None):
        for res in self._resources():
            if res["name"] != resource:
                continue
            types = res["types"] or self.manifest.get("types") or []
            if types and type_ not in types:
                continue
            prefixes = res["idPrefixes"] if res["idPrefixes"] is not None \
                else self.manifest.get("idPrefixes")
            if id_ and prefixes and not any(id_.startswith(p) for p in prefixes):
                continue
            return True
        return False

    def browse_catalogs(self):
        """Catalogs that can be shown as plain rows (none that need a
        search term or a list of ids to work)."""
        if "catalog" not in self.resource_names():
            return []
        rows = []
        for cat in self.manifest.get("catalogs") or []:
            extras = cat.get("extra") or []
            required = [e for e in extras if isinstance(e, dict) and e.get("isRequired")]
            required += [{"name": n} for n in (cat.get("extraRequired") or [])]
            if required:
                continue
            if cat.get("type") and cat.get("id"):
                rows.append(cat)
        return rows

    def to_dict(self):
        return {"url": self.url, "manifest": self.manifest}


def fetch_manifest(url):
    data = _get_json(url, ttl=0, timeout=20)
    if not isinstance(data, dict) or not data.get("id") or not data.get("resources"):
        raise ValueError("That link didn't return a Stremio add-on manifest.")
    return data


def load_addons():
    try:
        with open(ADDONS_FILE, encoding="utf-8") as f:
            data = json.load(f)
        addons = [Addon(d["url"], d.get("manifest")) for d in data
                  if isinstance(d, dict) and d.get("url")]
        return addons
    except (OSError, ValueError, KeyError):
        return [Addon(CINEMETA_URL)]          # first run: Cinemeta only


def save_addons(addons):
    _write_json(ADDONS_FILE, [a.to_dict() for a in addons])


def install_addon(addons, text):
    """Fetch and add an add-on; returns the new list. Raises ValueError
    with a message fit to show the user."""
    url = normalise_url(text)
    try:
        manifest = fetch_manifest(url)
    except requests.RequestException as error:
        raise ValueError(f"Couldn't reach that add-on ({error.__class__.__name__}).")
    new = Addon(url, manifest)
    kept = [a for a in addons if a.url != url and a.id != new.id]
    kept.append(new)
    save_addons(kept)
    return kept


_LINK_RE = re.compile(r"""(?:https?|stremio)://[^\s"'<>\\]+?/manifest\.json""")


def find_addon_links(text):
    """Every add-on link in whatever was pasted or imported: one link, a
    list of them, or a whole backup (e.g. from Stremio's add-on manager,
    whose entries carry a transportUrl). Stremio's own local add-ons
    (served by Stremio itself on 127.0.0.1) only work inside Stremio."""
    links = []
    text = (text or "").replace("\\/", "/")      # JSON written with escaped slashes
    for raw in _LINK_RE.findall(text):
        url = normalise_url(raw)
        host = urlsplit(url).hostname or ""
        if host in ("127.0.0.1", "localhost") and ":11470" in url:
            continue
        if url not in links:
            links.append(url)
    return links


def install_many(addons, text):
    """Install every add-on link found in `text`. Returns
    (addons, installed_names, problems). One unreachable add-on doesn't
    stop the rest."""
    links = find_addon_links(text)
    if not links:
        raise ValueError("No add-on links found. They end in /manifest.json.")
    have = {a.url for a in addons}
    installed, problems = [], []
    for url in links:
        if url in have:
            continue
        try:
            addons = install_addon(addons, url)
            installed.append(addons[-1].name)
        except ValueError as error:
            problems.append(f"{urlsplit(url).hostname}: {error}")
    addons = reorder_like(addons, links)
    return addons, installed, problems


def reorder_like(addons, links):
    """Put add-ons in the order their links appear in a backup (Stremio's
    own order, Cinemeta included); any not in it keep their place after."""
    rank = {url: i for i, url in enumerate(links)}
    ordered = sorted(addons, key=lambda a: (rank.get(a.url, len(rank)), addons.index(a)))
    if [a.url for a in ordered] != [a.url for a in addons]:
        save_addons(ordered)
    return ordered


def move_addon(addons, addon, delta):
    """Move one add-on up (-1) or down (+1); order decides whose streams
    come first and which add-on supplies details."""
    i = addons.index(addon)
    j = max(0, min(len(addons) - 1, i + delta))
    if i == j:
        return addons
    addons = list(addons)
    addons.insert(j, addons.pop(i))
    save_addons(addons)
    return addons


def remove_addon(addons, addon):
    kept = [a for a in addons if a is not addon]
    save_addons(kept)
    return kept


def refresh_manifests(addons):
    """Re-fetch every manifest (in a worker thread); keeps the old copy
    for any add-on that can't be reached right now."""
    changed = False
    for addon in addons:
        try:
            manifest = fetch_manifest(addon.url)
        except Exception:
            continue
        if manifest != addon.manifest:
            addon.manifest = manifest
            changed = True
    if changed:
        save_addons(addons)
    return addons


# ══════════════════════════════════════════════════════════════════
# Catalogs, details, streams
# ══════════════════════════════════════════════════════════════════
_REAL_ID = re.compile(r"^(tt\d+|[a-z][a-z0-9_.-]*:[^\s]+)$", re.I)


def _usable(meta):
    """Skip the fake "Error loading content" items many add-ons send back
    (with a big ✕ picture) when they have a hiccup instead of failing
    properly. Real titles have ids like tt1234567 or tmdb:603."""
    if not isinstance(meta, dict) or not _REAL_ID.match(str(meta.get("id") or "")):
        return False
    name = str(meta.get("name") or "").lower()
    return bool(name) and not re.search(r"\berror\b|failed to load|no results", name)


def _tmdb_size(url):
    """TMDB "original" backdrops are often 4K and several MB; 1280px looks
    the same on a TV and arrives far faster."""
    if isinstance(url, str) and "image.tmdb.org/t/p/original/" in url:
        return url.replace("/t/p/original/", "/t/p/w1280/")
    return url


def tidy_meta(meta):
    for key in ("background", "poster", "logo"):
        if meta.get(key):
            meta[key] = _tmdb_size(meta[key])
    return meta


def catalog(addon, type_, catalog_id, skip=0):
    extra = f"/skip={skip}" if skip else ""
    # 12s: one slow add-on mustn't hold the whole Discover screen up.
    data = _get_json(f"{addon.base}/catalog/{type_}/{quote(catalog_id, safe='')}{extra}.json",
                     timeout=12)
    metas = data.get("metas") if isinstance(data, dict) else None
    return [tidy_meta(m) for m in (metas or []) if _usable(m)]


def browse_rows(addons, limit=8):
    """[(title, type, metas)] for the Discover screen, in add-on order."""
    for addon in addons:
        if not addon.manifest:
            # First run: the add-on's manifest hasn't been fetched yet, and
            # without it there are no catalogs to ask for.
            try:
                addon.manifest = fetch_manifest(addon.url)
            except Exception:
                pass
    jobs = []
    for addon in addons:
        for cat in addon.browse_catalogs():
            jobs.append((addon, cat))
    jobs = jobs[:limit]
    kind = {"movie": "Films", "series": "Series"}

    def run(job):
        addon, cat = job
        try:
            metas = catalog(addon, cat["type"], cat["id"])
        except Exception:
            return None
        name = cat.get("name") or cat["id"].title()
        title = f"{name} {kind.get(cat['type'], cat['type'].title())}"
        if addon.id != "com.linvo.cinemeta":
            title = f"{title} · {addon.name}"
        return (title, cat["type"], metas) if metas else None

    with ThreadPoolExecutor(max_workers=6) as pool:
        return [r for r in pool.map(run, jobs) if r]


def search_catalogs(addon):
    """The add-on's catalogs that take a search term (Cinemeta's Popular,
    the TMDB add-on's "tmdb.search", AIOMetadata's search...)."""
    if "catalog" not in addon.resource_names():
        return []
    out = []
    for cat in addon.manifest.get("catalogs") or []:
        names = {e.get("name") for e in cat.get("extra") or [] if isinstance(e, dict)}
        names |= set(cat.get("extraSupported") or [])
        if "search" in names and cat.get("type") and cat.get("id"):
            out.append(cat)
    return out


def search_jobs(addons, limit=8):
    """(addon, catalog) pairs to ask, in add-on order."""
    return [(a, c) for a in addons for c in search_catalogs(a)][:limit]


def search_one(addon, cat, query):
    """One catalog's matches as (title, type, metas), or None."""
    query = " ".join((query or "").split())
    url = (f"{addon.base}/catalog/{cat['type']}/{quote(cat['id'], safe='')}"
           f"/search={quote(query, safe='')}.json")
    data = _get_json(url, ttl=600, timeout=15)
    metas = data.get("metas") if isinstance(data, dict) else None
    metas = [tidy_meta(m) for m in (metas or []) if isinstance(m, dict) and _usable(m)]
    kind = {"movie": "Films", "series": "Series"}
    title = f"{kind.get(cat['type'], cat['type'].title())} · {addon.name}"
    return (title, cat["type"], metas) if metas else None


DISCOVER_CACHE = os.path.join(APP_DIR, "discover_cache.json")
DISCOVER_MAX_AGE = 30 * 60          # older than this: refresh in the background


def _addon_signature(addons):
    return [a.url for a in addons]


def load_rows_cache(addons):
    """(rows, age_seconds) saved last time for this exact add-on line-up,
    or (None, None). Lets Discover appear instantly instead of waiting on
    every add-on's catalogs."""
    try:
        with open(DISCOVER_CACHE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None, None
    if data.get("addons") != _addon_signature(addons):
        return None, None
    # Drop anything saved before error items were filtered out.
    rows = [(t, ty, [m for m in ms if _usable(m)]) for t, ty, ms in data.get("rows") or []]
    rows = [r for r in rows if r[2]]
    return (rows or None), time.time() - data.get("saved", 0)


_ROW_FIELDS = ("id", "type", "name", "poster", "background", "description", "releaseInfo",
               "year", "released", "imdbRating", "genres", "behaviorHints")


def save_rows_cache(addons, rows):
    # Only what the rows and banner show: full catalog entries carry cast
    # lists, trailers etc. and made the file ~2 MB, slow to read back.
    slim = [[title, type_, [{k: m[k] for k in _ROW_FIELDS if k in m} for m in metas]]
            for title, type_, metas in rows]
    try:
        _write_json(DISCOVER_CACHE, {"addons": _addon_signature(addons),
                                     "saved": int(time.time()), "rows": slim})
    except Exception:
        pass


def meta(addons, type_, id_):
    for addon in addons:
        if addon.supports("meta", type_, id_):
            try:
                data = _get_json(f"{addon.base}/meta/{type_}/{quote(id_, safe=':')}.json")
            except Exception:
                continue
            m = data.get("meta") if isinstance(data, dict) else None
            if m and _usable(m):
                return tidy_meta(m)
    return None


_QUALITY = [(r"2160p|\b4k\b|\buhd\b", "4K", 4), (r"1080p|\bfhd\b", "1080p", 3),
            (r"720p", "720p", 2), (r"480p|\bsd\b", "480p", 1)]


def _size_text(stream, text):
    size = (stream.get("behaviorHints") or {}).get("videoSize")
    if isinstance(size, (int, float)) and size > 0:
        gb = size / 1024 ** 3
        return f"{gb:.1f} GB" if gb >= 1 else f"{size / 1024 ** 2:.0f} MB"
    m = re.search(r"(\d+(?:[.,]\d+)?)\s?(GB|MB|GiB|MiB)", text, re.I)
    return f"{m.group(1).replace(',', '.')} {m.group(2).upper().replace('I', '')}" if m else ""


def describe(addon, stream):
    """A Stremio stream object -> what FluxTV shows and plays, or None
    if it isn't something FluxTV can play (torrent-only, YouTube, web)."""
    url = stream.get("url")
    if not url or not url.startswith(("http://", "https://")):
        return None
    name = (stream.get("name") or "").strip()
    body = (stream.get("title") or stream.get("description") or "").strip()
    text = f"{name}\n{body}"
    low = text.lower()
    quality, rank = "", 0
    for pattern, label, r in _QUALITY:
        if re.search(pattern, low):
            quality, rank = label, r
            break
    tags = []
    if re.search(r"\b(dolby ?vision|dovi|dv)\b", low):
        tags.append("DV")
    if re.search(r"\bhdr10\+|\bhdr10plus", low):
        tags.append("HDR10+")
    elif re.search(r"\bhdr", low):
        tags.append("HDR")
    if re.search(r"\batmos\b", low):
        tags.append("Atmos")
    # Debrid add-ons mark files already on the debrid service: Torrentio
    # with "[TB+]" / "+]", others with a lightning bolt or "cached".
    cached = bool(re.search(r"\+\]|⚡|\bcached\b", text, re.I)) and \
        not re.search(r"\buncached\b|download\]", low)
    hints = stream.get("behaviorHints") or {}
    headers = ((hints.get("proxyHeaders") or {}).get("request") or {})
    lines = [ln.strip() for ln in body.splitlines() if ln.strip()]
    return {
        "url": url,
        "addon": addon.name,
        "label": name.splitlines()[0] if name else addon.name,
        "quality": quality, "rank": rank, "tags": tags,
        "size": _size_text(stream, text),
        "cached": cached,
        "lines": lines[:3],
        "filename": hints.get("filename") or (lines[0] if lines else ""),
        "headers": headers if isinstance(headers, dict) else {},
    }


def _fetch_streams(addon, type_, id_):
    """One add-on's stream list. Waits longer than for catalogs (debrid
    add-ons check the debrid service before answering), tries twice, and
    never caches an empty answer so a slow first reply isn't remembered."""
    url = f"{addon.base}/stream/{type_}/{quote(id_, safe=':')}.json"
    with _cache_lock:
        hit = _cache.get(url)
        if hit and time.time() - hit[0] < 600:
            return hit[1]
    last = None
    for attempt in range(2):
        try:
            response = _session.get(url, timeout=45)
            if response.status_code >= 500 and attempt == 0:
                last = requests.HTTPError(f"HTTP {response.status_code}")
                continue
            response.raise_for_status()
            data = response.json()
            break
        except (requests.ConnectionError, requests.Timeout) as error:
            last = error
        except ValueError:
            raise ValueError("sent back something that isn't a stream list")
    else:
        raise last
    items = data.get("streams") if isinstance(data, dict) else None
    items = [x for x in items or [] if isinstance(x, dict)]
    if items:
        with _cache_lock:
            _cache[url] = (time.time(), items)
    return items


def _why_unplayable(items):
    """When an add-on answers but nothing is playable, its streams usually
    carry the reason (e.g. Debridio's "invalid API key" entry)."""
    for x in items:
        text = " ".join((x.get("name") or "", x.get("title") or x.get("description") or ""))
        text = " ".join(text.split())
        if text:
            return text[:120]
    return ""


def stream_sources(addons, type_, id_):
    """The add-ons that can give streams for this, in the user's order."""
    for addon in addons:
        if not addon.manifest.get("resources"):        # never fetched / broken copy
            try:
                addon.manifest = fetch_manifest(addon.url)
            except Exception:
                pass
    return [a for a in addons if a.supports("stream", type_, id_)]


def streams_from(addon, type_, id_):
    """One add-on's playable streams: (streams, problem or None)."""
    t = time.time()
    try:
        items = _fetch_streams(addon, type_, id_)
    except Exception as error:
        print(f"[streams] {addon.name}: {type_} {id_} failed after "
              f"{time.time() - t:.1f}s: {error!r}", file=sys.stderr, flush=True)
        return [], f"{addon.name} didn't respond ({error.__class__.__name__})"
    print(f"[streams] {addon.name}: {type_} {id_} -> {len(items)} in "
          f"{time.time() - t:.1f}s", file=sys.stderr, flush=True)
    mine = [d for d in (describe(addon, x) for x in items) if d]
    if not mine:
        why = _why_unplayable(items) if items else ""
        return [], f"{addon.name}: " + (f"\u201c{why}\u201d" if why else "no links for this")
    return mine, None


def streams(addons, type_, id_):
    """All playable streams for one film/episode from every stream add-on,
    fetched in parallel. Returns (streams, problems) — problems names any
    add-on that failed or had nothing, so the screen can say so instead of
    just looking empty."""
    for addon in addons:
        if not addon.manifest.get("resources"):        # never fetched / broken copy
            try:
                addon.manifest = fetch_manifest(addon.url)
            except Exception:
                pass
    sources = [a for a in addons if a.supports("stream", type_, id_)]
    if not sources:
        return [], ["No stream add-ons are installed for this."]

    def run(addon):
        t = time.time()
        try:
            items = _fetch_streams(addon, type_, id_)
        except Exception as error:
            print(f"[streams] {addon.name}: {type_} {id_} failed after "
                  f"{time.time() - t:.1f}s: {error!r}", file=sys.stderr, flush=True)
            return addon, None, f"{addon.name} didn't respond ({error.__class__.__name__})"
        print(f"[streams] {addon.name}: {type_} {id_} -> {len(items)} in "
              f"{time.time() - t:.1f}s", file=sys.stderr, flush=True)
        return addon, items, None

    found, problems = [], []
    with ThreadPoolExecutor(max_workers=6) as pool:
        for addon, items, problem in pool.map(run, sources):
            if problem:
                problems.append(problem)
                continue
            mine = [d for d in (describe(addon, x) for x in items) if d]
            found += mine
            if not mine:
                why = _why_unplayable(items) if items else ""
                problems.append(f"{addon.name}: " + (f"“{why}”" if why else "no links for this"))
    # Like Stremio: grouped by add-on in the user's add-on order, and each
    # add-on's own ordering left alone (Torrentio sorted by size, Debridio
    # by its own settings...). pool.map already returns in source order.
    return found, problems


# ══════════════════════════════════════════════════════════════════
# Subtitles
# ══════════════════════════════════════════════════════════════════
# Used when no installed add-on offers subtitles (Stremio's own default).
OPENSUBTITLES_URL = "https://opensubtitles-v3.strem.io/manifest.json"
_LANG_NAMES = {"eng": "English", "en": "English", "spa": "Spanish", "fre": "French",
               "ger": "German", "ita": "Italian", "por": "Portuguese", "pob": "Portuguese (BR)",
               "dut": "Dutch", "nld": "Dutch", "may": "Malay", "msa": "Malay", "ind": "Indonesian",
               "chi": "Chinese", "zho": "Chinese", "jpn": "Japanese", "kor": "Korean",
               "ara": "Arabic", "hin": "Hindi", "tha": "Thai", "vie": "Vietnamese",
               "rus": "Russian", "tur": "Turkish", "pol": "Polish", "swe": "Swedish"}


def _tokens(text):
    return {t for t in re.split(r"[^a-z0-9]+", (text or "").lower()) if len(t) > 1}


def subtitles(addons, type_, id_, filename="", languages=("eng", "en"), limit=12):
    """Subtitles for one film/episode from every add-on that has them (plus
    OpenSubtitles if none do): [{"url", "lang", "title", "addon"}], your
    languages first, and within them the ones whose release name best
    matches the file being played (so they're in sync)."""
    sources = [a for a in addons if a.supports("subtitles", type_, id_)]
    if not sources:
        sources = [Addon(OPENSUBTITLES_URL, {"id": "org.stremio.opensubtitlesv3",
                                             "name": "OpenSubtitles",
                                             "resources": ["subtitles"],
                                             "types": ["movie", "series"],
                                             "idPrefixes": ["tt"]})]
        if not sources[0].supports("subtitles", type_, id_):
            return []
    extra = f"/filename={quote(filename, safe='')}" if filename else ""

    def run(addon):
        try:
            data = _get_json(f"{addon.base}/subtitles/{type_}/{quote(id_, safe=':')}{extra}.json",
                             ttl=3600, timeout=12)
        except Exception:
            return addon, []
        items = data.get("subtitles") if isinstance(data, dict) else None
        return addon, [s for s in items or [] if isinstance(s, dict) and s.get("url")]

    want = _tokens(filename)
    found = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for addon, items in pool.map(run, sources):
            for s in items:
                lang = (s.get("lang") or "").lower()
                release = s.get("subtitleFileName") or s.get("movieReleaseName") or ""
                found.append({"url": s["url"], "lang": lang, "addon": addon.name,
                              "match": len(want & _tokens(release)), "release": release})
    langs = [l.lower() for l in languages]
    found.sort(key=lambda s: (s["lang"] not in langs, -s["match"]))
    out, per_lang = [], {}
    for s in found:
        n = per_lang.get(s["lang"], 0)
        if n >= (4 if s["lang"] in langs else 1):
            continue
        per_lang[s["lang"]] = n + 1
        name = _LANG_NAMES.get(s["lang"], s["lang"].upper() or "Subtitles")
        s["title"] = f"{name} · {s['addon']}" + (f" ({n + 1})" if n else "")
        out.append(s)
        if len(out) >= limit:
            break
    return out
