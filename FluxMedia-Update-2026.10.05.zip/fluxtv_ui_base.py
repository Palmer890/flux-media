"""
Flux Media (FluxTV) — shared building blocks: logo loading, background jobs, cards, grids, rows.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)


# ══════════════════════════════════════════════════════════════════
# Logos
# ══════════════════════════════════════════════════════════════════
class LogoSignals(QObject):
    done = Signal(tuple, QPixmap)


def _cover_fit(pix, w, h):
    """Scale to fill (w, h) and centre-crop the overflow.

    Used for posters, which should bleed to the edge of the tile rather
    than letterbox — unlike a channel logo, cropping a poster a little
    doesn't make it unrecognisable.
    """
    scaled = pix.scaled(w, h, Qt.KeepAspectRatioByExpanding,
                        Qt.SmoothTransformation)
    x = max(0, (scaled.width() - w) // 2)
    y = max(0, (scaled.height() - h) // 2)
    return scaled.copy(x, y, w, h)


def _render_svg(path, w, h, mode):
    """A vector logo drawn at exactly the size it's shown, so it stays
    sharp however big the screen (bitmaps would have to be scaled up)."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QImage
    from PySide6.QtSvg import QSvgRenderer
    renderer = QSvgRenderer(path)
    if not renderer.isValid():
        return None
    vb = renderer.viewBoxF()
    vw, vh = max(1.0, vb.width()), max(1.0, vb.height())
    scale = max(w / vw, h / vh) if mode == "cover" else min(w / vw, h / vh)
    dw, dh = vw * scale, vh * scale
    image = QImage(int(w) if mode == "cover" else max(1, int(dw)),
                   int(h) if mode == "cover" else max(1, int(dh)),
                   QImage.Format_ARGB32_Premultiplied)
    image.fill(Qt.transparent)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.Antialiasing)
    renderer.render(painter, QRectF((image.width() - dw) / 2, (image.height() - dh) / 2, dw, dh))
    painter.end()
    return QPixmap.fromImage(image)


class LogoJob(QRunnable):
    """Fetch and decode one logo off the GUI thread.

    Disk cache and byte fetching both come from the engine, so the
    provider-specific headers that are known to work are reused as-is.
    """

    def __init__(self, key, signals):
        super().__init__()
        self.key, self.signals = key, signals

    @Slot()
    def run(self):
        url, box, mode = self.key
        path = core.logo_cache_path(url)
        try:
            if not os.path.exists(path):
                data = core.fetch_logo_bytes(url)
                with open(path + ".tmp", "wb") as fh:
                    fh.write(data)
                os.replace(path + ".tmp", path)
            w, h = box
            with open(path, "rb") as fh:
                head = fh.read(2048)
            if core.is_svg(head):
                pix = _render_svg(path, w, h, mode)
                if pix is not None:
                    self.signals.done.emit(self.key, pix)
                return
            pix = QPixmap(path)
            if pix.isNull():
                return
            if mode == "cover":
                pix = _cover_fit(pix, w, h)
            else:
                # Contain, never stretch: channel logos come in every
                # aspect ratio and a squashed logo reads as broken.
                pix = pix.scaled(w, h, Qt.KeepAspectRatio,
                                 Qt.SmoothTransformation)
            self.signals.done.emit(self.key, pix)
        except Exception:
            return


class LogoStore(QObject):
    """One decode per (URL, box, mode), shared by every card that shows it.

    Callers key their own lookups by URL alone (a card only ever wants its
    one size/mode), but the store keeps the full key internally so a
    channel logo and a poster crop of the same URL never collide.
    """

    ready = Signal(str)   # URL, so a card can check "is mine ready now?"

    def __init__(self):
        super().__init__()
        self._cache: dict[tuple, QPixmap] = {}
        self._inflight: set[tuple] = set()
        self._signals = LogoSignals()
        self._signals.done.connect(self._store)
        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(6)   # bounded: a shelf must not open 60 sockets

    def get(self, url, box, mode="contain"):
        return self._cache.get((url, box, mode))

    def request(self, url, box, mode="contain", priority=0):
        """Queue a download. Higher priority jumps the queue — a detail
        page's backdrop and episode thumbnails mustn't wait behind the
        hundred-odd posters a Discover screen asks for."""
        key = (url, box, mode)
        if not url or key in self._cache or key in self._inflight:
            return
        self._inflight.add(key)
        self.pool.start(LogoJob(key, self._signals), priority)

    @Slot(tuple, QPixmap)
    def _store(self, key, pix):
        self._inflight.discard(key)
        self._cache[key] = pix
        self.ready.emit(key[0])

    def clear(self):
        self._cache.clear()


LOGOS = LogoStore()


def _hm(dt):
    """HH:MM in the viewer's local time. The guide is stored in UTC, and
    formatting it directly showed every time an hour early during
    British Summer Time (or off by the local offset anywhere else)."""
    return dt.astimezone().strftime("%H:%M")


def _now_next(lib, channel):
    """(programme on now, programme on next) for a channel, either None.

    _epg_listing() already decides current-vs-upcoming: with something on
    air it returns it first; in a gap between shows it returns just the
    next one.
    """
    try:
        listing = lib._epg_listing(channel)
    except Exception:
        return None, None
    if not listing:
        return None, None
    now = datetime.now(timezone.utc)
    first = listing[0]
    if first["start"] <= now < first["stop"]:
        return first, (listing[1] if len(listing) > 1 else None)
    return None, first


def _format_hms(seconds):
    """Seconds -> 'H:MM:SS' or 'M:SS', for a resume-position status line."""
    seconds = int(seconds or 0)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _english_stamp(when):
    """'03 Oct, 20:15' with an English month, whatever the system language."""
    dt = datetime.fromtimestamp(when)
    month = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
             "Nov", "Dec")[dt.month - 1]
    return f"{dt.day:02d} {month}, {dt:%H:%M}"


def html_escape(text):
    import html
    return html.escape(str(text or ""))


def logo_pixmap(size):
    """The full Flux Media logo (emblem and name), sharp on high-resolution
    screens; a null pixmap if the image isn't there."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fluxtv_logo.png")
    pix = QPixmap(path)
    if pix.isNull():
        return pix
    screen = QApplication.primaryScreen()
    ratio = max(1.0, screen.devicePixelRatio() if screen else 1.0)
    pix = pix.scaled(int(size * ratio), int(size * ratio), Qt.KeepAspectRatio,
                     Qt.SmoothTransformation)
    pix.setDevicePixelRatio(ratio)
    return pix


class ClockLabel(QWidget):
    """The time, big enough to read from the couch, with the day under it."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Clear")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.time_lbl = QLabel("", self)
        self.time_lbl.setFont(font(28, QFont.Bold))
        self.time_lbl.setStyleSheet(f"color: {C.paper}; background: transparent;")
        self.date_lbl = QLabel("", self)
        self.date_lbl.setObjectName("Muted")
        self.date_lbl.setStyleSheet("background: transparent;")
        lay.addWidget(self.time_lbl)
        lay.addWidget(self.date_lbl)
        self._shown = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._tick()

    def _tick(self):
        now = datetime.now()
        minute = (now.date(), now.hour, now.minute)
        if minute == self._shown:
            return
        self._shown = minute
        hour = now.hour % 12 or 12
        self.time_lbl.setText(f"{hour}:{now.minute:02d} {'am' if now.hour < 12 else 'pm'}")
        # English names, whatever language the computer is set to.
        day = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
               "Saturday", "Sunday")[now.weekday()]
        month = ("January", "February", "March", "April", "May", "June", "July",
                 "August", "September", "October", "November", "December")[now.month - 1]
        self.date_lbl.setText(f"{day} {now.day} {month}")


def monogram(name, limit=2):
    """Placeholder for a channel with no artwork.

    Broadcast names are mostly acronyms, so an acronym is kept whole —
    "BBC One HD" reads as BBC, not BO.
    """
    import re
    skip = {"hd", "sd", "fhd", "uhd", "4k", "8k", "raw", "the",
            "channel", "tv", "vip", "plus", "backup", "alt"}
    words = [w for w in re.split(r"[^0-9A-Za-z]+", name or "") if w]
    keep = [w for w in words if w.lower() not in skip] or words
    if not keep:
        return "\u2022"
    first = keep[0]
    if 2 <= len(first) <= 4 and first.isupper():
        return first
    if len(keep) == 1:
        return first[:limit].upper()
    return "".join(w[0] for w in keep[:limit]).upper()


# ══════════════════════════════════════════════════════════════════
# Background provider work
# ══════════════════════════════════════════════════════════════════
class Fetch(QRunnable):
    """Run an engine call off the GUI thread and hand the result back."""

    class Sig(QObject):
        done = Signal(object)
        failed = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self.sig = Fetch.Sig()

    @Slot()
    def run(self):
        try:
            self.sig.done.emit(self.fn())
        except Exception as error:
            self.sig.failed.emit(str(error))


POOL = QThreadPool()


# A job's signal object must stay alive until its queued "done"/"failed"
# event is actually delivered on the GUI thread. QThreadPool auto-deletes
# the QRunnable the instant run() returns (on the worker thread, before
# that delivery happens), and nothing else held a Python reference to it —
# background() only returned it, and most call sites discarded that
# return value. The result was a race: the signal usually arrived in time
# to fire, but wasn't guaranteed to. Keeping every in-flight job here
# until it reports in removes that race entirely, for every caller.
_INFLIGHT_JOBS: set = set()


def show_dialog(widget, show_fn):
    """Call a native Qt dialog function (QMessageBox.question,
    QFileDialog.getOpenFileName, etc.) safely even when the app's main
    window is in true fullscreen.

    A genuinely fullscreen top-level window and a separately-spawned
    native dialog is a combination some window managers don't stack
    reliably — the WM can keep reasserting the fullscreen window on top
    moments after the dialog appears, which looks exactly like "a window
    flashed and then disappeared" with no way to actually interact with
    it. Dropping out of true fullscreen first, showing the dialog, then
    returning afterward sidesteps that entirely: a modal dialog over an
    ordinary window is a far more universally-reliable case across
    window managers than one over a fullscreen window is. Maximized
    (not showNormal()) is used as the "not fullscreen" state so the
    window doesn't also visibly shrink to a small size for the moment
    the dialog is up, only to jump back a second later.

    `widget` is whatever widget is asking for the dialog (SettingsView,
    FluxTV itself, ...) — window() finds its actual top-level window
    regardless of which one that is. `show_fn` is a zero-argument
    callable that shows the dialog and returns its result, typically a
    lambda wrapping the real call, e.g.
    show_dialog(self, lambda: QMessageBox.question(self, "Title", "Text")).
    """
    window = widget.window()
    was_fullscreen = window.isFullScreen()
    if was_fullscreen:
        window.showMaximized()
        # A single processEvents() only runs whatever's ALREADY queued —
        # it doesn't wait for the window manager to actually finish
        # applying the geometry change, which happens asynchronously
        # over X11. A dialog spawned before that settles can hit the
        # exact same kind of stacking problem this function exists to
        # avoid, just one step removed. Pumping several times with a
        # short real-time pause between each gives the WM genuine wall-
        # clock time to catch up before anything else is shown.
        for _ in range(10):
            QApplication.processEvents()
            time.sleep(0.02)
    try:
        return show_fn()
    finally:
        if was_fullscreen:
            window.showFullScreen()
            for _ in range(5):
                QApplication.processEvents()


def background(fn, on_done, on_fail=None):
    job = Fetch(fn)
    _INFLIGHT_JOBS.add(job)

    def _release(*_args):
        _INFLIGHT_JOBS.discard(job)

    job.sig.done.connect(on_done)
    job.sig.done.connect(_release)
    if on_fail:
        job.sig.failed.connect(on_fail)
    job.sig.failed.connect(_release)
    POOL.start(job)
    return job


# ══════════════════════════════════════════════════════════════════
# MPV playback control (position tracking, resume, and live commands)
# ══════════════════════════════════════════════════════════════════
def mpv_ipc_query(socket_path, properties, timeout=0.4):
    """Best-effort query of MPV JSON-IPC properties over a Unix socket.

    Returns {property: value} for whichever properties answered, or None
    if the socket isn't reachable at all (MPV still starting up, this
    platform doesn't support IPC sockets, or anything else went wrong).
    This is deliberately fire-and-forget: resume tracking is a bonus
    layered on top of playback, and must never be able to affect it.
    """
    if not socket_path or not hasattr(socket, "AF_UNIX"):
        return None
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect(socket_path)
    except OSError:
        return None
    try:
        for i, prop in enumerate(properties):
            request = json.dumps({"command": ["get_property", prop],
                                  "request_id": i}) + "\n"
            sock.sendall(request.encode("utf-8"))
        result: dict = {}
        buf = b""
        deadline = time.time() + timeout
        while len(result) < len(properties) and time.time() < deadline:
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                if not line.strip():
                    continue
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                rid = msg.get("request_id")
                if (rid is not None and msg.get("error") == "success"
                        and 0 <= rid < len(properties)):
                    result[properties[rid]] = msg.get("data")
        return result or None
    except OSError:
        return None
    finally:
        try:
            sock.close()
        except OSError:
            pass


def _cleanup_temp_file(path):
    """Remove a per-session temp file created for one MPV launch — the
    IPC socket from --input-ipc-server, or the small custom input.conf
    from --input-conf — once that MPV process is done with it.

    Each playback session gets a fresh, uniquely-named path for each of
    these (fluxtv-mpv-<uuid>.sock / .conf) — nothing ever reuses or
    overwrites an old one, so if this is skipped, the leftovers just
    accumulate in /tmp for as long as the app keeps running and
    switching channels. Best-effort: the file may already be gone, or
    may never have been created at all if MPV failed to start, either
    of which is fine to just ignore.
    """
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass


def _clear_native_window_black(win_id):
    """Paint a native X11 window solid black directly at the X11 level,
    bypassing Qt's own paint system entirely.

    VideoSurface carries WA_PaintOnScreen and a disabled paint engine —
    Qt is deliberately told never to paint that widget itself, since MPV
    draws into it directly. That almost certainly means its own
    "background: black" stylesheet never actually reaches this native
    window at all. There's a real gap — between one MPV process's
    window content going away and the next one rendering its first
    frame — where nothing at the Qt level is telling the window what
    colour to be, and hiding/showing the Qt widget around it (tried
    twice already) never touched that, because Qt was never the one
    painting it in the first place. Whatever showed through during that
    gap by default was apparently not black (reported as a purple
    flash — consistent with some other inherited default rather than
    an intentional colour). This calls into libX11 directly to force
    the window to solid black and clear it immediately, independent of
    Qt, MPV, or timing — the window is black the instant this returns,
    regardless of which process does or doesn't currently own it.

    Best-effort only: silently skipped on any failure (missing libX11,
    unexpected platform, closed display). This is a cosmetic fix, never
    something allowed to interrupt actual playback if it doesn't work.
    """
    try:
        import ctypes
        xlib = ctypes.CDLL("libX11.so.6")
        xlib.XOpenDisplay.restype = ctypes.c_void_p
        xlib.XOpenDisplay.argtypes = [ctypes.c_char_p]
        display = xlib.XOpenDisplay(None)
        if not display:
            return
        try:
            d = ctypes.c_void_p(display)
            w = ctypes.c_ulong(win_id)
            xlib.XSetWindowBackground(d, w, ctypes.c_ulong(0))
            xlib.XClearWindow(d, w)
            xlib.XFlush(d)
        finally:
            xlib.XCloseDisplay(ctypes.c_void_p(display))
    except Exception:
        pass


def _write_click_input_conf():
    """A minimal, single-purpose input.conf for one MPV launch: just
    MBTN_LEFT toggling pause.

    --no-input-default-bindings wipes MPV's own hardcoded bindings
    entirely (needed so it stops intercepting keyboard input meant for
    Qt), but a custom --input-conf still applies normally on top of
    that — it's the documented way to end up with exactly the bindings
    you want instead of all-or-nothing. This deliberately doesn't bind
    MBTN_LEFT_DBL: MPV treats a double-click as a distinct event from
    two single clicks, so leaving it unbound here means a double-click
    triggers no pause-toggle at all, leaving fullscreen (handled at the
    Qt level) as the only thing responding to it.

    Routing the click through MPV itself like this — rather than
    through Qt's own mouse events on the embedded video widget — sits
    on the same IPC channel already proven reliable for every other
    piece of state (PlaybackTracker polls "pause" over exactly this
    socket already), instead of depending on whether a raw click on a
    natively-embedded foreign window even reaches Qt's event handlers,
    which is a much less certain path.
    """
    path = os.path.join(tempfile.gettempdir(),
                        f"fluxtv-mpv-{uuid.uuid4().hex}.conf")
    try:
        with open(path, "w") as fh:
            fh.write("MBTN_LEFT cycle pause\n")
        return path
    except OSError:
        return None


def mpv_ipc_command(socket_path, command, timeout=0.4):
    """Fire an MPV command over IPC — e.g. ["cycle", "pause"],
    ["seek", 30, "absolute"], ["set_property", "volume", 80].

    A discrete user action (button click, seek-bar release) each gets
    its own short-lived connect/send/disconnect rather than sharing one
    persistent socket — simple, and the latency of one extra TCP-like
    handshake over a local Unix socket is well under what a person can
    perceive from a button press. Best-effort like mpv_ipc_query: a
    failure here is silent, never surfaced as an error to the person,
    since playback itself keeps running regardless of whether the
    control channel is reachable.
    """
    if not socket_path or not hasattr(socket, "AF_UNIX"):
        return False
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect(socket_path)
        sock.sendall((json.dumps({"command": command}) + "\n").encode("utf-8"))
        return True
    except OSError:
        return False
    finally:
        try:
            sock.close()
        except OSError:
            pass


class VideoSurface(QWidget):
    """A plain black surface for MPV to render into via --wid=.

    Qt aggressively avoids allocating a real native (OS-level) window
    per widget as a performance optimisation — most child widgets just
    share their parent's window and get composited in software. MPV's
    --wid embedding needs an actual native window handle to draw into,
    so WA_NativeWindow forces Qt to create one here specifically.
    WA_PaintOnScreen and a null paint engine tell Qt's own paint system
    to leave this widget alone entirely, since MPV is drawing into it
    directly at the OS level, outside Qt's compositing — if Qt tried to
    paint here too, the two would fight over the same pixels.

    X11 only. Wayland has no equivalent mechanism for embedding an
    arbitrary external process's window this way — callers must check
    for that themselves (see is_window_embedding_supported()) and fall
    back to MPV's own top-level window there instead.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_NativeWindow, True)
        self.setAttribute(Qt.WA_PaintOnScreen, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)
        self.setStyleSheet("background: black;")
        self.setMouseTracking(True)
        # A widget with WA_NativeWindow renders as its own OS-level
        # window; mouse events over it don't reliably bubble up through
        # Qt's normal parent-widget event propagation the way they do
        # for ordinary composited children. Rather than depend on that
        # bubbling (which is what silently broke "move the mouse to
        # bring the controls back"), PlayerView hands this a direct
        # callback and this calls it itself on any pointer activity.
        self.activity_callback = None
        # Matches the real Stremio player: click the video to toggle
        # play/pause, double-click to toggle fullscreen. Qt always sends
        # a single press/release before a double-click's own event, so
        # naively wiring both directly would toggle play/pause once on
        # every double-click too, right before the fullscreen toggle —
        # a single-click action has to wait out Qt's own double-click
        # window before it's safe to treat as a genuine single click.
        self.click_callback = None
        self.dblclick_callback = None
        self._click_pending = QTimer(self)
        self._click_pending.setSingleShot(True)
        self._click_pending.setInterval(QApplication.doubleClickInterval())
        self._click_pending.timeout.connect(self._fire_pending_click)

    def _fire_pending_click(self):
        if self.click_callback:
            self.click_callback()

    def paintEngine(self):
        # None tells Qt not to use its own raster/GL paint engine on this
        # widget at all — required alongside WA_PaintOnScreen for a
        # foreign-rendered surface; without it Qt's software paint path
        # can warn or assert when something tries to paint here.
        return None

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if self.activity_callback:
            self.activity_callback()

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if self.activity_callback:
            self.activity_callback()
        if event.button() == Qt.LeftButton and self.click_callback:
            # Defer the actual toggle until we know a second click isn't
            # about to arrive and promote this to a double-click instead.
            self._click_pending.start()

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        if event.button() == Qt.LeftButton:
            self._click_pending.stop()
            if self.dblclick_callback:
                self.dblclick_callback()

    def enterEvent(self, event):
        super().enterEvent(event)
        if self.activity_callback:
            self.activity_callback()


def is_window_embedding_supported():
    """Whether embedding MPV's video into one of our own widgets via
    --wid is expected to work on this session.

    True only for X11 (including XWayland-backed X11 sessions reported
    as such). Wayland native sessions have no equivalent to X11's
    reparenting-based window embedding, so --wid silently does nothing
    useful there — better to detect that up front and fall back to
    MPV's own window than to show a black box with no video and no
    explanation.
    """
    if platform.system() != "Linux":
        return False
    session_type = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if session_type == "wayland":
        return False
    if os.environ.get("WAYLAND_DISPLAY") and not os.environ.get("DISPLAY"):
        return False
    return True


class PlaybackTracker(QObject):
    """Polls MPV's IPC socket for playback state — position/duration for
    resume-watching, plus pause/volume/mute for the in-app player's
    on-screen controls to reflect reality (including changes made via
    MPV's own keyboard shortcuts inside the video area, not just our
    buttons).

    Best-effort only: if the socket never becomes reachable, this simply
    never emits — the caller sees no error, playback is unaffected, the
    title just won't offer to resume later and the on-screen controls
    won't animate, but nothing breaks.
    """

    progress = Signal(float, float)         # position, duration (seconds)
    state = Signal(bool, int, bool)         # paused, volume (0-100), muted

    def __init__(self, socket_path, parent=None, interval_ms=10_000):
        super().__init__(parent)
        self.socket_path = socket_path
        self.timer = QTimer(self)
        self.timer.setInterval(interval_ms)
        self.timer.timeout.connect(self._poll)

    def set_interval(self, interval_ms):
        self.timer.setInterval(interval_ms)

    def start(self):
        self.timer.start()

    def stop(self):
        self.timer.stop()

    def _poll(self):
        data = mpv_ipc_query(self.socket_path,
                             ["time-pos", "duration", "pause", "volume", "mute"])
        if not data:
            return
        pos, dur = data.get("time-pos"), data.get("duration")
        if isinstance(pos, (int, float)) and isinstance(dur, (int, float)) \
                and dur > 0:
            self.progress.emit(float(pos), float(dur))
        paused, volume, muted = data.get("pause"), data.get("volume"), data.get("mute")
        if isinstance(paused, bool) and isinstance(volume, (int, float)):
            self.state.emit(paused, int(volume), bool(muted))


# ══════════════════════════════════════════════════════════════════
# Channel card
# ══════════════════════════════════════════════════════════════════
class IconButton(QPushButton):
    """A flat button that draws its own simple vector icon instead of
    relying on a Unicode text glyph.

    Play/pause and volume/mute specifically sit in Unicode's pictograph
    ranges, which on most systems render as small, muddy, full-colour
    emoji rather than a clean monochrome glyph — illegible at the sizes
    a control bar actually uses them at. Stremio and virtually every
    other real media player sidestep this entirely by shipping their
    own icon font/asset set rather than trusting a text character to
    render consistently; drawing the shape directly here gets the same
    guaranteed crispness without needing to bundle a font.
    """

    def __init__(self, kind, parent=None, color=C.paper, hover_color=C.cyan_hi):
        super().__init__("", parent)
        self.kind = kind
        self._color = QColor(color)
        self._hover_color = QColor(hover_color)
        self._hovered = False

    def set_kind(self, kind):
        if kind != self.kind:
            self.kind = kind
            self.update()

    def enterEvent(self, event):
        super().enterEvent(event)
        self._hovered = True
        self.update()

    def leaveEvent(self, event):
        super().leaveEvent(event)
        self._hovered = False
        self.update()

    def paintEvent(self, event):
        super().paintEvent(event)  # background/hover fill from QSS
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        color = self._hover_color if (self._hovered and self.isEnabled()) else self._color
        painter.setPen(Qt.NoPen)
        painter.setBrush(color)

        w, h = self.width(), self.height()
        s = min(w, h) * 0.34   # icon half-size — leaves a comfortable margin
        cx, cy = w / 2, h / 2

        if self.kind == "play":
            path = QPainterPath()
            path.moveTo(cx - s * 0.7, cy - s)
            path.lineTo(cx - s * 0.7, cy + s)
            path.lineTo(cx + s, cy)
            path.closeSubpath()
            painter.drawPath(path)

        elif self.kind == "pause":
            bar_w = s * 0.55
            gap = s * 0.35
            painter.drawRoundedRect(QRectF(cx - gap - bar_w, cy - s, bar_w, 2 * s), 1, 1)
            painter.drawRoundedRect(QRectF(cx + gap, cy - s, bar_w, 2 * s), 1, 1)

        elif self.kind in ("volume", "mute"):
            # Speaker body: a small rectangle plus a trapezoid "horn",
            # exactly the familiar speaker silhouette.
            body_w, body_h = s * 0.5, s * 0.7
            path = QPainterPath()
            path.moveTo(cx - s * 0.95, cy - body_h / 2)
            path.lineTo(cx - s * 0.95 + body_w, cy - body_h / 2)
            path.lineTo(cx - s * 0.95 + body_w, cy + body_h / 2)
            path.lineTo(cx - s * 0.95, cy + body_h / 2)
            path.closeSubpath()
            painter.drawPath(path)
            horn = QPainterPath()
            hx = cx - s * 0.95 + body_w
            horn.moveTo(hx, cy - body_h / 2)
            horn.lineTo(hx + s * 0.5, cy - s)
            horn.lineTo(hx + s * 0.5, cy + s)
            horn.lineTo(hx, cy + body_h / 2)
            horn.closeSubpath()
            painter.drawPath(horn)
            pen_w = max(1.4, s * 0.16)
            if self.kind == "mute":
                pen = QPen(color)
                pen.setWidthF(pen_w)
                pen.setCapStyle(Qt.RoundCap)
                painter.setPen(pen)
                x0, y0 = hx + s * 0.65, cy - s * 0.55
                x1, y1 = hx + s * 1.15, cy + s * 0.55
                painter.drawLine(QPointF(x0, y0), QPointF(x1, y1))
                painter.drawLine(QPointF(x0, y1), QPointF(x1, y0))
            else:
                pen = QPen(color)
                pen.setWidthF(pen_w)
                pen.setCapStyle(Qt.RoundCap)
                painter.setBrush(Qt.NoBrush)
                for i, r in enumerate((s * 0.55, s * 0.95)):
                    painter.setPen(pen)
                    arc_rect = QRectF(hx + s * 0.15 - r, cy - r, 2 * r, 2 * r)
                    painter.drawArc(arc_rect, -40 * 16, 80 * 16)
        painter.end()


def _arrow_direction(event):
    """Map an arrow key press to 'left'/'right'/'up'/'down', or None."""
    return {
        Qt.Key_Left: "left", Qt.Key_Right: "right",
        Qt.Key_Up: "up", Qt.Key_Down: "down",
    }.get(event.key())


class _RingFollower(QObject):
    """Keeps a card's hover ring glued to its artwork tile.

    The ring used to be sized once, when it was shown. Coming back from
    the player, the focused card gets its ring back while the page is
    still being laid out, so it took a half-finished size and kept it
    until the next hover. Following every move/resize of the tile fixes
    that for good, whatever order layout happens in.
    """

    def __init__(self, well, ring):
        super().__init__(well)
        self.well = well
        self.ring = ring
        well.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Move, QEvent.Show):
            self.ring.setGeometry(self.well.geometry())
        return False


def _set_hot(well, state):
    """Hover/focus ring around a card's artwork tile.

    Drawn as a separate transparent frame laid over the tile rather than
    as the tile's own border, so the artwork can fill the tile edge to
    edge and the ring still sits on top of it (and of the hover overlay).
    """
    ring = getattr(well, "_hot_ring", None)
    if state:
        if ring is None:
            ring = QFrame(well.parentWidget())
            ring.setObjectName("HotRing")
            ring.setAttribute(Qt.WA_TransparentForMouseEvents)
            well._hot_ring = ring
            well._ring_follower = _RingFollower(well, ring)
        ring.setGeometry(well.geometry())
        ring.show()
        ring.raise_()
    elif ring is not None:
        ring.hide()


def _rounded(pix, radius=10):
    """Clip a pixmap to rounded corners so artwork matches its tile."""
    if pix is None or pix.isNull():
        return pix
    out = QPixmap(pix.size())
    out.setDevicePixelRatio(pix.devicePixelRatio())
    out.fill(Qt.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing)
    path = QPainterPath()
    ratio = pix.devicePixelRatio() or 1
    path.addRoundedRect(QRectF(0, 0, pix.width() / ratio, pix.height() / ratio),
                        radius, radius)
    p.setClipPath(path)
    p.drawPixmap(0, 0, pix)
    p.end()
    return out


class ChannelCard(QFrame):
    """A channel tile: logo, on-air state, now and next, EPG progress.

    Focus reveals the actions rather than showing a Watch button on every
    tile — the brief's focused-card model, and it keeps the resting grid
    quiet.
    """

    activated = Signal(object)
    selected = Signal(object)
    fav_toggled = Signal(object)

    def __init__(self, channel, library, parent=None):
        super().__init__(parent)
        self.channel = channel
        self.lib = library
        self.setObjectName("Card")
        self.setFixedSize(CARD_W, CARD_H)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setCursor(Qt.PointingHandCursor)
        self.setProperty("selected", False)
        # Set by whichever Shelf or LazyGrid actually built this card —
        # arrow-key navigation asks that container what's next in a given
        # direction rather than this card trying to work it out from its
        # own position in a layout it doesn't otherwise know the shape of.
        self._nav_container = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── well ─────────────────────────────────────────────────
        self.well = QFrame(self)
        self.well.setObjectName("CardWell")
        self.well.setFixedHeight(WELL_H)
        well_lay = QVBoxLayout(self.well)
        well_lay.setContentsMargins(12, 10, 12, 10)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        self.onair = QLabel("\u25cf  On air", self.well)
        self.onair.setObjectName("OnAir")
        self.onair.hide()
        top.addWidget(self.onair, 0, Qt.AlignTop | Qt.AlignLeft)
        top.addStretch(1)
        self.star = QPushButton("", self.well)
        self.star.setObjectName("Star")
        self.star.setFixedSize(24, 24)
        self.star.setCursor(Qt.PointingHandCursor)
        self.star.setFocusPolicy(Qt.NoFocus)
        self.star.clicked.connect(lambda: self.fav_toggled.emit(self.channel))
        top.addWidget(self.star, 0, Qt.AlignTop | Qt.AlignRight)
        well_lay.addLayout(top)

        self.art = QLabel(self.well)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setText(monogram(channel.get("name", "")))
        well_lay.addWidget(self.art, 1)
        root.addWidget(self.well)

        # ── text block ───────────────────────────────────────────
        body = QVBoxLayout()
        body.setContentsMargins(4, 10, 4, 8)
        body.setSpacing(3)
        self.title = QLabel(self)
        self.title.setObjectName("CardTitle")
        self.title.setWordWrap(False)
        body.addWidget(self.title)

        now_row = QHBoxLayout()
        now_row.setContentsMargins(0, 0, 0, 0)
        now_row.setSpacing(7)
        self.now_time = QLabel("", self)
        self.now_time.setObjectName("CardTime")
        self.now_prog = QLabel("", self)
        self.now_prog.setObjectName("CardNow")
        now_row.addWidget(self.now_time)
        now_row.addWidget(self.now_prog, 1)
        body.addLayout(now_row)

        self.progress = QProgressBar(self)
        self.progress.setObjectName("Epg")
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        body.addWidget(self.progress)

        self.next_prog = QLabel("", self)
        self.next_prog.setObjectName("CardNext")
        body.addWidget(self.next_prog)
        body.addStretch(1)
        root.addLayout(body)

        # ── focus overlay ────────────────────────────────────────
        self.overlay = QFrame(self)
        self.overlay.setObjectName("Overlay")
        self.overlay.setGeometry(0, 0, CARD_W, WELL_H)
        ov = QVBoxLayout(self.overlay)
        ov.setContentsMargins(16, 16, 16, 16)
        ov.setSpacing(8)
        ov.addStretch(1)
        watch = QPushButton("\u25b6  Watch now", self.overlay)
        watch.setObjectName("Primary")
        watch.setCursor(Qt.PointingHandCursor)
        watch.setFocusPolicy(Qt.NoFocus)
        watch.clicked.connect(lambda: self.activated.emit(self.channel))
        ov.addWidget(watch)
        self.list_btn = QPushButton("", self.overlay)
        self.list_btn.setObjectName("Ghost")
        self.list_btn.setCursor(Qt.PointingHandCursor)
        self.list_btn.setFocusPolicy(Qt.NoFocus)
        self.list_btn.clicked.connect(lambda: self.fav_toggled.emit(self.channel))
        ov.addWidget(self.list_btn)
        ov.addStretch(1)
        self.overlay.hide()

        self.refresh()
        LOGOS.ready.connect(self._logo_ready)
        self._want_logo()

    # ── data ─────────────────────────────────────────────────────
    @staticmethod
    def _set_elided(label, text, width):
        """Truncate with an ellipsis rather than let a long channel or
        programme name silently overflow the label's box — the bigger
        EPG text made this a real, visible risk (a longer name that
        used to just barely fit no longer does), where before it was
        mostly hidden by how much smaller the text was. The full text
        still goes in the tooltip so nothing is actually lost, just not
        all shown at once.

        ensurePolished() matters here: this can run as early as the end
        of __init__, before the card has been added to a parent or
        shown — and a stylesheet's font-size isn't actually resolved on
        a label until Qt polishes it, which normally only happens once
        it's part of a shown widget tree. Measuring against fontMetrics()
        before that point silently uses a smaller, unstyled fallback
        font, under-measuring the text and wrongly concluding a name
        that doesn't actually fit already does. ensurePolished() forces
        that resolution immediately, so the measurement is correct
        regardless of when this happens to be called.
        """
        label.ensurePolished()
        elided = label.fontMetrics().elidedText(text, Qt.ElideRight, width)
        label.setText(elided)
        label.setToolTip(text if elided != text else "")

    def refresh(self):
        # Elided here rather than once at construction: at __init__ time
        # this widget hasn't been added to a shown parent yet, so the
        # stylesheet's font-size hasn't actually been resolved — sizing
        # against that too-early, still-default font silently under-
        # measured longer names, concluding they already fit when they
        # didn't. refresh() always runs after the card is live in the
        # grid, where fontMetrics() reflects the real, styled font.
        self._set_elided(self.title, self.channel.get("name", "Unknown"), CARD_W - 26)

        fav = self.lib._is_fav(self.channel)
        self.star.setText("\u2605" if fav else "\u2606")
        self.star.setProperty("on", fav)
        self.star.style().unpolish(self.star)
        self.star.style().polish(self.star)
        self.list_btn.setText("\u2713  In my list" if fav else "+  My list")

        current, nxt = self._epg_window()
        if current:
            self.now_time.setText(_hm(current["start"]))
            self.now_time.ensurePolished()
            now_width = CARD_W - 26 - self.now_time.sizeHint().width() - 7
            self._set_elided(self.now_prog, current["title"], now_width)
            self.progress.setValue(self._pct(current))
            self.progress.show()
        elif nxt:
            # Nothing airing right now (a gap between shows) — still
            # worth showing what's coming up, just without a progress
            # bar that would make no sense for something unstarted.
            self.now_time.setText("")
            self.now_prog.setText("Nothing airing now")
            self.now_prog.setToolTip("")
            self.progress.hide()
        else:
            self.now_time.setText("")
            now_width = CARD_W - 26
            self._set_elided(self.now_prog, self.lib._programme_text(self.channel), now_width)
            self.progress.hide()

        if nxt:
            next_text = f"Next  {_hm(nxt['start'])}  {nxt['title']}"
            self._set_elided(self.next_prog, next_text, CARD_W - 26)
        else:
            self.next_prog.setText("")
            self.next_prog.setToolTip("")

    def _epg_window(self):
        """(current, next) programmes, via the engine's own matcher.

        _epg_listing() already decides current-vs-upcoming: when
        something is airing now it returns up to two "current" entries;
        when nothing is airing (a gap between shows — common) it returns
        exactly one future entry instead. Re-testing "does this entry's
        start/stop bracket now" here would fail for that second case by
        definition (it hasn't started), which used to make every gap
        silently discard perfectly good "next up" data. Trust what the
        engine already decided instead of re-deriving it.
        """
        try:
            listing = self.lib._epg_listing(self.channel)
        except Exception:
            return None, None
        if not listing:
            return None, None
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        first = listing[0]
        if first["start"] <= now < first["stop"]:
            following = listing[1] if len(listing) > 1 else None
            return first, following
        # First entry hasn't started yet -> it's the "upcoming" case.
        return None, first

    @staticmethod
    def _pct(item):
        from datetime import datetime, timezone
        try:
            span = (item["stop"] - item["start"]).total_seconds()
            gone = (datetime.now(timezone.utc) - item["start"]).total_seconds()
            return max(0, min(100, int(gone / span * 100)))
        except Exception:
            return 0

    def set_selected(self, state):
        self.setProperty("selected", bool(state))
        self.style().unpolish(self)
        self.style().polish(self)

    def set_on_air(self, state):
        self.onair.setVisible(bool(state))

    # ── artwork ──────────────────────────────────────────────────
    def _want_logo(self):
        if not self.lib.settings.get("show_logos", True):
            return
        url = self.channel.get("stream_icon", "")
        if not url:
            return
        self._logo_box = (CARD_W - 60, WELL_H - 52)
        pix = LOGOS.get(url, self._logo_box)
        if pix:
            self._apply(pix)
        else:
            LOGOS.request(url, self._logo_box)

    @Slot(str)
    def _logo_ready(self, url):
        if url == self.channel.get("stream_icon", ""):
            pix = LOGOS.get(url, self._logo_box)
            if pix:
                self._apply(pix)

    def _apply(self, pix):
        self.art.setPixmap(pix)
        self.art.setText("")

    # ── input ────────────────────────────────────────────────────
    def focusInEvent(self, event):
        super().focusInEvent(event)
        _set_hot(self.well, True)
        self.overlay.show()
        self.selected.emit(self.channel)

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        _set_hot(self.well, self.underMouse())
        self.overlay.hide()

    def enterEvent(self, event):
        super().enterEvent(event)
        _set_hot(self.well, True)
        self.overlay.show()

    def leaveEvent(self, event):
        super().leaveEvent(event)
        if not self.hasFocus():
            _set_hot(self.well, False)
            self.overlay.hide()

    def mousePressEvent(self, event):
        self.setFocus(Qt.MouseFocusReason)
        self.selected.emit(self.channel)

    def mouseDoubleClickEvent(self, event):
        self.activated.emit(self.channel)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.activated.emit(self.channel)
            return
        if event.key() == Qt.Key_F:
            self.fav_toggled.emit(self.channel)
            return
        direction = _arrow_direction(event)
        if direction and self._nav_container is not None:
            target = self._nav_container.nav_neighbor(self, direction)
            if target is not None:
                target.setFocus(Qt.OtherFocusReason)
                return
            edge_cb = getattr(self._nav_container, "nav_edge_cb", None)
            if edge_cb:
                edge_cb(self, direction)
                return
        super().keyPressEvent(event)


def cols_for_width(width, card_w=CARD_W, gap=16):
    """Column count for a grid, from a target tile width.

    Fixed breakpoints leave a dead gutter on wide windows because the tile
    width is also clamped; deriving columns from width keeps a row full.
    """
    return max(2, min(8, width // (card_w + gap)))


# ══════════════════════════════════════════════════════════════════
# Category / genre filter chip
# ══════════════════════════════════════════════════════════════════
class CategoryFilter(QPushButton):
    """A chip that opens a menu of categories and reports the selection.

    Used identically for Live TV categories and Movies/Series genres —
    both are just a list of {category_id, category_name} from the engine.
    """

    changed = Signal(object, str)   # category_id or None, label

    def __init__(self, all_label="All categories", parent=None):
        super().__init__(f"{all_label}  \u25be", parent)
        self.setObjectName("Ghost")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.all_label = all_label
        self.categories = []
        self.clicked.connect(self._open_menu)

    def set_categories(self, categories):
        self.categories = categories or []
        self.setVisible(bool(self.categories))

    def _open_menu(self):
        menu = QMenu(self)
        all_action = menu.addAction(self.all_label)
        all_action.triggered.connect(lambda: self._pick(None, self.all_label))
        if self.categories:
            menu.addSeparator()
        for cat in self.categories:
            cid = str(cat.get("category_id", ""))
            name = cat.get("category_name", "Unknown")[:50]
            action = menu.addAction(name)
            action.triggered.connect(partial(self._pick, cid, name))
        menu.exec(self.mapToGlobal(QPoint(0, self.height())))

    def _pick(self, cid, name):
        self.setText(f"{name}  \u25be")
        self.changed.emit(cid, name)


class LazyGrid(QScrollArea):
    """A vertically scrolling grid that builds tiles in batches.

    A provider library can run into the thousands, so building every tile
    up front is the freeze this exists to avoid: tiles are created only as
    the grid is scrolled into view, the same trade-off the original
    Tkinter build made with its own lazy renderer.
    """

    BATCH = 30

    def __init__(self, make_card, card_w=CARD_W, gap=16, parent=None):
        super().__init__(parent)
        self.make_card = make_card
        self.card_w = card_w
        self.gap = gap
        self.items = []
        self.cards = []
        self._built = 0
        self._cols = 4

        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.holder = QWidget()
        self.grid = QGridLayout(self.holder)
        self.grid.setContentsMargins(2, 2, 2, 24)
        self.grid.setSpacing(gap)
        # A short list (a handful of favourites) sits at the top of the
        # page rather than floating in the middle of it.
        self.grid.setAlignment(Qt.AlignTop)
        self.setWidget(self.holder)

        self.empty_label = QLabel("", self.holder)
        self.empty_label.setObjectName("Muted")
        self.empty_label.setWordWrap(True)
        self.empty_label.hide()

        self.verticalScrollBar().valueChanged.connect(self._maybe_more)

    def set_items(self, items, empty_text=""):
        for card in self.cards:
            card.setParent(None)
            card.deleteLater()
        self.cards.clear()
        self.items = list(items)
        self._built = 0
        self._cols = self._cols_for_current_width()

        if not self.items:
            self.empty_label.setText(empty_text or "Nothing to show.")
            self.empty_label.show()
            return
        self.empty_label.hide()
        self._build_batch()

    def _cols_for_current_width(self):
        # A page in a QStackedWidget that has never been the current widget
        # reports a tiny placeholder viewport width (it hasn't been through
        # a layout pass yet) — fall back to the window's width so the first
        # build doesn't lock in a too-small column count. resizeEvent
        # corrects this for real once the page is actually shown.
        width = self.viewport().width()
        if width < self.card_w + self.gap:
            top = self.window()
            width = top.width() - 260 if top else width
        return cols_for_width(width, self.card_w, self.gap)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.items:
            return
        new_cols = cols_for_width(event.size().width() - 14,
                                  self.card_w, self.gap)
        if new_cols != self._cols and new_cols >= 1:
            self._relayout(new_cols)

    def _relayout(self, new_cols):
        """Reposition already-built cards for a new column count, without
        recreating them — used both for the first real layout pass and for
        the window being resized afterward."""
        self._cols = new_cols
        for card in self.cards:
            self.grid.removeWidget(card)
        for i, card in enumerate(self.cards):
            self.grid.addWidget(card, i // new_cols, i % new_cols)
        self._settle()

    def _settle(self):
        """Apply the grid's layout now and repaint.

        Cards added while the grid is hidden (Series fills it behind its
        "Loading…" state) were laid out against a stale, too-short holder
        the moment it was shown, so rows drew on top of each other, and
        the corrected layout that followed didn't repaint what was
        already on screen. Forcing the layout, telling the scroll area
        its content changed size, and repainting closes that gap.
        """
        self.grid.invalidate()
        self.grid.activate()
        # The scroll area was sizing the holder to the viewport's height
        # rather than to what the rows need, squeezing them on top of each
        # other. An explicit minimum height is something it always honours.
        self.holder.setMinimumHeight(self.grid.totalMinimumSize().height())
        self.viewport().update()

    def showEvent(self, event):
        super().showEvent(event)
        # Now, before the first paint, and once more after the rest of the
        # page has finished its own show/resize pass.
        self._settle()
        QTimer.singleShot(0, self._settle)

    def _build_batch(self):
        end = min(self._built + self.BATCH, len(self.items))
        for i in range(self._built, end):
            card = self.make_card(self.items[i])
            card._nav_container = self
            self.grid.addWidget(card, i // self._cols, i % self._cols)
            # Qt would otherwise only show it on the next event-loop pass,
            # and a still-hidden card doesn't count towards the layout's
            # size — which is what left the rows squeezed together.
            card.show()
            self.cards.append(card)
        self._built = end
        self._settle()

    def _maybe_more(self, value):
        bar = self.verticalScrollBar()
        if bar.maximum() and value > bar.maximum() * 0.75:
            if self._built < len(self.items):
                self._build_batch()

    def refresh_cards(self):
        for card in self.cards:
            if hasattr(card, "refresh"):
                card.refresh()

    def nav_neighbor(self, card, direction):
        """The card to focus when an arrow key is pressed on `card`, or
        None if there's nothing that way. Left/Right stay within the
        current row (an edge column returns None rather than wrapping to
        the row above/below, which would be surprising); Up/Down move by
        a full row, lazily building the next batch first if the target
        card doesn't exist yet.
        """
        try:
            idx = self.cards.index(card)
        except ValueError:
            return None
        col = idx % self._cols
        if direction == "left":
            target = idx - 1 if col > 0 else None
        elif direction == "right":
            target = idx + 1 if col < self._cols - 1 else None
            if target is not None and target >= len(self.items):
                target = None
        elif direction == "up":
            target = idx - self._cols if idx - self._cols >= 0 else None
        elif direction == "down":
            target = idx + self._cols
            if target >= len(self.items):
                target = None
            elif target >= self._built:
                self._build_batch()
        else:
            target = None
        if target is None or target >= len(self.cards):
            return None
        result = self.cards[target]
        self.ensureWidgetVisible(result, 40, 60)
        return result


# ══════════════════════════════════════════════════════════════════
# Poster card (Movies / Series)
# ══════════════════════════════════════════════════════════════════
class PosterCard(QFrame):
    """A film or series tile: portrait cover art, title, one meta line.

    Movies and series ship portrait cover art, so this uses a cover-crop
    fill rather than ChannelCard's letterboxed logo — the poster should
    bleed to the tile's edge.

    Two distinct signals rather than one: `activated` fires only from the
    inline overlay button (instant action — play a movie right away,
    unchanged from before); `opened` fires from clicking the card body or
    pressing Enter (view details). Series wires both to the same place
    since there's no "quick play" for a whole show; Movies wires them
    to different destinations.
    """

    activated = Signal(object)
    opened = Signal(object)

    def __init__(self, item, name, meta, badge, art_url, action_label,
                 parent=None, progress_fraction=None, continue_text=None):
        super().__init__(parent)
        self.item = item
        self.setObjectName("Card")
        self.setFixedSize(POSTER_W, POSTER_H)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setCursor(Qt.PointingHandCursor)
        self._nav_container = None

        art_h = POSTER_H - 78
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.well = QFrame(self)
        self.well.setObjectName("PosterWell")
        self.well.setFixedHeight(art_h)
        well_lay = QVBoxLayout(self.well)
        well_lay.setContentsMargins(0, 0, 0, 0)

        self.art = QLabel(self.well)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setText(monogram(name))
        self.art.setFixedSize(POSTER_W, art_h)
        well_lay.addWidget(self.art)

        if badge:
            self.badge = QLabel(badge, self.well)
            # A star-rating badge gets its own gold treatment (matching
            # the real convention — IMDb-style ratings read as amber,
            # not the same blue used for a plain "N seasons" count).
            self.badge.setObjectName(
                "PosterRating" if badge.startswith("\u2605") else "PosterBadge")
            self.badge.move(11, 11)
            self.badge.adjustSize()
            self.badge.raise_()

        if continue_text:
            # A quiet "Continue · S2 E4" strip along the bottom of the
            # art, above the progress bar — only for content you've
            # actually started.
            self.continue_lbl = QLabel(continue_text, self.well)
            self.continue_lbl.setObjectName("PosterBadge")
            self.continue_lbl.setFixedSize(POSTER_W, 36)
            self.continue_lbl.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
            # Sits flush with the bottom of the poster (rounded to match
            # it); the progress bar is drawn inside it, under the text.
            self.continue_lbl.setStyleSheet(
                "background: rgba(12,11,17,0.86); color: white;"
                " border-radius: 0px; border-bottom-left-radius: 12px;"
                " border-bottom-right-radius: 12px; padding-top: 6px;"
                " font-size: 12px; font-weight: 700;")
            self.continue_lbl.move(0, art_h - 36)
            self.continue_lbl.raise_()

        if progress_fraction and progress_fraction > 0:
            self.watched = QProgressBar(self.well)
            self.watched.setObjectName("Epg")
            self.watched.setTextVisible(False)
            self.watched.setRange(0, 1000)
            self.watched.setValue(int(min(1.0, progress_fraction) * 1000))
            self.watched.setGeometry(14, art_h - 10, POSTER_W - 28, 3)
            self.watched.raise_()

        root.addWidget(self.well)

        body = QVBoxLayout()
        body.setContentsMargins(4, 10, 4, 8)
        body.setSpacing(3)
        title = QLabel(name, self)
        title.setObjectName("CardTitle")
        title.setWordWrap(False)
        # ensurePolished() first: at this point (still inside __init__,
        # before this card has been added to a parent or shown) the
        # stylesheet's font-size for #CardTitle hasn't actually been
        # resolved yet, so measuring against fontMetrics() without this
        # would silently use a smaller, unstyled fallback font — under-
        # measuring longer titles and wrongly leaving them un-elided.
        # (Found and fixed via the same bug in ChannelCard's own title.)
        title.ensurePolished()
        fm_title = title.fontMetrics()
        title.setText(fm_title.elidedText(name, Qt.ElideRight, POSTER_W - 26))
        body.addWidget(title)
        meta_lbl = QLabel(meta, self)
        meta_lbl.setObjectName("CardNow")
        meta_lbl.ensurePolished()
        fm_meta = meta_lbl.fontMetrics()
        meta_lbl.setText(fm_meta.elidedText(meta, Qt.ElideRight, POSTER_W - 26))
        body.addWidget(meta_lbl)
        body.addStretch(1)
        root.addLayout(body)

        self.overlay = QFrame(self)
        self.overlay.setObjectName("Overlay")
        self.overlay.setGeometry(0, 0, POSTER_W, art_h)
        ov = QVBoxLayout(self.overlay)
        ov.setContentsMargins(14, 14, 14, 14)
        ov.addStretch(1)
        action = QPushButton(action_label, self.overlay)
        action.setObjectName("Primary")
        action.setCursor(Qt.PointingHandCursor)
        action.setFocusPolicy(Qt.NoFocus)
        action.clicked.connect(lambda: self.activated.emit(self.item))
        ov.addWidget(action)
        self.overlay.hide()

        LOGOS.ready.connect(self._logo_ready)
        if art_url:
            self._logo_box = (POSTER_W, art_h)
            pix = LOGOS.get(art_url, self._logo_box, mode="cover")
            if pix:
                self._apply(pix)
            else:
                LOGOS.request(art_url, self._logo_box, mode="cover")
        self._art_url = art_url

    def _apply(self, pix):
        self.art.setPixmap(_rounded(pix, 12))
        self.art.setText("")

    @Slot(str)
    def _logo_ready(self, url):
        if url == self._art_url:
            pix = LOGOS.get(url, self._logo_box, mode="cover")
            if pix:
                self._apply(pix)

    def enterEvent(self, event):
        super().enterEvent(event)
        _set_hot(self.well, True)
        self.overlay.show()

    def leaveEvent(self, event):
        super().leaveEvent(event)
        if not self.hasFocus():
            _set_hot(self.well, False)
            self.overlay.hide()

    def focusInEvent(self, event):
        super().focusInEvent(event)
        _set_hot(self.well, True)
        self.overlay.show()

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        _set_hot(self.well, self.underMouse())
        self.overlay.hide()

    def mouseReleaseEvent(self, event):
        self.setFocus(Qt.MouseFocusReason)
        self.opened.emit(self.item)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.opened.emit(self.item)
            return
        direction = _arrow_direction(event)
        if direction and self._nav_container is not None:
            target = self._nav_container.nav_neighbor(self, direction)
            if target is not None:
                target.setFocus(Qt.OtherFocusReason)
                return
            edge_cb = getattr(self._nav_container, "nav_edge_cb", None)
            if edge_cb:
                edge_cb(self, direction)
                return
        super().keyPressEvent(event)


# ══════════════════════════════════════════════════════════════════
# Series detail (seasons and episodes)
# ══════════════════════════════════════════════════════════════════
def _soft_blur(pix, factor=40):
    """Cheap, good-looking blur: shrink hard, then scale back up smoothly.
    Used when a title has no backdrop and its portrait poster has to
    stand in behind the details."""
    w, h = pix.width(), pix.height()
    if w < 2 or h < 2:
        return pix
    small = pix.scaled(max(1, w // factor), max(1, h // factor),
                       Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
    return small.scaled(w, h, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)


def _first_url(value):
    """Xtream sends backdrop_path as a list, a string, or not at all."""
    if isinstance(value, (list, tuple)):
        value = next((v for v in value if v), "")
    return value.strip() if isinstance(value, str) and "://" in value else ""


def _clean_year(*values):
    for v in values:
        v = str(v or "").strip()
        if len(v) >= 4 and v[:4].isdigit():
            return v[:4]
    return ""


class _Backdrop(QWidget):
    """Full-bleed artwork behind a detail page, Stremio-style: the image
    fills the page and fades to the background colour on the left (where
    the text sits) and at the bottom."""

    BOX = (1600, 900)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._pix = None
        self._dim = False
        self._url = ""
        self._fallback_url = ""
        LOGOS.ready.connect(self._on_ready)

    def load(self, backdrop_url, fallback_url=""):
        """Show the backdrop if there is one, otherwise a blurred poster."""
        self._url, self._fallback_url = backdrop_url, fallback_url
        self._pix = None
        self._show_best()
        for url in (backdrop_url, fallback_url):
            if url and LOGOS.get(url, self.BOX, mode="cover") is None:
                LOGOS.request(url, self.BOX, mode="cover", priority=10)
        self.update()

    def _show_best(self):
        if self._url:
            pix = LOGOS.get(self._url, self.BOX, mode="cover")
            if pix is not None:
                self._pix, self._dim = pix, False
                return True
        if self._fallback_url and self._pix is None:
            pix = LOGOS.get(self._fallback_url, self.BOX, mode="cover")
            if pix is not None:
                self._pix, self._dim = _soft_blur(pix), True
        return False

    @Slot(str)
    def _on_ready(self, url):
        if url and url in (self._url, self._fallback_url):
            self._show_best()
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor(C.ink))
        if self._pix is not None and not self._pix.isNull():
            pw, ph = self._pix.width(), self._pix.height()
            scale = max(w / pw, h / ph)
            dw, dh = pw * scale, ph * scale
            p.setOpacity(0.55 if self._dim else 0.95)
            p.drawPixmap(QRectF((w - dw) / 2, (h - dh) * 0.3, dw, dh), self._pix,
                         QRectF(self._pix.rect()))
            p.setOpacity(1.0)
        ink = QColor(C.ink)

        def shade(alpha):
            c = QColor(ink)
            c.setAlphaF(alpha)
            return c

        left = QLinearGradient(0, 0, w, 0)
        left.setColorAt(0.0, shade(0.97))
        left.setColorAt(0.32, shade(0.86))
        left.setColorAt(0.62, shade(0.35))
        left.setColorAt(1.0, shade(0.12))
        p.fillRect(self.rect(), left)
        bottom = QLinearGradient(0, 0, 0, h)
        bottom.setColorAt(0.0, shade(0.35))
        bottom.setColorAt(0.25, shade(0.0))
        bottom.setColorAt(0.6, shade(0.0))
        bottom.setColorAt(1.0, shade(1.0))
        p.fillRect(self.rect(), bottom)
        p.end()


# ══════════════════════════════════════════════════════════════════
# Stremio add-ons: Discover rows, add-on detail page, streams panel
# ══════════════════════════════════════════════════════════════════
def _meta_year(meta):
    return _clean_year(meta.get("releaseInfo"), meta.get("year"), meta.get("released"))


def addon_hero_picks(rows, limit=7):
    """Banner slides from add-on catalog rows: Trending rows first (e.g. the
    TMDB add-on's), then Popular, then the rest; films and series
    alternating; only titles with a backdrop."""
    def rank(row):
        title = row[0].lower()
        return 0 if "trending" in title else 1 if "popular" in title else 2
    ordered = sorted(rows, key=rank)
    films = [(m, rank(r)) for r in ordered if r[1] == "movie" for m in r[2][:8] if m.get("background")]
    shows = [(m, rank(r)) for r in ordered if r[1] == "series" for m in r[2][:8] if m.get("background")]
    picks, seen = [], set()
    for i in range(limit):
        for kind, pool in (("addon:movie", films), ("addon:series", shows)):
            if i < len(pool) and pool[i][0]["id"] not in seen:
                meta, r = pool[i]
                seen.add(meta["id"])
                item = _meta_as_item(meta)
                item["_tag"] = "TRENDING" if r == 0 else "POPULAR"
                picks.append((kind, item))
    return picks[:limit]


def _meta_as_item(meta):
    """An add-on meta shaped like the provider items HeroBanner shows."""
    genres = meta.get("genres") or meta.get("genre") or []
    if isinstance(genres, list):
        genres = ", ".join(genres[:3])
    return {"name": meta.get("name", ""), "backdrop_path": [meta.get("background") or ""],
            "cover": meta.get("poster") or "", "plot": meta.get("description") or "",
            "year": _meta_year(meta), "rating": meta.get("imdbRating") or "",
            "genre": genres, "_meta": meta}


class PosterShelf(QWidget):
    """A titled sideways row of posters from one add-on catalog."""

    opened = Signal(dict)
    MAX = 20
    SHELF_CARD_W, SHELF_CARD_H = POSTER_W, POSTER_H

    def __init__(self, title, metas, parent=None, progress=None, see_all=None):
        """progress: {meta id: (fraction, "Continue \u2022 S3 E5")} for a
        Continue-watching row. see_all: called by the row's "See all"
        button (the button only appears when this is given)."""
        super().__init__(parent)
        progress = progress or {}
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(12)
        head = QHBoxLayout()
        label = QLabel(title, self)
        label.setObjectName("ShelfTitle")
        head.addWidget(label)
        if see_all is not None:
            head.addSpacing(12)
            more = QPushButton(f"See all {len(metas)}  \u203a", self)
            more.setObjectName("SeeAll")
            more.setCursor(Qt.PointingHandCursor)
            more.setFocusPolicy(Qt.NoFocus)
            more.clicked.connect(see_all)
            head.addWidget(more, 0, Qt.AlignVCenter)
        head.addStretch(1)
        self.left = QPushButton("‹", self)
        self.right = QPushButton("›", self)
        for btn, step in ((self.left, -1), (self.right, 1)):
            btn.setObjectName("Arrow")
            btn.setFixedSize(32, 32)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFocusPolicy(Qt.NoFocus)
            btn.clicked.connect(lambda _=False, d=step: self._slide(d))
            head.addWidget(btn)
        root.addLayout(head)

        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFixedHeight(self.SHELF_CARD_H + 14)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setFocusPolicy(Qt.NoFocus)
        strip = QWidget()
        self._lay = QHBoxLayout(strip)
        self._lay.setContentsMargins(0, 4, 0, 4)
        self._lay.setSpacing(16)
        self._lay.addStretch(1)
        self._metas = metas[:self.MAX]
        self._progress = progress
        self._watched = fluxtv_trakt.watched_sets()[0]
        self._built = 0
        # Only the posters you can see are built now; the rest follow as
        # the row is scrolled (four rows x twenty posters at once was what
        # kept Discover blank for over a second).
        self._build(self.FIRST)
        self.scroll.setWidget(strip)
        root.addWidget(self.scroll)
        self.scroll.horizontalScrollBar().valueChanged.connect(self._maybe_more)
        self._anim = QPropertyAnimation(self.scroll.horizontalScrollBar(), b"value", self)
        self._anim.setDuration(260)

    FIRST = 8

    def _build(self, count):
        end = min(len(self._metas), self._built + count)
        for meta in self._metas[self._built:end]:
            rating = meta.get("imdbRating") or ""
            genres = meta.get("genres") or []
            line = "   ".join(filter(None, [_meta_year(meta),
                                            genres[0] if isinstance(genres, list) and genres else ""]))
            fraction, cont = self._progress.get(meta.get("id"), (None, None))
            watched = meta.get("type", "movie") == "movie" and meta.get("id") in self._watched
            card = PosterCard(meta, meta.get("name", ""), line,
                              "\u2713 Watched" if watched else (f"\u2605 {rating}" if rating else ""),
                              meta.get("poster") or "", "\u25b6  Watch",
                              progress_fraction=fraction, continue_text=cont)
            card.opened.connect(self.opened.emit)
            card.activated.connect(self.opened.emit)
            self._lay.insertWidget(self._lay.count() - 1, card)
        self._built = end

    def _maybe_more(self, value):
        bar = self.scroll.horizontalScrollBar()
        if self._built < len(self._metas) and value >= bar.maximum() - (self.SHELF_CARD_W + 16) * 2:
            self._build(6)

    def _slide(self, direction):
        if direction > 0 and self._built < len(self._metas):
            self._build(6)
        bar = self.scroll.horizontalScrollBar()
        self._anim.stop()
        self._anim.setStartValue(bar.value())
        self._anim.setEndValue(max(0, min(bar.maximum(),
                                          bar.value() + direction * (self.SHELF_CARD_W + 16) * 4)))
        self._anim.start()


# ══════════════════════════════════════════════════════════════════
# Password field
# ══════════════════════════════════════════════════════════════════
class PasswordField(QFrame):
    """Masked entry with a reveal toggle.

    QLineEdit.addAction needs a real QIcon, and shipping icon assets for
    one glyph is not worth it, so the toggle is an ordinary button inside
    a bordered wrapper that mirrors the focus ring.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("PwdWrap")
        self.setProperty("focused", False)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(11, 0, 6, 0)
        lay.setSpacing(4)

        self.edit = QLineEdit(self)
        self.edit.setObjectName("PwdField")
        self.edit.setEchoMode(QLineEdit.Password)
        lay.addWidget(self.edit, 1)

        self.eye = QPushButton("\U0001f441", self)
        self.eye.setObjectName("Eye")
        self.eye.setFixedSize(28, 28)
        self.eye.setCursor(Qt.PointingHandCursor)
        self.eye.setFocusPolicy(Qt.NoFocus)
        self.eye.setToolTip("Show password")
        self.eye.clicked.connect(self.toggle)
        lay.addWidget(self.eye)

        self.edit.focusInEvent = self._wrap(self.edit.focusInEvent, True)
        self.edit.focusOutEvent = self._wrap(self.edit.focusOutEvent, False)

    def _wrap(self, original, state):
        def handler(event):
            original(event)
            self.setProperty("focused", state)
            self.style().unpolish(self)
            self.style().polish(self)
        return handler

    def toggle(self):
        hidden = self.edit.echoMode() == QLineEdit.Password
        self.edit.setEchoMode(QLineEdit.Normal if hidden else QLineEdit.Password)
        self.eye.setProperty("on", hidden)
        self.eye.setToolTip("Hide password" if hidden else "Show password")
        self.eye.style().unpolish(self.eye)
        self.eye.style().polish(self.eye)

    def text(self):
        return self.edit.text()

    def setText(self, value):
        self.edit.setText(value)

    def returnPressed(self):
        return self.edit.returnPressed
