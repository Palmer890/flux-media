"""
Flux Media (FluxTV) — the Home screen and its featured banner.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (ChannelCard, LOGOS, _Backdrop, _clean_year, _first_url, _soft_blur)


# ══════════════════════════════════════════════════════════════════
# Horizontal shelf
# ══════════════════════════════════════════════════════════════════
class Shelf(QWidget):
    """A titled row of cards that scrolls sideways.

    Cards are built in batches as the row is scrolled, so a 2,000-channel
    category costs the same to open as a 12-channel one.
    """

    activated = Signal(object)
    selected = Signal(object)
    fav_toggled = Signal(object)

    BATCH = 8

    def __init__(self, title, channels, library, empty_text="", parent=None):
        super().__init__(parent)
        self.lib = library
        self.channels = list(channels)
        self.cards: list[ChannelCard] = []
        self._built = 0
        # Set by HomeView after construction: called as edge_cb(card,
        # direction) when Up/Down is pressed on a card in this shelf,
        # since a single horizontal row has nothing "above" or "below"
        # itself to offer — only the page that arranges several shelves
        # vertically knows what that should mean.
        self.nav_edge_cb = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(12)

        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(10)
        # Gold accent pip — cinema feel
        pip = QFrame(self)
        pip.setFixedSize(3, 18)
        pip.setStyleSheet(f"background: {C.cyan}; border-radius: 1px;")
        pip.hide()
        label = QLabel(title, self)
        label.setObjectName("ShelfTitle")
        head.addWidget(label)
        if self.channels:
            count = QLabel(str(len(self.channels)), self)
            count.setObjectName("ShelfCount")
            head.addWidget(count)
        head.addStretch(1)

        self.left = QPushButton("\u2039", self)
        self.right = QPushButton("\u203a", self)
        for btn in (self.left, self.right):
            btn.setObjectName("Arrow")
            btn.setFixedSize(32, 32)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFocusPolicy(Qt.NoFocus)
            head.addWidget(btn)
        self.left.clicked.connect(lambda: self._slide(-1))
        self.right.clicked.connect(lambda: self._slide(1))
        root.addLayout(head)

        if not self.channels:
            note = QLabel(empty_text, self)
            note.setObjectName("Faint")
            note.setWordWrap(True)
            root.addWidget(note)
            self.left.hide()
            self.right.hide()
            self.scroll = None
            return

        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFixedHeight(CARD_H + 14)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setFocusPolicy(Qt.NoFocus)

        strip = QWidget()
        self.strip_lay = QHBoxLayout(strip)
        self.strip_lay.setContentsMargins(0, 4, 0, 4)
        self.strip_lay.setSpacing(14)
        self.strip_lay.addStretch(1)
        self.scroll.setWidget(strip)
        root.addWidget(self.scroll)

        self._anim = QPropertyAnimation(self.scroll.horizontalScrollBar(), b"value")
        self._anim.setDuration(260)

        self.scroll.horizontalScrollBar().valueChanged.connect(self._maybe_more)
        self._build_batch()
        self._update_arrows()

    # ── lazy build ───────────────────────────────────────────────
    def _build_batch(self):
        end = min(self._built + self.BATCH, len(self.channels))
        for ch in self.channels[self._built:end]:
            card = ChannelCard(ch, self.lib)
            card._nav_container = self
            card.activated.connect(self.activated.emit)
            card.selected.connect(self.selected.emit)
            card.fav_toggled.connect(self.fav_toggled.emit)
            self.strip_lay.insertWidget(self.strip_lay.count() - 1, card)
            self.cards.append(card)
        self._built = end
        self._update_arrows()

    def _maybe_more(self, value):
        bar = self.scroll.horizontalScrollBar()
        if bar.maximum() and value > bar.maximum() * 0.7:
            if self._built < len(self.channels):
                self._build_batch()
        self._update_arrows()

    def _update_arrows(self):
        if not self.scroll:
            return
        bar = self.scroll.horizontalScrollBar()
        self.left.setEnabled(bar.value() > 0)
        self.right.setEnabled(bar.value() < bar.maximum()
                              or self._built < len(self.channels))

    # ── sliding ──────────────────────────────────────────────────
    def _slide(self, direction):
        if not self.scroll:
            return
        if direction > 0 and self._built < len(self.channels):
            self._build_batch()
        bar = self.scroll.horizontalScrollBar()
        step = (CARD_W + 14) * 3
        self._anim.stop()
        self._anim.setStartValue(bar.value())
        self._anim.setEndValue(max(0, min(bar.maximum(),
                                          bar.value() + step * direction)))
        self._anim.start()

    def ensure_visible(self, card):
        if self.scroll:
            self.scroll.ensureWidgetVisible(card, 40, 0)

    def nav_neighbor(self, card, direction):
        """Left/Right only — this is a single row, so Up/Down are left
        for nav_edge_cb (set by HomeView) to turn into shelf-to-shelf
        movement instead."""
        try:
            idx = self.cards.index(card)
        except ValueError:
            return None
        if direction == "right":
            target = idx + 1
            if target >= self._built and target < len(self.channels):
                self._build_batch()
            if target >= len(self.cards):
                return None
        elif direction == "left":
            target = idx - 1
            if target < 0:
                return None
        else:
            return None
        result = self.cards[target]
        self.ensure_visible(result)
        return result

    def refresh_cards(self):
        for card in self.cards:
            card.refresh()

    def mark_on_air(self, channel):
        key = self.lib._fav_key(channel) if channel else None
        for card in self.cards:
            card.set_on_air(key is not None
                            and self.lib._fav_key(card.channel) == key)


# ══════════════════════════════════════════════════════════════════
# Home
# ══════════════════════════════════════════════════════════════════
class HeroBanner(QWidget):
    """The big featured card at the top of Home: newest films and series
    from the provider, rotating every few seconds (paused while the
    pointer is over it). Backdrop art if the provider has it, otherwise
    a blurred poster behind the sharp one."""

    open_item = Signal(str, dict)       # "movie" / "series", item
    play_item = Signal(str, dict)

    H = 420
    POSTER = (220, 330)
    ROTATE_MS = 9000

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Clear")
        self.setFixedHeight(self.H)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.items = []
        self.index = 0
        self._hover = False
        LOGOS.ready.connect(self._on_ready)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(52, 40, 52 + self.POSTER[0] + 40, 44)
        lay.setSpacing(10)
        self.tag = QLabel("", self)
        self.tag.setObjectName("HeroTag")
        lay.addWidget(self.tag, 0, Qt.AlignLeft)
        lay.addStretch(1)
        self.title = QLabel("", self)
        self.title.setObjectName("BannerTitle")
        self.title.setWordWrap(True)
        lay.addWidget(self.title)
        self.facts = QLabel("", self)
        self.facts.setObjectName("HeroFacts")
        self.facts.setTextFormat(Qt.RichText)
        lay.addWidget(self.facts)
        self.plot = QLabel("", self)
        self.plot.setObjectName("HeroPlot")
        self.plot.setWordWrap(True)
        self.plot.setMaximumWidth(700)
        lay.addWidget(self.plot)
        lay.addSpacing(8)
        row = QHBoxLayout()
        row.setSpacing(12)
        self.play_btn = QPushButton("▶  Play", self)
        self.play_btn.setObjectName("HeroPlay")
        self.play_btn.setCursor(Qt.PointingHandCursor)
        self.play_btn.clicked.connect(self._play)
        row.addWidget(self.play_btn)
        self.info_btn = QPushButton("More info", self)
        self.info_btn.setObjectName("HeroGhost")
        self.info_btn.setCursor(Qt.PointingHandCursor)
        self.info_btn.clicked.connect(self._open)
        row.addWidget(self.info_btn)
        row.addStretch(1)
        lay.addLayout(row)

        self._timer = QTimer(self)
        self._timer.setInterval(self.ROTATE_MS)
        self._timer.timeout.connect(lambda: self.go_to(self.index + 1))
        self.hide()

    # ── data ─────────────────────────────────────────────────────
    def set_items(self, items):
        """items: [("movie"|"series", item), ...]"""
        self.items = [(k, i) for k, i in items if i]
        self.index = 0
        if not self.items:
            self._timer.stop()
            self.hide()
            return
        self.show()
        for n, (kind, item) in enumerate(self.items):
            for url, box in self._art_for(kind, item):
                if url and LOGOS.get(url, box, mode="cover") is None:
                    # The slide on screen first, ahead of any poster rows.
                    LOGOS.request(url, box, mode="cover", priority=8 if n == 0 else 4)
        self._apply()
        self._timer.start()

    @staticmethod
    def _poster_url(kind, item):
        return item.get("cover") or item.get("stream_icon") or ""

    def _art_for(self, kind, item):
        back = _first_url(item.get("backdrop_path"))
        poster = self._poster_url(kind, item)
        return [(back, _Backdrop.BOX), (poster, _Backdrop.BOX), (poster, self.POSTER)]

    def go_to(self, index):
        if not self.items:
            return
        self.index = index % len(self.items)
        self._apply()
        self._timer.start()

    def _apply(self):
        kind, item = self.items[self.index]
        if kind.startswith("addon:"):
            what = "SERIES" if kind.endswith("series") else "FILM"
            self.tag.setText(f"{item.get('_tag', 'POPULAR')} {what}")
        else:
            self.tag.setText("NEW SERIES" if kind == "series" else "NEW FILM")
        self.title.setText(item.get("name", ""))
        year = _clean_year(item.get("year"), item.get("releaseDate"),
                           item.get("releasedate"))
        bits = []
        rating = item.get("rating") or item.get("rating_5based")
        try:
            if rating and float(rating) > 0:
                bits.append(f"<span style='color:{C.gold}; font-weight:700'>"
                            f"★ {float(rating):.1f}</span>")
        except (TypeError, ValueError):
            pass
        if year:
            bits.append(year)
        if item.get("genre"):
            bits.append(str(item.get("genre")).replace(" / ", ", "))
        sep = f"<span style='color:{C.faint}'>&nbsp;&nbsp;•&nbsp;&nbsp;</span>"
        self.facts.setText(sep.join(bits))
        plot = " ".join((item.get("plot") or "").split())
        if len(plot) > 190:
            plot = plot[:190].rsplit(" ", 1)[0] + "…"
        self.plot.setText(plot)
        self.plot.setVisible(bool(plot))
        self.play_btn.setText({"movie": "▶  Play", "series": "▶  Episodes"}
                              .get(kind, "▶  Watch"))
        self.update()

    @Slot(str)
    def _on_ready(self, url):
        if self.items and url:
            kind, item = self.items[self.index]
            if url in (u for u, _ in self._art_for(kind, item)):
                self.update()

    def _play(self):
        if self.items:
            kind, item = self.items[self.index]
            self.play_item.emit(kind, item)

    def _open(self):
        if self.items:
            kind, item = self.items[self.index]
            self.open_item.emit(kind, item)

    # ── pointer: pause rotation while hovered, dots to jump ─────
    def enterEvent(self, e):
        self._hover = True
        self._timer.stop()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        if self.items:
            self._timer.start()
        super().leaveEvent(e)

    def _dot_rects(self):
        n = len(self.items)
        w = n * 10 + (n - 1) * 8 + 16
        x0 = self.width() - 52 - w + 8
        y = self.height() - 30
        rects = []
        x = x0
        for i in range(n):
            dw = 22 if i == self.index else 10
            rects.append(QRectF(x, y, dw, 6))
            x += dw + 8
        return rects

    def mousePressEvent(self, e):
        for i, r in enumerate(self._dot_rects()):
            if r.adjusted(-6, -8, 6, 8).contains(e.position()):
                self.go_to(i)
                return
        super().mousePressEvent(e)

    def paintEvent(self, event):
        if not self.items:
            return
        kind, item = self.items[self.index]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        card = QRectF(self.rect())
        path = QPainterPath()
        path.addRoundedRect(card, 20, 20)
        p.setClipPath(path)
        p.fillRect(card, QColor(C.card))

        back, poster = _first_url(item.get("backdrop_path")), self._poster_url(kind, item)
        pix = LOGOS.get(back, _Backdrop.BOX, mode="cover") if back else None
        dim = False
        if pix is None and poster:
            pix = LOGOS.get(poster, _Backdrop.BOX, mode="cover")
            if pix is not None:
                pix, dim = _soft_blur(pix), True
        if pix is not None:
            w, h = card.width(), card.height()
            scale = max(w / pix.width(), h / pix.height())
            dw, dh = pix.width() * scale, pix.height() * scale
            p.setOpacity(0.6 if dim else 0.95)
            p.drawPixmap(QRectF((w - dw) / 2, (h - dh) * 0.35, dw, dh), pix,
                         QRectF(pix.rect()))
            p.setOpacity(1.0)
        ink = QColor(C.ink)
        g = QLinearGradient(0, 0, card.width(), 0)
        for stop, alpha in ((0.0, 0.94), (0.4, 0.72), (0.75, 0.2), (1.0, 0.05)):
            c = QColor(ink)
            c.setAlphaF(alpha)
            g.setColorAt(stop, c)
        p.fillRect(card, g)
        v = QLinearGradient(0, 0, 0, card.height())
        for stop, alpha in ((0.5, 0.0), (1.0, 0.6)):
            c = QColor(ink)
            c.setAlphaF(alpha)
            v.setColorAt(stop, c)
        p.fillRect(card, v)

        # Sharp poster on the right.
        pw, ph = self.POSTER
        prect = QRectF(card.right() - 52 - pw, (card.height() - ph) / 2 - 8, pw, ph)
        poster_pix = LOGOS.get(poster, self.POSTER, mode="cover") if poster else None
        if poster_pix is not None:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 90))
            p.drawRoundedRect(prect.adjusted(-2, 6, 6, 12), 14, 14)
            pp = QPainterPath()
            pp.addRoundedRect(prect, 12, 12)
            p.save()
            p.setClipPath(pp)
            p.drawPixmap(prect, poster_pix, QRectF(poster_pix.rect()))
            p.restore()

        # Page dots.
        p.setPen(Qt.NoPen)
        for i, r in enumerate(self._dot_rects()):
            p.setBrush(QColor(C.paper) if i == self.index else QColor(255, 255, 255, 70))
            p.drawRoundedRect(r, 3, 3)
        p.end()


class HomeView(QWidget):
    """Content first, controls second: shelves only, no button grid."""

    activated = Signal(object)
    selected = Signal(object)
    fav_toggled = Signal(object)

    HERO_ITEMS = 7

    def __init__(self, library, parent=None):
        super().__init__(parent)
        self.lib = library
        self.shelves: list[Shelf] = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        self.lay = QVBoxLayout(holder)
        self.lay.setContentsMargins(34, 26, 24, 40)
        self.lay.setSpacing(34)
        self.scroll.setWidget(holder)
        outer.addWidget(self.scroll)

        # Stremio-style featured banner in place of the old greeting line.
        self.greeting = QLabel("", holder)
        self.greeting.setObjectName("Greeting")
        self.greeting.hide()
        self.hero = HeroBanner(holder)
        self.lay.addWidget(self.hero)
        self.lay.addStretch(1)

    def set_addon_hero(self, picks):
        """Banner from the add-ons' trending/popular titles. Once set, it
        takes over from the provider's VOD, which tends to be out of date
        or in another language."""
        self._addon_picks = picks or []
        if self._addon_picks:
            self.hero.set_items(self._addon_picks)
        else:
            self.refresh_hero()

    def refresh_hero(self):
        """Newest provider films and series — only used when there are no
        add-on picks to show."""
        if getattr(self, "_addon_picks", None):
            return
        def newest(items, *keys):
            def stamp(item):
                for k in keys:
                    try:
                        return float(item.get(k) or 0)
                    except (TypeError, ValueError):
                        continue
                return 0.0
            with_art = [i for i in items if i.get("stream_icon") or i.get("cover")
                        or i.get("backdrop_path")]
            return sorted(with_art, key=stamp, reverse=True)[:self.HERO_ITEMS]

        films = newest(self.lib.vod_channels or [], "added")
        shows = newest(self.lib.series_list or [], "last_modified")
        picks = []
        for i in range(self.HERO_ITEMS):
            if i < len(films):
                picks.append(("movie", films[i]))
            if i < len(shows):
                picks.append(("series", shows[i]))
        self.hero.set_items(picks[:self.HERO_ITEMS])

    def rebuild(self):
        # Pure time-based greeting, matching the original build exactly —
        # no username suffix (a raw provider login like "fo3b26f436" is
        # not something anyone wants printed on their home screen).
        self.greeting.setText(core.time_greeting())

        rows = [
            ("Continue watching", self.lib._recent_channels(),
             "Nothing watched yet. Open Live TV and pick a channel."),
            ("My favourites", self.lib._fav_channels(),
             "Star any channel to keep it here."),
            ("Live sport", self.lib._collection("Sports"),
             "No sport categories found on this provider."),
            ("News", self.lib._collection("News"),
             "No news categories found on this provider."),
            ("Kids", self.lib._collection("Kids"), ""),
        ]
        # Same channels in the same rows as last visit: keep the shelves and
        # just refresh their cards (what's on now, stars). Rebuilding all
        # of them every time Home was opened was the wait.
        sig = [(title, [id(c) for c in channels[:40]]) for title, channels, _e in rows]
        if sig == getattr(self, "_sig", None) and self.shelves:
            self.refresh_cards()
            return
        self._sig = sig
        for shelf in self.shelves:
            shelf.setParent(None)
            shelf.deleteLater()
        self.shelves.clear()
        for title, channels, empty in rows:
            if not channels and not empty:
                continue
            shelf = Shelf(title, channels[:40], self.lib, empty, self)
            shelf.activated.connect(self.activated.emit)
            shelf.selected.connect(self.selected.emit)
            shelf.fav_toggled.connect(self.fav_toggled.emit)
            shelf.nav_edge_cb = self._cross_shelf
            self.lay.insertWidget(self.lay.count() - 1, shelf)
            self.shelves.append(shelf)

    def _cross_shelf(self, card, direction):
        """Up/Down at a shelf's own edge moves to the previous/next
        shelf, landing on whichever card sits closest to the same
        horizontal position rather than always snapping back to the
        first card in the row."""
        if direction not in ("up", "down"):
            return
        shelf = card._nav_container
        try:
            shelf_idx = self.shelves.index(shelf)
        except ValueError:
            return
        target_idx = shelf_idx - 1 if direction == "up" else shelf_idx + 1
        if not (0 <= target_idx < len(self.shelves)):
            return
        target_shelf = self.shelves[target_idx]
        if not target_shelf.cards:
            return
        card_idx = min(shelf.cards.index(card), len(target_shelf.cards) - 1)
        target_card = target_shelf.cards[card_idx]
        target_shelf.ensure_visible(target_card)
        # target_shelf.ensure_visible() only scrolls that shelf's own
        # horizontal strip — it has no idea the whole page can also
        # scroll vertically, so crossing onto a shelf below the fold
        # moved focus there correctly but left the page itself unscrolled,
        # leaving the newly-focused card off-screen. The page's own
        # QScrollArea needs to be told separately.
        self.scroll.ensureWidgetVisible(target_card, 40, 60)
        target_card.setFocus(Qt.OtherFocusReason)

    def refresh_cards(self):
        for shelf in self.shelves:
            shelf.refresh_cards()

    def mark_on_air(self, channel):
        for shelf in self.shelves:
            shelf.mark_on_air(channel)
