"""
Flux Media (FluxTV) — the TV guide, catch-up list and recordings page.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (CategoryFilter, _hm, html_escape)


class EpgGuideScreen(QWidget):
    """A proper multi-hour TV guide: channels down the side, a time
    ruler across the top, programme blocks sized by their actual
    duration — for seeing what's on later tonight, not just the
    now/next a channel card shows.

    Two independently-scrollable panes kept vertically in sync: a
    fixed-width channel sidebar (vertical scroll only, so channel names
    never scroll out of view horizontally) and the timeline itself
    (scrolls both ways, since the visible time window is wider than the
    screen). Rebuilding is a plain clear-and-recreate on every filter
    or window change — this screen is opened deliberately to look
    something up, not left running continuously, so there's no need for
    LazyGrid-style incremental building here.
    """

    activated = Signal(object)   # channel — tune in (clicked the airing block)
    catchup_requested = Signal(object, object)   # channel, programme — watch from the archive
    catchup_list_requested = Signal(object)      # channel — its catch-up list
    record_requested = Signal(object, object)    # channel, programme
    recordings_requested = Signal()

    ROW_H = 60
    PX_PER_MIN = 4
    WINDOW_HOURS = 4
    SIDEBAR_W = 200
    RULER_H = 28
    BATCH = 40
    MAX_BATCHES_PER_TICK = 4     # keeps the UI responsive while catching up
    RECENT_LIMIT = 30            # how many recently-watched channels count as "mine"

    MODES = [("mine", "\u2605  My channels"),
             ("sport", "Sport"),
             ("all", "All channels")]

    def __init__(self, library, parent=None):
        super().__init__(parent)
        self.lib = library
        self._all_channels = []
        self.channels = []
        self.category_id = None
        self._empty_text = ""
        self._window_start = self._floor_half_hour(datetime.now(timezone.utc))
        self._syncing = False
        self._now_line = None
        self._built = 0
        self._row_widgets = []
        self._label_widgets = []
        self.mode = "mine"
        self._mode_chosen = False    # False until the person picks one themselves
        self.query = ""
        self._pool_cache = None      # (stamp, channels-with-guide-data)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(11)
        pip = QFrame(self)
        pip.setFixedSize(4, 24)
        pip.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:0, y2:1,"
                          f" stop:0 {C.cyan}, stop:1 {C.violet}); border-radius: 2px;")
        pip.hide()
        self.title_label = QLabel("TV Guide", self)
        self.title_label.setObjectName("ScreenTitle")
        title_row.addWidget(self.title_label)
        lay.addLayout(title_row)
        self.subtitle_label = QLabel("See what's on now and later", self)
        self.subtitle_label.setObjectName("Muted")
        lay.addWidget(self.subtitle_label)
        lay.addSpacing(14)

        controls_row = QHBoxLayout()
        controls_row.setSpacing(8)
        # With a provider carrying tens of thousands of channels, "every
        # channel" is never what anyone wants to look at — these choose
        # WHICH channels the guide is about. Defaults to the person's own
        # channels (see _pick_default_mode).
        self._mode_btns = {}
        for mode, label in self.MODES:
            btn = QPushButton(label, self)
            btn.setObjectName("GuideMode")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(partial(self._on_mode, mode))
            controls_row.addWidget(btn)
            self._mode_btns[mode] = btn
        controls_row.addSpacing(6)
        self.filter_chip = CategoryFilter("All categories", self)
        self.filter_chip.changed.connect(self._on_category)
        controls_row.addWidget(self.filter_chip)
        controls_row.addStretch(1)
        self.earlier_btn = QPushButton("\u25c0  Earlier", self)
        self.earlier_btn.setObjectName("Ghost")
        self.earlier_btn.setCursor(Qt.PointingHandCursor)
        self.earlier_btn.clicked.connect(lambda: self._shift_window(-2))
        controls_row.addWidget(self.earlier_btn)
        self.now_btn = QPushButton("Now", self)
        self.now_btn.setObjectName("Ghost")
        self.now_btn.setCursor(Qt.PointingHandCursor)
        self.now_btn.clicked.connect(self._jump_to_now)
        controls_row.addWidget(self.now_btn)
        self.later_btn = QPushButton("Later  \u25b6", self)
        self.later_btn.setObjectName("Ghost")
        self.later_btn.setCursor(Qt.PointingHandCursor)
        self.later_btn.clicked.connect(lambda: self._shift_window(2))
        controls_row.addWidget(self.later_btn)
        controls_row.addSpacing(10)
        rec_btn = QPushButton("\u25cf  Recordings", self)
        rec_btn.setObjectName("Ghost")
        rec_btn.setCursor(Qt.PointingHandCursor)
        rec_btn.clicked.connect(self.recordings_requested.emit)
        controls_row.addWidget(rec_btn)
        lay.addLayout(controls_row)
        lay.addSpacing(10)

        # Sits directly under the controls: when there's nothing to list
        # the grid below is hidden, and a message stranded at the very
        # bottom of the window would read as if nothing had happened.
        self.empty_label = QLabel("", self)
        self.empty_label.setObjectName("GuideEmpty")
        self.empty_label.setWordWrap(True)
        self.empty_label.hide()
        lay.addWidget(self.empty_label)

        grid_row = QHBoxLayout()
        grid_row.setContentsMargins(0, 0, 0, 0)
        grid_row.setSpacing(0)

        # Both scroll areas use setWidgetResizable(False): their content
        # widgets are sized explicitly (once, in _rebuild(), from the
        # FULL channel count) and children are positioned with .move()
        # rather than a layout — a layout would need every preceding
        # row to already exist to stack correctly, which doesn't work
        # once rows are built in lazy batches rather than all at once.
        self.sidebar_scroll = QScrollArea(self)
        self.sidebar_scroll.setFixedWidth(self.SIDEBAR_W)
        self.sidebar_scroll.setWidgetResizable(False)
        self.sidebar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.sidebar_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.sidebar_scroll.setObjectName("GuideSidebar")
        self.sidebar_holder = QWidget()
        self.sidebar_scroll.setWidget(self.sidebar_holder)
        grid_row.addWidget(self.sidebar_scroll)

        self.timeline_scroll = QScrollArea(self)
        self.timeline_scroll.setWidgetResizable(False)
        self.timeline_holder = QWidget()
        self.timeline_holder.setObjectName("GuideTimeline")
        self.timeline_scroll.setWidget(self.timeline_holder)
        grid_row.addWidget(self.timeline_scroll, 1)

        lay.addLayout(grid_row, 1)

        self.sidebar_scroll.verticalScrollBar().valueChanged.connect(
            self._sync_from_sidebar)
        self.timeline_scroll.verticalScrollBar().valueChanged.connect(
            self._sync_from_timeline)

        # Repositions the "now" line on a plain timer so it stays roughly
        # accurate for as long as the guide is left open, without a full
        # rebuild — everything else here only changes on an actual filter
        # or window action.
        self._now_timer = QTimer(self)
        self._now_timer.setInterval(60_000)
        self._now_timer.timeout.connect(self._update_now_line)
        self._now_timer.start()

    # ── scroll sync + lazy build ─────────────────────────────────
    def _sync_from_sidebar(self, value):
        if not self._syncing:
            self._syncing = True
            self.timeline_scroll.verticalScrollBar().setValue(value)
            self._syncing = False
        self._maybe_more(value)

    def _sync_from_timeline(self, value):
        if not self._syncing:
            self._syncing = True
            self.sidebar_scroll.verticalScrollBar().setValue(value)
            self._syncing = False
        self._maybe_more(value)

    def _maybe_more(self, value):
        # The scrollbar's range reflects the FULL channel count from the
        # moment _rebuild() runs (that's what makes "near the bottom"
        # meaningful at all), so someone can jump straight to the very
        # end — dragging the thumb, or a Home/End-style jump — past
        # anything a single batch covers. Catching up fully in one go was
        # fine for a few thousand rows but scales linearly, so it's done
        # in bounded slices instead: a few batches now, and if that isn't
        # enough the remainder is scheduled for the next turn of the
        # event loop, so the window keeps painting and responding while
        # the blank area fills in rather than freezing until it's done.
        bar = self.timeline_scroll.verticalScrollBar()
        if not (bar.maximum() and value > bar.maximum() * 0.75):
            return
        for _ in range(self.MAX_BATCHES_PER_TICK):
            if self._built >= len(self.channels):
                return
            self._build_batch()
        if self._built < len(self.channels):
            QTimer.singleShot(0, lambda: self._maybe_more(bar.value()))

    # ── time window ──────────────────────────────────────────────
    @staticmethod
    def _floor_half_hour(dt):
        minute = 0 if dt.minute < 30 else 30
        return dt.replace(minute=minute, second=0, microsecond=0)

    def _shift_window(self, hours):
        self._window_start += timedelta(hours=hours)
        self._built_sig = None
        self._rebuild()

    def _jump_to_now(self):
        self._window_start = self._floor_half_hour(datetime.now(timezone.utc))
        self._built_sig = None
        self._rebuild()

    # ── which channels ───────────────────────────────────────────
    def set_categories(self, categories):
        self.filter_chip.set_categories(categories)

    def _on_category(self, cid, _label):
        self.category_id = cid
        self._apply_filter()

    def _on_mode(self, mode):
        self.mode = mode
        self._mode_chosen = True     # from now on, respect it even if it's empty
        self._apply_filter()

    def set_query(self, query):
        self.query = (query or "").strip().lower()
        self._apply_filter()

    def set_channels(self, channels, empty_text=""):
        # Kept as the same list object, not a copy: the caches below are
        # keyed on its identity, so a fresh library load is what
        # invalidates them.
        self._all_channels = channels
        self._empty_text = empty_text
        if not self._mode_chosen and getattr(self, "_picked_for", None) is not channels:
            self._pick_default_mode()
            self._picked_for = channels
        self._apply_filter()

    # Ranking: what the person actually watches floats to the top, so the
    # handful of channels that matter aren't buried among thousands.
    #   1. starred channels, A-Z
    #   2. recently watched, most recent first
    #   3. everything else, A-Z
    def _ranked(self, channels):
        lib = self.lib
        fav_ids = {id(c) for c in lib._fav_channels()}
        recent_pos = {id(c): i for i, c in enumerate(lib._recent_channels())}

        def key(c):
            cid = id(c)
            if cid in fav_ids:
                return (0, 0, (c.get("name") or "").lower())
            if cid in recent_pos:
                return (1, recent_pos[cid], "")
            return (2, 0, (c.get("name") or "").lower())
        return sorted(channels, key=key)

    def _guide_pool(self):
        """Every channel that has ANY programme data — the only ones a TV
        guide can say something about. Cached until the channel list or
        the EPG is replaced, since it means checking all of them."""
        lib = self.lib
        stamp = (id(self._all_channels), len(self._all_channels),
                 id(lib.epg), len(lib.epg))
        if self._pool_cache and self._pool_cache[0] == stamp:
            return self._pool_cache[1]
        quick = lib._epg_quick_key
        pool = [c for c in self._all_channels if quick(c) is not None]
        self._pool_cache = (stamp, pool)
        return pool

    def _mine(self):
        lib = self.lib
        seen, mine = set(), []
        for c in list(lib._fav_channels()) + list(lib._recent_channels())[:self.RECENT_LIMIT]:
            if id(c) not in seen:
                seen.add(id(c))
                mine.append(c)
        return self._ranked(mine)

    def _with_guide(self, channels):
        quick = self.lib._epg_quick_key
        return [c for c in channels if quick(c) is not None]

    def _channels_for(self, mode):
        lib = self.lib
        if mode == "mine":
            return self._mine()
        if mode == "sport":
            return self._ranked(self._with_guide(lib._collection("Sports")))
        pool = self._guide_pool()
        if self.category_id:
            cid = str(self.category_id)
            pool = [c for c in pool if str(c.get("category_id", "")) == cid]
        return self._ranked(pool)

    def _pick_default_mode(self):
        """First time in: land on the person's own channels if they have
        any, otherwise sport, otherwise everything — so a brand-new
        install (nothing starred, nothing watched yet) still opens onto
        something useful instead of an empty screen."""
        for mode in ("mine", "sport", "all"):
            if self._channels_for(mode):
                self.mode = mode
                return
        self.mode = "mine"

    def _apply_filter(self, reset_scroll=True):
        lib = self.lib
        epg_ready = bool(lib.epg)
        n_all = len(self._all_channels)

        if self.query:
            # A search looks everywhere — someone typing a channel name
            # wants that channel, not just the ones already in their list.
            pool = self._guide_pool()
            self.channels = self._ranked([c for c in pool
                                          if self.query in (c.get("name") or "").lower()])
            sub = f'Searching every channel that has a guide for "{self.query}"'
            empty = f'No channel with a guide matches "{self.query}".'
        else:
            self.channels = self._channels_for(self.mode)
            sub = {"mine": "Your starred channels first, then what you've watched lately",
                   "sport": "Sport channels that have a guide, your favourites first",
                   "all": "Every channel that has a guide, your favourites first"}[self.mode]
            if self.mode == "mine":
                empty = ("Nothing here yet. Star a channel with the \u2606 on its card, or "
                         "watch a few, and they'll appear here. Try Sport or All channels "
                         "in the meantime.")
            elif not epg_ready:
                empty = ("The guide information hasn't finished downloading yet — it loads "
                         "in the background after the app starts. Give it a minute and "
                         "click this tab again.")
            else:
                empty = "No channels with guide information found here."
        if not n_all:
            empty = self._empty_text or "No channels found. Still loading?"

        self.subtitle_label.setText(f"{sub}  \u00b7  {len(self.channels):,} channels"
                                    if self.channels else sub)
        self._empty_message = empty
        for m, btn in self._mode_btns.items():
            btn.setChecked(m == self.mode and not self.query)
        self.filter_chip.setVisible(self.mode == "all" and not self.query)
        # Nothing to redraw if it's the same channels over the same hours
        # with the same guide data as what's on screen already.
        sig = ([id(c) for c in self.channels], self._window_start,
               id(lib.epg), len(lib.epg), empty)
        if sig == getattr(self, "_built_sig", None) and (self._row_widgets or not self.channels):
            self._update_now_line()
            return
        self._built_sig = sig
        self._rebuild()
        if reset_scroll:
            self.timeline_scroll.verticalScrollBar().setValue(0)

    def refresh(self):
        self._apply_filter(reset_scroll=False)


    # ── build ────────────────────────────────────────────────────
    def _rebuild(self):
        for w in self._row_widgets + self._label_widgets:
            w.setParent(None)
            w.deleteLater()
        self._row_widgets = []
        self._label_widgets = []
        self._built = 0
        if self._now_line is not None:
            self._now_line.setParent(None)
            self._now_line.deleteLater()
        self._now_line = None

        if not self.channels:
            self.empty_label.setText(getattr(self, "_empty_message", "") or "No channels to show.")
            self.empty_label.show()
            self.sidebar_scroll.hide()
            self.timeline_scroll.hide()
            self.timeline_holder.resize(1, 1)
            self.sidebar_holder.resize(self.SIDEBAR_W, 1)
            return
        self.empty_label.hide()
        self.sidebar_scroll.show()
        self.timeline_scroll.show()

        self._window_end = self._window_start + timedelta(hours=self.WINDOW_HOURS)
        self._total_w = int(self.WINDOW_HOURS * 60 * self.PX_PER_MIN)

        # Full size set immediately from the complete channel count, even
        # though only the first batch of actual row widgets gets built —
        # this is what makes the scrollbar correctly reflect the whole
        # list right away, which is what _maybe_more() needs to detect
        # "near the bottom" and load further batches as the person
        # actually scrolls, exactly like LazyGrid already does for the
        # channel/poster grids. Building only a fixed first batch instead
        # of all rows at once is what keeps this fast regardless of
        # whether the person's provider has 50 channels or five thousand.
        total_h = self.RULER_H + len(self.channels) * self.ROW_H
        self.timeline_holder.resize(self._total_w, total_h)
        self.sidebar_holder.resize(self.SIDEBAR_W, total_h)

        self._build_ruler()
        self._build_batch()

    def _build_batch(self):
        end = min(self._built + self.BATCH, len(self.channels))
        for i in range(self._built, end):
            ch = self.channels[i]
            y = self.RULER_H + i * self.ROW_H

            # A button, not a label: clicking a channel's name watches it,
            # which is the only way in for a channel that has no guide
            # data (so no block of its own to click), and a natural thing
            # to try for anyone who isn't used to the interface.
            full_name = ch.get("name", "Unknown")
            name_lbl = QPushButton("", self.sidebar_holder)
            name_lbl.setObjectName("GuideChannelName")
            name_lbl.setGeometry(0, y, self.SIDEBAR_W, self.ROW_H)
            name_lbl.setCursor(Qt.PointingHandCursor)
            name_lbl.setFocusPolicy(Qt.NoFocus)
            name_lbl.ensurePolished()
            elided = name_lbl.fontMetrics().elidedText(
                full_name, Qt.ElideRight,
                self.SIDEBAR_W - (64 if core.XtreamAPI.has_catchup(ch) else 24))
            name_lbl.setText(elided)
            name_lbl.setToolTip(full_name if elided != full_name else "Watch " + full_name)
            name_lbl.clicked.connect(partial(self.activated.emit, ch))
            name_lbl.show()
            self._label_widgets.append(name_lbl)
            if core.XtreamAPI.has_catchup(ch):
                # The provider keeps this channel's recent programmes.
                cu = QPushButton("\u21ba", self.sidebar_holder)
                cu.setObjectName("GuideCatchup")
                cu.setToolTip("Catch-up: watch earlier programmes")
                cu.setCursor(Qt.PointingHandCursor)
                cu.setFocusPolicy(Qt.NoFocus)
                cu.setGeometry(self.SIDEBAR_W - 44, y + (self.ROW_H - 34) // 2, 36, 34)
                cu.clicked.connect(partial(self.catchup_list_requested.emit, ch))
                cu.show()
                self._label_widgets.append(cu)

            row = self._build_row(ch, self._window_end, self._total_w)
            row.move(0, y)
            row.show()
            self._row_widgets.append(row)
        self._built = end
        self._update_now_line()

    def _build_ruler(self):
        ruler = QWidget(self.timeline_holder)
        ruler.setFixedSize(self._total_w, self.RULER_H)
        ruler.setObjectName("GuideRuler")
        ruler.move(0, 0)
        t = self._window_start
        while t < self._window_end:
            x = int((t - self._window_start).total_seconds() / 60 * self.PX_PER_MIN)
            lbl = QLabel(_hm(t), ruler)
            lbl.setObjectName("GuideRulerLabel")
            lbl.move(x + 4, 4)
            lbl.show()
            t += timedelta(minutes=30)
        ruler.show()
        self._row_widgets.append(ruler)   # cleared alongside rows on rebuild

    def _build_row(self, channel, window_end, total_w):
        row = QWidget(self.timeline_holder)
        row.setFixedSize(total_w, self.ROW_H)
        row.setObjectName("GuideRow")
        now = datetime.now(timezone.utc)
        entries = self.lib._epg_range(channel, self._window_start, window_end)
        if not entries:
            # Say so, rather than leave a blank stripe that looks like a
            # rendering fault.
            note = QLabel("No guide information for this time", row)
            note.setObjectName("GuideNoData")
            note.adjustSize()
            note.move(12, (self.ROW_H - note.height()) // 2)
            note.show()
        for entry in entries:
            start = max(entry["start"], self._window_start)
            stop = min(entry["stop"], window_end)
            x = int((start - self._window_start).total_seconds() / 60 * self.PX_PER_MIN)
            w = max(30, int((stop - start).total_seconds() / 60 * self.PX_PER_MIN) - 3)
            is_airing = entry["start"] <= now < entry["stop"]
            block = QPushButton(entry["title"], row)
            block.setObjectName("GuideBlockAiring" if is_airing else "GuideBlock")
            block.setGeometry(x, 4, w, self.ROW_H - 8)
            block.setCursor(Qt.PointingHandCursor)
            block.setFocusPolicy(Qt.NoFocus)
            span = f"{_hm(entry['start'])}\u2013{_hm(entry['stop'])}"
            block.setToolTip(f"{span}  {entry['title']}")
            archive_days = int(channel.get("tv_archive_duration") or 0) \
                if core.XtreamAPI.has_catchup(channel) else 0
            archived = archive_days > 0 and \
                now - timedelta(days=archive_days) <= entry["start"] < now
            if is_airing and archived:
                block.clicked.connect(partial(self._airing_menu, block, channel, entry))
            elif is_airing:
                block.clicked.connect(partial(self.activated.emit, channel))
            elif archived and entry["stop"] <= now:
                block.setText("\u21ba " + entry["title"])
                block.setToolTip(f"{span}  {entry['title']}\nCatch-up: click to watch")
                block.clicked.connect(partial(self.catchup_requested.emit, channel, entry))
            elif entry["start"] > now:
                # Not on yet: offer to record it.
                block.clicked.connect(partial(self._future_menu, block, channel, entry, span))
            else:
                block.clicked.connect(partial(self._show_info, block, span, entry["title"]))
            if entry["stop"] > now:
                # Right-click anything still to come (or on now): Record.
                block.setContextMenuPolicy(Qt.CustomContextMenu)
                block.customContextMenuRequested.connect(
                    partial(self._record_menu, block, channel, entry))
            block.show()
        return row

    def _future_menu(self, block, channel, entry, span):
        menu = QMenu(self)
        head = menu.addAction(f"{span}  {entry['title']}")
        head.setEnabled(False)
        menu.addSeparator()
        menu.addAction("\u25cf  Record this programme",
                       lambda: self.record_requested.emit(channel, entry))
        menu.exec(block.mapToGlobal(QPoint(0, block.height())))

    def _record_menu(self, block, channel, entry, _pos=None):
        menu = QMenu(self)
        on_now = entry["start"] <= datetime.now(timezone.utc)
        menu.addAction("\u25cf  Record the rest of this" if on_now else "\u25cf  Record this programme",
                       lambda: self.record_requested.emit(channel, entry))
        menu.exec(QCursor.pos())

    def _airing_menu(self, block, channel, entry):
        menu = QMenu(self)
        menu.addAction("\u25b6  Watch live", lambda: self.activated.emit(channel))
        menu.addAction("\u25cf  Record the rest of this",
                       lambda: self.record_requested.emit(channel, entry))
        menu.addAction("\u21ba  Watch from the start",
                       lambda: self.catchup_requested.emit(channel, entry))
        menu.addAction("Earlier programmes\u2026", lambda: self.catchup_list_requested.emit(channel))
        menu.exec(block.mapToGlobal(QPoint(0, block.height())))

    def _show_info(self, widget, span, title):
        # Hasn't aired yet, so there's nothing to tune into — just a
        # lightweight way to see the full time and title without
        # cramming both into the block's own visible label.
        from PySide6.QtGui import QCursor
        from PySide6.QtWidgets import QToolTip
        QToolTip.showText(QCursor.pos(), f"{span}\n{title}", widget)

    def _update_now_line(self):
        if not self.channels:
            return
        window_end = self._window_start + timedelta(hours=self.WINDOW_HOURS)
        now = datetime.now(timezone.utc)
        if self._now_line is None:
            self._now_line = QFrame(self.timeline_holder)
            self._now_line.setObjectName("GuideNowLine")
        if not (self._window_start <= now <= window_end):
            self._now_line.hide()
            return
        x = int((now - self._window_start).total_seconds() / 60 * self.PX_PER_MIN)
        self._now_line.setGeometry(x, 0, 2, self.timeline_holder.height())
        self._now_line.show()
        self._now_line.raise_()


# ══════════════════════════════════════════════════════════════════
# Lazy vertical grid
# ══════════════════════════════════════════════════════════════════
class RecordingsView(QWidget):
    """Recording now, scheduled and finished recordings."""

    back = Signal()
    play_requested = Signal(object)          # recording entry
    stop_requested = Signal(str)             # id
    remove_requested = Signal(str, bool)     # id, delete the file too

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)
        top = QHBoxLayout()
        back_btn = QPushButton("\u2039  Guide", self)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back.emit)
        top.addWidget(back_btn)
        top.addStretch(1)
        folder_btn = QPushButton("Open recordings folder", self)
        folder_btn.setObjectName("Ghost")
        folder_btn.setCursor(Qt.PointingHandCursor)
        folder_btn.clicked.connect(self._open_folder)
        top.addWidget(folder_btn)
        lay.addLayout(top)
        lay.addSpacing(10)
        title = QLabel("Recordings", self)
        title.setObjectName("ScreenTitle")
        lay.addWidget(title)
        self.subtitle = QLabel("", self)
        self.subtitle.setObjectName("Muted")
        self.subtitle.setWordWrap(True)
        lay.addWidget(self.subtitle)
        lay.addSpacing(12)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        holder.setObjectName("Clear")
        self.rows = QVBoxLayout(holder)
        self.rows.setContentsMargins(0, 0, 0, 30)
        self.rows.setSpacing(6)
        self.rows.addStretch(1)
        self.scroll.setWidget(holder)
        lay.addWidget(self.scroll, 1)
        self._sizes = {}

    def _open_folder(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        folder = fluxtv_record.default_folder()
        os.makedirs(folder, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def set_sizes(self, sizes):
        """Bytes written so far, for recordings in progress."""
        self._sizes = dict(sizes)

    def refresh(self):
        while self.rows.count() > 1:
            item = self.rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        items = fluxtv_record.load()
        self.subtitle.setText(
            f"Saved in {fluxtv_record.default_folder()}  \u00b7  Flux Media needs to be open "
            "for a scheduled recording to happen. Record from the Guide (click a programme "
            "that's still to come, or right-click one that's on) or press R while watching.")
        groups = (("Recording now", [r for r in items if r["status"] == "recording"]),
                  ("Coming up", [r for r in items if r["status"] == "scheduled"]),
                  ("Finished", [r for r in reversed(items) if r["status"] in ("done", "failed", "missed")]))
        if not items:
            note = QLabel("Nothing recorded yet.", self)
            note.setObjectName("Muted")
            self.rows.insertWidget(self.rows.count() - 1, note)
        for heading, rows in groups:
            if not rows:
                continue
            head = QLabel(heading, self)
            head.setObjectName("ShelfTitle")
            self.rows.insertWidget(self.rows.count() - 1, head)
            for r in rows:
                self.rows.insertWidget(self.rows.count() - 1, self._row(r))

    def _row(self, r):
        frame = QFrame(self)
        frame.setObjectName("EpisodeRow")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 10, 12, 10)
        lay.setSpacing(12)
        start, stop = time.localtime(r["start"]), time.localtime(r["stop"])
        day = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")[start.tm_wday]
        when = f"{day} {start.tm_mday}  {time.strftime('%H:%M', start)}\u2013{time.strftime('%H:%M', stop)}"
        size = self._sizes.get(r["id"], r.get("bytes", 0))
        extra = {"recording": f"\u25cf recording \u00b7 {size / 1048576:.0f} MB",
                 "scheduled": "scheduled",
                 "done": f"{size / 1048576:.0f} MB",
                 "failed": f"failed \u2014 {r.get('error') or 'no picture received'}",
                 "missed": "missed (Flux Media wasn't open)"}.get(r["status"], r["status"])
        text = QLabel(f"<b>{html_escape(r['title'])}</b>   \u00b7   {html_escape(r['channel'])}"
                      f"<br><span style='color:{C.dim}'>{when}   \u00b7   {extra}</span>", frame)
        text.setTextFormat(Qt.RichText)
        lay.addWidget(text, 1)

        def button(label, name, fn):
            b = QPushButton(label, frame)
            b.setObjectName(name)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False: fn())
            lay.addWidget(b)
        if r["status"] == "recording":
            button("\u25b6  Watch", "Ghost", lambda: self.play_requested.emit(r))
            button("\u25a0  Stop", "Primary", lambda: self.stop_requested.emit(r["id"]))
        elif r["status"] == "scheduled":
            button("Cancel", "Ghost", lambda: self.remove_requested.emit(r["id"], False))
        else:
            if r["status"] == "done" or os.path.exists(r["file"]):
                button("\u25b6  Play", "Primary", lambda: self.play_requested.emit(r))
            button("Delete", "Ghost", lambda: self.remove_requested.emit(r["id"], True))
        return frame


class CatchupView(QWidget):
    """A channel's earlier programmes from the provider's archive, newest
    day first; click one to watch it from the start."""

    back = Signal()
    play_requested = Signal(object, object)       # channel, programme

    def __init__(self, parent=None):
        super().__init__(parent)
        self.channel = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)
        top = QHBoxLayout()
        back_btn = QPushButton("\u2039  Guide", self)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back.emit)
        top.addWidget(back_btn)
        top.addStretch(1)
        lay.addLayout(top)
        lay.addSpacing(10)
        self.title = QLabel("", self)
        self.title.setObjectName("ScreenTitle")
        lay.addWidget(self.title)
        self.subtitle = QLabel("", self)
        self.subtitle.setObjectName("Muted")
        self.subtitle.setWordWrap(True)
        lay.addWidget(self.subtitle)
        lay.addSpacing(12)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        holder.setObjectName("Clear")
        self.rows = QVBoxLayout(holder)
        self.rows.setContentsMargins(0, 0, 0, 30)
        self.rows.setSpacing(6)
        self.rows.addStretch(1)
        self.scroll.setWidget(holder)
        lay.addWidget(self.scroll, 1)

    def _clear(self):
        while self.rows.count() > 1:
            item = self.rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def show_loading(self, channel):
        self.channel = channel
        self.title.setText(f"Catch-up \u00b7 {channel.get('name', '')}")
        self.subtitle.setText("Getting this channel's earlier programmes from your provider\u2026")
        self._clear()

    def show_listings(self, channel, listings, error=""):
        if channel is not self.channel:
            return
        self._clear()
        if error:
            self.subtitle.setText(f"Couldn't get the catch-up list: {error}")
            return
        now = datetime.now(timezone.utc)
        days = int(channel.get("tv_archive_duration") or 0)
        past = [e for e in listings
                if now - timedelta(days=days) <= e["start"] < now
                and (e.get("archive", True) or e["stop"] > now)]
        if not past:
            self.subtitle.setText("Your provider has nothing recorded for this channel right now.")
            return
        self.subtitle.setText(f"The last {days} day{'s' if days != 1 else ''} your provider keeps "
                              "\u2014 click a programme to watch it from the start.")
        today = datetime.now().date()
        current_day = None
        for entry in reversed(past):
            local = entry["start"].astimezone()
            if local.date() != current_day:
                current_day = local.date()
                gap = (today - current_day).days
                weekday = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
                           "Saturday", "Sunday")[current_day.weekday()]
                label = "Today" if gap == 0 else "Yesterday" if gap == 1 else \
                    f"{weekday} {current_day.day}"
                head = QLabel(label, self)
                head.setObjectName("ShelfTitle")
                self.rows.insertWidget(self.rows.count() - 1, head)
            airing = entry["stop"] > now
            text = f"{_hm(entry['start'])}\u2013{_hm(entry['stop'])}    {entry['title']}" + \
                ("    (on now \u2014 from the start)" if airing else "")
            row = QPushButton(text, self)
            row.setObjectName("GuideBlockAiring" if airing else "GuideBlock")
            row.setCursor(Qt.PointingHandCursor)
            row.setMinimumHeight(48)
            row.setStyleSheet("text-align: left; padding-left: 16px;")
            if entry.get("description"):
                row.setToolTip(entry["description"][:400])
            row.clicked.connect(partial(self.play_requested.emit, channel, entry))
            self.rows.insertWidget(self.rows.count() - 1, row)
        self.scroll.verticalScrollBar().setValue(0)
