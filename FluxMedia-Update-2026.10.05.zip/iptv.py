#!/usr/bin/env python3
"""
FluxTV — Qt presentation layer.

This module draws the interface and nothing else. Every provider call,
credential read, EPG lookup, favourite and cache access goes through
fluxtv_core, which holds the implementations already proven against a live
provider. If something here is wrong, the engine is unaffected.

Stages present: application shell, navigation, login, home screen,
horizontal shelves, channel cards, cache-first loading, background refresh.
"""

from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
import fluxtv_perf
import fluxtv_backup
import fluxtv_details
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (ClockLabel, IconButton, LOGOS, POOL, PlaybackTracker, VideoSurface, _cleanup_temp_file, _clear_native_window_black, _format_hms, _hm, _now_next, _write_click_input_conf, addon_hero_picks, background, is_window_embedding_supported, logo_pixmap, mpv_ipc_command, show_dialog)
from fluxtv_home_ui import (HomeView)
from fluxtv_guide_ui import (CatchupView, EpgGuideScreen, RecordingsView)
from fluxtv_library_ui import (AddonDetailView, ChannelGridScreen, DiscoverView, LibraryView, MovieDetailView, PosterGridScreen, SeriesDetailView)
from fluxtv_settings_ui import (LoginView, SettingsView)
from fluxtv_music_ui import (MiniPlayer, MusicController, MusicView, NowPlayingView, PlaylistView)


POOL.setMaxThreadCount(4)


class PlayerView(QWidget):
    """Embedded playback screen: a video surface with ONE floating
    control panel that fades in/out together with mouse activity —
    not a separate top bar and bottom bar.

    Every pixel this panel paints is fully opaque. An earlier version
    tried a fully transparent, no-background "just text and icons
    floating on the video" look, matching Stremio's own visual style —
    but on this app's specific setup (MPV's video embedded via a native
    X11 window, most likely without a compositing window manager in the
    loop), a translucent widget stacked above that native window doesn't
    correctly alpha-blend with it — without a compositor to do that
    blend, translucent Qt content over a foreign native window just
    doesn't render at all, rather than showing through cleanly. A fully
    opaque panel needs no such blending — it just overwrites pixels
    directly — which is the one approach confirmed to actually render
    correctly on this hardware. The panel is inset from the screen edges
    and rounded, so it still reads as "controls floating over the video"
    rather than "a bar spanning the screen", without needing any
    transparency to achieve that.
    """

    back_requested = Signal()
    play_pause_requested = Signal()
    seek_requested = Signal(float)          # absolute seconds
    volume_changed = Signal(int)            # 0-100
    mute_toggle_requested = Signal()
    fullscreen_toggle_requested = Signal()

    HIDE_DELAY_MS = 5000
    PANEL_MARGIN = 22   # inset from the left/right/bottom screen edges
    # Sized for the current, deliberately large title/subtitle/time text
    # (title 22px + subtitle 18px stacked alone need real room) — a
    # smaller PANEL_H here was exactly what caused the title and
    # subtitle to visibly overlap the first time these were enlarged.
    PANEL_H = 152

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("PlayerScreen")
        self.setMouseTracking(True)
        self._is_live = False
        self._is_paused = False
        self._seeking = False
        self._controls_visible = True

        self.video = VideoSurface(self)

        # ── one unified, opaque, rounded control panel ──────────────
        self.panel = QFrame(self)
        self.panel.setObjectName("PlayerPanel")
        self.panel.setMouseTracking(True)
        pv = QVBoxLayout(self.panel)
        pv.setContentsMargins(20, 12, 20, 14)
        pv.setSpacing(6)

        # Row 1: back + title/subtitle (left), live badge + fullscreen (right)
        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        self.back_btn = QPushButton("\u2039", self.panel)
        self.back_btn.setObjectName("PlayerBtn")
        self.back_btn.setCursor(Qt.PointingHandCursor)
        self.back_btn.setFocusPolicy(Qt.NoFocus)
        self.back_btn.setFixedSize(30, 30)
        self.back_btn.clicked.connect(self.back_requested.emit)
        top_row.addWidget(self.back_btn)

        title_box = QVBoxLayout()
        title_box.setSpacing(0)
        self.title_label = QLabel("", self.panel)
        self.title_label.setObjectName("PlayerTitle")
        title_box.addWidget(self.title_label)
        self.subtitle_label = QLabel("", self.panel)
        self.subtitle_label.setObjectName("PlayerSub")
        title_box.addWidget(self.subtitle_label)
        top_row.addLayout(title_box, 1)

        self.live_badge = QLabel("\u25cf LIVE", self.panel)
        self.live_badge.setObjectName("LiveBadge")
        self.live_badge.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.live_badge.hide()
        top_row.addWidget(self.live_badge, 0, Qt.AlignVCenter)

        self.fs_btn = QPushButton("\u26f6", self.panel)
        self.fs_btn.setObjectName("PlayerBtn")
        self.fs_btn.setCursor(Qt.PointingHandCursor)
        self.fs_btn.setFocusPolicy(Qt.NoFocus)
        self.fs_btn.setFixedSize(30, 30)
        self.fs_btn.clicked.connect(self.fullscreen_toggle_requested.emit)
        top_row.addWidget(self.fs_btn, 0, Qt.AlignVCenter)
        pv.addLayout(top_row)

        # Row 2: position -- seek bar -- duration
        seek_row = QHBoxLayout()
        seek_row.setSpacing(10)
        self.pos_label = QLabel("0:00", self.panel)
        self.pos_label.setObjectName("PlayerTime")
        self.pos_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        seek_row.addWidget(self.pos_label)

        self.seek = QSlider(Qt.Horizontal, self.panel)
        self.seek.setObjectName("PlayerSeek")
        self.seek.setRange(0, 1000)
        self.seek.sliderPressed.connect(self._on_seek_pressed)
        self.seek.sliderReleased.connect(self._on_seek_released)
        seek_row.addWidget(self.seek, 1)

        self.dur_label = QLabel("0:00", self.panel)
        self.dur_label.setObjectName("PlayerTime")
        self.dur_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        seek_row.addWidget(self.dur_label)

        self.live_dot = QLabel("\u25cf LIVE", self.panel)
        self.live_dot.setObjectName("LiveBadge")
        self.live_dot.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.live_dot.hide()
        seek_row.addWidget(self.live_dot)
        pv.addLayout(seek_row)

        # Row 3: play/pause, mute + volume
        controls_row = QHBoxLayout()
        controls_row.setSpacing(10)
        self.play_btn = IconButton("pause", self.panel)
        self.play_btn.setObjectName("PlayerBtnBig")
        self.play_btn.setCursor(Qt.PointingHandCursor)
        self.play_btn.setFocusPolicy(Qt.NoFocus)
        self.play_btn.setFixedSize(34, 34)
        self.play_btn.clicked.connect(self.play_pause_requested.emit)
        controls_row.addWidget(self.play_btn)

        self.mute_btn = IconButton("volume", self.panel)
        self.mute_btn.setObjectName("PlayerBtn")
        self.mute_btn.setCursor(Qt.PointingHandCursor)
        self.mute_btn.setFocusPolicy(Qt.NoFocus)
        self.mute_btn.setFixedSize(28, 28)
        self.mute_btn.clicked.connect(self.mute_toggle_requested.emit)
        controls_row.addWidget(self.mute_btn)

        self.volume = QSlider(Qt.Horizontal, self.panel)
        self.volume.setObjectName("PlayerVolume")
        self.volume.setRange(0, 100)
        self.volume.setValue(100)
        self.volume.setFixedWidth(80)
        self.volume.valueChanged.connect(self.volume_changed.emit)
        controls_row.addWidget(self.volume)
        controls_row.addStretch(1)
        pv.addLayout(controls_row)

        self.video.activity_callback = self.show_controls
        # Single click's play/pause toggle is handled by MPV itself now
        # (see _write_click_input_conf), read back here via the same IPC
        # poll everything else already uses — not wired through Qt's own
        # click_callback, to avoid a real double-toggle risk: if Qt ever
        # did also receive that same click on some setup, its own
        # (deliberately debounced, ~300ms-delayed) toggle would fire
        # right after MPV's immediate one and instantly undo it.
        self.video.dblclick_callback = self.fullscreen_toggle_requested.emit

        self._hide_timer = QTimer(self)
        self._hide_timer.setInterval(self.HIDE_DELAY_MS)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._hide_controls)

        # Belt-and-braces: poll the OS cursor position directly rather
        # than rely solely on Qt receiving mouse-move events for this
        # area. A widget showing a foreign process's video is exactly
        # the case where event delivery through the normal Qt/X11 path
        # is least certain — polling the actual pointer position side-
        # steps that question entirely.
        self._last_cursor_pos = None
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(200)
        self._poll_timer.timeout.connect(self._poll_cursor)
        self._poll_timer.start()

        self.show_controls()

    def _poll_cursor(self):
        from PySide6.QtGui import QCursor
        pos = QCursor.pos()
        if self._last_cursor_pos is not None and pos != self._last_cursor_pos:
            self.show_controls()
        self._last_cursor_pos = pos

    # ── layout ───────────────────────────────────────────────────
    def _place_panel(self):
        """Position the video surface and the control panel from this
        page's CURRENT size. Kept in one place, and called whenever the
        size changes, the page is shown, or the controls are about to be
        shown, so the panel's position never depends on which of those
        happened to run last."""
        w, h = self.width(), self.height()
        self.video.setGeometry(0, 0, w, h)
        m = self.PANEL_MARGIN
        self.panel.setGeometry(m, h - self.PANEL_H - m, w - 2 * m, self.PANEL_H)
        self.panel.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._place_panel()

    def showEvent(self, event):
        super().showEvent(event)
        self._place_panel()

    def _verify_layout(self):
        """Last line of defence, run just before the controls appear:
        if this page isn't the size of the area it lives in, or the panel
        isn't where it should be for the page's size, put both right and
        note it in a small log. If the control bar has ever been seen in
        the wrong place, this both fixes it on the spot and leaves a
        record of what the sizes were, instead of relying on anyone
        having noticed and reproduced it."""
        if not self.isVisible():
            # Not on screen (this also runs once while the page is still
            # being constructed, before it has any real size) — there is
            # no meaningful geometry to judge yet.
            return
        problems = []
        parent = self.parentWidget()
        if parent is not None and self.geometry() != parent.rect():
            problems.append(f"page {self.geometry().getRect()} != stack {parent.rect().getRect()}")
            self.setGeometry(parent.rect())
        m = self.PANEL_MARGIN
        want_top = self.height() - self.PANEL_H - m
        if self.panel.geometry().y() != want_top:
            problems.append(f"panel y={self.panel.geometry().y()} want {want_top} (page h={self.height()})")
        if problems:
            self._place_panel()
            self._log_layout_problem("; ".join(problems))

    def _log_layout_problem(self, text):
        try:
            os.makedirs(core.APP_DIR, exist_ok=True)
            path = os.path.join(core.APP_DIR, "layout_debug.log")
            if os.path.exists(path) and os.path.getsize(path) > 64 * 1024:
                return                      # never let a diagnostic grow without bound
            win = self.window()
            with open(path, "a") as fh:
                fh.write(f"{datetime.now().isoformat(timespec='seconds')}  {text}  "
                         f"| window {win.width()}x{win.height()} fullscreen={win.isFullScreen()}\n")
        except Exception:
            pass

    # ── content ──────────────────────────────────────────────────
    def set_now_playing(self, title, subtitle="", is_live=False):
        self._is_live = is_live
        self.title_label.setText(title)
        self.subtitle_label.setText(subtitle)
        self.subtitle_label.setVisible(bool(subtitle))
        self.live_badge.setVisible(is_live)
        self.live_dot.setVisible(is_live)
        self.seek.setVisible(not is_live)
        self.pos_label.setVisible(not is_live)
        self.dur_label.setVisible(not is_live)
        self.seek.setValue(0)
        self.pos_label.setText("0:00")
        self.dur_label.setText("0:00")
        self.play_btn.set_kind("pause")   # assume playing on launch

    def update_progress(self, position, duration):
        if self._seeking or self._is_live or duration <= 0:
            return
        self.seek.setValue(int(min(1.0, position / duration) * 1000))
        self.pos_label.setText(_format_hms(position))
        self.dur_label.setText(_format_hms(duration))

    def update_state(self, paused, volume, muted):
        # Stremio's real player never auto-hides its controls while
        # paused — only while actually playing — which is a small but
        # noticeable difference from "just don't hide during an active
        # seek drag": resuming playback here explicitly restarts the
        # auto-hide countdown fresh, rather than leaving a stale timer
        # from whenever the pause happened to fire.
        was_paused = self._is_paused
        self._is_paused = paused
        if was_paused and not paused:
            self.show_controls()
        self.play_btn.set_kind("play" if paused else "pause")
        if not self.volume.isSliderDown():
            self.volume.blockSignals(True)
            self.volume.setValue(volume)
            self.volume.blockSignals(False)
        self.mute_btn.set_kind("mute" if muted else "volume")

    def _on_seek_pressed(self):
        self._seeking = True

    def _on_seek_released(self):
        self._seeking = False
        if self.dur_label.text() != "0:00":
            duration = self._duration_seconds()
            if duration > 0:
                target = (self.seek.value() / 1000.0) * duration
                self.seek_requested.emit(target)

    def _duration_seconds(self):
        parts = self.dur_label.text().split(":")
        parts = [int(p) for p in parts]
        while len(parts) < 3:
            parts.insert(0, 0)
        h, m, s = parts
        return h * 3600 + m * 60 + s

    # ── auto-hide ────────────────────────────────────────────────
    def show_controls(self):
        self._controls_visible = True
        self._verify_layout()
        self.panel.show()
        self.setCursor(Qt.ArrowCursor)
        self.video.setCursor(Qt.ArrowCursor)
        self._hide_timer.start()

    def _hide_controls(self):
        if self.seek.isSliderDown():
            self._hide_timer.start()
            return
        if self._is_paused:
            # Matches the real Stremio player exactly: controls only
            # auto-hide while something is actually playing. Left
            # visible and the timer left stopped rather than endlessly
            # re-armed — update_state() restarts it the moment playback
            # actually resumes.
            return
        self._controls_visible = False
        self.panel.hide()
        self.setCursor(Qt.BlankCursor)
        self.video.setCursor(Qt.BlankCursor)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if not self._controls_visible:
            self.show_controls()
        else:
            self._hide_timer.start()

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        self.show_controls()

    def keyPressEvent(self, event):
        # Space and Escape are handled by FluxTV's own app-level
        # shortcuts (context-aware there — Space means something
        # different depending on which screen is showing), not here,
        # to avoid both this handler and the global shortcut firing for
        # the same keypress. "F" for fullscreen is local-only since
        # nothing else in the app uses that key.
        if event.key() == Qt.Key_F:
            self.fullscreen_toggle_requested.emit()
            self.show_controls()
            return
        self.show_controls()
        super().keyPressEvent(event)


# ══════════════════════════════════════════════════════════════════
# Main window
# ══════════════════════════════════════════════════════════════════
class WheelRouter(QObject):
    """Scroll wheel / touchpad scrolling that works wherever the pointer is.

    Qt hands a wheel event to the widget under the pointer and only passes
    it up if that widget ignores it — so a scroll that started over a card,
    an episode row, or a sideways shelf on Home either did nothing or
    nudged the shelf instead of moving the page. This sends every vertical
    scroll to the nearest page that can actually scroll vertically.
    The player (wheel = volume) and list views keep their own handling.
    """

    PX_PER_NOTCH = 110
    PAGE_KEYS = (Qt.Key_PageUp, Qt.Key_PageDown, Qt.Key_Home, Qt.Key_End)

    @staticmethod
    def _passthrough(w):
        """Widgets that keep their own wheel/key handling."""
        return isinstance(w, (QAbstractItemView, QSlider, PlayerView,
                              fluxtv_player.StremioPlayerView))

    def _scrollable_from(self, w):
        while w is not None:
            if self._passthrough(w):
                return None
            if (isinstance(w, QScrollArea)
                    and w.verticalScrollBarPolicy() != Qt.ScrollBarAlwaysOff
                    and w.verticalScrollBar().maximum() > 0):
                return w
            w = w.parentWidget()
        return None

    def _page_target(self):
        """The page Page Up/Down should move: whatever is under the
        pointer, else the biggest scrollable area on the current screen."""
        app = self.parent()
        if getattr(app, "screen_name", "") == "player":
            return None
        under = QApplication.widgetAt(QCursor.pos())
        if under is not None and under.window() is app.window():
            target = self._scrollable_from(under)
            if target is not None:
                return target
        screens = getattr(app, "screens", None)
        page = screens.currentWidget() if screens is not None else None
        if page is None:
            return None
        best, best_area = None, 0
        for area in page.findChildren(QScrollArea):
            if (area.isVisible()
                    and area.verticalScrollBarPolicy() != Qt.ScrollBarAlwaysOff
                    and area.verticalScrollBar().maximum() > 0):
                size = area.width() * area.height()
                if size > best_area:
                    best, best_area = area, size
        return best

    def _page_key(self, event):
        target = self._page_target()
        if target is None:
            return False
        bar = target.verticalScrollBar()
        key = event.key()
        if key == Qt.Key_Home:
            bar.setValue(bar.minimum())
        elif key == Qt.Key_End:
            bar.setValue(bar.maximum())
        else:
            step = int(target.viewport().height() * 0.85)
            bar.setValue(bar.value() + (step if key == Qt.Key_PageDown else -step))
        return True

    def eventFilter(self, obj, event):
        if (event.type() == QEvent.KeyPress and event.key() in self.PAGE_KEYS
                and isinstance(obj, QWidget)
                and not (isinstance(obj, QLineEdit)
                         and event.key() in (Qt.Key_Home, Qt.Key_End))):
            w = obj
            while w is not None:
                if self._passthrough(w):
                    return False
                w = w.parentWidget()
            return self._page_key(event)
        if event.type() != QEvent.Wheel or not isinstance(obj, QWidget):
            return False
        pixel, angle = event.pixelDelta(), event.angleDelta()
        dy = pixel.y() if not pixel.isNull() else angle.y() * self.PX_PER_NOTCH / 120
        dx = pixel.x() if not pixel.isNull() else angle.x()
        if not dy or abs(dx) > abs(dy):
            return False
        target = self._scrollable_from(obj)
        if target is None:
            return False
        bar = target.verticalScrollBar()
        bar.setValue(int(bar.value() - dy))
        return True


class _RecordSignals(QObject):
    done = Signal(str, bool, str, int)         # id, ok, error, bytes (from the worker thread)


class _CursorWatch(QObject):
    """While a station is full screen: any mouse movement brings the
    pointer back for another few seconds."""

    def __init__(self, app_window):
        super().__init__(app_window)
        self.win = app_window

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.MouseMove, QEvent.MouseButtonPress, QEvent.Wheel):
            self.win._show_cursor()
            self.win._cursor_timer.start()
        return False


class FluxTV(QWidget):
    """The single application window. Login and the app share it."""

    NAV = [("Home", "home"), ("Live TV", "live"), ("Guide", "guide"),
           ("Sport", "sport"), ("Movies", "movies"), ("Series", "series"),
           ("Debrid", "discover"), ("Music", "music"), ("Favourites", "favourites")]
    NAV_ICONS = {"home": "home", "live": "live", "guide": "guide",
                 "sport": "sport", "movies": "movies", "series": "series",
                 "discover": "discover", "music": "music", "favourites": "favourites"}
    RAIL_W = 128   # sized for a 55" TV across the room

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Flux Media")
        self.resize(1440, 900)
        self.setMinimumSize(1080, 700)

        self.api = None
        self.lib = None
        self.current = None
        self.mpv = None
        self._watchdog = None
        self._tracker = None
        self._embedded = False
        self._ipc_path = None
        self._input_conf_path = None
        # libmpv player (fluxtv_player): video drawn inside our own window
        # with Stremio-style translucent controls. When it isn't available
        # the original separate-MPV-process path below is used instead.
        self._wheel_router = WheelRouter(self)
        QApplication.instance().installEventFilter(self._wheel_router)
        self._libmpv = fluxtv_player.AVAILABLE
        self._session = None
        self._reconnects = 0
        # Live channel changing inside the player: the list being flicked
        # through (whatever list the channel was started from), where we
        # are in it, and the channel before this one for "last channel".
        self._zap_list = []
        self._zap_index = -1
        self._zap_title = ""
        self._zap_pending = None
        self._zapping = False
        self._prev_channel = None
        self._zap_timer = QTimer(self)
        self._zap_timer.setSingleShot(True)
        self._zap_timer.setInterval(450)
        self._zap_timer.timeout.connect(self._commit_zap)
        self._pre_player_screen = "home"
        self._pre_video_window_state = "fullscreen"
        self.screen_name = "home"

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(0, 0, 0, 0)
        self.root.setSpacing(0)

        self.stack = QStackedWidget(self)
        self.root.addWidget(self.stack, 1)

        creds = core.load_credentials()
        if creds and creds.get("server") and creds.get("username") \
                and creds.get("password"):
            self.start_app(core.XtreamAPI(creds["server"], creds["username"],
                                          creds["password"]))
        else:
            self.show_login()

    # ── login ────────────────────────────────────────────────────
    def show_login(self, prefill=None):
        view = LoginView(prefill)
        view.signed_in.connect(lambda api: self.start_app(api))
        self._swap(view)

    def _swap(self, widget):
        while self.stack.count():
            old = self.stack.widget(0)
            pv = getattr(self, "player_view", None)
            if pv is not None and hasattr(pv, "shutdown") and old.isAncestorOf(pv):
                # The libmpv player owns an MPV instance and a GL context;
                # release them properly rather than leaving it to deleteLater.
                pv.shutdown()
            self.stack.removeWidget(old)
            old.deleteLater()
        self.stack.addWidget(widget)
        self.stack.setCurrentWidget(widget)

    # ── app ──────────────────────────────────────────────────────
    def start_app(self, api):
        self.api = api
        self.lib = core.Library(api)
        self._vod_loaded = False
        self._series_loaded = False
        self._vod_fetch_started = False
        self._series_fetch_started = False
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.timeout.connect(self._apply_search)
        self.addons = fluxtv_addons.load_addons()
        shell = self._build_shell()
        self._swap(shell)
        self.restore_cache()          # cached content on screen first
        self._load_home_hero()
        addons = self.addons
        background(lambda: fluxtv_addons.refresh_manifests(addons),
                   lambda a: self.settings_view.set_addons(a), lambda e: None)
        fluxtv_perf.mark("app screens built")
        self._maybe_first_run()
        # Build Live TV, Guide, Movies and Series quietly in the background a
        # little after start-up, so the first visit to each is instant too.
        QTimer.singleShot(8_000, lambda: self._prebuild(["live", "guide", "sport", "movies", "series",
                                                        "favourites"]))
        self.refresh_in_background()  # provider catches up afterwards, one
                                      # request at a time (see the method)
        # No separate test_connection() here: refresh_in_background's own
        # get_categories/get_channels calls already prove the connection,
        # and firing a dedicated check on top of them just adds a fourth
        # near-simultaneous request for no extra information.

    def _build_shell(self):
        shell = QWidget(self)
        lay = QVBoxLayout(shell)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ── top bar: logo · centred search pill · window controls ──
        # Stremio 5 layout: the bar itself is just the page colour; the
        # logo sits above the navigation rail and search is a pill in
        # the middle.
        bar = QFrame(shell)
        bar.setObjectName("TopBar")
        bar.setFixedHeight(96)
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(0, 0, 18, 0)
        bl.setSpacing(6)

        logo_cell = QWidget(bar)
        logo_cell.setFixedWidth(self.RAIL_W)
        lc = QHBoxLayout(logo_cell)
        lc.setContentsMargins(0, 0, 0, 0)
        logo_pix = logo_pixmap(84)
        if not logo_pix.isNull():
            logo_lbl = QLabel(logo_cell)
            logo_lbl.setPixmap(logo_pix)
            logo_lbl.setFixedSize(84, 84)
            logo_lbl.setToolTip("Flux Media")
            lc.addWidget(logo_lbl, 0, Qt.AlignCenter)
        bl.addWidget(logo_cell)
        bl.addSpacing(12)
        self.clock = ClockLabel(bar)
        bl.addWidget(self.clock, 0, Qt.AlignVCenter)
        bl.addStretch(1)

        # Inline search, not a modal dialog.
        self.search_wrap = QFrame(bar)
        self.search_wrap.setObjectName("SearchWrap")
        self.search_wrap.setFixedWidth(520)
        self.search_wrap.setFixedHeight(46)
        sw = QHBoxLayout(self.search_wrap)
        sw.setContentsMargins(18, 0, 16, 0)
        sw.setSpacing(10)
        self.search = QLineEdit(self.search_wrap)
        self.search.setObjectName("SearchField")
        self.search.setPlaceholderText("Search channels, movies and series")
        self.search.textChanged.connect(lambda _: self._search_timer.start(250))
        sw.addWidget(self.search, 1)
        sw.addWidget(IconGlyph("search", 20, self.search_wrap))
        bl.addWidget(self.search_wrap)
        bl.addStretch(1)

        self.fs_toggle_btn = ChromeIconButton("expand", bar,
                                              tip="Toggle fullscreen (F11)")
        self.fs_toggle_btn.clicked.connect(self._fullscreen)
        bl.addWidget(self.fs_toggle_btn)
        # A real close button, right next to the fullscreen toggle —
        # exiting fullscreen doesn't reliably bring back the window
        # manager's own title bar and close button on every setup, so
        # this gives a guaranteed way out that doesn't rely on the OS.
        self.close_btn = ChromeIconButton("close", bar, danger=True,
                                          tip="Close Flux Media (Ctrl+Q)")
        self.close_btn.clicked.connect(self.close)
        bl.addWidget(self.close_btn)
        lay.addWidget(bar)
        self.chrome_top = bar

        # ── navigation rail ─────────────────────────────────────
        rail = QFrame(shell)
        rail.setObjectName("NavRail")
        rail.setFixedWidth(self.RAIL_W)
        rl = QVBoxLayout(rail)
        rl.setContentsMargins(0, 4, 0, 16)
        rl.setSpacing(4)
        self.nav_buttons = {}
        for label, key in self.NAV:
            btn = NavRailButton(self.NAV_ICONS[key], label, rail)
            btn.clicked.connect(partial(self.go, key))
            rl.addWidget(btn, 0, Qt.AlignHCenter)
            self.nav_buttons[key] = btn
        rl.addStretch(1)
        self.settings_btn = NavRailButton("settings", "Settings", rail)
        self.settings_btn.clicked.connect(partial(self.go, "settings"))
        rl.addWidget(self.settings_btn, 0, Qt.AlignHCenter)
        self.nav_buttons["settings"] = self.settings_btn
        rail.installEventFilter(self)
        self._rail = rail
        # go() hides "the divider" along with the other chrome when the
        # player opens; the rail is what now sits in that role.
        self.chrome_divider = rail

        # ── screens ──────────────────────────────────────────────
        self.screens = QStackedWidget(shell)
        self.screen_widgets = {}

        self.home = HomeView(self.lib, shell)
        self.home.activated.connect(self.play)
        self.home.selected.connect(self._select)
        self.home.fav_toggled.connect(self._toggle_fav)
        self.home.hero.open_item.connect(self._open_featured)
        self.home.hero.play_item.connect(self._play_featured)
        self._add_screen("home", self.home)

        self.live = ChannelGridScreen(
            "Live TV", "Browse live channels or search by name",
            self.lib, show_categories=True, parent=shell)
        self._wire_channel_screen(self.live)
        self._add_screen("live", self.live)

        self.guide = EpgGuideScreen(self.lib, parent=shell)
        self.guide.activated.connect(self.play)
        self.guide.catchup_requested.connect(self.play_catchup)
        self.guide.catchup_list_requested.connect(self._open_catchup)
        self.guide.record_requested.connect(self.record_programme)
        self.guide.recordings_requested.connect(partial(self.go, "recordings"))
        self._add_screen("guide", self.guide)
        self.catchup_view = CatchupView(shell)
        self.catchup_view.back.connect(partial(self.go, "guide"))
        self.catchup_view.play_requested.connect(self.play_catchup)
        self._add_screen("catchup", self.catchup_view)
        self.recordings_view = RecordingsView(shell)
        self.recordings_view.back.connect(partial(self.go, "guide"))
        self.recordings_view.play_requested.connect(self._play_recording)
        self.recordings_view.stop_requested.connect(self._stop_recording)
        self.recordings_view.remove_requested.connect(self._remove_recording)
        self._add_screen("recordings", self.recordings_view)
        self._recorders = {}
        self._rec_bytes = {}
        self._rec_signals = _RecordSignals(self)
        self._rec_signals.done.connect(self._recording_finished)
        self._rec_timer = QTimer(self)
        self._rec_timer.setInterval(10_000)
        self._rec_timer.timeout.connect(self._check_recordings)
        self._rec_timer.start()
        QTimer.singleShot(5_000, self._check_recordings)

        self.sport = ChannelGridScreen(
            "Sport", "Live sport channels from your provider",
            self.lib, show_categories=False, parent=shell)
        self._wire_channel_screen(self.sport)
        self._add_screen("sport", self.sport)

        self.favourites = ChannelGridScreen(
            "Favourites", "Channels you've starred",
            self.lib, show_categories=False, parent=shell)
        self._wire_channel_screen(self.favourites)
        self._add_screen("favourites", self.favourites)

        self.movies = PosterGridScreen(
            "Movies", "Browse your VOD library", "\u25b6  Play", parent=shell)
        self.movies.activated.connect(self.play_vod)
        self.movies.opened.connect(self.open_movie_detail)
        self.movies.retry_requested.connect(self.retry_vod)
        self._add_screen("movies", self.movies)

        self.movie_detail = MovieDetailView(shell)
        self.movie_detail.back.connect(self._leave_detail)
        self.movie_detail.play_movie.connect(self.play_vod)
        self.movie_detail.trailer_requested.connect(self._play_trailer)
        self.movie_detail.link_requested.connect(self._open_other_copy)
        self._add_screen("movie_detail", self.movie_detail)

        self.series = PosterGridScreen(
            "Series", "Browse TV series and episodes", "Open", parent=shell)
        self.series.activated.connect(self.open_series)
        self.series.opened.connect(self.open_series)
        self.series.retry_requested.connect(self.retry_series)
        self._add_screen("series", self.series)

        self.series_detail = SeriesDetailView(shell)
        self.series_detail.back.connect(self._leave_detail)
        self.series_detail.play_episode.connect(self.play_episode)
        self.series_detail.trailer_requested.connect(self._play_trailer)
        self.series_detail.link_requested.connect(self._open_other_copy)
        self._add_screen("series_detail", self.series_detail)

        self.discover = DiscoverView(shell)
        self.discover.open_item.connect(self.open_addon)
        self.discover.library_provider = lambda: (fluxtv_stremio.continue_watching(),
                                                  fluxtv_stremio.load_library())
        self.discover.see_all_library.connect(self._show_library)
        self.library_view = LibraryView(shell)
        self.library_view.open_item.connect(self.open_addon)
        self.library_view.back.connect(lambda: self.go("discover"))
        self._add_screen("library", self.library_view)

        fluxtv_youtube.set_cookie_browser(self.lib.settings.get("yt_cookie_browser", ""))
        self.music = MusicController(self)
        self.music.watch_cb = self._watch_youtube
        self.music_view = MusicView(shell)
        self.music_view.set_mode(self.lib.settings.get("music_mode", "listen"))
        self.music_view.play_requested.connect(self._music_play)
        self.music_view.open_now_playing.connect(partial(self.go, "nowplaying"))
        self.music_view.mode_changed.connect(self._music_mode)
        self.music_view.menu_requested.connect(self._music_menu)
        self.music_view.open_playlist.connect(self._open_playlist)
        self.music_view.new_playlist.connect(lambda: self._new_playlist())
        self._add_screen("music", self.music_view)
        self.playlist_view = PlaylistView(shell)
        self.playlist_view.back.connect(partial(self.go, "music"))
        self.playlist_view.play_requested.connect(self._music_play)
        self.playlist_view.menu_requested.connect(self._music_menu)
        self.playlist_view.rename_requested.connect(self._rename_playlist)
        self.playlist_view.delete_requested.connect(self._delete_playlist)
        self._add_screen("playlist", self.playlist_view)
        self.now_playing = NowPlayingView(self.music, shell)
        self.now_playing.back.connect(partial(self.go, "music"))
        self.now_playing.add_current.connect(
            lambda pos: self.music.current and not self.music.is_radio and
            self._playlist_menu([self.music.current], pos))
        self.now_playing.save_queue.connect(self._save_queue)
        self.now_playing.upnext_menu.connect(self._upnext_menu)
        self._add_screen("nowplaying", self.now_playing)
        self.music.track_changed.connect(self.music_view.set_now_playing)
        self.music.track_changed.connect(lambda _t: self._update_mini())
        self.music.track_changed.connect(self._radio_track_changed)
        self.music.state.connect(lambda *_a: self._update_mini())
        self._cursor_timer = QTimer(self)
        self._cursor_timer.setSingleShot(True)
        self._cursor_timer.setInterval(3000)
        self._cursor_timer.timeout.connect(self._hide_cursor)
        self._cursor_watch = _CursorWatch(self)
        self.music.song_title.connect(
            lambda t: self.screen_name != "player" and self.status.setText(f"\u266b  {t}"))
        self.music.state.connect(self._music_state)
        # Keep yt-dlp current (YouTube changes often); used from next start.
        QTimer.singleShot(90_000, lambda: background(fluxtv_youtube.update_if_due,
                                                     lambda _r: None, lambda _e: None))

        self._add_screen("discover", self.discover)
        self.addon_detail = AddonDetailView(shell)
        self.addon_detail.back.connect(self._leave_detail)
        self.addon_detail.streams_requested.connect(self._fetch_addon_streams)
        self.addon_detail.play_stream.connect(self._play_addon)
        self.addon_detail.trailer_requested.connect(self._play_trailer)
        self.addon_detail.link_requested.connect(self._open_other_copy)
        self._provider_index = fluxtv_details.ProviderIndex()
        self._other_copy = {}
        self._add_screen("addon_detail", self.addon_detail)

        self.settings_view = SettingsView(self.lib, self.api, shell)
        self.settings_view.set_addons(self.addons)
        self.settings_view.install_addon_requested.connect(self._install_addon)
        self.settings_view.set_stremio_account(fluxtv_stremio.load_account())
        self.settings_view.stremio_login_requested.connect(self._stremio_login)
        self.settings_view.stremio_sync_requested.connect(self._stremio_sync)
        self.settings_view.stremio_logout_requested.connect(self._stremio_logout)
        cfg = fluxtv_trakt.load()
        self.settings_view.set_trakt_state("on" if fluxtv_trakt.connected() else "off", cfg)
        self.settings_view.trakt_connect_requested.connect(self._trakt_connect)
        self.settings_view.trakt_cancel_requested.connect(self._trakt_cancel)
        self.settings_view.trakt_sync_requested.connect(self._trakt_sync)
        self.settings_view.trakt_disconnect_requested.connect(self._trakt_disconnect)
        self._trakt_timer = QTimer(self)
        self._trakt_timer.setSingleShot(True)
        self._trakt_timer.timeout.connect(self._trakt_poll)
        self._trakt_device = None
        self.settings_view.remove_addon_requested.connect(self._remove_addon)
        self.settings_view.move_addon_requested.connect(self._move_addon)
        self.settings_view.refresh_requested.connect(self.refresh_server)
        self.settings_view.logout_requested.connect(self.logout)
        self.settings_view.quit_requested.connect(self.close)
        self.settings_view.change_login_requested.connect(self.change_login)
        self.settings_view.epg_reload_requested.connect(self.reload_epg)
        self.settings_view.credentials_changed.connect(self.apply_credentials)
        self.settings_view.install_update_requested.connect(self._install_update)
        self.settings_view.restore_requested.connect(self._restore_backup)
        self.settings_view.check_updates_requested.connect(lambda: self._check_online_update(manual=True))
        self.settings_view.online_update_requested.connect(self._install_online_update)
        QTimer.singleShot(60_000, self._check_online_update)
        self.settings_view.stremio_addons_requested.connect(self._stremio_import_addons)
        QTimer.singleShot(120_000, self._weekly_backup)
        self.settings_view.parental_changed.connect(self._parental_changed)
        self.settings_view.check_services_requested.connect(self._check_services)
        self.settings_view.undo_update_requested.connect(self._undo_update)
        self._add_screen("settings", self.settings_view)

        if self._libmpv:
            try:
                self.player_view = fluxtv_player.StremioPlayerView(
                    shell, log_file=core.MPV_LOG_FILE)
            except Exception as error:
                # libmpv loaded but wouldn't start — keep the old player.
                fluxtv_player.LIBMPV_ERROR = f"{type(error).__name__}: {error}"
                self._libmpv = False
        if self._libmpv:
            pv = self.player_view
            pv.back_requested.connect(self.stop)
            pv.fullscreen_toggle_requested.connect(self._fullscreen)
            pv.progress.connect(self._on_libmpv_progress)
            pv.started.connect(self._on_libmpv_started)
            pv.ended.connect(self._on_libmpv_ended)
            pv.retry_requested.connect(self._retry_libmpv)
            pv.render_failed.connect(self._on_libmpv_render_failed)
            # Pausing/resuming an add-on title is reported to Trakt too.
            pv.video.pause_changed.connect(self._trakt_on_pause)
            pv.zap_requested.connect(self._zap)
            pv.channel_chosen.connect(self._zap_to_row)
            pv.channel_list_requested.connect(self._open_channel_list)
            pv.last_channel_requested.connect(self._last_channel)
            pv.info_requested.connect(self._show_channel_banner)
            pv.record_requested.connect(self._record_current)
            # A bound slot, so Qt drops the connection when the view goes.
            LOGOS.ready.connect(pv.on_logo_ready)
            self._add_screen("player", pv)
        else:
            self._build_external_player_view(shell)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(rail)
        body.addWidget(self.screens, 1)
        lay.addLayout(body, 1)

        self.mini_player = MiniPlayer(self.music, shell)
        self.mini_player.open_requested.connect(partial(self.go, "nowplaying"))
        self.mini_player.hide()
        lay.addWidget(self.mini_player)

        # ── status strip ─────────────────────────────────────────
        strip = QFrame(shell)
        strip.setFixedHeight(30)
        sl = QHBoxLayout(strip)
        sl.setContentsMargins(34, 0, 20, 0)
        self.status = QLabel("Loading your library\u2026", strip)
        self.status.setObjectName("Faint")
        sl.addWidget(self.status)
        sl.addStretch(1)
        self.conn = QLabel("Connecting\u2026", strip)
        self.conn.setObjectName("ConnStatus")
        sl.addWidget(self.conn)
        lay.addWidget(strip)
        self.chrome_status = strip

        self._install_shortcuts()
        self.go("home")
        return shell

    def _build_external_player_view(self, shell):
        self.player_view = PlayerView(shell)
        self.player_view.back_requested.connect(self.stop)
        self.player_view.play_pause_requested.connect(
            lambda: mpv_ipc_command(self._ipc_path, ["cycle", "pause"]))
        self.player_view.seek_requested.connect(
            lambda secs: mpv_ipc_command(self._ipc_path,
                                         ["seek", secs, "absolute"]))
        self.player_view.volume_changed.connect(
            lambda vol: mpv_ipc_command(self._ipc_path,
                                        ["set_property", "volume", vol]))
        self.player_view.mute_toggle_requested.connect(
            lambda: mpv_ipc_command(self._ipc_path, ["cycle", "mute"]))
        self.player_view.fullscreen_toggle_requested.connect(self._fullscreen)
        self._add_screen("player", self.player_view)

    def _add_screen(self, key, widget):
        self.screen_widgets[key] = widget
        self.screens.addWidget(widget)

    def _wire_channel_screen(self, screen):
        screen.activated.connect(self.play)
        screen.selected.connect(self._select)
        screen.fav_toggled.connect(self._toggle_fav)

    # ── navigation ───────────────────────────────────────────────
    def go(self, key):
        previous = self.screen_name
        self.screen_name = key
        for name, btn in self.nav_buttons.items():
            btn.setProperty("active", name == key)
            btn.update()

        if key == "player" and previous != "player":
            # Remember where to return to when playback stops — but don't
            # clobber that if we're already on the player screen (e.g.
            # switching titles without a full stop in between).
            self._pre_player_screen = previous

        # Swap the visible screen FIRST, and only then touch the
        # surrounding chrome and refresh data. This used to be the other
        # way round: the nav/status bars were shown (resizing the video
        # page still on screen — visible jitter, with the app's purple
        # palette appearing around a black frame) and then every screen
        # refresh ran to completion before the destination finally
        # appeared. On a library of tens of thousands of channels that
        # refresh alone can take a few hundred milliseconds, all of it
        # spent staring at a half-transitioned player page.
        destination = self.screen_widgets[key]
        leaving_player = previous == "player" and key != "player"
        self.screens.setCurrentWidget(destination)
        if key == "discover":
            if not self.search.text().strip():
                self.discover.end_search()
            self._ensure_discover()
        elif key == "music":
            self._ensure_music()
        elif key == "recordings":
            self.recordings_view.set_sizes(self._rec_bytes)
            self.recordings_view.refresh()
        elif key == "nowplaying":
            self.now_playing.refresh_queue()
            self.now_playing.setFocus(Qt.OtherFocusReason)
        if key == "nowplaying" and self.music.is_radio and not self.music.stopped:
            self._radio_fullscreen(True)
        elif previous == "nowplaying" and key != "nowplaying":
            self._radio_fullscreen(False)
        self._update_mini()
        self.search.setPlaceholderText(
            "Search films and series in your add-ons"
            if key in ("discover", "library", "addon_detail") else
            "Search songs, artists and music videos"
            if key in ("music", "nowplaying", "playlist") else
            "Search channels, movies and series")
        if key == "player":
            self.chrome_top.hide()
            self.chrome_divider.hide()
            self.chrome_status.hide()
        elif not getattr(self, "_radio_full", False):     # a station keeps them hidden
            self.chrome_top.show()
            self.chrome_divider.show()
            self.chrome_status.show()
        # Apply the resulting layout NOW, not on the next pass of the
        # event loop. Hiding the chrome only marks the layout as needing
        # a recalculation; until that runs, the newly-current page keeps
        # the old size — for the player, 98px shorter than the window
        # (the nav bar, divider and status bar it's about to lose). In
        # that gap the control panel is positioned for a page that's too
        # short (so ~98px too high), and the video is handed a window
        # that's about to change size. Everything that touches the page
        # between here and the next event-loop turn saw that stale size;
        # on real X11, where window geometry updates land
        # asynchronously, that made the bar's final position a race.
        # The old ordering (chrome hidden BEFORE the swap) happened to
        # avoid this; swapping first needs this to match it.
        shell_layout = self.screens.parentWidget().layout()
        if shell_layout is not None:
            shell_layout.activate()
        if leaving_player:
            # Showing the page moves keyboard focus back onto whatever
            # card was last selected on it, and the scroll area follows
            # focus — so the page used to end up wherever that card was
            # (the bottom of Home, in practice). Start from the top
            # instead, then let the destination paint before the refresh
            # below blocks the UI thread. User-input events are left out
            # so nothing can re-enter mid-navigation.
            self._land_on_top(destination)
            QApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        if key == "home":
            # Matches the original build: re-render on every visit, so the
            # greeting tracks the current time and the shelves reflect
            # anything starred/watched since the last time Home was shown.
            self.home.rebuild()
            # rebuild() just deleted every shelf and built fresh ones, so
            # whatever scroll position was left over from a previous
            # visit no longer corresponds to anything real — but the
            # scroll area doesn't know that on its own, so it keeps the
            # old value. This isn't limited to arriving from the player
            # (already handled by leaving_player above): the exact same
            # thing happens on any ordinary visit to Home, e.g. from
            # Series, since Home rebuilds every single time regardless of
            # where the visit came from.
            self._land_on_top(self.home)
            self._focus_first_card(self.home)
        elif key == "live":
            self.live.set_categories(self.lib.categories)
            self.live.set_channels(self.lib.all_channels,
                                   "No channels found. Still loading?")
        elif key == "guide":
            self.guide.set_categories(self.lib.categories)
            self.guide.set_channels(self.lib.all_channels,
                                    "No channels found. Still loading?")
        elif key == "sport":
            self.sport.set_channels(self.lib._collection("Sports"),
                                    "No sport categories found on this provider.")
        elif key == "favourites":
            self.favourites.set_channels(self.lib._fav_channels(),
                                         "Star a channel to keep it here.")
        elif key == "movies":
            self._ensure_vod()
        elif key == "series":
            self._ensure_series()
        elif key == "settings":
            self.settings_view.refresh_updates()
            self.settings_view.fav_count_label.setText(
                f"{sum(1 for v in self.lib.favs.values() if v.get('fav'))} "
                "channels starred")

        if leaving_player:
            # The refresh above deleted and rebuilt the page's cards, which
            # drops keyboard focus altogether — and arrow-key navigation
            # only works from a focused card. Put it back on the first
            # card so the keyboard works straight after closing the
            # player, exactly as it did before the swap-first ordering.
            self._land_on_top(destination)
            self._focus_first_card(destination)

    def _land_on_top(self, screen):
        """Scroll every vertical scroll area on a page back to the top."""
        for area in screen.findChildren(QScrollArea):
            area.verticalScrollBar().setValue(0)

    def _focus_first_card(self, screen):
        cards = []
        grid = getattr(screen, "grid", None)
        if grid is not None and getattr(grid, "cards", None):
            cards = grid.cards
        else:
            for shelf in getattr(screen, "shelves", []):
                # Home's shelves list their cards; poster / video rows
                # don't, so take the first tile in them.
                found = getattr(shelf, "cards", None) or                     [c for c in [shelf.findChild(QFrame, "Card")] if c is not None]
                if found:
                    cards = found
                    break
        if cards:
            cards[0].setFocus(Qt.OtherFocusReason)

    def _install_shortcuts(self):
        binds = [
            ("Ctrl+F", lambda: self.search.setFocus()),
            ("F1", partial(self.go, "home")),
            ("F2", partial(self.go, "live")),
            ("F3", partial(self.go, "favourites")),
            ("F4", partial(self.go, "guide")),
            ("Esc", self._handle_escape),
            ("Space", self._handle_space),
            ("F11", self._fullscreen),
            ("Ctrl+Q", self.close),
        ]
        for keys, fn in binds:
            QShortcut(QKeySequence(keys), self, activated=fn)

    def _handle_escape(self):
        if self.screen_name in ("nowplaying", "playlist"):
            self.go("music")
            return
        if (self.screen_name == "player" and self._libmpv
                and self.player_view.handle_escape()):
            return
        self.stop()

    def _handle_space(self):
        """Space toggles play/pause while the player is on screen,
        rather than re-triggering play_current() and relaunching the
        same title from scratch — the two need different handling
        depending on whether something is actually showing right now."""
        if self.screen_name == "nowplaying":
            self.music.toggle_pause()
            return
        if self.screen_name == "player" and (self.mpv or self._session):
            self.player_view.show_controls()
            self.player_view.play_pause_requested.emit()
        else:
            self.play_current()

    def _fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    # ── search ───────────────────────────────────────────────────
    def _apply_search(self):
        query = self.search.text()
        target = self.screen_name
        if target in ("discover", "library", "addon_detail"):
            self._addon_search(query)
            return
        if target in ("music", "nowplaying", "playlist"):
            self._music_search(query)
            return
        if target not in ("live", "sport", "favourites", "guide", "movies", "series"):
            if not query.strip():
                return
            target = "live"
            self.go(target)
        if target in ("live", "sport", "favourites", "guide"):
            self.screen_widgets[target].set_query(query)
        elif target in ("movies", "series"):
            self.screen_widgets[target].set_query(query)

    def _addon_search(self, query):
        """Search typed on Discover / the Stremio library / an add-on title:
        like Stremio, search the add-ons' catalogs, not the TV channels."""
        query = " ".join(query.split())
        if not query:
            self.discover.end_search()
            return
        if self.screen_name != "discover":
            self.go("discover")
        jobs = fluxtv_addons.search_jobs(list(self.addons))
        self.discover.begin_search(query, len(jobs))
        for i, (addon, cat) in enumerate(jobs):
            background(lambda a=addon, c=cat: fluxtv_addons.search_one(a, c, query),
                       lambda row, i=i: self.discover.add_search_result(query, i, row),
                       lambda _e, i=i: self.discover.add_search_result(query, i, None))

    def _check_services(self):
        api, lib, addons = self.api, self.lib, list(self.addons)
        background(lambda: fluxtv_health.check_all(api, lib, addons),
                   self.settings_view.show_health,
                   lambda e: self.settings_view.show_health([("Check", False, str(e))]))

    # ── parental lock ───────────────────────────────────────────
    def _parental_changed(self):
        """The lock changed: every page picks up the new lists next time it's
        shown (they rebuild because the lists are different now)."""
        self.status.setText("Parental lock on \u2014 adult categories hidden"
                            if self.lib.parental_locked() else "Parental lock off")

    # ── recording ───────────────────────────────────────────────
    def record_programme(self, channel, entry):
        now = time.time()
        start = max(now, entry["start"].timestamp() - fluxtv_record.PAD_BEFORE)
        stop = entry["stop"].timestamp()
        self._schedule_recording(channel, entry.get("title") or channel.get("name", ""), start, stop)

    def _schedule_recording(self, channel, title, start, stop):
        rec = fluxtv_record.new_recording(channel.get("name", ""), channel.get("stream_id"),
                                          title, start, stop)
        clash = fluxtv_record.overlaps(rec)
        fluxtv_record.add(rec)
        when = time.strftime("%H:%M", time.localtime(stop))
        msg = (f"\u25cf Recording {title} until {when}" if start <= time.time() + 5 else
               f"\u25cf Will record {title} at {time.strftime('%H:%M', time.localtime(start))}")
        if clash:
            msg += "  \u2014  note: it overlaps another recording; many providers allow only one or two streams at once"
        self.status.setText(msg)
        if self.screen_name == "player" and self._libmpv:
            self.player_view.show_indicator("\u25cf Recording" if start <= time.time() + 5 else "\u25cf Scheduled")
        self._check_recordings()

    def _record_current(self):
        """R while watching a live channel: record it until the programme ends."""
        s, channel = self._session, self.current
        if not s or not s.get("is_live") or not channel:
            return
        stop = time.time() + 3600
        title = channel.get("name", "")
        now_entry, _next = _now_next(self.lib, channel)
        if now_entry and now_entry.get("stop"):
            stop = now_entry["stop"].timestamp()
            title = now_entry.get("title") or title
        self._schedule_recording(channel, title, time.time(), stop)

    def _check_recordings(self):
        now = time.time()
        items = fluxtv_record.load()
        changed = False
        for r in items:
            if r["status"] == "scheduled" and now >= r["stop"]:
                r["status"] = "missed"
                changed = True
            elif r["status"] in ("scheduled", "recording") and r["start"] <= now < r["stop"] \
                    and r["id"] not in self._recorders:
                url = self.api.get_stream_url(r["stream_id"]) if self.api else ""
                if not url:
                    continue
                rec = fluxtv_record.Recorder(
                    r, url, on_progress=lambda rid, n: self._rec_bytes.__setitem__(rid, n),
                    on_done=lambda rid, ok, err, n: self._rec_signals.done.emit(rid, ok, err, n))
                self._recorders[r["id"]] = rec
                rec.start()
                r["status"] = "recording"
                changed = True
            elif r["status"] == "recording" and r["id"] not in self._recorders and now >= r["stop"]:
                r["status"] = "done" if os.path.exists(r["file"]) else "failed"   # from a crash
                changed = True
        if changed:
            fluxtv_record.save(items)
        if self.screen_name == "recordings":
            self.recordings_view.set_sizes(self._rec_bytes)
            self.recordings_view.refresh()

    def _recording_finished(self, rid, ok, error, size):
        self._recorders.pop(rid, None)
        self._rec_bytes.pop(rid, None)
        fluxtv_record.update(rid, status="done" if ok else "failed", error=error, bytes=size)
        title = next((r["title"] for r in fluxtv_record.load() if r["id"] == rid), "Recording")
        self.status.setText(f"Recording finished: {title}" if ok else f"Recording failed: {title} ({error})")
        if self.screen_name == "recordings":
            self.recordings_view.refresh()

    def _stop_recording(self, rid):
        rec = self._recorders.get(rid)
        if rec:
            rec.stop()
        else:
            fluxtv_record.update(rid, status="done")
            self.recordings_view.refresh()

    def _remove_recording(self, rid, delete_file):
        if delete_file:
            answer = QMessageBox.question(self, "Delete recording",
                                          "Delete this recording and its file?")
            if answer != QMessageBox.Yes:
                return
        rec = self._recorders.pop(rid, None)
        if rec:
            rec.stop()
        fluxtv_record.remove(rid, delete_file=delete_file)
        self.recordings_view.refresh()

    def _play_recording(self, r):
        if not os.path.exists(r["file"]):
            self.status.setText("That recording's file isn't there any more.")
            return
        when = time.localtime(r["start"])
        self._launch(r["file"], f"{r['title']}  \u2014  {r['channel']}", is_live=False,
                     subtitle=f"Recording \u00b7 {time.strftime('%a %d %b %H:%M', when)}",
                     extra_meta={"kind": "recording"})

    # ── catch-up ────────────────────────────────────────────────
    def _open_catchup(self, channel):
        self.catchup_view.show_loading(channel)
        self.go("catchup")
        api = self.api
        background(lambda: api.get_catchup_listings(channel.get("stream_id")),
                   lambda rows: self.catchup_view.show_listings(channel, rows),
                   lambda e: self.catchup_view.show_listings(channel, [], str(e)))

    def play_catchup(self, channel, entry):
        """Watch a programme from the provider's archive, from its start."""
        minutes = int((entry["stop"] - entry["start"]).total_seconds() // 60) + 5
        name = channel.get("name", "")
        when = entry["start"].astimezone()
        day = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")[when.weekday()]
        subtitle = (f"Catch-up \u00b7 {day} {when.day} \u00b7 "
                    f"{_hm(entry['start'])}\u2013{_hm(entry['stop'])}")
        self.status.setText(f"Opening catch-up: {entry['title']}\u2026")
        api = self.api

        def launch(url):
            self._launch(url, f"{entry['title']}  \u2014  {name}", is_live=False,
                         subtitle=subtitle, extra_meta={"kind": "catchup"})

        background(lambda: api.catchup_url(channel.get("stream_id"), entry["start"], minutes),
                   launch, lambda e: self.status.setText(f"Catch-up failed: {e}"))

    def _prebuild(self, keys):
        """One page at a time, a moment apart, so the app stays responsive."""
        if not keys:
            fluxtv_perf.mark("pages pre-built")
            return
        key, rest = keys[0], keys[1:]
        if self.screen_name not in ("player",) and key != self.screen_name:
            try:
                lib = self.lib
                if key == "live":
                    self.live.set_categories(lib.categories)
                    self.live.set_channels(lib.all_channels, "No channels found. Still loading?")
                elif key == "guide":
                    self.guide.set_categories(lib.categories)
                    self.guide.set_channels(lib.all_channels, "No channels found. Still loading?")
                elif key == "sport":
                    self.sport.set_channels(lib._collection("Sports"),
                                            "No sport categories found on this provider.")
                elif key == "favourites":
                    self.favourites.set_channels(lib._fav_channels(), "Star a channel to keep it here.")
                elif key == "movies" and self._vod_loaded:
                    self.movies.set_categories(lib.vod_categories)
                    self.movies.set_items(lib.vod_channels)
                elif key == "series" and self._series_loaded:
                    self.series.set_categories(lib.series_categories)
                    self.series.set_items(lib.series_list)
            except Exception as error:
                print(f"FluxTV: pre-building {key} skipped: {error}", file=sys.stderr)
        QTimer.singleShot(700, lambda: self._prebuild(rest))

    # ── updates ─────────────────────────────────────────────────
    # ── first run ───────────────────────────────────────────────
    def _maybe_first_run(self):
        """The setup wizard, only for a brand-new install (someone already
        using Flux Media never sees it)."""
        settings = self.lib.settings
        if settings.get("setup_done"):
            return
        already = os.path.exists(fluxtv_addons.ADDONS_FILE) or fluxtv_stremio.load_account() \
            or any(v.get("fav") for v in self.lib.favs.values())
        if already:
            settings["setup_done"] = True
            core.save_settings(settings)
            return
        QTimer.singleShot(1200, self._show_setup)

    def _show_setup(self):
        from fluxtv_settings_ui import SetupWizard
        dlg = SetupWizard(self)
        self._wizard = dlg
        dlg.stremio_requested.connect(self._wizard_stremio)

        def pin():
            self.settings_view._parental_action("set")
            if self.lib.settings.get("parental_pin"):
                dlg.pin_result_text("PIN set \u2014 adult categories are hidden.")
        dlg.pin_requested.connect(pin)
        dlg.exec()
        self._wizard = None
        self.lib.settings["setup_done"] = True
        core.save_settings(self.lib.settings)

    def _wizard_stremio(self, email, password):
        current = list(self.addons)

        def work():
            fluxtv_stremio.login(email, password)
            count, _resumed = fluxtv_stremio.sync()
            urls = fluxtv_stremio.get_addons()
            addons, installed, problems = (current, [], [])
            if urls:
                addons, installed, problems = fluxtv_addons.install_many(current, "\n".join(urls))
            return count, addons, installed, problems

        def done(result):
            count, addons, installed, problems = result
            self.addons = addons
            self.settings_view.set_addons(addons)
            self.settings_view.set_stremio_account(fluxtv_stremio.load_account())
            self.discover.invalidate()
            self.discover.set_library(fluxtv_stremio.continue_watching(), fluxtv_stremio.load_library())
            text = (f"Done \u2014 {len(installed)} add-on{'s' if len(installed) != 1 else ''} and "
                    f"{count} library title{'s' if count != 1 else ''} brought across.")
            if problems:
                text += "  (Couldn't add: " + "; ".join(problems) + ")"
            if self._wizard is not None:
                self._wizard.stremio_result(True, text)

        def failed(error):
            if self._wizard is not None:
                self._wizard.stremio_result(False, str(error))
        background(work, done, failed)

    def _stremio_import_addons(self):
        """Settings: add the Stremio account's add-ons you don't have yet
        (your own order and add-ons are left alone)."""
        view = self.settings_view
        view.stremio_result(True, "Getting your add-ons from Stremio\u2026")
        current = list(self.addons)

        def work():
            urls = fluxtv_stremio.get_addons()
            have = {a.url for a in current}
            addons, added, problems = current, [], []
            for url in urls:
                if url in have:
                    continue
                try:
                    addons = fluxtv_addons.install_addon(addons, url)
                    added.append(addons[-1].name)
                except Exception as error:
                    problems.append(str(error))
            return addons, added, problems

        def done(result):
            addons, added, problems = result
            self.addons = addons
            view.set_addons(addons)
            if added:
                self.discover.invalidate()
            text = ("Added " + ", ".join(added) + "." if added else
                    "You already have all your Stremio add-ons.")
            if problems:
                text += "  Couldn't add: " + "; ".join(problems)
            view.stremio_result(not problems or bool(added), text)

        background(work, done, lambda e: view.stremio_result(False, str(e)))

    # ── online updates ──────────────────────────────────────────
    def _check_online_update(self, manual=False):
        """Once a day (or when asked): is a newer Flux Media published?"""
        settings = self.lib.settings
        feed = settings.get("update_feed", fluxtv_update.DEFAULT_FEED)
        view = self.settings_view
        if not feed:
            if manual:
                view.update_message(False, "Online updates aren't set up yet \u2014 there's no "
                                           "update source. Update files still work (above).")
            return
        if not manual and time.time() - settings.get("update_checked", 0) < 20 * 3600:
            return
        if manual:
            view.update_message(True, "Checking for updates\u2026")

        def done(info):
            settings["update_checked"] = time.time()
            core.save_settings(settings)
            view.show_online_update(info)
            if info:
                self.status.setText(f"Flux Media {info['version']} is available \u2014 "
                                    "Settings \u2192 Updates to install it")
            elif manual:
                view.update_message(True, f"You're up to date ({fluxtv_update.VERSION}).")

        def failed(error):
            if manual:
                view.update_message(False, f"Couldn't check for updates ({error.__class__.__name__}).")
        background(lambda: fluxtv_update.newer_online(feed), done, failed)

    def _install_online_update(self, info):
        view = self.settings_view
        view.update_message(True, f"Downloading {info['version']}\u2026")
        background(lambda: fluxtv_update.download(info), self._install_update,
                   lambda e: view.update_message(False, f"Download failed: {e}"))

    def _restore_backup(self, path):
        try:
            fluxtv_backup.restore_backup(path)
        except (fluxtv_backup.BackupError, OSError) as error:
            self.settings_view.backup_message(False, f"Not restored: {error}")
            return
        self.settings_view.backup_message(True, "Restored. Flux Media is restarting\u2026")
        QTimer.singleShot(1500, self.restart_app)

    def _weekly_backup(self):
        """A copy of everything every week in the settings folder (last 3
        kept), so there's always something to go back to."""
        folder = os.path.join(fluxtv_backup.BACKUP_DIR, "weekly")

        def work():
            try:
                existing = sorted(n for n in os.listdir(folder) if n.endswith(".fmbackup"))
            except OSError:
                existing = []
            newest = os.path.getmtime(os.path.join(folder, existing[-1])) if existing else 0
            if time.time() - newest < 7 * 86400:
                return None
            path = fluxtv_backup.make_backup(folder)
            for old in sorted(n for n in os.listdir(folder) if n.endswith(".fmbackup"))[:-3]:
                os.remove(os.path.join(folder, old))
            return path
        background(work, lambda _p: None, lambda _e: None)

    def _install_update(self, path):
        view = self.settings_view
        view.update_message(True, "Checking and installing the update…")

        def done(version):
            view.update_message(True, f"Updated to {version}. Flux Media will restart now.")
            QTimer.singleShot(1500, self.restart_app)

        def failed(error):
            view.update_message(False, f"Update not installed: {error}")
        background(lambda: fluxtv_update.install_update(path), done, failed)

    def _undo_update(self):
        answer = QMessageBox.question(self, "Undo last update",
                                      "Go back to the version before the last update?")
        if answer != QMessageBox.Yes:
            return
        try:
            version = fluxtv_update.undo_last_update()
        except (fluxtv_update.UpdateError, OSError) as error:
            self.settings_view.update_message(False, str(error))
            return
        self.settings_view.update_message(True, f"Back to {version}. Restarting…")
        QTimer.singleShot(1500, self.restart_app)

    def restart_app(self):
        """Start a fresh copy of Flux Media, then close this one."""
        from PySide6.QtCore import QProcess
        script = os.path.abspath(sys.argv[0] if sys.argv and sys.argv[0] else __file__)
        QProcess.startDetached(sys.executable, [script] + sys.argv[1:],
                               os.path.dirname(script))
        self.close()
        QApplication.quit()

    # ── Music (YouTube) ─────────────────────────────────────────
    MUSIC_CACHE = os.path.join(core.APP_DIR, "music_home.json")
    MUSIC_REFRESH = 30 * 60

    def _ensure_music(self):
        if not getattr(self, "_yt_warmed", False) and fluxtv_youtube.available():
            self._yt_warmed = True        # load YouTube support now, not at start-up
            background(fluxtv_youtube.warm_up, lambda _r: None, lambda _e: None)
        """The Music page appears straight away: from memory on a revisit,
        from last time's saved rows on a fresh start. Fresh rows are
        fetched in the background and only changed rows are redrawn."""
        view = self.music_view
        if not view.loaded:
            cached = self._load_music_cache()
            if cached:
                self._music_data = cached
                self._render_music_rows()
        if view.loaded:
            self._render_music_rows()                   # instant: from disk/memory
            self._music_fetch_mix_if_needed()
            if time.time() - getattr(self, "_music_fetched", 0) > self.MUSIC_REFRESH:
                self._load_music_rows()
            return
        if view.loading:
            return
        view.loading = True
        if not fluxtv_youtube.available():
            view.show_status("Setting up YouTube for Flux Media \u2014 a one-off download, "
                             "about a minute\u2026")

            def installed(_r):
                view.show_status("")
                self._load_music_rows()

            def failed(error):
                view.loading = False
                view.show_status(str(error))
            background(fluxtv_youtube.ensure_installed, installed, failed)
            return
        view.show_status("Loading music\u2026")
        self._load_music_rows()

    def _load_music_cache(self):
        try:
            with open(self.MUSIC_CACHE, encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) and data.get("chart") is not None else None
        except (OSError, ValueError):
            return None

    def _save_music_cache(self):
        try:
            core._write_json(self.MUSIC_CACHE, self._music_data)
        except OSError:
            pass

    def _load_music_rows(self):
        if getattr(self, "_music_loading", False):
            return
        self._music_loading = True
        self._music_fetched = time.time()
        view = self.music_view

        def work():
            data = {}
            try:
                data["popular"] = fluxtv_radio.popular("NZ")
            except fluxtv_radio.RadioError:
                data["popular"] = []
            data["rova"] = fluxtv_radio.rova_stations()
            if not getattr(self, "_logos_filled", False):
                self._logos_filled = True
                try:
                    fluxtv_radio.fill_logos(fluxtv_radio.load_favourites())
                except Exception:
                    pass
            history = fluxtv_youtube.load_history()
            data["chart_title"], data["chart"] = fluxtv_youtube.trending()
            for n, t in enumerate(data["chart"]):
                t["_badge"] = f"#{n + 1}"
            data["mix_seed"], data["mixed"] = "", []
            if history:
                try:
                    data["mixed"] = fluxtv_youtube.mix(history[0]["id"])[1:]
                    data["mix_seed"] = history[0]["id"]
                except fluxtv_youtube.YouTubeError:
                    pass
            return data

        def done(data):
            self._music_loading = False
            view.loading = False
            if not data.get("mixed") and getattr(self, "_music_data", {}).get("mixed"):
                data["mixed"] = self._music_data["mixed"]       # keep what we had
                data["mix_seed"] = self._music_data.get("mix_seed", "")
            self._music_data = data
            self._save_music_cache()
            self._render_music_rows()
            view.show_status("" if data.get("chart") or fluxtv_youtube.load_history() else
                             "Couldn't reach YouTube just now \u2014 search still works, "
                             "or try again in a moment.")

        def failed(error):
            self._music_loading = False
            view.loading = False
            if not view.loaded:
                view.show_status(f"Couldn't load music: {error}")
        background(work, done, failed)

    def _music_fetch_mix_if_needed(self):
        """"Because you played…" follows the last song played; fetch just
        that row when it has changed."""
        history = fluxtv_youtube.load_history()
        data = getattr(self, "_music_data", {})
        if not history or history[0]["id"] == data.get("mix_seed") or \
                getattr(self, "_mix_fetching", False):
            return
        seed = history[0]["id"]
        self._mix_fetching = True

        def done(tracks):
            self._mix_fetching = False
            data["mixed"], data["mix_seed"] = tracks[1:], seed
            self._save_music_cache()
            self._render_music_rows()

        def failed(_error):
            self._mix_fetching = False
        background(lambda: fluxtv_youtube.mix(seed), done, failed)

    def _render_music_rows(self):
        data = getattr(self, "_music_data", None) or {}
        history = fluxtv_youtube.load_history()
        tiles = []
        for p in fluxtv_youtube.load_playlists():
            tracks = p.get("tracks") or []
            n = len(tracks)
            tiles.append({"id": p["id"], "title": p.get("name", ""),
                          "channel": f"{n} song{'s' if n != 1 else ''}",
                          "thumb": tracks[0].get("thumb") if tracks else "",
                          "_badge": "\u2261  Playlist", "_menu": False})
        rows = [("Your playlists", tiles, "playlists"),
                ("Your radio stations", fluxtv_radio.load_favourites(), "radio"),
                ("Rova stations", data.get("rova") or [], "radio"),
                ("Recently played", history[:30], "single"),
                (data.get("chart_title") or "", data.get("chart") or [], "queue"),
                ("Popular radio in New Zealand", data.get("popular") or [], "radio")]
        mixed = data.get("mixed") or []
        seed = next((t for t in history if t["id"] == data.get("mix_seed")), None)
        if mixed and seed:
            rows.append((f"Because you played {seed.get('title', '')}", mixed, "queue"))
        self.music_view.set_rows(rows)
        if rows and self.music_view.status.text().startswith("Loading music"):
            self.music_view.show_status("")

    # ── music: queue, playlists, menus ──────────────────────────
    def _music_enqueue(self, tracks, where):
        if self.music.stopped or self.music.current is None:
            self._music_play(tracks, 0)
            return
        if where == "next":
            self.music.play_next(tracks)
            self.status.setText(f"Playing next: {tracks[0].get('title', '')}")
        else:
            self.music.add_to_queue(tracks)
            self.status.setText(f"Added to the queue: {tracks[0].get('title', '')}")

    def _music_menu(self, track, pos, context):
        menu = QMenu(self)
        if track.get("kind") == "radio":
            menu.addAction("\u25b6  Play", lambda: self._music_play([track], 0))
            if fluxtv_radio.is_favourite(track):
                menu.addAction("Remove from my stations",
                               lambda: (fluxtv_radio.remove_favourite(track), self._playlists_changed()))
            else:
                menu.addAction("Add to my stations",
                               lambda: (fluxtv_radio.add_favourite(track), self._playlists_changed(),
                                        self.status.setText(f"Added {track.get('title', '')} "
                                                            "to your stations")))
            menu.exec(pos)
            return
        menu.addAction("\u25b6  Play now", lambda: self._music_play([track], 0))
        menu.addAction("Play next", lambda: self._music_enqueue([track], "next"))
        menu.addAction("Add to queue", lambda: self._music_enqueue([track], "end"))
        menu.addSeparator()
        self._fill_playlist_menu(menu.addMenu("Add to playlist"), [track])
        if context.startswith("playlist:"):
            pid = context.split(":", 1)[1]
            menu.addSeparator()
            menu.addAction("Remove from this playlist",
                           lambda: self._remove_from_playlist(pid, track))
        menu.exec(pos)

    def _fill_playlist_menu(self, menu, tracks):
        for p in fluxtv_youtube.load_playlists():
            menu.addAction(p.get("name", ""), lambda pid=p["id"], name=p.get("name", ""):
                           self._add_to_playlist(pid, name, tracks))
        if not menu.isEmpty():
            menu.addSeparator()
        menu.addAction("+  New playlist\u2026", lambda: self._new_playlist(tracks))

    def _playlist_menu(self, tracks, pos):
        menu = QMenu(self)
        self._fill_playlist_menu(menu, tracks)
        menu.exec(pos)

    def _upnext_menu(self, index, pos):
        if not 0 <= index < len(self.music.queue):
            return
        track = self.music.queue[index]
        menu = QMenu(self)
        menu.addAction("\u25b6  Play now", lambda: self.music.jump(index))
        menu.addAction("Remove from queue", lambda: self.music.remove_at(index))
        menu.addSeparator()
        self._fill_playlist_menu(menu.addMenu("Add to playlist"), [track])
        menu.exec(pos)

    def _add_to_playlist(self, pid, name, tracks):
        added = fluxtv_youtube.add_to_playlist(pid, tracks)
        self.status.setText(f"Added to \u201c{name}\u201d" if added
                            else f"Already in \u201c{name}\u201d")
        self._playlists_changed(pid)

    def _remove_from_playlist(self, pid, track):
        fluxtv_youtube.remove_from_playlist(pid, track["id"])
        self._playlists_changed(pid)

    def _playlists_changed(self, pid=None):
        if self.music_view.loaded:
            self._render_music_rows()
        if pid and self.playlist_view.pid == pid:
            playlist = fluxtv_youtube.get_playlist(pid)
            if playlist:
                self.playlist_view.show_playlist(playlist)

    def _ask_text(self, title, label, text=""):
        dialog = QInputDialog(self)
        dialog.setWindowTitle(title)
        dialog.setLabelText(label)
        dialog.setTextValue(text)
        dialog.resize(560, dialog.sizeHint().height())
        return dialog.textValue().strip() if dialog.exec() else None

    def _new_playlist(self, tracks=None):
        """A new playlist with these songs \u2014 or, given a YouTube
        playlist link instead of a name, a copy of that playlist."""
        text = self._ask_text("New playlist", "Name your playlist \u2014 or paste a "
                                              "YouTube playlist link to save it:")
        if not text:
            return
        if fluxtv_youtube.is_playlist_link(text):
            self.music_view.show_status("Saving the YouTube playlist\u2026")

            def done(playlist):
                self.music_view.show_status("")
                self.status.setText(f"Saved \u201c{playlist['name']}\u201d "
                                    f"({len(playlist['tracks'])} songs)")
                if tracks:
                    fluxtv_youtube.add_to_playlist(playlist["id"], tracks)
                self._playlists_changed()

            def failed(error):
                self.music_view.show_status(f"Couldn't save that playlist: {error}")
            background(lambda: fluxtv_youtube.import_playlist(text), done, failed)
            return
        playlist = fluxtv_youtube.create_playlist(text, tracks or [])
        self.status.setText(f"Made \u201c{playlist['name']}\u201d")
        self._playlists_changed()

    def _save_queue(self):
        current = self.music.current
        tracks = ([current] if current else []) + [t for _i, t in self.music.up_next(200)]
        if not tracks:
            return
        name = self._ask_text("Save as playlist", "Name for this playlist:",
                              f"Mix \u2014 {tracks[0].get('title', '')}"[:60])
        if name:
            fluxtv_youtube.create_playlist(name, tracks)
            self.status.setText(f"Saved \u201c{name}\u201d ({len(tracks)} songs)")
            self._playlists_changed()

    def _open_playlist(self, pid):
        playlist = fluxtv_youtube.get_playlist(pid)
        if playlist:
            self.playlist_view.show_playlist(playlist)
            self.go("playlist")

    def _rename_playlist(self, pid):
        playlist = fluxtv_youtube.get_playlist(pid)
        if not playlist:
            return
        name = self._ask_text("Rename playlist", "New name:", playlist.get("name", ""))
        if name:
            fluxtv_youtube.rename_playlist(pid, name)
            self._playlists_changed(pid)

    def _delete_playlist(self, pid):
        playlist = fluxtv_youtube.get_playlist(pid)
        if not playlist:
            return
        answer = QMessageBox.question(
            self, "Delete playlist",
            f"Delete \u201c{playlist.get('name', '')}\u201d? The songs stay on YouTube.")
        if answer == QMessageBox.Yes:
            fluxtv_youtube.delete_playlist(pid)
            self._playlists_changed()
            self.go("music")

    # ── radio: full screen, no cursor ───────────────────────────
    def _radio_track_changed(self, track):
        if self.screen_name != "nowplaying":
            return
        self._radio_fullscreen(bool(track) and track.get("kind") == "radio")

    def _radio_fullscreen(self, on):
        """A station on Now Playing takes the whole screen like a video:
        window full screen, top bar / left bar / status line hidden, and
        the pointer hidden after a few still seconds. Leaving Now Playing
        (Esc, ‹ Music) puts it all back."""
        if on == getattr(self, "_radio_full", False):
            return
        self._radio_full = on
        if on:
            if self.lib.settings.get("fullscreen", True):
                self._enter_video_fullscreen()
            for w in (self.chrome_top, self.chrome_divider, self.chrome_status):
                w.hide()
            self._cursor_timer.start()
            QApplication.instance().installEventFilter(self._cursor_watch)
        else:
            QApplication.instance().removeEventFilter(self._cursor_watch)
            self._cursor_timer.stop()
            self._show_cursor()
            if self.screen_name != "player":        # a video keeps its own full screen
                for w in (self.chrome_top, self.chrome_divider, self.chrome_status):
                    w.show()
                self._exit_video_fullscreen()

    def _hide_cursor(self):
        if getattr(self, "_radio_full", False) and not getattr(self, "_cursor_hidden", False):
            QApplication.setOverrideCursor(Qt.BlankCursor)
            self._cursor_hidden = True

    def _show_cursor(self):
        if getattr(self, "_cursor_hidden", False):
            QApplication.restoreOverrideCursor()
            self._cursor_hidden = False

    def _update_mini(self):
        show = self.music.is_playing_sound() and \
            self.screen_name not in ("nowplaying", "player")
        self.mini_player.setVisible(show)

    def _music_search(self, query):
        query = " ".join(query.split())
        view = self.music_view
        if not query:
            view.clear_search()
            return
        if self.screen_name != "music":
            self.go("music")
        view.show_results(query, None)
        background(lambda: fluxtv_radio.search(query, limit=20),
                   lambda stations: view.query == query and view.show_radio_results(query, stations),
                   lambda _e: None)

        def work():
            fluxtv_youtube.ensure_installed()
            return fluxtv_youtube.search(query)

        def done(tracks):
            if view.query == query:
                view.show_results(query, tracks)

        def failed(error):
            if view.query == query:
                view.show_results(query, [])
                view.results_title.setText(f"Search failed: {error}")
        background(work, done, failed)

    def _music_mode(self, mode):
        self.lib.settings["music_mode"] = mode
        core.save_settings(self.lib.settings)

    def _music_play(self, tracks, index):
        mode = self.lib.settings.get("music_mode", "listen")
        if tracks and tracks[0].get("kind") == "radio":
            mode = "listen"
            if not fluxtv_player.AVAILABLE:             # no libmpv: the video player
                st = tracks[index]
                self._launch(st["url"], st.get("title", ""), is_live=True,
                             subtitle="Live radio", extra_meta={"kind": "radio"})
                return
        if mode == "listen" and not fluxtv_player.AVAILABLE:
            mode = "watch"                    # no libmpv: video player only
        if mode == "listen" and self._session:
            self.stop(silent=True)
        self.music.play_tracks(tracks, index, mode)
        if mode == "listen":
            self.go("nowplaying")

    def _music_state(self, state, text):
        if state == "stopped" and self.status.text().startswith("♫"):
            self.status.setText("")             # don't leave the last song showing
        # Watch mode has no Now Playing screen, so the Music page says
        # what's happening while the video is fetched (a few seconds).
        if self.music.mode == "watch":
            track = self.music.current or {}
            if state == "loading":
                self.music_view.show_status(
                    f"▶  Getting “{track.get('title', '')}” from YouTube…")
            elif state in ("playing", "stopped"):
                self.music_view.show_status("")
            elif state == "error":
                self.music_view.show_status(text)
        if state == "error":
            print(f"FluxTV music: {text}", file=sys.stderr, flush=True)
            self.status.setText(text)
            if self.screen_name == "player" and self.music.mode == "watch" and \
                    self.music.stopped:
                self.player_view.show_notice("Couldn't play this video", text)
        elif state == "skip":
            self.status.setText(text)

    def _watch_youtube(self, track, links, start):
        extra = []
        if links.get("user_agent"):
            extra.append(f"--user-agent={links['user_agent']}")
        if links.get("audio"):
            extra.append(f"--audio-file={links['audio']}")
        self._launch(links["url"], track.get("title", ""), is_live=bool(links.get("live")),
                     subtitle=track.get("channel", ""), extra_args=extra,
                     progress_key=None, resume_seconds=start,
                     extra_meta={"kind": "youtube", "yt_id": track["id"]})

    # ── VOD / Series, loaded once per session ───────────────────
    def _ensure_vod(self):
        if self._vod_loaded:
            self.movies.set_categories(self.lib.vod_categories)
            self.movies.set_items(self.lib.vod_channels)
            return
        # Set the loading UI here, unconditionally — not inside
        # _fetch_vod(), which may skip the actual network call if the
        # automatic startup refresh already has one in flight. Whichever
        # fetch is actually running will still call set_loading(False)
        # once it completes, since its done()/failed() handlers check
        # screen_name rather than caring who triggered them.
        self.movies.set_loading(True)
        self.status.setText("Loading movies\u2026")
        self._fetch_vod()

    def retry_vod(self):
        self._vod_loaded = False
        self._vod_fetch_started = False
        self._ensure_vod()

    def _ensure_series(self):
        if self._series_loaded:
            self.series.set_categories(self.lib.series_categories)
            self.series.set_items(self.lib.series_list)
            return
        self.series.set_loading(True)
        self.status.setText("Loading series\u2026")
        self._fetch_series()

    def retry_series(self):
        self._series_loaded = False
        self._series_fetch_started = False
        self._ensure_series()

    def _remember_detail_origin(self):
        if self.screen_name not in ("movie_detail", "series_detail", "addon_detail", "player"):
            self._detail_origin = self.screen_name

    def _leave_detail(self):
        self.go(getattr(self, "_detail_origin", None) or "home")

    # ── Stremio add-ons ──────────────────────────────────────────
    def _show_library(self):
        self.library_view.set_items(fluxtv_stremio.load_library())
        self.go("library")

    # ── Trakt ───────────────────────────────────────────────────
    def _trakt_connect(self, client_id, secret):
        def started(device):
            self._trakt_device = device
            self._trakt_deadline = time.time() + int(device.get("expires_in", 600))
            self.settings_view.set_trakt_state("code", code=device.get("user_code"),
                                               url=device.get("verification_url"))
            self.settings_view.trakt_result(True, "Waiting for you to approve Flux Media on Trakt\u2026")
            self._trakt_timer.start(int(device.get("interval", 5)) * 1000)
        background(lambda: fluxtv_trakt.start_device(client_id, secret), started,
                   lambda e: self.settings_view.trakt_result(False, str(e)))

    def _trakt_poll(self):
        device = self._trakt_device
        if not device:
            return
        if time.time() > self._trakt_deadline:
            self._trakt_cancel("The code expired \u2014 press Connect to get a new one.")
            return

        def checked(result):
            if not self._trakt_device:
                return                                  # cancelled meanwhile
            if result in ("pending", "slow_down"):
                extra = 5 if result == "slow_down" else 0
                self._trakt_timer.start((int(device.get("interval", 5)) + extra) * 1000)
                return
            self._trakt_device = None
            self.settings_view.set_trakt_state("on", result)
            self.settings_view.trakt_result(True, "Connected to Trakt \u2014 fetching your watched history\u2026")
            self._trakt_sync()

        background(lambda: fluxtv_trakt.poll_device(device["device_code"]), checked,
                   lambda e: self._trakt_cancel(str(e)))

    def _trakt_cancel(self, message="Cancelled."):
        self._trakt_device = None
        self._trakt_timer.stop()
        self.settings_view.set_trakt_state("off")
        self.settings_view.trakt_result(False, message if isinstance(message, str) else "Cancelled.")

    def _trakt_sync(self):
        def done(counts):
            films, eps = counts
            self.settings_view.set_trakt_state("on", fluxtv_trakt.load())
            self.settings_view.trakt_result(True, f"Synced from Trakt: {films:,} films and "
                                                  f"{eps:,} episodes watched.")
            self.discover.invalidate_watched()
        background(fluxtv_trakt.sync_watched, done,
                   lambda e: self.settings_view.trakt_result(False, str(e)))

    def _trakt_disconnect(self):
        def done(_r):
            self.settings_view.set_trakt_state("off")
            self.settings_view.trakt_result(True, "Disconnected from Trakt. Your watched ticks stay.")
        background(fluxtv_trakt.disconnect, done, lambda e: done(None))

    def _addon_session(self):
        s = self._session
        if s and (s.get("extra_meta") or {}).get("kind") == "addon":
            return s
        return None

    def _trakt_scrobble(self, action, session=None):
        s = session or self._addon_session()
        if not s or not fluxtv_trakt.connected() or \
                not self.lib.settings.get("trakt_scrobble", True):
            return
        meta = dict(s["extra_meta"])
        progress = (s["position"] / s["duration"] * 100) if s.get("duration") else 0
        background(lambda: fluxtv_trakt.scrobble(action, meta, progress),
                   lambda _r: None, lambda e: self.status.setText(f"Trakt: {e}"))

    def _trakt_on_pause(self, paused):
        if self._addon_session():
            self._trakt_scrobble("pause" if paused else "start")

    def _finish_addon_session(self, s):
        """Called as an add-on title stops: scrobble the stop, and count it
        as watched here once 80% of the way through (with or without Trakt)."""
        if not s or (s.get("extra_meta") or {}).get("kind") != "addon":
            return
        meta = s["extra_meta"]
        self._trakt_scrobble("stop", s)
        if s.get("duration") and s["position"] / s["duration"] >= 0.8:
            if meta.get("addon_type") == "series" and meta.get("series_id"):
                fluxtv_trakt.add_watched(episodes=[meta.get("addon_id")])
            else:
                fluxtv_trakt.add_watched(movies=[meta.get("addon_id")])

    # ── Stremio account ─────────────────────────────────────────
    def _stremio_synced(self, result, verb):
        count, resumed = result
        self.settings_view.set_stremio_account(fluxtv_stremio.load_account())
        extra = f", {resumed} to resume" if resumed else ""
        self.settings_view.stremio_result(True, f"{verb} {count} titles from your Stremio library{extra}.")
        self.discover.set_library(fluxtv_stremio.continue_watching(), fluxtv_stremio.load_library())

    def _stremio_login(self, email, password):
        def work():
            fluxtv_stremio.login(email, password)
            return fluxtv_stremio.sync()
        background(work, lambda r: self._stremio_synced(r, "Imported"),
                   lambda e: self.settings_view.stremio_result(False, str(e)))

    def _stremio_sync(self):
        background(fluxtv_stremio.sync, lambda r: self._stremio_synced(r, "Synced"),
                   lambda e: self.settings_view.stremio_result(False, str(e)))

    def _stremio_logout(self):
        def done(_r):
            self.settings_view.set_stremio_account(None)
            self.settings_view.stremio_result(True, "Signed out of Stremio. Your imported "
                                                    "watch progress stays in Flux Media.")
            self.discover.set_library(fluxtv_stremio.continue_watching(), [])
        background(fluxtv_stremio.logout, done, lambda e: done(None))

    def _ensure_discover(self):
        account = fluxtv_stremio.load_account()
        if account and not getattr(self, "_stremio_auto_synced", False) and \
                time.time() - (account.get("last_sync") or 0) > 6 * 3600:
            # Keep the library current without anyone pressing Sync.
            self._stremio_auto_synced = True
            background(fluxtv_stremio.sync,
                       lambda r: self.discover.set_library(fluxtv_stremio.continue_watching(),
                                                           fluxtv_stremio.load_library()),
                       lambda e: None)
        if self.discover.loaded or self.discover.loading:
            return
        addons = list(self.addons)
        cached, age = fluxtv_addons.load_rows_cache(addons)
        if cached:
            # Saved rows first, so Discover appears straight away...
            self.discover.show_rows(cached)
            if age < fluxtv_addons.DISCOVER_MAX_AGE:
                return
        else:
            self.discover.set_loading("Loading from your add-ons\u2026")

        def fresh(rows):
            # ...then the up-to-date rows, swapped in quietly when they land.
            if rows:
                fluxtv_addons.save_rows_cache(addons, rows)
                self.home.set_addon_hero(addon_hero_picks(rows))
            if not cached or self._row_ids(rows) != self._row_ids(cached):
                self.discover.show_rows(rows)

        def failed(error):
            if not cached:
                self.discover.show_error(f"Couldn't load from your add-ons ({error}).")

        background(lambda: fluxtv_addons.browse_rows(addons), fresh, failed)

    @staticmethod
    def _row_ids(rows):
        return [(title, [m.get("id") for m in metas]) for title, _type, metas in rows or []]

    def open_addon(self, type_, meta):
        self._remember_detail_origin()
        self.addon_detail.show_stub(type_, meta)
        self.screens.setCurrentWidget(self.addon_detail)
        self.screen_name = "addon_detail"
        addons, meta_id = list(self.addons), meta.get("id", "")
        background(lambda: fluxtv_addons.meta(addons, type_, meta_id),
                   self.addon_detail.show_meta, lambda e: None)
        self._offer_provider_copy(type_, meta)
        if str(meta_id).startswith("tt"):
            self._load_details(self.addon_detail, ("addon", meta_id), type_,
                               imdb_id=meta_id)

    def _fetch_addon_streams(self, type_, stream_id, auto):
        """Ask every stream add-on at once and show each one's links the
        moment they arrive (Debridio's don't wait for a slow add-on).
        Play (auto) starts once the add-ons ahead of the first one that
        found something have all answered \u2014 your order still decides."""
        addons = list(self.addons)
        job = {"id": stream_id, "sources": None, "results": {}, "auto": auto, "played": False}
        self._stream_job = job

        def got_sources(sources):
            if self._stream_job is not job:
                return
            job["sources"] = sources
            if not sources:
                self.addon_detail.show_streams(stream_id, [], ["No stream add-ons are installed for this."], False)
                return
            for addon in sources:
                background(lambda a=addon: fluxtv_addons.streams_from(a, type_, stream_id),
                           lambda r, a=addon: answered(a, r[0], r[1]),
                           lambda e, a=addon: answered(a, [], f"{a.name} didn't respond"))

        def answered(addon, found, problem):
            if self._stream_job is not job:
                return                               # left the page / another episode
            job["results"][addon.url] = (found, problem)
            sources = job["sources"]
            combined, problems, pending = [], [], []
            ready_to_play = None
            for a in sources:
                if a.url not in job["results"]:
                    pending.append(a.name)
                    continue
                f, prob = job["results"][a.url]
                combined += f
                if prob:
                    problems.append(prob)
                if ready_to_play is None and f and not pending:
                    ready_to_play = True             # everything ahead of it has answered
            if pending:
                problems.append("Still asking: " + ", ".join(pending) + "\u2026")
            play_now = job["auto"] and not job["played"] and bool(ready_to_play)
            if play_now:
                job["played"] = True
            self.addon_detail.show_streams(stream_id, combined, problems, play_now)

        background(lambda: fluxtv_addons.stream_sources(addons, type_, stream_id), got_sources,
                   lambda e: self.addon_detail.show_streams(stream_id, [], [str(e)], False))

    def _play_addon(self, stream, ctx):
        extra = []
        headers = stream.get("headers") or {}
        if headers:
            extra.append("--http-header-fields=" +
                         ",".join(f"{k}: {v}" for k, v in headers.items()))
        key = f"addon:{ctx['id']}"
        self._launch(stream["url"], ctx.get("title", ""), is_live=False,
                     subtitle=ctx.get("subtitle", ""), extra_args=extra,
                     progress_key=key, resume_seconds=self._resume_seconds(key),
                     extra_meta={"kind": "addon", "addon_type": ctx.get("type"),
                                 "addon_id": ctx["id"], "series_id": ctx.get("series_id"),
                                 "season": ctx.get("season"),
                                 "episode_num": ctx.get("episode"),
                                 "show": ctx.get("name"),
                                 "poster": ctx.get("poster") or ""})
        self._fetch_subtitles(stream, ctx)

    # ── subtitles from add-ons ──────────────────────────────────
    def _fetch_subtitles(self, stream, ctx):
        url = stream["url"]
        addons = list(self.addons)
        filename = stream.get("filename") or ""
        type_ = "series" if ctx.get("type") == "series" else "movie"
        background(lambda: fluxtv_addons.subtitles(addons, type_, ctx["id"], filename),
                   lambda subs: self._got_subtitles(url, subs), lambda _e: None)

    def _got_subtitles(self, url, subs):
        s = self._session
        if not s or s["url"] != url or not subs:
            return
        s["subtitles"] = subs
        if s.get("started"):
            self._apply_subtitles()

    def _apply_subtitles(self):
        s = self._session
        subs = (s or {}).pop("subtitles", None)
        if not subs or not self._libmpv:
            return
        auto = self.lib.settings.get("subtitles_auto", False)
        for i, sub in enumerate(subs):
            self.player_view.video.add_subtitle(
                sub["url"], sub["title"], sub["lang"],
                select=auto and i == 0 and sub["lang"] in ("eng", "en"))
        english = sum(1 for sub in subs if sub["lang"] in ("eng", "en"))
        self.status.setText(f"Subtitles ready: {english} English, {len(subs) - english} other "
                            "— choose them from the player's subtitle menu"
                            if not auto else "English subtitles on")

    def _install_addon(self, text):
        current = list(self.addons)

        def done(result):
            addons, installed, problems = result
            self.addons = addons
            self.settings_view.set_addons(addons)
            if installed:
                message = "Installed " + ", ".join(installed) + "."
            else:
                message = "Nothing new to install — those add-ons are already here."
            if problems:
                message += "  Couldn't install: " + "; ".join(problems)
            self.settings_view.addon_result(bool(installed) or not problems, message)
            self.discover.invalidate()

        background(lambda: fluxtv_addons.install_many(current, text), done,
                   lambda e: self.settings_view.addon_result(False, str(e)))

    def _move_addon(self, addon, delta):
        self.addons = fluxtv_addons.move_addon(self.addons, addon, delta)
        self.settings_view.set_addons(self.addons)
        self.discover.invalidate()

    def _remove_addon(self, addon):
        self.addons = fluxtv_addons.remove_addon(self.addons, addon)
        self.settings_view.set_addons(self.addons)
        self.settings_view.addon_result(True, f"Removed {addon.name}.")
        self.discover.invalidate()

    def _open_featured(self, kind, item):
        if kind.startswith("addon:"):
            self.open_addon(kind.split(":", 1)[1], item.get("_meta") or {})
        elif kind == "movie":
            self.open_movie_detail(item)
        else:
            self.open_series(item)

    def _play_featured(self, kind, item):
        if kind.startswith("addon:"):
            self.open_addon(kind.split(":", 1)[1], item.get("_meta") or {})
        elif kind == "movie":
            self.play_vod(item)
        else:
            self.open_series(item)

    def _load_home_hero(self):
        """Home banner from the add-ons: saved rows straight away, then a
        quiet refresh if they're old (which also warms Discover)."""
        addons = list(self.addons)
        cached, age = fluxtv_addons.load_rows_cache(addons)
        if cached:
            self.home.set_addon_hero(addon_hero_picks(cached))
            if age < fluxtv_addons.DISCOVER_MAX_AGE:
                return

        def fresh(rows):
            if not rows:
                return
            fluxtv_addons.save_rows_cache(addons, rows)
            self.home.set_addon_hero(addon_hero_picks(rows))

        background(lambda: fluxtv_addons.browse_rows(addons), fresh, lambda e: None)

    def open_series(self, item):
        self._remember_detail_origin()
        self.series_detail.show_series(item)
        self.screens.setCurrentWidget(self.series_detail)
        self.screen_name = "series_detail"

        def fetch():
            return self.api.get_series_info(item.get("series_id"))

        background(fetch, self.series_detail.show_episodes,
                  lambda e: self.series_detail.status_label.setText(
                      f"Could not load episodes. {e}"))
        self._load_details(self.series_detail, ("series", item.get("series_id")), "series",
                           name=item.get("name", ""),
                           year=fluxtv_details.year_of(item.get("year"), item.get("releaseDate"),
                                                       item.get("release_date"), item.get("name")))

    def open_movie_detail(self, item):
        self._remember_detail_origin()
        self.movie_detail.show_movie(item)
        self.screens.setCurrentWidget(self.movie_detail)
        self.screen_name = "movie_detail"

        def fetch():
            return self.api.get_vod_info(item.get("stream_id"))

        background(fetch, self.movie_detail.show_info, lambda e: None)
        self._load_details(self.movie_detail, ("vod", item.get("stream_id")), "movie",
                           name=item.get("name", ""),
                           year=fluxtv_details.year_of(item.get("year"), item.get("releasedate"),
                                                       item.get("name")))

    # ── richer details and "one library" ─────────────────────────
    def _load_details(self, view, key, type_, name="", year=None, imdb_id=None):
        """Ratings, awards, cast and trailers for a detail page. A provider
        title is matched to IMDb by name and year first; when it matches
        and you have stream add-ons, "More sources" opens its Debrid page."""
        settings = self.lib.settings
        tmdb_key = settings.get("tmdb_key", "").strip()
        omdb_key = settings.get("omdb_key", "").strip()

        def work():
            found = None
            imdb = imdb_id
            if not imdb:
                found = fluxtv_details.find_imdb(type_, name, year)
                imdb = (found or {}).get("id")
            if not imdb:
                return found, None
            return found, fluxtv_details.details(type_, imdb, tmdb_key, omdb_key)

        def done(result):
            found, info = result
            if view.details_for != key:
                return                                      # left this page already
            if info:
                view.apply_details(key, info)
            if found and not imdb_id and self._has_stream_addons():
                self._other_copy[id(view)] = ("addon", type_, found)
                view.set_link("More sources")

        background(work, done, lambda e: None)

    def _has_stream_addons(self):
        for addon in self.addons:
            for res in addon.manifest.get("resources") or []:
                if (res if isinstance(res, str) else (res or {}).get("name")) == "stream":
                    return True
        return False

    def _offer_provider_copy(self, type_, meta):
        """On a Debrid page: if your IPTV provider has the same film or
        series, offer it (no debrid needed to watch)."""
        films = self.lib.vod_channels if type_ != "series" else []
        shows = self.lib.series_list if type_ == "series" else []
        if not films and not shows:
            return
        item = self._provider_index.find(type_, meta.get("name", ""),
                                         fluxtv_details.year_of(meta.get("releaseInfo"),
                                                                meta.get("year")),
                                         films, shows)
        if item:
            self._other_copy[id(self.addon_detail)] = ("provider", type_, item)
            self.addon_detail.set_link("\u25b6  Play from your provider" if type_ != "series"
                                       else "Your provider has this")

    def _open_other_copy(self):
        view = self.sender()
        entry = self._other_copy.get(id(view))
        if not entry:
            return
        where, type_, item = entry
        origin = getattr(self, "_detail_origin", None)
        if where == "addon":
            self.open_addon(type_, dict(item))
        elif type_ == "series":
            self.open_series(item)
        else:
            self.play_vod(item)
            return
        self._detail_origin = origin            # Back still goes where you started

    def _play_trailer(self, code, title):
        """Trailers play here, through the same YouTube player as Music.
        Without YouTube support (or if YouTube refuses) the browser opens."""
        code = (code or "").strip()
        video_id = code
        if code.startswith("http"):
            import re
            m = re.search(r"(?:v=|youtu\.be/|embed/)([\w-]{11})", code)
            video_id = m.group(1) if m else ""

        def browser():
            from PySide6.QtCore import QUrl
            from PySide6.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl(code if code.startswith("http")
                                          else f"https://www.youtube.com/watch?v={code}"))

        if not video_id or not fluxtv_youtube.available():
            if code.startswith("http") and not video_id:
                self._launch(code, f"{title} \u2014 Trailer", extra_meta={"kind": "trailer"})
            else:
                browser()
            return
        self.status.setText(f"Getting the trailer for {title}\u2026")

        def done(links):
            extra = []
            if links.get("user_agent"):
                extra.append(f"--user-agent={links['user_agent']}")
            if links.get("audio"):
                extra.append(f"--audio-file={links['audio']}")
            self._launch(links["url"], f"{title} \u2014 Trailer", subtitle="Trailer",
                         extra_args=extra, extra_meta={"kind": "trailer", "yt_id": video_id})

        def failed(error):
            self.status.setText(f"Couldn't play the trailer here ({error}) \u2014 opening YouTube")
            browser()

        background(lambda: fluxtv_youtube.resolve(video_id, "watch"), done, failed)

    # ── cache first, network second ──────────────────────────────
    def restore_cache(self):
        """Paint from the local cache before touching the network — for
        Live TV, and equally for Movies/Series, which used to have no
        disk cache at all and so always waited on a live fetch on first
        visit every single session, unlike everything else."""
        fluxtv_perf.mark("reading saved channel list")
        cached = core.load_library_cache(self.api.server, self.api.username)
        fluxtv_perf.mark(f"saved channel list read ({len((cached or {}).get('channels') or [])} channels)")
        if not cached:
            self.status.setText("No local cache yet \u2014 fetching from provider\u2026")
        else:
            # load_library_cache returns the whole payload dict (key,
            # saved_at, categories, channels) — not a (categories,
            # channels) tuple.
            self.lib.categories = cached.get("categories") or []
            self.lib.all_channels = cached.get("channels") or []
            self.lib.channels = self.lib.all_channels
            self.lib._invalidate_caches()
            self.home.rebuild()
            self.status.setText(
                f"{len(self.lib.all_channels):,} channels from cache")

        fluxtv_perf.mark("home screen built")
        vod_cached = core.load_vod_cache(self.api.server, self.api.username)
        fluxtv_perf.mark(f"saved films read ({len((vod_cached or {}).get('vod_channels') or [])})")
        if vod_cached:
            self.lib.vod_categories = vod_cached.get("categories") or []
            self.lib.vod_channels = vod_cached.get("vod_channels") or []
            self._vod_loaded = True

        # The guide is the slow one (a full XMLTV download + parse), so
        # it's cached too — loaded off the UI thread since it can be large.
        source = self.lib.settings.get("epg_url") or ""
        background(lambda: core.load_epg_cache(self.api.server,
                                               self.api.username, source),
                   self._got_cached_epg, lambda e: None)

        series_cached = core.load_series_cache(self.api.server, self.api.username)
        fluxtv_perf.mark(f"saved series read ({len((series_cached or {}).get('series_list') or [])})")
        if series_cached:
            self.lib.series_categories = series_cached.get("categories") or []
            self.lib.series_list = series_cached.get("series_list") or []
            self._series_loaded = True
        self.home.refresh_hero()

    def refresh_in_background(self):
        """Categories, channels, EPG, then VOD and series — one at a time.

        All chained sequentially rather than fired at once. A personal
        IPTV subscription commonly caps concurrent connections at 1 or 2,
        and a burst of simultaneous requests right after a fresh login
        (which just used a connection of its own to validate) is exactly
        the shape of request that trips a "too many connections" error.
        This runs unconditionally on every launch — same as Live TV's own
        categories/channels refresh — so the Movies/Series disk cache
        restored above stays current in the background even if the user
        never navigates there this session.
        """
        def guarded(step_name, next_fn, *args):
            # A single bad record from a real, messy provider (a null
            # name, a missing field — the exact shape that crashed
            # _collection() here) previously took the whole chain down
            # with it silently: an uncaught exception in one of these
            # callbacks (they run as queued signal handlers, not inside
            # Fetch's own try/except, which only wraps the network call
            # itself) simply stops that function at the point it failed
            # — so whatever chains the NEXT fetch, on the very next line,
            # never runs. From the outside that looked exactly like "EPG
            # doesn't load and no channels work": channels had actually
            # been received, but processing them failed before the EPG
            # fetch was ever started. This isolates each step so a
            # failure in one is visible and logged, but can never again
            # stop the rest of the chain from at least being attempted.
            try:
                next_fn(*args)
            except Exception as error:
                import traceback
                print(f"[refresh_in_background] {step_name} failed:\n"
                     f"{traceback.format_exc()}", file=sys.stderr)
                self.status.setText(
                    f"Something went wrong loading {step_name} — see the "
                    f"terminal for details ({error}). Continuing anyway.")

        def after_categories(categories):
            guarded("categories", self._got_categories, categories)
            background(self.api.get_channels, after_channels,
                      lambda e: None)

        def after_channels(channels):
            guarded("channels", self._got_channels, channels)
            age = core.epg_cache_age(self.api.server, self.api.username,
                                     self.lib.settings.get("epg_url") or "")
            if age is not None and age < core.EPG_CACHE_MAX_AGE:
                # Guide on disk is recent: skip the big download this
                # launch and move straight on to movies/series.
                self._background_library_refresh()
                return
            if age is not None and self._is_playing():
                # An older guide is already showing and something is
                # playing: downloading and parsing a big XMLTV file now
                # would stall the picture (parsing holds Python's lock),
                # so it waits until playback stops.
                self._library_refresh_deferred = "epg"
                return
            self._refresh_epg_then_library()

        background(self.api.get_categories, after_categories,
                  lambda e: self.conn.setText("Provider unavailable"))

    def _is_playing(self):
        return bool(self._session) or (self.mpv is not None and self.mpv.poll() is None)

    def _refresh_epg_then_library(self):
        def after_epg(epg):
            try:
                self._got_epg(epg)
            except Exception as error:
                self.status.setText(f"Something went wrong loading the guide ({error}).")
            self._background_library_refresh()

        def failed(error):
            self.status.setText(f"EPG unavailable: {str(error)[:60]}")
            self._background_library_refresh()

        background(self._load_epg, after_epg, failed)

    def _background_library_refresh(self):
        """The startup refresh of the (often huge) movie and series lists.

        If something is already playing — the "launch and go straight in"
        case — wait until playback stops: those downloads share the
        connection (and the provider's connection limit) with the stream.
        The cached library is still on screen meanwhile. Opening Movies or
        Series still fetches on demand if there's no cache at all.
        """
        if self._is_playing():
            self._library_refresh_deferred = True
            return
        self._library_refresh_deferred = False
        self._fetch_vod(chain_series_after=True)

    def _resume_deferred_refresh(self):
        pending = getattr(self, "_library_refresh_deferred", False)
        if not pending or self._is_playing():
            return
        self._library_refresh_deferred = False
        if pending == "epg":
            self._refresh_epg_then_library()
        else:
            self._background_library_refresh()

    def _fetch_vod(self, chain_series_after=False):
        """Refresh the Movies library. Safe to call whether or not a disk
        cache already populated the screen — this is what keeps that
        cache current, exactly like Live TV's own background refresh.

        Two different triggers can both want to fetch VOD: the automatic
        startup chain, and the user navigating to Movies before that
        chain gets there. An in-flight-only guard isn't enough to stop
        both from firing — one can complete and reset its "in flight"
        flag before the other's turn even arrives, so it sails through
        as if nothing had run yet. _vod_fetch_started never resets once
        a fetch has been dispatched (only retry_vod() clears it), so at
        most one real fetch happens per session either way; whichever
        caller loses the race still gets series chained after it via
        _vod_chain_series_pending once the in-flight one finishes.
        """
        if getattr(self, "_vod_fetch_started", False):
            if chain_series_after:
                if self._vod_loaded:
                    self._fetch_series()
                else:
                    self._vod_chain_series_pending = True
            return
        self._vod_fetch_started = True
        if self.screen_name == "movies" and not self._vod_loaded:
            self.movies.set_loading(True)
        self.status.setText("Loading movies\u2026")

        server, user = self.api.server, self.api.username

        def fetch():
            try:
                cats = self.api.get_vod_categories()
            except Exception:
                cats = []
            vods = self.api.get_vod_streams()
            # Saved here on the worker thread, not in done(): writing a big
            # library to disk on the UI thread stalls playback.
            try:
                core.save_vod_cache(server, user, cats, vods)
            except Exception:
                pass
            return cats, vods

        def done(result):
            cats, vods = result
            self.lib.vod_categories = cats or []
            self.lib.vod_channels = vods or []
            self._vod_loaded = True
            if self.screen_name == "movies":
                self.movies.set_loading(False)
                self.movies.set_categories(self.lib.vod_categories)
                self.movies.set_items(
                    self.lib.vod_channels,
                    "Your provider may not include VOD content.")
            self.status.setText(f"{len(self.lib.vod_channels)} movies loaded")
            self.home.refresh_hero()
            if chain_series_after or getattr(self, "_vod_chain_series_pending", False):
                self._vod_chain_series_pending = False
                self._fetch_series()

        def failed(error):
            if self.screen_name == "movies" and not self._vod_loaded:
                self.movies.show_error(f"Could not load movies.\n{error}")
            self.status.setText("Could not load movies.")
            if chain_series_after or getattr(self, "_vod_chain_series_pending", False):
                self._vod_chain_series_pending = False
                self._fetch_series()

        background(fetch, done, failed)

    def _fetch_series(self):
        """Refresh the Series library — see _fetch_vod, same shape and
        the same reasoning for using a never-auto-reset "started" flag
        rather than an in-flight-only one."""
        if getattr(self, "_series_fetch_started", False):
            return
        self._series_fetch_started = True
        if self.screen_name == "series" and not self._series_loaded:
            self.series.set_loading(True)
        self.status.setText("Loading series\u2026")

        server, user = self.api.server, self.api.username

        def fetch():
            try:
                cats = self.api.get_series_categories()
            except Exception:
                cats = []
            shows = self.api.get_series()
            try:
                core.save_series_cache(server, user, cats, shows)
            except Exception:
                pass
            return cats, shows

        def done(result):
            cats, shows = result
            self.lib.series_categories = cats or []
            self.lib.series_list = shows or []
            self._series_loaded = True
            if self.screen_name == "series":
                self.series.set_loading(False)
                self.series.set_categories(self.lib.series_categories)
                self.series.set_items(
                    self.lib.series_list,
                    "Your provider may not include series content.")
            self.status.setText(f"{len(self.lib.series_list)} series loaded")
            self.home.refresh_hero()

        def failed(error):
            if self.screen_name == "series" and not self._series_loaded:
                self.series.show_error(f"Could not load series.\n{error}")
            self.status.setText("Could not load series.")

        background(fetch, done, failed)

    def _load_epg(self, url=None):
        # get_xmltv() already calls parse_xmltv() internally and returns a dict
        # Do NOT call parse_xmltv() again — that would pass a dict to BytesIO
        source = url if url is not None else (self.lib.settings.get("epg_url") or "")
        epg = self.api.get_xmltv(source or None) or {}
        # Runs on the worker thread, so the (large) write never blocks the UI.
        core.save_epg_cache(self.api.server, self.api.username, source, epg)
        return epg

    def _got_cached_epg(self, epg):
        fluxtv_perf.mark(f"saved guide loaded ({len(epg or {})} channels)")
        # A fresh download may already have landed; never replace it
        # with the older copy from disk.
        if epg and not self.lib.epg:
            self._got_epg(epg)
            self.status.setText(f"Guide loaded from cache for {len(epg):,} channels")

    def _got_categories(self, categories):
        self.lib.categories = categories or self.lib._raw.get("categories", [])
        self._persist()

    def _got_channels(self, channels):
        if not channels:
            return
        fluxtv_perf.mark(f"provider channel list arrived ({len(channels)})")
        fresh = len(channels) != len(self.lib.all_channels)
        self.lib.all_channels = channels
        self.lib.channels = channels
        self.lib._invalidate_caches()
        self.conn.setText("Connected")
        self.conn.setStyleSheet(f"color: {C.ok};")
        self._persist()
        if fresh:
            self.home.rebuild()
            if self.screen_name == "live":
                self.live.set_categories(self.lib.categories)
                self.live.set_channels(self.lib.all_channels)
            elif self.screen_name == "sport":
                self.sport.set_channels(self.lib._collection("Sports"))
        self.status.setText(f"{len(channels):,} channels")

    def _got_epg(self, epg):
        # An empty-but-successful fetch used to look identical to "never
        # tried" here (both silently did nothing), which made a real
        # parsing/matching failure invisible. Always assign and report.
        epg = epg or {}
        self.lib.epg = epg
        self._refresh_all_cards()
        if epg:
            self.status.setText(f"Guide loaded for {len(epg):,} channels")
        else:
            self.status.setText(
                "Programme guide loaded but contained no data \u2014 check "
                "the custom XMLTV URL in Settings if you've set one.")

    def _refresh_all_cards(self):
        """EPG now/next changes every card that shows a channel."""
        self.home.refresh_cards()
        for key in ("live", "sport", "favourites"):
            self.screen_widgets[key].refresh_cards()

    def _persist(self):
        """Save the channel library — on a worker thread, since gzipping
        tens of thousands of channels on the UI thread froze the picture
        of whatever was playing for a second or more."""
        # The full lists, not what the parental lock lets through.
        raw_cats = self.lib._raw.get("categories") or []
        raw_chans = self.lib._raw.get("all_channels") or []
        if raw_cats and raw_chans:
            server, user = self.api.server, self.api.username
            cats, chans = list(raw_cats), list(raw_chans)
            background(lambda: core.save_library_cache(server, user, cats, chans),
                       lambda _r: None, lambda _e: None)

    # ── actions ──────────────────────────────────────────────────
    def _select(self, channel):
        self.lib.selected = channel

    def _toggle_fav(self, channel):
        self.lib._toggle_fav(channel)
        self._refresh_all_cards()
        # A toggle changes the Favourites screen's membership, not just
        # its cards' star state, so it needs a full rebuild if visible.
        if self.screen_name == "favourites":
            self.favourites.set_channels(self.lib._fav_channels(),
                                         "Star a channel to keep it here.")

    def play_current(self):
        if self.current:
            self.play(self.current)

    def play(self, channel):
        """Launch a live channel — same stream URL and cache/demuxer
        flags as always, now routed through the shared _launch() so it
        can embed in the player screen like everything else does."""
        name = channel.get("name", "Unknown")
        stream_id = channel.get("stream_id")
        if not stream_id:
            show_dialog(self, lambda: QMessageBox.critical(
                self, "Playback error", f"No stream ID for {name}."))
            return
        settings = self.lib.settings
        fmt = settings.get("stream_format", "ts")
        stream_url = (f"{self.api.server}/live/{self.api.username}/"
                      f"{self.api.password}/{stream_id}.{fmt}")
        if not self._zapping:
            self._set_zap_context(channel)
        if self.current is not None and self.current is not channel:
            self._prev_channel = self.current
        self.current = channel
        self.lib.favs.setdefault(self.lib._fav_key(channel), {})[
            "last_watched"] = int(time.time())
        core.save_favs(self.lib.favs)
        self.lib._invalidate_user_caches()
        subtitle = self.lib._programme_text(channel)

        # Fast path: switching from one already-playing LIVE channel to
        # another. Rather than killing MPV and spawning a fresh process
        # for every single channel change — which tears down and rebuilds
        # the entire video output pipeline each time, and is exactly
        # where a brief stray-colour flash between one video ending and
        # the next one's first frame has kept appearing despite three
        # separate attempts at hiding it (Qt widget visibility, then a
        # direct X11 window clear) — tell the SAME already-running MPV
        # process to load the new URL over the IPC channel already used
        # for play/pause and volume. The video output itself never tears
        # down or restarts, so there's no transition left for anything
        # to flash into. Only applies live-to-live: a VOD/episode
        # session keeps using a full relaunch below, since resume
        # tracking there is more involved than this fast path is worth
        # covering.
        if (not self._libmpv and self.player_view._is_live and self._embedded
                and self._ipc_path and
                self.mpv and self.mpv.poll() is None):
            if mpv_ipc_command(self._ipc_path, ["loadfile", stream_url, "replace"]):
                self._mark_on_air(channel)
                self.player_view.set_now_playing(name, subtitle, is_live=True)
                self.status.setText(f"Playing {name}")
                return True
            # IPC didn't go through — MPV may have become unresponsive
            # since the watchdog last checked. Fall through to a full
            # relaunch below rather than leaving the person stuck on a
            # dead channel.

        cache = settings.get("cache_secs", 30)
        max_mb = settings.get("demuxer_max_mb", 50)
        readahead = settings.get("readahead_secs", 20)
        extra_args = ["--cache=yes", f"--cache-secs={cache}",
                      f"--demuxer-max-bytes={max_mb}M",
                      f"--demuxer-readahead-secs={readahead}"]
        started = self._launch(stream_url, name, is_live=True,
                               subtitle=subtitle, extra_args=extra_args)
        if started:
            self._mark_on_air(channel)
            self._start_watchdog()
            if self._libmpv:
                self._show_channel_banner()
        return started

    # ── live channel changing (libmpv player) ────────────────────
    def _set_zap_context(self, channel):
        """Pick the list Up/Down will move through: the list the channel
        was started from (a Live TV category, Favourites, a Home shelf,
        the Guide), falling back to the channel's own category."""
        def index_in(channels):
            for i, c in enumerate(channels):
                if c is channel:
                    return i
            sid = channel.get("stream_id")
            for i, c in enumerate(channels):
                if sid is not None and c.get("stream_id") == sid:
                    return i
            return -1

        screen_name = self.screen_name
        if screen_name == "player" and index_in(self._zap_list) >= 0:
            self._zap_index = index_in(self._zap_list)
            return
        screen = self.screen_widgets.get(screen_name)
        titles = {"live": "Live TV", "sport": "Sport", "favourites": "Favourites",
                  "guide": "TV Guide", "home": "Home"}
        candidates = []
        grid = getattr(screen, "grid", None)
        if grid is not None and getattr(grid, "items", None):
            candidates.append(list(grid.items))
        for shelf in getattr(screen, "shelves", []) or []:
            candidates.append(list(getattr(shelf, "channels", [])))
        if getattr(screen, "channels", None):
            candidates.append(list(screen.channels))
        for channels in candidates:
            i = index_in(channels)
            if i >= 0:
                self._zap_list, self._zap_index = channels, i
                self._zap_title = titles.get(screen_name, "")
                return
        cat = str(channel.get("category_id", ""))
        same = [c for c in self.lib.all_channels
                if str(c.get("category_id", "")) == cat] or list(self.lib.all_channels)
        self._zap_list = same
        self._zap_index = max(0, index_in(same))
        names = {str(c.get("category_id")): c.get("category_name", "")
                 for c in self.lib.categories}
        self._zap_title = names.get(cat, "")

    def _channel_info(self, channel, row=None):
        now, nxt = _now_next(self.lib, channel)
        logo = None
        url = channel.get("stream_icon", "")
        if url and self.lib.settings.get("show_logos", True):
            box = (150, 100)
            logo = LOGOS.get(url, box)
            if logo is None:
                LOGOS.request(url, box)
        number = channel.get("num") or (row + 1 if row is not None else "")
        return {"name": channel.get("name", "Unknown"), "number": number,
                "logo": logo, "now": now, "next": nxt}

    def _show_channel_banner(self):
        channel = self._zap_pending or self.current
        if channel is None or not self._libmpv:
            return
        row = self._zap_index if self._zap_index >= 0 else None
        self.player_view.show_banner(self._channel_info(channel, row))

    def _zap(self, delta):
        """Up/Down in the player. The banner jumps straight to the target
        channel; the stream only switches once you stop pressing, so
        flicking past five channels doesn't load five streams."""
        if self._session and self._session["extra_meta"].get("kind") == "youtube":
            self.music.next() if delta > 0 else self.music.previous()
            return
        if not self._zap_list:
            return
        self._zap_index = (self._zap_index + delta) % len(self._zap_list)
        self._zap_pending = self._zap_list[self._zap_index]
        self._show_channel_banner()
        self._zap_timer.start()

    def _commit_zap(self):
        channel, self._zap_pending = self._zap_pending, None
        if channel is not None and channel is not self.current:
            self._zapping = True
            try:
                self.play(channel)
            finally:
                self._zapping = False

    def _zap_to_row(self, row):
        if 0 <= row < len(self._zap_list):
            self._zap_timer.stop()
            self._zap_index = row
            self._zap_pending = self._zap_list[row]
            self._commit_zap()

    def _last_channel(self):
        channel = self._prev_channel
        if channel is None:
            return
        self._zap_timer.stop()
        for i, c in enumerate(self._zap_list):
            if c is channel:
                self._zap_index = i
                break
        self._zap_pending = channel
        self._commit_zap()

    def _open_channel_list(self):
        if not self._zap_list:
            return
        self.player_view.open_channel_list(
            lambda row: self._channel_info(self._zap_list[row], row),
            len(self._zap_list), self._zap_index, self._zap_title)

    def _mark_on_air(self, channel):
        self.home.mark_on_air(channel)
        for key in ("live", "sport", "favourites"):
            self.screen_widgets[key].mark_on_air(channel)

    def stop(self, silent=False):
        if self._libmpv:
            self._stop_libmpv(silent)
            return
        QTimer.singleShot(3000, self._resume_deferred_refresh)
        if self._watchdog:
            self._watchdog.stop()
            self._watchdog = None
        if self._tracker:
            self._tracker.stop()
            self._tracker = None
        # Hiding the video surface early (before MPV is even asked to
        # terminate) only matters when actually leaving the player
        # screen behind — that's the situation where Qt goes on to
        # restore window state and switch screens while MPV's real,
        # separate native window can still be sitting there with its
        # last frame, colliding with that transition. A channel switch
        # calls this same stop() silently as its very first step before
        # immediately launching the next channel on the SAME video
        # surface, with no screen switch or window-state change to race
        # against — hiding it there was never fixing anything, only
        # adding a visible gap of its own (a blank flash) where there
        # used to be a clean, direct cut from one channel's video to the
        # next. Scoping this to the non-silent, actually-leaving case is
        # what "before anything else at all" should have meant.
        if not silent and self._embedded:
            self.player_view.video.hide()
            self.player_view.panel.hide()
            QApplication.processEvents()
        ipc_path = self._ipc_path
        input_conf_path = self._input_conf_path
        if self.mpv and self.mpv.poll() is None:
            try:
                self.mpv.terminate()
                # Give MPV 2s to exit cleanly, then kill
                import threading
                def reap(proc, sock_path, conf_path):
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    _cleanup_temp_file(sock_path)
                    _cleanup_temp_file(conf_path)
                threading.Thread(target=reap, args=(self.mpv, ipc_path, input_conf_path),
                                 daemon=True).start()
            except Exception:
                _cleanup_temp_file(ipc_path)
                _cleanup_temp_file(input_conf_path)
        else:
            # MPV already wasn't running (e.g. a crash already reaped by
            # _check_mpv) — nothing to terminate, but the socket file it
            # left behind in /tmp is still there and still ours to clear.
            _cleanup_temp_file(ipc_path)
            _cleanup_temp_file(input_conf_path)
        self.mpv = None
        was_embedded = self._embedded
        self._embedded = False
        self._ipc_path = None
        self._input_conf_path = None
        if not silent:
            self.current = None
            self._mark_on_air(None)
            self.status.setText("Stopped")
            self._exit_video_fullscreen()
            if was_embedded and self.screen_name == "player":
                self.go(getattr(self, "_pre_player_screen", "home"))

    def _exit_video_fullscreen(self):
        """Leave fullscreen the way we found it. The app now starts
        fullscreen by default, so "the way we found it" is usually
        fullscreen itself — the old maximized-only version of this
        assumed the browsing window was never fullscreen to begin with,
        which stopped being true the moment startup switched to
        showFullScreen(), and would have dropped back to a small window
        every time a video stopped. Qt's showFullScreen() -> showNormal()
        clears maximized along with fullscreen regardless, landing on
        the small base window size — the actual bug this is guarding
        against — so the prior state has to be restored explicitly
        rather than assumed.
        """
        if not self.isFullScreen():
            return
        state = getattr(self, "_pre_video_window_state", "fullscreen")
        if state == "maximized":
            self.showMaximized()
        elif state == "normal":
            self.showNormal()
        # else "fullscreen": already there, nothing to do.

    def _start_watchdog(self):
        """Poll every 5s — restart MPV if it died unexpectedly."""
        if self._libmpv:
            return      # the libmpv player reports drops itself (ended signal)
        if self._watchdog:
            self._watchdog.stop()
        self._watchdog = QTimer(self)
        self._watchdog.setInterval(5000)
        self._watchdog.timeout.connect(self._check_mpv)
        self._watchdog.start()

    def _check_mpv(self):
        if not self.mpv or not self.current:
            return
        if self.mpv.poll() is not None:
            # MPV exited — check if it was intentional. With the video
            # embedded there's no separate window for the person to
            # close, so an exit here almost always means a crash; the
            # exit-code-0 case mainly still matters for the Wayland/
            # no-embedding fallback, where MPV keeps its own window.
            code = self.mpv.poll()
            self.mpv = None
            _cleanup_temp_file(self._ipc_path)
            _cleanup_temp_file(self._input_conf_path)
            self._ipc_path = None
            self._input_conf_path = None
            if code == 0:
                self.current = None
                self._mark_on_air(None)
                self.status.setText("Stopped")
                if self._watchdog:
                    self._watchdog.stop()
                    self._watchdog = None
                self._exit_video_fullscreen()
                if self._embedded and self.screen_name == "player":
                    self.go(getattr(self, "_pre_player_screen", "home"))
            else:
                # Unexpected crash — restart after 2s
                self.status.setText(f"Stream dropped (exit {code}) — restarting…")
                ch = self.current
                QTimer.singleShot(2000, lambda: self.play(ch))

    # ── VOD / episode playback ───────────────────────────────────
    def play_vod(self, item):
        name = item.get("name", "Unknown")
        stream_id = item.get("stream_id")
        ext = item.get("container_extension", "mp4")
        url = self.api.get_vod_url(stream_id, ext)
        key = core.vod_key(item)
        resume = self._resume_seconds(key)
        subtitle = "   ".join(filter(None, [str(item.get("year", "")),
                                            item.get("genre", "")]))
        self._launch(url, name, is_live=False, subtitle=subtitle,
                    progress_key=key, resume_seconds=resume,
                    extra_meta={"kind": "vod", "stream_id": stream_id,
                               "container_extension": ext})

    def play_episode(self, ep, series):
        name = ep.get("title") or f"Episode {ep.get('episode_num', '?')}"
        stream_id = ep.get("id")
        ext = ep.get("container_extension", "mp4")
        url = self.api.get_episode_url(stream_id, ext)
        series_name = series.get("name", "") if series else ""
        label = f"{series_name} \u2014 {name}" if series_name else name
        key = core.episode_key(ep)
        resume = self._resume_seconds(key)
        season = ep.get("season")
        subtitle = f"Season {season}" if season else series_name
        self._launch(url, label, is_live=False, subtitle=subtitle,
                    progress_key=key, resume_seconds=resume,
                    extra_meta={
                        "kind": "episode", "stream_id": stream_id,
                        "container_extension": ext,
                        "series_id": series.get("series_id") if series else None,
                        "series_name": series_name,
                        "season": season,
                        "episode_num": ep.get("episode_num"),
                    })

    def _resume_seconds(self, key):
        """Where to resume, or 0 to start from the beginning.

        Below 2% watched isn't worth resuming (may as well start over);
        above 92% is treated as finished, not paused partway through.
        """
        entry = core.load_watch_progress().get(key)
        if not entry:
            return 0
        fraction = core.watch_progress_fraction(entry)
        if 0.02 < fraction < 0.92:
            return int(entry.get("position", 0))
        return 0

    def _launch(self, url, name, *, is_live=False, subtitle="",
               extra_args=None, progress_key=None, resume_seconds=0,
               extra_meta=None):
        """Single shared launch path for live channels, movies and
        episodes. Builds the common MPV invocation, decides whether the
        video can embed inside our own player screen or needs to fall
        back to MPV's own top-level window, and — when embedding — wires
        that screen's on-screen controls up to the newly running process.

        Returns True if MPV was actually launched, False if it failed
        (a message box has already told the person why in that case).
        """
        if (extra_meta or {}).get("kind") != "youtube" and self.music.is_playing_sound():
            self.music.stop()
        if self._libmpv:
            return self._launch_libmpv(
                url, name, is_live=is_live, subtitle=subtitle,
                extra_args=extra_args, progress_key=progress_key,
                resume_seconds=resume_seconds, extra_meta=extra_meta)
        self.stop(silent=True)
        settings = self.lib.settings

        ipc_path = (os.path.join(tempfile.gettempdir(),
                                 f"fluxtv-mpv-{uuid.uuid4().hex}.sock")
                   if hasattr(socket, "AF_UNIX") else None)
        embed = ipc_path is not None and is_window_embedding_supported()

        args = [core.MPV_PATH]
        if ipc_path:
            args.append(f"--input-ipc-server={ipc_path}")
        # Force the older, more battle-tested "gpu" video output rather
        # than letting MPV auto-select whatever its own default is
        # (on a reasonably recent build, that's "gpu-next"). This is a
        # known, documented failure combination: gpu-next's libplacebo
        # renderer mapping a VAAPI-hardware-decoded surface can fail
        # (mpv's own upstream issue tracker has multiple reports of
        # exactly this — "mapping VAAPI EGL image failed" / "Mapping
        # hardware decoded surface failed" — logged right as the
        # screen goes solid purple or blue instead of erroring out
        # cleanly), and it's specifically the VAAPI+gpu-next combination
        # implicated, not hardware decoding on its own. Every channel
        # switch reconfigures the decoder for a new stream, which is
        # exactly the kind of moment that triggers a fresh surface
        # mapping attempt — matching a purple flash appearing right at
        # that transition. The plain "gpu" VO doesn't use that newer
        # renderer path and keeps hardware decoding working normally.
        args.append("--vo=gpu")
        # Multi-language releases often list Russian (or another) audio
        # first; ask for English first, falling back to the file's default.
        args.append(f"--alang={settings.get('audio_lang', 'en,eng,english')}")
        # Hardware decoding was already happening implicitly via MPV's
        # own auto-detection before this setting existed — this makes
        # it an explicit, visible choice instead, with software
        # decoding as a real fallback if hardware decoding is ever the
        # cause of a playback issue on a given machine.
        if settings.get("hardware_accel", True):
            args.append("--hwdec=auto")
        else:
            args.append("--hwdec=no")

        if embed:
            # Get the window to its FINAL size first — fullscreen it (if
            # that's the setting) before the player screen, and its video
            # surface, even exist yet. Previously this switched screens
            # (creating the video surface at whatever size the window
            # happened to be) and only THEN resized to fullscreen a
            # moment later — two separate resizes of a widget that's
            # about to have a foreign process's video drawn into it,
            # which is exactly the kind of sequence that can leave a
            # stale frame briefly visible underneath the new one. Doing
            # the resize first means the video surface is created once,
            # already at its final geometry, with nothing left to resize
            # around it afterward.
            if settings.get("fullscreen", True):
                if self.isFullScreen():
                    self._pre_video_window_state = "fullscreen"
                elif self.isMaximized():
                    self._pre_video_window_state = "maximized"
                else:
                    self._pre_video_window_state = "normal"
                # showFullScreen() already sizes to the exact screen by
                # definition — an explicit setGeometry() call right after
                # it was redundant belt-and-braces from an earlier round,
                # and turned out to actively interfere with the
                # fullscreen state in some window-transition sequences
                # (confirmed: it could silently prevent fullscreen from
                # actually taking effect at all). Trusting showFullScreen()
                # on its own is both simpler and more reliable.
                self.showFullScreen()
                QApplication.processEvents()

            self.go("player")
            self.player_view.set_now_playing(name, subtitle, is_live=is_live)
            # Hide the panel before anything else can resize — switching
            # screens still triggers its own layout pass, and a visible
            # panel being repositioned mid-pass is what caused the
            # bar-flicker seen before.
            self.player_view.panel.hide()
            QApplication.processEvents()
            # Switching to the player screen can itself generate a
            # synthetic enter/activity event for the video surface (it's
            # now "under the cursor" as far as the window is concerned),
            # which fires the same activity callback a real mouse move
            # would — re-showing the panel we just hid, within that same
            # processEvents() call. Re-asserting hidden afterward beats
            # trying to out-guess every possible source of that signal.
            self.player_view.panel.hide()
            # stop() now explicitly hides this surface as the very first
            # step of tearing down the previous session (to stop a stale
            # last frame lingering on screen during the transition) — so
            # it has to be explicitly shown again here for THIS session,
            # or the video would stay invisible even though MPV is
            # correctly drawing into it underneath.
            self.player_view.video.show()
            wid = int(self.player_view.video.winId())
            args.append(f"--wid={wid}")
            # Force this window to solid black right now, before the new
            # MPV process is even started — covers the gap between
            # whatever was here before (another channel's last frame, or
            # nothing at all right after startup) and this session's
            # first decoded frame, which is exactly where a stray colour
            # was showing through. Guarded here too, on top of the
            # function's own internal safety net: this is a cosmetic
            # improvement, and nothing about it should ever be able to
            # stop a channel from actually playing.
            try:
                _clear_native_window_black(wid)
            except Exception:
                pass
            # Create the embedded window promptly rather than lazily
            # waiting for the first video frame to know its size — the
            # window (and thus the wid MPV is drawing into) already has
            # its final geometry now, so there's no reason to wait.
            args.append("--force-window=immediate")
            # Embedding the video does NOT automatically stop MPV from
            # acting like it owns its own window: by default it still
            # grabs keyboard input for its own bindings (space, f, q,
            # arrows...), runs its own cursor auto-hide timer, and draws
            # its own on-screen controls — all independently of, and
            # conflicting with, the Qt controls layered on top of it.
            # That's what caused the cursor and "can't get back" issues:
            # MPV was quietly intercepting input before Qt ever saw it.
            args += [
                "--no-input-default-bindings",
                "--input-vo-keyboard=no",
                "--cursor-autohide=no",
                "--osc=no",
            ]
            # A single click on the video should toggle play/pause, the
            # same as clicking a video in virtually any other player.
            # That has to be handled by MPV itself rather than Qt: a
            # click landing on this natively-embedded window is MPV's
            # to receive first, and --no-input-default-bindings above
            # already wiped its own hardcoded click-to-pause default
            # along with everything else it was intercepting — so it
            # has to be added back explicitly, deliberately narrowed to
            # just this one binding rather than restoring all of them.
            input_conf_path = _write_click_input_conf()
            if input_conf_path:
                args.append(f"--input-conf={input_conf_path}")
            QTimer.singleShot(250, self.player_view.show_controls)
        else:
            args.append("--force-window=immediate")
            fullscreen = "--fs" if settings.get("fullscreen", True) else "--no-fs"
            args.append(fullscreen)
            input_conf_path = None

        if resume_seconds and resume_seconds > 0:
            args.append(f"--start={resume_seconds}")
        if extra_args:
            args += extra_args
        args += [url, f"--title=Flux Media \u2014 {name}",
                f"--log-file={core.MPV_LOG_FILE}"]

        try:
            self.mpv = subprocess.Popen(args)
        except FileNotFoundError:
            _cleanup_temp_file(input_conf_path)
            show_dialog(self, lambda: QMessageBox.critical(
                self, "MPV not found",
                f"Could not find MPV at:\n{core.MPV_PATH}\n\n"
                "Install MPV and try again."))
            if embed:
                self.go(getattr(self, "_pre_player_screen", "home"))
            return False
        except OSError as error:
            _cleanup_temp_file(input_conf_path)
            reason = str(error)        # `error` is gone once the except block ends
            show_dialog(self, lambda: QMessageBox.critical(
                self, "MPV error", f"Could not start MPV:\n{reason}"))
            if embed:
                self.go(getattr(self, "_pre_player_screen", "home"))
            return False

        resumed = f" (resuming at {_format_hms(resume_seconds)})" \
            if resume_seconds else ""
        self.status.setText(f"Playing {name}{resumed}")
        self._embedded = embed
        self._ipc_path = ipc_path
        self._input_conf_path = input_conf_path
        self._start_ipc(ipc_path, embed, name, progress_key, extra_meta or {})
        return True

    # ── libmpv player (fluxtv_player) ────────────────────────────
    @staticmethod
    def _cli_args_to_options(extra_args):
        """["--cache-secs=30", ...] -> {"cache-secs": "30", ...} so the
        same per-stream flags work as libmpv properties."""
        options = {}
        for arg in extra_args or []:
            if arg.startswith("--") and "=" in arg:
                key, value = arg[2:].split("=", 1)
                if key == "audio-file":
                    # A list option: set as a list so the URL's ':' isn't
                    # taken as a separator.
                    options["audio-files"] = [value]
                else:
                    options[key] = value
        return options

    def _enter_video_fullscreen(self):
        if self.isFullScreen():
            self._pre_video_window_state = "fullscreen"
        elif self.isMaximized():
            self._pre_video_window_state = "maximized"
        else:
            self._pre_video_window_state = "normal"
        self.showFullScreen()

    def _launch_libmpv(self, url, name, *, is_live, subtitle, extra_args,
                       progress_key, resume_seconds, extra_meta):
        """Play through the long-lived in-window libmpv player. Switching
        titles is a loadfile on the same player, so there is no process
        to kill, no window to re-embed and nothing to flash between."""
        self._save_final_progress()
        if self._session and self._session["url"] != url:
            self._finish_addon_session(self._session)
        if not self._session or self._session["url"] != url:
            self._reconnects = 0
        settings = self.lib.settings
        if settings.get("fullscreen", True) and self.screen_name != "player":
            self._enter_video_fullscreen()
        self.go("player")
        self.player_view.set_now_playing(name, subtitle, is_live=is_live)
        self._session = {
            "url": url, "name": name, "is_live": is_live, "subtitle": subtitle,
            "extra_args": extra_args, "progress_key": progress_key,
            "extra_meta": extra_meta or {}, "last_save": 0.0,
            "position": 0.0, "duration": 0.0,
        }
        options = {"alang": self.lib.settings.get("audio_lang", "en,eng,english"),
                   **self._cli_args_to_options(extra_args)}
        rewind = bool(is_live and settings.get("live_rewind", True))
        self.player_view.live_rewind = rewind
        if rewind:
            # Keep what's been watched so live TV can be paused and rewound:
            # up to ~1.5 GB (half an hour or more of HD) in a temporary file
            # on disk rather than in memory.
            cache_dir = os.path.join(tempfile.gettempdir(), "fluxmedia-live-cache")
            os.makedirs(cache_dir, exist_ok=True)
            options.update({"cache": "yes", "demuxer-seekable-cache": "yes",
                            "cache-on-disk": "yes", "demuxer-cache-dir": cache_dir,
                            "demuxer-max-back-bytes": "1500MiB"})
        self.player_view.play(
            url, start=resume_seconds or 0, options=options,
            hwdec=settings.get("hardware_accel", True), title=name)
        resumed = f" (resuming at {_format_hms(resume_seconds)})" \
            if resume_seconds else ""
        self.status.setText(f"Playing {name}{resumed}")
        return True

    def _stop_libmpv(self, silent):
        if not silent and self._session and \
                self._session["extra_meta"].get("kind") == "youtube":
            self.music.watch_stopped()
        self._save_final_progress()
        self._finish_addon_session(self._session)
        self._session = None
        self._reconnects = 0
        self.player_view.stop_playback()
        QTimer.singleShot(3000, self._resume_deferred_refresh)
        if not silent:
            self.current = None
            self._mark_on_air(None)
            self.status.setText("Stopped")
            self._exit_video_fullscreen()
            if self.screen_name == "player":
                back_to = getattr(self, "_pre_player_screen", "home")
                self.go("music" if back_to == "nowplaying" and self.music.stopped else back_to)

    def _on_libmpv_progress(self, position, duration):
        s = self._session
        if not s:
            return
        s["position"], s["duration"] = position, duration
        if s["extra_meta"].get("kind") == "youtube":
            target = self.music.skip_target(position)
            if target is not None:
                if duration and target >= duration - 1:
                    self._on_libmpv_ended("eof")
                else:
                    self.player_view.video.seek(target)
                    self.status.setText("Skipped the non-music part")
        if not s["progress_key"]:
            return
        now = time.monotonic()
        if now - s["last_save"] < 5:
            return
        s["last_save"] = now
        self._save_progress(s, position, duration)

    def _save_final_progress(self):
        s = self._session
        if s and s["progress_key"] and s["duration"] > 0:
            self._save_progress(s, s["position"], s["duration"])

    def _save_progress(self, s, position, duration):
        data = core.load_watch_progress()
        fraction = position / duration if duration > 0 else 0
        if fraction >= 0.92:
            data.pop(s["progress_key"], None)       # finished, nothing to resume
        else:
            entry = {"position": position, "duration": duration,
                     "updated": int(time.time()), "title": s["name"]}
            entry.update(s["extra_meta"])
            data[s["progress_key"]] = entry
        core.save_watch_progress(data)

    def _on_libmpv_started(self):
        self._reconnects = 0
        if self._session:
            self.status.setText(f"Playing {self._session['name']}")
            self._trakt_scrobble("start")
            self._session["started"] = True
            self._apply_subtitles()

    def _on_libmpv_ended(self, reason):
        s = self._session
        if not s:
            return
        if s["extra_meta"].get("kind") == "youtube":
            upcoming = self.music.up_next(1)
            if reason == "eof" and upcoming:
                self.player_view.show_notice("Up next", upcoming[0][1].get("title", ""),
                                             buttons=False)
            self.music.on_watch_ended(reason)
            return
        if s["is_live"] and self.current:
            # Same as the old watchdog: a live stream that drops gets
            # reconnected — but give up after a few tries rather than
            # looping forever on a channel that's genuinely down.
            self._reconnects += 1
            if self._reconnects > 5:
                self.player_view.show_notice(
                    "This channel isn't responding",
                    "The stream kept dropping. It may be offline right now.")
                self.status.setText("Stream unavailable.")
                return
            self.player_view.show_notice("Reconnecting…", buttons=False)
            self.status.setText("Stream dropped — reconnecting…")
            channel = self.current
            QTimer.singleShot(2000, lambda: self._reconnect_live(channel))
        elif reason == "eof":
            s["position"] = s["duration"]          # counts as finished
            self.stop()
        else:
            self.player_view.show_notice(
                "Couldn't play this title",
                "The stream failed to load. Your provider may be busy — "
                "try again in a moment.")
            self.status.setText("Playback failed.")

    def _reconnect_live(self, channel):
        if self._session and self.current is channel:
            self.player_view.hide_notice()
            self.play(channel)

    def _retry_libmpv(self):
        s = self._session
        if not s:
            return
        self._reconnects = 0
        if s["is_live"] and self.current:
            self.player_view.hide_notice()
            self.play(self.current)
            return
        resume = self._resume_seconds(s["progress_key"]) if s["progress_key"] else 0
        self._launch_libmpv(s["url"], s["name"], is_live=False,
                            subtitle=s["subtitle"], extra_args=s["extra_args"],
                            progress_key=s["progress_key"],
                            resume_seconds=resume, extra_meta=s["extra_meta"])

    def _on_libmpv_render_failed(self, detail):
        self.player_view.show_notice(
            "Video output couldn't start",
            f"OpenGL rendering failed ({detail}). Start Flux Media with "
            "FLUXTV_PLAYER=external to use MPV's own window instead.")

    def _start_ipc(self, ipc_path, embed, name, progress_key, extra_meta):
        """Start polling MPV over IPC — driving the player screen's
        controls when embedded, and/or checkpointing resume position for
        VOD/episodes either way. Skips entirely for a live channel that
        isn't embedded (MPV's own window, nothing here to update)."""
        if not ipc_path or (not embed and not progress_key):
            return
        interval = 1000 if embed else 10_000
        self._tracker = PlaybackTracker(ipc_path, self, interval_ms=interval)
        checkpoint_every = max(1, 5000 // interval)
        tick = {"n": 0}

        def on_progress(position, duration):
            if embed:
                self.player_view.update_progress(position, duration)
            if progress_key:
                tick["n"] += 1
                if tick["n"] % checkpoint_every != 0:
                    return
                data = core.load_watch_progress()
                fraction = position / duration if duration > 0 else 0
                if fraction >= 0.92:
                    # Close enough to the end to count as finished —
                    # remove rather than leave a stale near-complete
                    # entry offering to "resume" the last few seconds.
                    data.pop(progress_key, None)
                else:
                    entry = {"position": position, "duration": duration,
                             "updated": int(time.time()), "title": name}
                    entry.update(extra_meta)
                    data[progress_key] = entry
                core.save_watch_progress(data)

        self._tracker.progress.connect(on_progress)
        if embed:
            self._tracker.state.connect(self.player_view.update_state)
        # MPV needs a moment after Popen returns to actually create the
        # IPC socket file; the first poll would just fail harmlessly
        # either way, but there's no reason to spend it on a guaranteed
        # miss.
        QTimer.singleShot(1000 if embed else 1500, self._tracker.start)

    # ── settings actions ─────────────────────────────────────────
    def refresh_server(self):
        self.status.setText("Checking server and refreshing library\u2026")

        def check():
            return self.api.test_connection()

        def done(result):
            ok, detail = result
            if not ok:
                show_dialog(self, lambda: QMessageBox.critical(
                    self, "Server connection", str(detail)))
                self.status.setText("Server refresh failed.")
                return
            self.refresh_in_background()
            self.status.setText("Server refreshed \u2014 library updating.")

        background(check, done)

    def change_login(self):
        reply = show_dialog(self, lambda: QMessageBox.question(
            self, "Change login",
            "Return to the Flux Media login page and enter a different account?"))
        if reply != QMessageBox.Yes:
            return
        self.stop(silent=True)
        prefill = {"server": self.api.server, "username": self.api.username,
                  "password": self.api.password}
        self.show_login(prefill)

    def logout(self):
        reply = show_dialog(self, lambda: QMessageBox.question(
            self, "Sign out",
            "Sign out and forget these saved details on this computer?"))
        if reply != QMessageBox.Yes:
            return
        self.stop(silent=True)
        core.clear_credentials()
        self.show_login()

    def reload_epg(self, url):
        self.status.setText("Reloading programme guide\u2026")

        def fetch():
            return self._load_epg(url or "")

        background(fetch, self._got_epg,
                  lambda e: self.status.setText(f"Could not reload guide. {e}"))

    def apply_credentials(self, server, user, pwd):
        self.api.server = server.rstrip("/")
        self.api.username = user
        self.api.password = pwd
        try:
            core.save_credentials(self.api.server, user, pwd)
        except Exception:
            pass
        sources = core.load_sources()
        for src in sources:
            if (src.get("server") or "").rstrip("/") == self.api.server:
                src.update({"username": user, "password": pwd})
                core.save_sources(sources)
                break
        self.status.setText("Credentials updated \u2014 refreshing\u2026")
        self.refresh_server()

    def eventFilter(self, obj, event):
        if obj is getattr(self, "_rail", None) and event.type() == QEvent.Resize:
            # 86px tabs suit a TV; on a laptop screen they wouldn't all fit.
            count = len(self.NAV) + 1
            room = obj.height() - 20 - 4 * count - 12
            height = max(58, min(86, room // count))
            for btn in self.nav_buttons.values():
                btn.set_height(height)
        return super().eventFilter(obj, event)

    def closeEvent(self, event):
        for rec in list(getattr(self, "_recorders", {}).values()):
            rec.stop()
        self.stop(silent=True)
        self.music.shutdown()
        pv = getattr(self, "player_view", None)
        if pv is not None and hasattr(pv, "shutdown"):
            pv.shutdown()
        super().closeEvent(event)


def main():
    if sys.stdout is None or sys.stderr is None:
        # Started without a console (Windows Desktop shortcut runs
        # pythonw.exe): keep FluxTV's messages in a log file instead of
        # losing them.
        try:
            os.makedirs(core.APP_DIR, exist_ok=True)
            log = open(os.path.join(core.APP_DIR, "fluxtv.log"), "a", buffering=1,
                       encoding="utf-8", errors="replace")
            log.write(f"\n--- Flux Media started {datetime.now():%Y-%m-%d %H:%M} ---\n")
            sys.stdout = sys.stdout or log
            sys.stderr = sys.stderr or log
        except OSError:
            pass
    # libmpv's zero-copy VAAPI path imports decoded frames through EGL.
    # Qt on X11 defaults to GLX, which left hardware decoding stuck in the
    # slower "vaapi-copy" mode (frames copied GPU -> RAM -> GPU) and made
    # busy streams jitter. Must be set before QApplication exists; an
    # explicit setting in the environment still wins.
    if platform.system() == "Linux" and fluxtv_player.AVAILABLE:
        os.environ.setdefault("QT_XCB_GL_INTEGRATION", "xcb_egl")
    if platform.system() == "Windows":
        # Without its own app id Windows files the window under Python —
        # Python's taskbar icon and name, grouped with any other Python
        # program — whatever icon the window itself sets.
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("FluxTV.App")
        except Exception:
            pass
    app = QApplication(sys.argv)
    app.setApplicationName("Flux Media")
    app.setOrganizationName("FluxTV")
    app.setApplicationDisplayName("Flux Media")
    # Lets Linux desktops (GNOME/KDE, Wayland especially) match the window
    # to FluxTV.desktop, so the taskbar shows FluxTV's icon and name.
    app.setDesktopFileName("FluxTV")

    # Set taskbar / window icon. On Windows the .ico carries every size
    # the taskbar and Alt-Tab use; elsewhere the small PNG renders crisper
    # than downscaling the full logo.
    here = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(here, "fluxtv_icon.ico")
    if platform.system() != "Windows" or not os.path.exists(icon_path):
        icon_path = os.path.join(here, "fluxtv_icon_32.png")
    if not os.path.exists(icon_path):
        icon_path = os.path.join(here, "fluxtv_mark.png")
    if os.path.exists(icon_path):
        icon = QIcon(icon_path)
        app.setWindowIcon(icon)

    app.setStyleSheet(stylesheet())
    if not fluxtv_player.AVAILABLE:
        print(f"FluxTV: libmpv player unavailable ({fluxtv_player.LIBMPV_ERROR}); "
              "using MPV's own window.", file=sys.stderr)
    fluxtv_perf.mark("Qt started")
    stall_watch = fluxtv_perf.StallWatch(QTimer)   # noqa: F841 (kept alive for the session)
    window = FluxTV()

    # Also set on the window itself (belt and braces for Linux WMs)
    if os.path.exists(icon_path):
        window.setWindowIcon(QIcon(icon_path))

    # A 55" TV or any large-display media-center setup wants zero OS
    # chrome around this, not a windowed app someone has to enlarge or
    # nudge into place. Chasing "maximized, but precisely matching the
    # work area" didn't hold up in practice — some window managers don't
    # report a taskbar reservation at all, or reassert their own idea of
    # "maximized" asynchronously right after an explicit geometry is set,
    # overriding it. True fullscreen sidesteps that argument entirely:
    # it's a different, higher-priority request that essentially every
    # window manager honours by removing its own title bar and yielding
    # the taskbar, rather than something dependent on the WM correctly
    # reporting or respecting a reserved area. The existing F11 shortcut
    # still toggles back to a normal window if that's ever wanted.
    window.showFullScreen()
    fluxtv_perf.mark("window shown")
    QTimer.singleShot(60_000, fluxtv_perf.flush_startup)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()