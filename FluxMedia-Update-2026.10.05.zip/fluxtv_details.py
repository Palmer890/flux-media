#!/usr/bin/env python3
"""
Flux Media (FluxTV) — richer details for films and series, and matching a
title across your provider and the add-ons ("one library").

Always (free, no key): IMDb rating, director, writers, top cast, awards and
YouTube trailers, from Cinemeta (Stremio's own catalogue).
With a TMDB key (Settings): the main cast with photos and characters.
With an OMDb key (Settings): Rotten Tomatoes and Metacritic scores.

Titles are matched by name and year, so a film from your IPTV provider can
show its Debrid sources and the same details, and the other way round.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
import unicodedata
from urllib.parse import quote

import requests

from fluxtv_core import APP_DIR, _write_json

CINEMETA = "https://v3-cinemeta.strem.io"
CACHE_FILE = os.path.join(APP_DIR, "details_cache.json")
CACHE_DAYS = 7
_session = requests.Session()
_session.headers["User-Agent"] = "FluxMedia/1.0"
_lock = threading.Lock()
_cache = None


# ── names ────────────────────────────────────────────────────────
_NOISE = re.compile(
    r"\b(4k|uhd|fhd|hd|sd|1080p|720p|2160p|hdr|multi|sub|dub|dubbed|vostfr|vf|"
    r"x264|x265|hevc|web|webrip|bluray|imax|extended|remastered|director'?s cut)\b", re.I)


def clean_title(name):
    """Comparable form of a title: provider names often carry tags like
    'EN | Dune: Part Two (2024) 4K'."""
    text = unicodedata.normalize("NFKD", name or "")
    text = "".join(c for c in text if not unicodedata.combining(c)).lower()
    text = re.sub(r"^\s*[\[(|]?\s*[a-z]{2,3}\s*[\])|:-]+\s*", "", text)     # "EN | ", "[UK] "
    text = re.sub(r"[\[(]\s*(19|20)\d\d\s*[\])]", " ", text)               # "(2024)"
    text = _NOISE.sub(" ", text)
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"^(the|a|an) ", "", text.strip())
    return " ".join(text.split())


def year_of(*values):
    for v in values:
        m = re.search(r"(19|20)\d\d", str(v or ""))
        if m:
            return int(m.group(0))
    return None


def same_title(a_name, a_year, b_name, b_year):
    if clean_title(a_name) != clean_title(b_name):
        return False
    return not a_year or not b_year or abs(int(a_year) - int(b_year)) <= 1


# ── cache ────────────────────────────────────────────────────────
def _load_cache():
    global _cache
    if _cache is None:
        try:
            with open(CACHE_FILE, encoding="utf-8") as f:
                _cache = json.load(f)
        except (OSError, ValueError):
            _cache = {}
    return _cache


def _cached(key):
    with _lock:
        hit = _load_cache().get(key)
    if hit and time.time() - hit.get("_saved", 0) < CACHE_DAYS * 86400:
        return hit
    return None


def _store(key, value):
    with _lock:
        cache = _load_cache()
        cache[key] = dict(value, _saved=time.time())
        if len(cache) > 600:                       # keep the newest
            for old in sorted(cache, key=lambda k: cache[k].get("_saved", 0))[:100]:
                cache.pop(old, None)
        _write_json(CACHE_FILE, cache)


# ── finding a title on Cinemeta ──────────────────────────────────
def find_imdb(type_, name, year=None):
    """Cinemeta's entry for a provider title (by name and year), or None."""
    type_ = "series" if type_ == "series" else "movie"
    key = f"find:{type_}:{clean_title(name)}:{year or ''}"
    hit = _cached(key)
    if hit is not None:
        return hit.get("meta") or None
    query = re.sub(r"[\[(]\s*(19|20)\d\d\s*[\])]", "", name or "")
    query = re.sub(r"^\s*[\[(|]?\s*[a-zA-Z]{2,3}\s*[\])|:-]+\s*", "", query).strip()
    found = None
    try:
        r = _session.get(f"{CINEMETA}/catalog/{type_}/top/search={quote(query, safe='')}.json",
                         timeout=12)
        metas = (r.json() or {}).get("metas") or []
        for m in metas[:12]:
            if same_title(m.get("name"), year_of(m.get("releaseInfo"), m.get("year")),
                          name, year):
                found = {"id": m.get("id"), "type": type_, "name": m.get("name"),
                         "poster": m.get("poster"), "releaseInfo": m.get("releaseInfo")}
                break
    except (requests.RequestException, ValueError):
        return None                                   # not cached: try again next time
    _store(key, {"meta": found})
    return found


# ── details ─────────────────────────────────────────────────────
def details(type_, imdb_id, tmdb_key="", omdb_key=""):
    """{"imdb_rating", "rt", "metacritic", "director", "writers", "cast":
    [{"name", "character", "photo"}], "awards", "trailers": [youtube ids],
    "plot", "runtime", "genres", "year"} — what's available."""
    type_ = "series" if type_ == "series" else "movie"
    key = f"det:{type_}:{imdb_id}:{bool(tmdb_key)}:{bool(omdb_key)}"
    hit = _cached(key)
    if hit is not None:
        return hit
    out = {"imdb_id": imdb_id}
    try:
        meta = (_session.get(f"{CINEMETA}/meta/{type_}/{imdb_id}.json", timeout=12).json()
                or {}).get("meta") or {}
    except (requests.RequestException, ValueError):
        meta = {}
    out.update({
        "imdb_rating": meta.get("imdbRating") or "",
        "director": meta.get("director") or [],
        "writers": meta.get("writer") or [],
        "cast": [{"name": n, "character": "", "photo": ""} for n in meta.get("cast") or []],
        "awards": meta.get("awards") or "",
        "trailers": [t.get("source") for t in meta.get("trailers") or []
                     if isinstance(t, dict) and t.get("source")],
        "plot": meta.get("description") or "",
        "runtime": meta.get("runtime") or "",
        "genres": meta.get("genres") or meta.get("genre") or [],
        "year": meta.get("year") or meta.get("releaseInfo") or "",
        "tmdb_id": meta.get("moviedb_id") or "",
        "background": meta.get("background") or "",
        "poster": meta.get("poster") or "",
    })
    if tmdb_key:
        _add_tmdb(out, type_, imdb_id, tmdb_key)
    if omdb_key:
        _add_omdb(out, imdb_id, omdb_key)
    if meta:                                          # don't cache a failed lookup
        _store(key, out)
    return out


def _add_tmdb(out, type_, imdb_id, key):
    kind = "tv" if type_ == "series" else "movie"
    try:
        tmdb_id = out.get("tmdb_id")
        if not tmdb_id:
            found = _session.get(f"https://api.themoviedb.org/3/find/{imdb_id}",
                                 params={"api_key": key, "external_source": "imdb_id"},
                                 timeout=12).json()
            hits = found.get("tv_results" if kind == "tv" else "movie_results") or []
            tmdb_id = hits[0]["id"] if hits else ""
        if not tmdb_id:
            return
        credits = _session.get(f"https://api.themoviedb.org/3/{kind}/{tmdb_id}/"
                               + ("aggregate_credits" if kind == "tv" else "credits"),
                               params={"api_key": key}, timeout=12).json()
    except (requests.RequestException, ValueError, KeyError, IndexError):
        return
    cast = []
    for c in (credits.get("cast") or [])[:12]:
        character = c.get("character") or ""
        if not character and c.get("roles"):
            character = (c["roles"][0] or {}).get("character", "")
        cast.append({"name": c.get("name", ""), "character": character,
                     "photo": f"https://image.tmdb.org/t/p/w185{c['profile_path']}"
                     if c.get("profile_path") else ""})
    if cast:
        out["cast"] = cast
    if not out.get("director"):
        out["director"] = [c.get("name") for c in credits.get("crew") or []
                           if c.get("job") == "Director"][:2]


def _add_omdb(out, imdb_id, key):
    try:
        data = _session.get("https://www.omdbapi.com/", params={"i": imdb_id, "apikey": key},
                            timeout=12).json()
    except (requests.RequestException, ValueError):
        return
    if str(data.get("Response")) != "True":
        return
    for r in data.get("Ratings") or []:
        source, value = r.get("Source", ""), r.get("Value", "")
        if source == "Rotten Tomatoes":
            out["rt"] = value
        elif source == "Metacritic":
            out["metacritic"] = value.split("/")[0]
    if not out.get("imdb_rating") and data.get("imdbRating") not in (None, "N/A"):
        out["imdb_rating"] = data["imdbRating"]
    if not out.get("awards") and data.get("Awards") not in (None, "N/A"):
        out["awards"] = data["Awards"]


# ── one library: your provider's copy of a title ────────────────
class ProviderIndex:
    """Look up a film or series in the provider's lists by name + year."""

    def __init__(self):
        self._key = None
        self._films = {}
        self._shows = {}

    def _build(self, films, shows):
        key = (id(films), len(films), id(shows), len(shows))
        if key == self._key:
            return
        self._key = key
        self._films, self._shows = {}, {}
        for item in films:
            self._films.setdefault(clean_title(item.get("name")), []).append(item)
        for item in shows:
            self._shows.setdefault(clean_title(item.get("name")), []).append(item)

    def find(self, type_, name, year, films, shows):
        self._build(films, shows)
        pool = (self._shows if type_ == "series" else self._films).get(clean_title(name)) or []
        for item in pool:
            iy = year_of(item.get("year"), item.get("releaseDate"), item.get("releasedate"),
                         item.get("name"))
            if not year or not iy or abs(iy - int(year)) <= 1:
                return item
        return None
