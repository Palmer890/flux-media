#!/usr/bin/env python3
"""
FluxTV — YouTube music: search, "Mix" radio, playable links, SponsorBlock.

Everything goes through yt-dlp (plus Deno, which yt-dlp now uses to read
YouTube's player code). FluxTV installs its own copy of both into its
settings folder the first time Music is opened (or whenever the yt-dlp it
finds is too old) and updates it once a day, because YouTube changes often
and old yt-dlp versions stop working.

No Google account is used: search and Mix are the public pages, and the
links are played straight from YouTube's servers, so no adverts.
"""

from __future__ import annotations

import importlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time

import requests

from fluxtv_core import APP_DIR, _write_json

HISTORY_FILE = os.path.join(APP_DIR, "music_history.json")
STATE_FILE = os.path.join(APP_DIR, "youtube_state.json")
HISTORY_MAX = 60
UPDATE_EVERY = 24 * 3600

_lock = threading.Lock()


class YouTubeError(Exception):
    pass


# ══════════════════════════════════════════════════════════════════
# yt-dlp: present? install / update it
# ══════════════════════════════════════════════════════════════════
# FluxTV keeps its own copy in its settings folder and puts it first on
# the import path. A yt-dlp that came with Linux (apt) or was pip-installed
# long ago is often years old: it can still search, but fails to play
# ("Unable to extract uploader id"). Installing with --target also works
# where the system Python refuses pip installs (Debian/Ubuntu PEP 668).
LIB_DIR = os.path.join(APP_DIR, "pylib")
if os.path.isdir(LIB_DIR) and LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

MIN_VERSION = (2025, 11, 1)          # first with Deno support for YouTube


def version():
    try:
        v = importlib.import_module("yt_dlp.version").__version__
        return tuple(int(x) for x in v.split(".")[:3])
    except (ImportError, AttributeError, ValueError):
        return None


def available():
    """An up-to-date yt-dlp can be imported."""
    found = version()
    return found is not None and found >= MIN_VERSION


def _pip(*args, timeout=900, low_priority=False):
    """Run pip in FluxTV's own Python, without a console window popping
    up on Windows. Returns (ok, last output line)."""
    python = sys.executable
    if os.name == "nt" and python.lower().endswith("pythonw.exe"):
        python = python[:-len("pythonw.exe")] + "python.exe"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        extra = {}
        if low_priority and hasattr(os, "nice"):
            extra["preexec_fn"] = lambda: os.nice(15)     # don't compete with playback
        done = subprocess.run([python, "-m", "pip", "install", "--quiet",
                               "--disable-pip-version-check", *args],
                              capture_output=True, text=True, timeout=timeout,
                              creationflags=flags, **extra)
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)
    lines = (done.stderr or done.stdout or "").strip().splitlines()
    return done.returncode == 0, (lines[-1] if lines else "")


PACKAGES = ("yt-dlp[default]", "deno")


def _install_own_copy():
    os.makedirs(LIB_DIR, exist_ok=True)
    ok, why = _pip("--target", LIB_DIR, "--upgrade", *PACKAGES)
    print(f"FluxTV youtube: installing yt-dlp into {LIB_DIR}: "
          f"{'ok' if ok else 'failed'} {why}", file=sys.stderr, flush=True)
    return ok, why


def _reload():
    """Drop an old yt-dlp already imported so the fresh copy is used."""
    if LIB_DIR not in sys.path:
        sys.path.insert(0, LIB_DIR)
    for name in [m for m in sys.modules if m == "yt_dlp" or m.startswith(("yt_dlp.", "yt_dlp_ejs"))]:
        del sys.modules[name]
    importlib.invalidate_caches()


def ensure_installed():
    """Make sure an up-to-date yt-dlp + Deno are there (a minute or so,
    once). Raises YouTubeError with something readable if that fails."""
    with _lock:
        if available():
            return
        old = version()
        ok, why = _install_own_copy()
        _reload()
        if not ok or not available():
            if "No module named pip" in why:
                why = "pip is missing — run:  sudo apt install python3-pip"
            raise YouTubeError(f"Couldn't set up YouTube support ({why or 'pip failed'}). "
                               "Check the internet connection and try again.")
        if old:
            print(f"FluxTV youtube: replaced old yt-dlp {old} with {version()}",
                  file=sys.stderr, flush=True)
        _save_state(last_update=time.time())


def update_if_due():
    """Called in the background at startup: keep yt-dlp current. A newer
    version is used from the next start (this one may already be loaded)."""
    if not available():
        return False
    if time.time() - (_load_state().get("last_update") or 0) < UPDATE_EVERY:
        return False
    # Ask PyPI what the newest yt-dlp is first (a few hundred bytes): only
    # download and install when there really is a newer one, and only
    # yt-dlp itself \u2014 not Deno (40 MB) again every day.
    try:
        latest = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15).json()["info"]["version"]
        newest = tuple(int(x) for x in latest.split(".")[:3])
    except Exception:
        return False
    _save_state(last_update=time.time())
    if (version() or (0,)) >= newest:
        return False
    os.makedirs(LIB_DIR, exist_ok=True)
    ok, why = _pip("--target", LIB_DIR, "--upgrade", "--no-deps", "yt-dlp",
                   low_priority=True)
    print(f"FluxTV youtube: daily update to {latest}: {'ok' if ok else why}",
          file=sys.stderr, flush=True)
    if not _deno():
        _pip("--target", LIB_DIR, "--upgrade", "deno", low_priority=True)
    return ok


def _load_state():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_state(**values):
    state = _load_state()
    state.update(values)
    _write_json(STATE_FILE, state)


def _deno():
    places = os.pathsep.join([os.path.join(LIB_DIR, "bin"), os.path.join(LIB_DIR, "Scripts"),
                              os.path.dirname(sys.executable)])
    return shutil.which("deno", path=places) or shutil.which("deno")


def _ydl(**opts):
    ensure_installed()                   # instant once a current copy is there
    yt_dlp = importlib.import_module("yt_dlp")
    base = {"quiet": True, "no_warnings": True, "skip_download": True,
            "noprogress": True, "socket_timeout": 15}
    deno = _deno()
    if deno:
        base["js_runtimes"] = {"deno": {"path": deno}}
    base.update(opts)
    return yt_dlp.YoutubeDL(base)


def warm_up():
    """Load yt-dlp (thousands of site extractors) in the background at
    start-up, so the first song or search doesn't wait for it. Does
    nothing if YouTube support isn't set up yet."""
    if available():
        with _ydl():
            pass


# ══════════════════════════════════════════════════════════════════
# Tracks
# ══════════════════════════════════════════════════════════════════
def thumb(video_id, size="hq"):
    """hq = 480x360 (a 16:9 picture with bars, cropped away by the cards);
    mq = 320x180; maxres may not exist for older videos."""
    return f"https://i.ytimg.com/vi/{video_id}/{size}default.jpg"


def _track(entry):
    vid = entry.get("id")
    if not vid or len(vid) != 11:
        return None                      # channels / playlists in results
    duration = entry.get("duration")
    live = entry.get("live_status") == "is_live" or bool(entry.get("is_live"))
    return {"id": vid,
            "title": entry.get("title") or "",
            "channel": entry.get("channel") or entry.get("uploader") or "",
            "duration": int(duration) if isinstance(duration, (int, float)) else 0,
            "live": live,
            "thumb": thumb(vid)}


def _flat(url, limit):
    try:
        with _ydl(extract_flat=True, playlistend=limit) as y:
            info = y.extract_info(url, download=False)
    except Exception as error:
        raise YouTubeError(_short_error(error))
    out, seen = [], set()
    for e in (info or {}).get("entries") or []:
        t = _track(e) if isinstance(e, dict) else None
        if t and t["id"] not in seen:
            seen.add(t["id"])
            out.append(t)
    return out


def search(query, limit=30):
    query = " ".join((query or "").split())
    if not query:
        return []
    tracks = _flat(f"ytsearch{limit}:{query}", limit)
    # Shorts are useless for listening.
    return [t for t in tracks if t["live"] or not t["duration"] or t["duration"] > 60]


def mix(video_id, limit=25):
    """YouTube's endless "Mix" for a song: similar songs, radio-style.
    The first entry is the song itself."""
    return _flat(f"https://www.youtube.com/watch?v={video_id}&list=RD{video_id}", limit)


def playlist(url, limit=200):
    return _flat(url, limit)


CHART_SEARCH = ("https://www.youtube.com/results?search_query=uk+top+40+songs+this+week"
                "&sp=EgIQAw%253D%253D")              # playlists only
TRENDING_CACHE = os.path.join(APP_DIR, "music_trending.json")
TRENDING_MAX_AGE = 6 * 3600


def trending(limit=30, max_age=TRENDING_MAX_AGE):
    """("UK Top 40 this week", tracks). YouTube dropped its own trending
    page, so this is the first up-to-date chart playlist YouTube finds;
    kept for six hours."""
    try:
        with open(TRENDING_CACHE, encoding="utf-8") as f:
            cached = json.load(f)
        if time.time() - cached.get("saved", 0) < max_age and cached.get("tracks"):
            return cached["title"], cached["tracks"]
    except (OSError, ValueError, AttributeError):
        pass
    title, tracks = "UK Top 40 this week", []
    try:
        with _ydl(extract_flat=True, playlistend=6) as y:
            found = y.extract_info(CHART_SEARCH, download=False)
        for e in (found or {}).get("entries") or []:
            name = (e.get("title") or "").lower()
            if e.get("url") and "top" in name and str(time.localtime().tm_year) in name:
                tracks = playlist(e["url"], limit)
                if len(tracks) >= 10:
                    break
    except Exception:
        tracks = []
    if not tracks:
        title, tracks = "New music videos", search("official music video new this week", limit)
    _write_json(TRENDING_CACHE, {"saved": time.time(), "title": title, "tracks": tracks})
    return title, tracks


_FORMATS = {
    "listen": "bestaudio[ext=m4a]/bestaudio/best",
    "watch": ("bestvideo[height<=?1080][vcodec^=avc1]+bestaudio[ext=m4a]/"
              "bestvideo[height<=?1080]+bestaudio/best[height<=?1080]/best"),
}


# When YouTube refuses ("confirm you're not a bot", "page needs to be
# reloaded", 403s), asking the way another of its apps does usually works.
_FALLBACK_CLIENTS = (["android_vr"], ["mweb"], ["tv", "web_safari"])
_BLOCKED = ("not a bot", "sign in to confirm", "needs to be reloaded", "403",
            "forbidden", "requested format is not available", "unable to extract")
_cookie_browser = ""


def set_cookie_browser(name):
    """Use this browser's YouTube login ("firefox", "chrome", ...; "" = off)."""
    global _cookie_browser
    _cookie_browser = (name or "").strip().lower()


def _attempts():
    yield {}
    for clients in _FALLBACK_CLIENTS:
        yield {"extractor_args": {"youtube": {"player_client": clients}}}
    if _cookie_browser:
        yield {"cookiesfrombrowser": (_cookie_browser,)}


def resolve(video_id, mode="listen"):
    """Playable links for one video: {"url", "audio" (separate audio for
    video-only formats, or ""), "user_agent", "title", "channel",
    "duration", "live", "thumb"}. Links stay valid for a few hours.
    If YouTube refuses, the other ways of asking are tried in turn."""
    info, first_error = None, None
    for extra in _attempts():
        try:
            with _ydl(format=_FORMATS.get(mode, _FORMATS["listen"]), **extra) as y:
                info = y.extract_info(f"https://www.youtube.com/watch?v={video_id}",
                                      download=False)
            break
        except Exception as error:
            first_error = first_error or error
            text = str(error).lower()
            if not any(b in text for b in _BLOCKED):
                break                       # private / removed etc.: retrying won't help
    if info is None:
        raise YouTubeError(_short_error(first_error))
    parts = info.get("requested_formats") or [info]
    video = next((f for f in parts if f.get("vcodec") not in (None, "none")), None)
    audio = next((f for f in parts if f.get("acodec") not in (None, "none")
                  and f.get("vcodec") in (None, "none")), None)
    main = video or audio or parts[0]
    url = main.get("url")
    if not url:
        raise YouTubeError("YouTube didn't give a playable link for this one.")
    headers = main.get("http_headers") or info.get("http_headers") or {}
    duration = info.get("duration")
    return {"id": video_id, "url": url,
            "audio": audio["url"] if video and audio and audio is not video else "",
            "user_agent": headers.get("User-Agent", ""),
            "title": info.get("title") or "", "channel": info.get("channel") or info.get("uploader") or "",
            "duration": int(duration) if isinstance(duration, (int, float)) else 0,
            "live": bool(info.get("is_live")),
            "thumb": thumb(video_id), "resolved": time.time()}


def _short_error(error):
    print(f"FluxTV youtube: {error!r}", file=sys.stderr, flush=True)
    text = str(error).replace("ERROR: ", "").strip()
    text = text.split("\n", 1)[0]
    if "Sign in to confirm your age" in text:
        return "YouTube only plays this one when signed in (age-restricted)."
    if "Private video" in text or "unavailable" in text.lower():
        return "This video isn't available."
    if "Sign in to confirm" in text:
        return "YouTube is asking to confirm you're not a bot — try again in a few minutes."
    return text[:160] or error.__class__.__name__


# ══════════════════════════════════════════════════════════════════
# SponsorBlock: skip the non-music parts of music videos
# ══════════════════════════════════════════════════════════════════
SPONSORBLOCK = "https://sponsor.ajay.app/api/skipSegments"
SKIP_CATEGORIES = ["music_offtopic", "sponsor", "selfpromo", "interaction"]


def skip_segments(video_id):
    """[(start, end), ...] seconds to skip; empty if none or unreachable."""
    try:
        r = requests.get(SPONSORBLOCK, timeout=6,
                         params={"videoID": video_id,
                                 "categories": json.dumps(SKIP_CATEGORIES)})
        if r.status_code != 200:
            return []
        data = r.json()
    except (requests.RequestException, ValueError):
        return []
    out = []
    for seg in data if isinstance(data, list) else []:
        pair = seg.get("segment") if isinstance(seg, dict) else None
        if isinstance(pair, list) and len(pair) == 2 and pair[1] - pair[0] >= 1:
            out.append((float(pair[0]), float(pair[1])))
    return sorted(out)


# ══════════════════════════════════════════════════════════════════
# Recently played
# ══════════════════════════════════════════════════════════════════
def load_history():
    try:
        with open(HISTORY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [t for t in data if isinstance(t, dict) and t.get("id")] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def add_history(track):
    keep = ("id", "title", "channel", "duration", "live", "thumb")
    entry = {k: track.get(k) for k in keep}
    entry["played"] = int(time.time())
    items = [entry] + [t for t in load_history() if t.get("id") != track.get("id")]
    _write_json(HISTORY_FILE, items[:HISTORY_MAX])


# ══════════════════════════════════════════════════════════════════
# Your playlists
# ══════════════════════════════════════════════════════════════════
PLAYLISTS_FILE = os.path.join(APP_DIR, "music_playlists.json")
_TRACK_KEYS = ("id", "title", "channel", "duration", "live", "thumb")


def _slim(track):
    return {k: track.get(k) for k in _TRACK_KEYS}


def load_playlists():
    try:
        with open(PLAYLISTS_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [p for p in data if isinstance(p, dict) and p.get("id")] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save_playlists(playlists):
    _write_json(PLAYLISTS_FILE, playlists)


def get_playlist(pid):
    return next((p for p in load_playlists() if p["id"] == pid), None)


def create_playlist(name, tracks=(), source=""):
    playlists = load_playlists()
    entry = {"id": os.urandom(6).hex(), "name": (name or "").strip() or "My playlist",
             "tracks": [_slim(t) for t in tracks], "source": source,
             "created": int(time.time())}
    playlists.insert(0, entry)
    save_playlists(playlists)
    return entry


def _change(pid, fn):
    playlists = load_playlists()
    for p in playlists:
        if p["id"] == pid:
            fn(p)
            p["updated"] = int(time.time())
            save_playlists(playlists)
            return p
    return None


def add_to_playlist(pid, tracks):
    """Adds songs not already in it; returns how many were added."""
    added = []

    def fn(p):
        have = {t["id"] for t in p["tracks"]}
        for t in tracks:
            if t.get("id") and t["id"] not in have:
                have.add(t["id"])
                p["tracks"].append(_slim(t))
                added.append(t["id"])
    _change(pid, fn)
    return len(added)


def remove_from_playlist(pid, track_id):
    return _change(pid, lambda p: p.__setitem__(
        "tracks", [t for t in p["tracks"] if t["id"] != track_id]))


def rename_playlist(pid, name):
    return _change(pid, lambda p: p.__setitem__("name", (name or "").strip() or p["name"]))


def delete_playlist(pid):
    save_playlists([p for p in load_playlists() if p["id"] != pid])


def is_playlist_link(text):
    text = (text or "").strip()
    return text.startswith(("http://", "https://")) and \
        ("youtube.com" in text or "youtu.be" in text) and "list=" in text


def import_playlist(url, limit=500):
    """Save a YouTube playlist (pasted link) as one of yours."""
    try:
        with _ydl(extract_flat=True, playlistend=limit) as y:
            info = y.extract_info(url.strip(), download=False)
    except YouTubeError:
        raise
    except Exception as error:
        raise YouTubeError(_short_error(error))
    tracks = []
    for e in (info or {}).get("entries") or []:
        t = _track(e) if isinstance(e, dict) else None
        if t:
            tracks.append(t)
    if not tracks:
        raise YouTubeError("That playlist is empty or private.")
    return create_playlist(info.get("title") or "YouTube playlist", tracks, source=url.strip())
