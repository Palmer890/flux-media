#!/usr/bin/env python3
"""
Flux Media (FluxTV) — performance log.

Writes <settings folder>/performance.log:
  * how long start-up took, stage by stage;
  * any time the screen froze for more than a second, with what the app
    was doing at that moment (the main thread's call stack), so a slow
    spot on someone's PC can be found and fixed without guessing.

Costs next to nothing: a timer ticks on the main thread four times a
second, and a background thread notices when the ticks stop.
"""

from __future__ import annotations

import os
import sys
import threading
import time
import traceback

from fluxtv_core import APP_DIR

LOG = os.path.join(APP_DIR, "performance.log")
MAX_BYTES = 300_000
STALL = 1.0                      # seconds without a tick = a freeze worth noting

_start = time.monotonic()
_lock = threading.Lock()
_marks = []


def _write(text):
    with _lock:
        try:
            if os.path.exists(LOG) and os.path.getsize(LOG) > MAX_BYTES:
                with open(LOG, "rb") as f:
                    f.seek(-MAX_BYTES // 2, os.SEEK_END)
                    tail = f.read()
                with open(LOG, "wb") as f:
                    f.write(tail)
            with open(LOG, "a", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            pass


def mark(stage):
    """Start-up milestones: 'window shown', 'library on screen', ..."""
    _marks.append((time.monotonic() - _start, stage))


def flush_startup():
    if not _marks:
        return
    lines = [f"\n=== Flux Media started {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n"]
    lines += [f"  {t:6.2f}s  {stage}\n" for t, stage in _marks]
    _write("".join(lines))
    _marks.clear()


class StallWatch:
    """Notices when the main (screen) thread stops responding."""

    def __init__(self, qtimer_cls):
        self._beat = time.monotonic()
        self._main = threading.main_thread().ident
        self._timer = qtimer_cls()
        self._timer.timeout.connect(self._tick)
        self._timer.start(250)
        self._stack = None
        self._stall_started = None
        threading.Thread(target=self._watch, daemon=True, name="flux-stallwatch").start()

    def _tick(self):
        now = time.monotonic()
        if self._stall_started is not None:
            length = now - self._stall_started + STALL
            stack = self._stack or "  (no stack captured)\n"
            _write(f"\n--- screen froze for {length:.1f}s at "
                   f"{time.strftime('%H:%M:%S')} (+{now - _start:.0f}s after start) ---\n{stack}")
            self._stall_started = None
            self._stack = None
        self._beat = now

    def _watch(self):
        while True:
            time.sleep(0.25)
            late = time.monotonic() - self._beat
            if late > STALL and self._stall_started is None:
                self._stall_started = time.monotonic()
                frame = sys._current_frames().get(self._main)
                if frame is not None:
                    lines = traceback.format_stack(frame)[-12:]
                    self._stack = "".join(lines)
