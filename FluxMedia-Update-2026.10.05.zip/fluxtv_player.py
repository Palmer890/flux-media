#!/usr/bin/env python3
"""
FluxTV — Stremio-style in-app player.

Stremio's desktop shell never hands MPV a native window. It links libmpv
and asks it to draw each frame into an OpenGL framebuffer that Qt owns
(mpv_render_context), then lays its controls over the video as ordinary,
translucent UI: a soft black gradient at the top and bottom edges, a thin
accent-coloured seek bar, icon-only buttons with no panel behind them, all
fading out together while something plays.

This module does the same with python-mpv's render API and a
QOpenGLWidget. Because the video is just another Qt widget here, the
overlay can be genuinely see-through — which the old --wid embedding
(a foreign native window under Qt's widgets) could never do — and it
behaves identically on X11, Wayland and Windows.

If libmpv or python-mpv isn't installed, AVAILABLE is False and FluxTV
keeps using its original "launch mpv as a separate process" player.
Set FLUXTV_PLAYER=external to force that fallback.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import locale
import math
import os
import platform
import sys
import time

from PySide6.QtCore import (QByteArray, QEasingCurve, QEvent, QPoint,
                            QPointF, QPropertyAnimation, QRectF, QSize, Qt,
                            QTimer, Signal)
from PySide6.QtGui import (QColor, QConicalGradient, QCursor, QFont,
                           QGuiApplication,
                           QLinearGradient, QOpenGLContext, QPainter,
                           QPainterPath, QPen, QPixmap)
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QFrame,
                               QGraphicsOpacityEffect, QListWidget,
                               QListWidgetItem, QStyle, QStyledItemDelegate,
                               QHBoxLayout, QLabel, QPushButton, QScrollArea,
                               QSizePolicy, QVBoxLayout, QWidget)

from fluxtv_style import C, font


# ══════════════════════════════════════════════════════════════════
# libmpv availability
# ══════════════════════════════════════════════════════════════════
def _prepare_dll_search():
    """On Windows python-mpv looks for libmpv-2.dll on PATH. Put the
    app's own folder and the usual MPV install folders there first, so a
    DLL dropped next to iptv.py (what the installer does) is found."""
    if platform.system() != "Windows":
        return
    here = os.path.dirname(os.path.abspath(__file__))
    dirs = [d for d in (here, r"C:\mpv", r"C:\Program Files\mpv")
            if os.path.isdir(d)]
    os.environ["PATH"] = os.pathsep.join(dirs + [os.environ.get("PATH", "")])
    for d in dirs:
        try:
            os.add_dll_directory(d)
        except (OSError, AttributeError):
            pass


LIBMPV_ERROR = None


def tls_options():
    """Point mpv at Python's up-to-date list of trusted certificate
    authorities. Some libmpv builds (the Windows one) carry an incomplete
    list and refuse perfectly good https streams, e.g. StreamTheWorld's
    radio servers ("TLS certificate verification failed")."""
    try:
        import certifi
        path = certifi.where()
        return {"tls_ca_file": path} if os.path.exists(path) else {}
    except ImportError:
        return {}
if os.environ.get("FLUXTV_PLAYER", "").lower() == "external":
    mpv = None
    LIBMPV_ERROR = "disabled by FLUXTV_PLAYER=external"
else:
    try:
        _prepare_dll_search()
        import mpv                                   # python-mpv
        mpv.MpvRenderContext                          # too old without it
        mpv.MpvGlGetProcAddressFn
    except Exception as error:   # ImportError, OSError (no libmpv), AttributeError
        mpv = None
        LIBMPV_ERROR = f"{type(error).__name__}: {error}"

AVAILABLE = mpv is not None


_NATIVE_DISPLAY = None


def _native_display_params():
    """The display connection libmpv needs for zero-copy hardware
    decoding. Without it, VAAPI on Linux can only run in "copy" mode
    (every decoded frame copied from the GPU to RAM and back), which is
    what made busy streams jitter. One connection is opened for the
    life of the app and reused.
    """
    global _NATIVE_DISPLAY
    if _NATIVE_DISPLAY is not None:
        return _NATIVE_DISPLAY
    _NATIVE_DISPLAY = {}
    platform_name = QGuiApplication.platformName()
    try:
        if platform_name == "xcb":
            x11 = ctypes.CDLL(ctypes.util.find_library("X11") or "libX11.so.6")
            x11.XOpenDisplay.restype = ctypes.c_void_p
            x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
            display = x11.XOpenDisplay(None)
            if display:
                _NATIVE_DISPLAY = {"x11_display": ctypes.c_void_p(display)}
        elif platform_name.startswith("wayland"):
            wl = ctypes.CDLL(ctypes.util.find_library("wayland-client")
                             or "libwayland-client.so.0")
            wl.wl_display_connect.restype = ctypes.c_void_p
            wl.wl_display_connect.argtypes = [ctypes.c_char_p]
            display = wl.wl_display_connect(None)
            if display:
                _NATIVE_DISPLAY = {"wl_display": ctypes.c_void_p(display)}
    except (OSError, AttributeError):
        pass
    return _NATIVE_DISPLAY


def _fmt(seconds):
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ══════════════════════════════════════════════════════════════════
# Video surface: libmpv rendering into a QOpenGLWidget
# ══════════════════════════════════════════════════════════════════
class MpvVideo(QOpenGLWidget):
    """One long-lived MPV instance drawing into this widget.

    The instance lives as long as the app does: changing channel or title
    is a `loadfile replace` on the same player, so the video pipeline never
    tears down between streams and there's nothing to flash through.

    python-mpv delivers property changes on its own event thread; they are
    funnelled through the queued `_prop` signal so every piece of state
    below is only ever touched on the Qt main thread.
    """

    _prop = Signal(str, object)
    _frame = Signal()

    position = Signal(float)
    duration = Signal(float)
    pause_changed = Signal(bool)
    volume_changed = Signal(int)
    mute_changed = Signal(bool)
    buffering_changed = Signal(bool)
    cache_end_changed = Signal(float)      # absolute seconds buffered up to
    tracks_changed = Signal(list)
    started = Signal()                     # first position of a new stream
    ended = Signal(str)                    # "eof" or "error"
    render_failed = Signal(str)

    clicked = Signal()
    double_clicked = Signal()

    OBSERVED = ("time-pos", "duration", "pause", "volume", "mute",
                "paused-for-cache", "seeking", "idle-active", "track-list",
                "demuxer-cache-time")

    def __init__(self, parent=None, log_file=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.player = None
        self._ctx = None
        self._proc_fn = None
        self._pending = None          # a play() waiting for the GL context
        self._overrides = {}          # option -> value before we changed it
        self._active = False          # a stream is meant to be playing
        self._seen_running = False    # MPV left idle since that play()
        self._idle = True
        self._loading = False
        self._for_cache = False
        self._seeking = False
        self._buffering = False
        self._pos = 0.0
        self._dur = 0.0

        self._prop.connect(self._handle_prop, Qt.QueuedConnection)
        self._frame.connect(self.update, Qt.QueuedConnection)
        self.frameSwapped.connect(self._report_swap)

        self._click_timer = QTimer(self)
        self._click_timer.setSingleShot(True)
        self._click_timer.setInterval(QApplication.doubleClickInterval())
        self._click_timer.timeout.connect(self.clicked.emit)

        # Qt sets LC_NUMERIC from the environment when QApplication is
        # created; libmpv refuses to start under anything but "C".
        locale.setlocale(locale.LC_NUMERIC, "C")
        opts = dict(vo="libmpv", idle="yes", keep_open="no",
                    input_default_bindings=False, input_vo_keyboard=False,
                    osc=False, ytdl=False, audio_client_name="Flux Media",
                    audio_fallback_to_null="yes", hwdec="auto-safe", **tls_options())
        if log_file:
            opts["log_file"] = log_file
        self.player = mpv.MPV(**opts)
        for name in self.OBSERVED:
            self.player.observe_property(name, self._on_mpv_prop)

    # ── mpv thread → Qt thread ───────────────────────────────────
    def _on_mpv_prop(self, name, value):
        self._prop.emit(name, value)

    def _handle_prop(self, name, value):
        number = isinstance(value, (int, float)) and not isinstance(value, bool)
        if name == "time-pos":
            if number and self._active:
                self._pos = float(value)
                if self._loading:
                    self._loading = False
                    self._update_buffering()
                    self.started.emit()
                self.position.emit(self._pos)
        elif name == "duration":
            # mpv clears the duration as a file ends, just before going
            # idle; keeping the last real value is what lets the end be
            # told apart from a failure (play() resets it per title).
            if number:
                self._dur = float(value)
                self.duration.emit(self._dur)
        elif name == "pause" and isinstance(value, bool):
            self.pause_changed.emit(value)
        elif name == "volume" and number:
            self.volume_changed.emit(int(round(value)))
        elif name == "mute" and isinstance(value, bool):
            self.mute_changed.emit(value)
        elif name == "paused-for-cache":
            self._for_cache = bool(value)
            self._update_buffering()
        elif name == "seeking":
            self._seeking = bool(value)
            self._update_buffering()
        elif name == "demuxer-cache-time" and number:
            self.cache_end_changed.emit(float(value))
        elif name == "track-list":
            self.tracks_changed.emit(list(value or []))
        elif name == "idle-active":
            self._idle = bool(value)
            if not self._active:
                return
            if not self._idle:
                self._seen_running = True
            elif self._seen_running:
                # Went idle without us asking: the stream ended or failed.
                self._active = False
                self._loading = False
                self._update_buffering()
                self._frame.emit()
                finished = self._dur > 0 and self._pos >= self._dur - 5
                self.ended.emit("eof" if finished else "error")

    def _update_buffering(self):
        busy = self._active and (self._loading or self._for_cache or self._seeking)
        if busy != self._buffering:
            self._buffering = busy
            self.buffering_changed.emit(busy)

    # ── OpenGL ───────────────────────────────────────────────────
    def initializeGL(self):
        if self._ctx is not None or self.player is None:
            return
        self.context().aboutToBeDestroyed.connect(self._free_render_context)

        def get_proc_address(_ctx, name):
            glctx = QOpenGLContext.currentContext()
            if glctx is None:
                return 0
            address = glctx.getProcAddress(QByteArray(name))
            try:
                return int(address) if address else 0
            except TypeError:
                return 0

        # Kept on self: ctypes callbacks must outlive the render context.
        self._proc_fn = mpv.MpvGlGetProcAddressFn(get_proc_address)
        init = {"opengl_init_params": {"get_proc_address": self._proc_fn}}
        display = _native_display_params()
        self._ctx = None
        if display:
            # With the display, VAAPI decodes straight into GPU textures.
            try:
                self._ctx = mpv.MpvRenderContext(self.player, "opengl",
                                                 **init, **display)
                print(f"FluxTV: libmpv given the {next(iter(display)).split('_')[0]} "
                      "display for zero-copy hardware decoding", file=sys.stderr)
            except Exception:
                self._ctx = None
        if self._ctx is None:
            try:
                self._ctx = mpv.MpvRenderContext(self.player, "opengl", **init)
            except Exception as error:
                self.render_failed.emit(f"{type(error).__name__}: {error}")
                return
        self._ctx.update_cb = self._frame.emit
        if self._pending:
            args = self._pending
            self._pending = None
            QTimer.singleShot(0, lambda: self._load(*args))

    def paintGL(self):
        if self._ctx is None or not self._active:
            f = self.context().functions()
            f.glClearColor(0.0, 0.0, 0.0, 1.0)
            f.glClear(0x00004000)            # GL_COLOR_BUFFER_BIT
            return
        ratio = self.devicePixelRatioF()
        try:
            self._ctx.render(flip_y=True, opengl_fbo={
                "fbo": self.defaultFramebufferObject(),
                "w": int(self.width() * ratio),
                "h": int(self.height() * ratio)})
        except Exception:
            pass

    def _report_swap(self):
        if self._ctx is not None and self._active:
            try:
                self._ctx.report_swap()
            except Exception:
                pass

    def _free_render_context(self):
        if self._ctx is None:
            return
        self.makeCurrent()
        try:
            self._ctx.update_cb = None
        except Exception:
            pass
        try:
            self._ctx.free()
        except Exception:
            pass
        self._ctx = None
        self.doneCurrent()

    # ── playback control ─────────────────────────────────────────
    def play(self, url, *, start=0, options=None, hwdec=True, title=""):
        self._active = True
        self._seen_running = not self._idle
        self._loading = True
        self._pos = 0.0
        self._dur = 0.0
        self._update_buffering()
        args = (url, start, options or {}, hwdec, title)
        if self._ctx is None:
            # vo=libmpv without a render context would disable video for
            # this file, so wait until initializeGL has run.
            self._pending = args
            self.update()
        else:
            self._load(*args)

    def _load(self, url, start, options, hwdec, title):
        p = self.player
        if p is None or not self._active:
            return
        # Per-stream options (the live cache settings) must not leak into
        # the next title, so anything set last time and not this time goes
        # back to what it was before we first touched it.
        for key in list(self._overrides):
            if key not in options:
                self._set(key, self._overrides.pop(key))
        for key, value in options.items():
            if key not in self._overrides:
                try:
                    self._overrides[key] = p[key]
                except Exception:
                    continue
            self._set(key, value)
        self._set("hwdec", "auto-safe" if hwdec else "no")
        self._set("start", str(int(start)) if start else "none")
        self._set("force-media-title", title or "")
        self._set("pause", False)
        try:
            p.command("loadfile", url, "replace")
        except Exception:
            self._active = False
            self._loading = False
            self._update_buffering()
            self.ended.emit("error")

    def _set(self, key, value):
        try:
            self.player[key] = value
        except Exception:
            pass

    def _cmd(self, *args):
        if self.player is None:
            return
        try:
            self.player.command(*args)
        except Exception:
            pass

    def stop(self):
        self._active = False
        self._pending = None
        self._loading = False
        self._update_buffering()
        self._cmd("stop")
        self.update()

    def toggle_pause(self):
        if self._active:
            self._cmd("cycle", "pause")

    def seek(self, seconds):
        if self._active:
            self._cmd("seek", f"{max(0.0, seconds):.2f}", "absolute")

    def seek_relative(self, delta):
        if self._active:
            self._cmd("seek", str(delta), "relative")

    def set_volume(self, value):
        self._set("volume", max(0, min(100, int(value))))

    def toggle_mute(self):
        self._cmd("cycle", "mute")

    def set_track(self, kind, track_id):
        self._set(kind, track_id if track_id is not None else "no")

    def add_subtitle(self, url, title="", lang="", select=False):
        """An external subtitle file (from an add-on) as an extra track;
        "auto" adds it without switching it on."""
        if self._active:
            self._cmd("sub-add", url, "select" if select else "auto", title, lang)

    @property
    def position_seconds(self):
        return self._pos

    @property
    def duration_seconds(self):
        return self._dur

    def shutdown(self):
        self._active = False
        self._free_render_context()
        if self.player is not None:
            try:
                self.player.terminate()
            except Exception:
                pass
            self.player = None

    # ── pointer ──────────────────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # Wait out the double-click window so a double-click (full
            # screen) doesn't also toggle pause on its first half.
            self._click_timer.start()
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._click_timer.stop()
            self.double_clicked.emit()
        super().mouseDoubleClickEvent(event)


# ══════════════════════════════════════════════════════════════════
# Icons — drawn on a 24-unit grid so they stay crisp at any size
# ══════════════════════════════════════════════════════════════════
def draw_icon(p, kind, rect, color):
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    u = min(rect.width(), rect.height()) / 24.0
    ox = rect.center().x() - 12 * u
    oy = rect.center().y() - 12 * u

    def P(x, y):
        return QPointF(ox + x * u, oy + y * u)

    stroke = QPen(color, max(1.6, 2.1 * u), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)

    def line(*pts):
        p.setPen(stroke)
        p.setBrush(Qt.NoBrush)
        path = QPainterPath(P(*pts[0]))
        for pt in pts[1:]:
            path.lineTo(P(*pt))
        p.drawPath(path)

    def solid(*pts):
        p.setPen(QPen(color, 2.2 * u, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.setBrush(color)
        path = QPainterPath(P(*pts[0]))
        for pt in pts[1:]:
            path.lineTo(P(*pt))
        path.closeSubpath()
        p.drawPath(path)

    if kind == "play":
        solid((7.5, 5), (19, 12), (7.5, 19))
    elif kind == "pause":
        p.setPen(Qt.NoPen)
        p.setBrush(color)
        p.drawRoundedRect(QRectF(P(6, 4.5), P(10.2, 19.5)), 1.4 * u, 1.4 * u)
        p.drawRoundedRect(QRectF(P(13.8, 4.5), P(18, 19.5)), 1.4 * u, 1.4 * u)
    elif kind == "back":
        line((15, 5), (8, 12), (15, 19))
    elif kind in ("rewind", "forward"):
        forward = kind == "forward"
        r = 8 * u
        c = P(12, 12.5)
        box = QRectF(c.x() - r, c.y() - r, 2 * r, 2 * r)
        p.setPen(stroke)
        p.setBrush(Qt.NoBrush)
        start = 70 if forward else 110
        p.drawArc(box, start * 16, (290 if forward else -290) * 16)
        tip = QPointF(c.x() + r * math.cos(math.radians(start)),
                      c.y() - r * math.sin(math.radians(start)))
        d = 1 if forward else -1
        p.drawLine(tip, QPointF(tip.x() - d * 3.2 * u, tip.y() - 3 * u))
        p.drawLine(tip, QPointF(tip.x() - d * 3.2 * u, tip.y() + 3 * u))
        f = QFont(p.font())
        f.setPixelSize(max(6, int(7.2 * u)))
        f.setBold(True)
        p.setFont(f)
        p.setPen(color)
        p.drawText(QRectF(P(4, 8.5), P(20, 17)), Qt.AlignCenter, "10")
    elif kind.startswith("volume") or kind == "mute":
        solid((3.5, 9.5), (7.5, 9.5), (12.5, 5), (12.5, 19), (7.5, 14.5), (3.5, 14.5))
        p.setPen(stroke)
        p.setBrush(Qt.NoBrush)
        if kind == "mute":
            p.drawLine(P(16, 9.5), P(21, 14.5))
            p.drawLine(P(16, 14.5), P(21, 9.5))
        else:
            level = {"volume0": 0, "volume1": 1}.get(kind, 2)
            c = P(12.5, 12)
            for i, radius in enumerate((4.2, 7.8)):
                if i < level:
                    rr = radius * u
                    p.drawArc(QRectF(c.x() - rr, c.y() - rr, 2 * rr, 2 * rr),
                              -45 * 16, 90 * 16)
    elif kind == "subtitles":
        p.setPen(stroke)
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(QRectF(P(3, 5), P(21, 19)), 3 * u, 3 * u)
        line((7, 12.5), (10.5, 12.5))
        line((13.5, 12.5), (17, 12.5))
        line((7, 15.5), (14, 15.5))
    elif kind == "audio":
        line((5, 10), (5, 14))
        line((9, 6), (9, 18))
        line((13, 8.5), (13, 15.5))
        line((17, 5), (17, 19))
        line((21, 10.5), (21, 13.5))
    elif kind == "fullscreen":
        line((4, 9), (4, 4), (9, 4))
        line((15, 4), (20, 4), (20, 9))
        line((20, 15), (20, 20), (15, 20))
        line((9, 20), (4, 20), (4, 15))
    elif kind == "fullscreen_exit":
        line((9, 4), (9, 9), (4, 9))
        line((15, 4), (15, 9), (20, 9))
        line((20, 15), (15, 15), (15, 20))
        line((4, 15), (9, 15), (9, 20))
    elif kind == "list":
        for y in (6.5, 12, 17.5):
            p.setPen(Qt.NoPen)
            p.setBrush(color)
            p.drawEllipse(P(4.5, y), 1.4 * u, 1.4 * u)
            line((9, y), (20, y))
    elif kind == "check":
        line((5, 12.5), (10, 17), (19, 7))
    p.restore()


def _paint_cached(widget, render):
    """Render `render(painter)` once into a transparent pixmap the size of
    `widget` (at its device pixel ratio) and return it.

    Qt repaints every widget layered over the video each time a new video
    frame arrives — 50 times a second on sport. Redrawing gradients, text
    and antialiased shapes from scratch that often is what made the
    picture stutter while the channel banner or controls were up; drawing
    them once and blitting the result is nearly free.
    """
    ratio = widget.devicePixelRatioF()
    pix = QPixmap(max(1, int(widget.width() * ratio)), max(1, int(widget.height() * ratio)))
    pix.setDevicePixelRatio(ratio)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    render(p)
    p.end()
    return pix


class PlayerButton(QPushButton):
    """Icon-only control, Stremio style: no chrome at rest, a soft
    rounded highlight under the pointer, dimmed when unavailable."""

    def __init__(self, kind, parent=None, size=52, tip=""):
        super().__init__(parent)
        self.kind = kind
        self._hover = False
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.setToolTip(tip)

    def set_kind(self, kind):
        if kind != self.kind:
            self.kind = kind
            self.update()

    def enterEvent(self, event):
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        # Everything laid over the video is repainted on every video frame,
        # so the icon is drawn once per state and then just blitted.
        state = (self.kind, self._hover, self.isDown(), self.isEnabled(),
                 self.width(), self.devicePixelRatioF())
        if getattr(self, "_cache_state", None) != state:
            self._cache = _paint_cached(self, self._render)
            self._cache_state = state
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)
        p.end()

    def _render(self, p):
        p.setRenderHint(QPainter.Antialiasing)
        if self.isEnabled() and (self._hover or self.isDown()):
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 46 if self.isDown() else 30))
            p.drawRoundedRect(QRectF(self.rect()), 12, 12)
        color = QColor(C.paper)
        if not self.isEnabled():
            color.setAlphaF(0.35)
        pad = self.width() * 0.24
        draw_icon(p, self.kind, QRectF(self.rect()).adjusted(pad, pad, -pad, -pad), color)


# ══════════════════════════════════════════════════════════════════
# Seek bar and volume slider
# ══════════════════════════════════════════════════════════════════
def _accent_gradient(x0, x1):
    g = QLinearGradient(x0, 0, max(x1, x0 + 1), 0)
    g.setColorAt(0.0, QColor(C.cyan))
    g.setColorAt(1.0, QColor(C.violet_hi))
    return g


class SeekBar(QWidget):
    seek_committed = Signal(float)
    scrubbing = Signal(bool)
    hover_time = Signal(float, int)          # seconds, x in own coords; -1 = gone

    MARGIN = 10

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(30)
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)
        self._pos = 0.0
        self._dur = 0.0
        self._buf = 0.0
        self._drag = None
        self._hover = False

    def set_state(self, pos, dur):
        self._pos, self._dur = pos, dur
        if self._drag is None:
            self.update()

    def set_buffered(self, end_seconds):
        self._buf = end_seconds
        self.update()

    def reset(self):
        self._pos = self._dur = self._buf = 0.0
        self._drag = None
        self.update()

    def _span(self):
        return max(1.0, self.width() - 2 * self.MARGIN)

    def _time_at(self, x):
        frac = min(1.0, max(0.0, (x - self.MARGIN) / self._span()))
        return frac * self._dur

    def _x_for(self, seconds):
        frac = min(1.0, max(0.0, seconds / self._dur)) if self._dur > 0 else 0.0
        return self.MARGIN + frac * self._span()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        active = self._hover or self._drag is not None
        t = 6.0 if active else 4.0
        y = self.height() / 2
        x0 = self.MARGIN
        track = QRectF(x0, y - t / 2, self._span(), t)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 56))
        p.drawRoundedRect(track, t / 2, t / 2)
        if self._dur > 0:
            bx = self._x_for(self._buf)
            if bx > x0:
                p.setBrush(QColor(255, 255, 255, 100))
                p.drawRoundedRect(QRectF(x0, track.y(), bx - x0, t), t / 2, t / 2)
            shown = self._drag if self._drag is not None else self._pos
            px = self._x_for(shown)
            if px > x0:
                p.setBrush(_accent_gradient(x0, px))
                p.drawRoundedRect(QRectF(x0, track.y(), px - x0, t), t / 2, t / 2)
            r = 8.5 if active else 6.5
            if active:
                glow = QColor(C.cyan_hi)
                glow.setAlpha(70)
                p.setBrush(glow)
                p.drawEllipse(QPointF(px, y), r + 5, r + 5)
            p.setBrush(QColor(C.paper))
            p.drawEllipse(QPointF(px, y), r, r)
        p.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self._dur > 0:
            self._drag = self._time_at(event.position().x())
            self.scrubbing.emit(True)
            self.update()

    def mouseMoveEvent(self, event):
        x = event.position().x()
        self._hover = True
        if self._drag is not None:
            self._drag = self._time_at(x)
            self.update()
        if self._dur > 0:
            self.hover_time.emit(self._time_at(x), int(min(max(x, self.MARGIN),
                                                           self.width() - self.MARGIN)))

    def mouseReleaseEvent(self, event):
        if self._drag is not None and event.button() == Qt.LeftButton:
            target = self._drag
            self._drag = None
            self._pos = target
            self.scrubbing.emit(False)
            self.seek_committed.emit(target)
            self.update()

    def enterEvent(self, event):
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover = False
        self.hover_time.emit(-1.0, -1)
        self.update()
        super().leaveEvent(event)


class VolumeSlider(QWidget):
    changed = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(120, 40)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self._value = 100
        self._drag = False
        self._hover = False

    def value(self):
        return self._value

    def is_dragging(self):
        return self._drag

    def set_value(self, value):
        value = max(0, min(100, int(value)))
        if value != self._value:
            self._value = value
            self.update()

    def _from_x(self, x):
        return int(round(min(1.0, max(0.0, (x - 8) / (self.width() - 16))) * 100))

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        t = 4.0
        y = self.height() / 2
        w = self.width() - 16
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 60))
        p.drawRoundedRect(QRectF(8, y - t / 2, w, t), 2, 2)
        fx = 8 + w * self._value / 100.0
        p.setBrush(QColor(C.paper))
        p.drawRoundedRect(QRectF(8, y - t / 2, fx - 8, t), 2, 2)
        r = 7.0 if (self._hover or self._drag) else 5.5
        p.drawEllipse(QPointF(fx, y), r, r)
        p.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag = True
            self.set_value(self._from_x(event.position().x()))
            self.changed.emit(self._value)

    def mouseMoveEvent(self, event):
        if self._drag:
            self.set_value(self._from_x(event.position().x()))
            self.changed.emit(self._value)

    def mouseReleaseEvent(self, event):
        self._drag = False
        self.update()

    def wheelEvent(self, event):
        step = 5 if event.angleDelta().y() > 0 else -5
        self.set_value(self._value + step)
        self.changed.emit(self._value)

    def enterEvent(self, event):
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover = False
        self.update()
        super().leaveEvent(event)


# ══════════════════════════════════════════════════════════════════
# Overlay pieces
# ══════════════════════════════════════════════════════════════════
class _Scrim(QWidget):
    """The top or bottom band of controls, painted over a black-to-clear
    gradient so white text stays legible on any picture."""

    def __init__(self, edge, parent=None):
        super().__init__(parent)
        self.edge = edge
        self.setMouseTracking(True)

    def paintEvent(self, event):
        state = (self.width(), self.height(), self.devicePixelRatioF())
        if getattr(self, "_cache_state", None) != state:
            self._cache = _paint_cached(self, self._render)
            self._cache_state = state
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)
        p.end()

    def _render(self, p):
        g = QLinearGradient(0, 0, 0, self.height())
        if self.edge == "top":
            g.setColorAt(0.0, QColor(0, 0, 0, 175))
            g.setColorAt(0.55, QColor(0, 0, 0, 70))
            g.setColorAt(1.0, QColor(0, 0, 0, 0))
        else:
            g.setColorAt(0.0, QColor(0, 0, 0, 0))
            g.setColorAt(0.4, QColor(0, 0, 0, 95))
            g.setColorAt(1.0, QColor(0, 0, 0, 205))
        p.fillRect(self.rect(), g)


class Spinner(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(84, 84)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)

    def _tick(self):
        self._angle = (self._angle - 7) % 360
        self.update()

    def showEvent(self, event):
        self._timer.start()
        super().showEvent(event)

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect()).adjusted(9, 9, -9, -9)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 90))
        p.drawEllipse(QRectF(self.rect()).adjusted(2, 2, -2, -2))
        p.setPen(QPen(QColor(255, 255, 255, 40), 5))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(rect)
        g = QConicalGradient(rect.center(), self._angle)
        g.setColorAt(0.0, QColor(C.cyan_hi))
        g.setColorAt(0.35, QColor(C.violet_hi))
        g.setColorAt(0.36, QColor(0, 0, 0, 0))
        g.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(QPen(g, 5, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(rect, self._angle * 16, -126 * 16)
        p.end()


def _pill_style(bg="rgba(18,17,32,0.88)", size=15):
    return (f"background: {bg}; color: {C.paper}; border-radius: 10px;"
            f"padding: 7px 14px; font-size: {size}px; font-weight: 600;")


_LANGS = {
    "eng": "English", "en": "English", "spa": "Spanish", "es": "Spanish",
    "fre": "French", "fra": "French", "fr": "French", "ger": "German",
    "deu": "German", "de": "German", "ita": "Italian", "it": "Italian",
    "por": "Portuguese", "pt": "Portuguese", "ara": "Arabic", "ar": "Arabic",
    "tur": "Turkish", "tr": "Turkish", "pol": "Polish", "pl": "Polish",
    "dut": "Dutch", "nld": "Dutch", "nl": "Dutch", "rus": "Russian",
    "ru": "Russian", "hin": "Hindi", "hi": "Hindi", "jpn": "Japanese",
    "ja": "Japanese", "kor": "Korean", "ko": "Korean", "chi": "Chinese",
    "zho": "Chinese", "zh": "Chinese", "gre": "Greek", "ell": "Greek",
    "swe": "Swedish", "nor": "Norwegian", "dan": "Danish", "fin": "Finnish",
    "alb": "Albanian", "sqi": "Albanian", "rum": "Romanian", "ron": "Romanian",
    "urd": "Urdu", "pan": "Punjabi", "ben": "Bengali", "per": "Persian",
    "fas": "Persian", "heb": "Hebrew", "ukr": "Ukrainian", "und": "",
}


def _track_text(track):
    lang = (track.get("lang") or "").lower()
    language = _LANGS.get(lang, lang.upper())
    title = track.get("title") or ""
    main = title or language or f"Track {track.get('id')}"
    bits = []
    if title and language and language.lower() not in title.lower():
        bits.append(language)
    codec = (track.get("codec") or "").upper()
    if codec:
        bits.append(codec)
    ch = track.get("demux-channel-count")
    if track.get("type") == "audio" and ch:
        bits.append({1: "Mono", 2: "Stereo", 6: "5.1", 8: "7.1"}.get(ch, f"{ch}ch"))
    return main, "  \u00b7  ".join(bits)


class _MenuRow(QPushButton):
    def __init__(self, text, detail, selected, parent=None):
        super().__init__(parent)
        self._text, self._detail, self._selected = text, detail, selected
        self._hover = False
        self.setFixedHeight(46)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self._hover:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 22))
            p.drawRoundedRect(QRectF(self.rect()), 9, 9)
        if self._selected:
            draw_icon(p, "check", QRectF(10, 13, 20, 20), QColor(C.cyan_hi))
        p.setPen(QColor(C.paper if self._selected else C.dim))
        p.setFont(font(15, QFont.DemiBold if self._selected else QFont.Normal))
        text_rect = QRectF(40, 0, self.width() - 52, self.height())
        p.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, self._text)
        if self._detail:
            p.setPen(QColor(C.faint))
            p.setFont(font(12))
            p.drawText(text_rect, Qt.AlignVCenter | Qt.AlignRight, self._detail)
        p.end()


class TrackMenu(QFrame):
    """Audio / subtitle picker that pops up above the control bar, like
    Stremio's menu layer: a dark rounded card with a checkmark list."""

    chosen = Signal(str, object, str)       # "aid"/"sid", id or None, label

    def __init__(self, parent=None):
        super().__init__(parent)
        self.kind = None
        self.hide()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 12, 10, 10)
        outer.setSpacing(6)
        self.header = QLabel(self)
        self.header.setStyleSheet(f"color: {C.faint}; background: transparent;"
                                  "font-size: 12px; font-weight: 700;"
                                  "letter-spacing: 1px; padding-left: 10px;")
        outer.addWidget(self.header)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget"
                                  " { background: transparent; }")
        outer.addWidget(self.scroll)
        self.body = None

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(255, 255, 255, 26), 1))
        p.setBrush(QColor(22, 21, 38, 238))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 14, 14)
        p.end()

    def open_for(self, kind, tracks, right_x, bottom_y, max_h):
        self.kind = kind
        want = "audio" if kind == "aid" else "sub"
        self.header.setText("AUDIO" if kind == "aid" else "SUBTITLES")
        self.body = QWidget()
        lay = QVBoxLayout(self.body)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        rows = []
        mine = [t for t in tracks if t.get("type") == want]
        if kind == "sid":
            none_selected = not any(t.get("selected") for t in mine)
            rows.append(("Off", "", none_selected, None))
        for t in mine:
            text, detail = _track_text(t)
            rows.append((text, detail, bool(t.get("selected")), t.get("id")))
        for text, detail, selected, tid in rows:
            row = _MenuRow(text, detail, selected, self.body)
            row.clicked.connect(lambda _=False, i=tid, l=text: self._pick(i, l))
            lay.addWidget(row)
        lay.addStretch(1)
        self.scroll.setWidget(self.body)
        width = 320
        height = min(max_h, 12 + 22 + 10 + len(rows) * 48 + 12)
        self.setFixedSize(width, height)
        self.move(int(right_x - width), int(bottom_y - height))
        self.show()
        self.raise_()

    def _pick(self, track_id, label):
        self.hide()
        self.chosen.emit(self.kind, track_id, label)


class _Notice(QFrame):
    """Centered message card for 'reconnecting' / 'couldn't play'."""

    retry = Signal()
    back = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.hide()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 28, 34, 26)
        lay.setSpacing(8)
        self.title = QLabel(self)
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setWordWrap(True)
        self.title.setStyleSheet(f"color: {C.paper}; background: transparent;"
                                 "font-size: 20px; font-weight: 700;")
        self.detail = QLabel(self)
        self.detail.setAlignment(Qt.AlignCenter)
        self.detail.setWordWrap(True)
        self.detail.setStyleSheet(f"color: {C.dim}; background: transparent;"
                                  "font-size: 15px;")
        lay.addWidget(self.title)
        lay.addWidget(self.detail)
        row = QHBoxLayout()
        row.setSpacing(10)
        row.addStretch(1)
        self.back_btn = QPushButton("Back", self)
        self.retry_btn = QPushButton("Try again", self)
        for btn, primary in ((self.back_btn, False), (self.retry_btn, True)):
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFocusPolicy(Qt.NoFocus)
            btn.setMinimumHeight(42)
            bg = C.cyan if primary else "rgba(255,255,255,0.10)"
            fg = C.on_cyan if primary else C.paper
            hover = C.cyan_hi if primary else "rgba(255,255,255,0.18)"
            btn.setStyleSheet(
                f"QPushButton {{ background: {bg}; color: {fg}; border: none;"
                f" border-radius: 10px; padding: 0 22px; font-size: 15px;"
                f" font-weight: 700; }} QPushButton:hover {{ background: {hover}; }}")
            row.addWidget(btn)
        row.addStretch(1)
        lay.addSpacing(10)
        lay.addLayout(row)
        self.back_btn.clicked.connect(self.back.emit)
        self.retry_btn.clicked.connect(self.retry.emit)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(255, 255, 255, 26), 1))
        p.setBrush(QColor(22, 21, 38, 235))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 16, 16)
        p.end()

    def present(self, title, detail="", buttons=True):
        self.title.setText(title)
        self.detail.setText(detail)
        self.detail.setVisible(bool(detail))
        self.back_btn.setVisible(buttons)
        self.retry_btn.setVisible(buttons)
        self._fit()
        self.show()
        self.raise_()
        # Fonts and visibility settle once the card is actually on screen
        # (and differ with display scaling); measure again after that.
        QTimer.singleShot(0, self._fit)

    def _fit(self):
        """Size the card to its content at its real width.

        adjustSize() asked the layout for its height before the wrapped
        second line had been measured at the card's actual width (and
        before the stylesheet fonts were applied), so on some setups the
        card came out too short and the title and detail lines overlapped.
        """
        width = 440
        for w in (self, self.title, self.detail):
            w.ensurePolished()
        lay = self.layout()
        lay.invalidate()
        lay.activate()
        height = lay.totalHeightForWidth(width) if lay.hasHeightForWidth() \
            else lay.totalSizeHint().height()
        self.setFixedSize(width, max(height, lay.totalMinimumSize().height()))
        parent = self.parentWidget()
        if parent is not None and self.isVisible():
            self.move((parent.width() - width) // 2, (parent.height() - self.height()) // 2)


# ══════════════════════════════════════════════════════════════════
# Live TV: channel banner and in-player channel list
# ══════════════════════════════════════════════════════════════════
# Both are fed "channel info" dicts built by the app, so this module never
# needs to know about the provider, the EPG or the logo cache:
#   {"name", "number", "logo": QPixmap|None,
#    "now": {"title", "start", "stop"}|None, "next": {...}|None}
# (start/stop are aware datetimes; shown here in local time).

def _hm(dt):
    try:
        return dt.astimezone().strftime("%H:%M")
    except Exception:
        return ""


def _fraction(item):
    from datetime import datetime, timezone
    try:
        span = (item["stop"] - item["start"]).total_seconds()
        gone = (datetime.now(timezone.utc) - item["start"]).total_seconds()
        return max(0.0, min(1.0, gone / span))
    except Exception:
        return 0.0


def _draw_logo(p, logo, rect, name):
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(255, 255, 255, 14))
    p.drawRoundedRect(rect, 10, 10)
    if logo is not None and not logo.isNull():
        ratio = logo.devicePixelRatio() or 1
        w, h = logo.width() / ratio, logo.height() / ratio
        scale = min((rect.width() - 12) / max(1, w),
                    (rect.height() - 10) / max(1, h), 1.0)
        dw, dh = w * scale, h * scale
        p.drawPixmap(QRectF(rect.center().x() - dw / 2, rect.center().y() - dh / 2,
                            dw, dh), logo, QRectF(logo.rect()))
    else:
        letters = "".join(w[0] for w in (name or "?").split()[:2]).upper()
        p.setPen(QColor(C.faint))
        p.setFont(font(int(rect.height() * 0.32), QFont.Bold))
        p.drawText(rect, Qt.AlignCenter, letters)


class ChannelBanner(QFrame):
    """The info bar that appears on a channel change, TiviMate-style:
    logo, number and name, what's on now (with progress) and next."""

    W, H = 660, 146

    def __init__(self, parent=None):
        super().__init__(parent)
        self.info = None
        self.setFixedSize(self.W, self.H)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.hide()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)

    def present(self, info, ms=5000):
        self.info = info
        self._cache = None
        self.update()
        self.show()
        self.raise_()
        self._timer.start(ms)

    def refresh(self, info):
        if self.isVisible():
            self.info = info
            self._cache = None
            self.update()

    def paintEvent(self, event):
        # Drawn once per channel into a pixmap, then just blitted on each
        # video frame (see _paint_cached) — redrawing it live every frame
        # is what slowed the picture while the banner was up.
        if not self.info:
            return
        if getattr(self, "_cache", None) is None:
            self._cache = _paint_cached(self, self._render)
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache)
        p.end()

    def _render(self, p):
        info = self.info
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(255, 255, 255, 24), 1))
        p.setBrush(QColor(16, 15, 26, 236))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 16, 16)

        _draw_logo(p, info.get("logo"), QRectF(18, 18, 150, 110), info.get("name"))

        x = 190
        right = self.width() - 22
        number = str(info.get("number") or "")
        p.setFont(font(22, QFont.Bold))
        x_name = x
        if number:
            p.setPen(QColor(C.cyan_hi))
            p.drawText(QRectF(x, 16, 80, 32), Qt.AlignLeft | Qt.AlignVCenter, number)
            x_name = x + p.fontMetrics().horizontalAdvance(number) + 12
        p.setPen(QColor(C.paper))
        name = p.fontMetrics().elidedText(info.get("name") or "", Qt.ElideRight,
                                          int(right - x_name))
        p.drawText(QRectF(x_name, 16, right - x_name, 32),
                   Qt.AlignLeft | Qt.AlignVCenter, name)

        now, nxt = info.get("now"), info.get("next")
        if now:
            p.setFont(font(12, QFont.Bold))
            p.setPen(QColor(C.onair))
            p.drawText(QRectF(x, 56, 44, 22), Qt.AlignLeft | Qt.AlignVCenter, "NOW")
            span = f"{_hm(now['start'])} \u2013 {_hm(now['stop'])}"
            p.setFont(font(13))
            p.setPen(QColor(C.dim))
            sw = p.fontMetrics().horizontalAdvance(span)
            p.drawText(QRectF(right - sw, 56, sw, 22),
                       Qt.AlignRight | Qt.AlignVCenter, span)
            p.setFont(font(17, QFont.DemiBold))
            p.setPen(QColor(C.paper))
            title = p.fontMetrics().elidedText(now.get("title", ""), Qt.ElideRight,
                                               int(right - sw - 16 - (x + 46)))
            p.drawText(QRectF(x + 46, 54, right - x - 46, 26),
                       Qt.AlignLeft | Qt.AlignVCenter, title)
            bar = QRectF(x, 88, right - x, 4)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 40))
            p.drawRoundedRect(bar, 2, 2)
            p.setBrush(QColor(C.cyan))
            p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width() * _fraction(now), 4), 2, 2)
        else:
            p.setFont(font(15))
            p.setPen(QColor(C.faint))
            p.drawText(QRectF(x, 54, right - x, 26), Qt.AlignLeft | Qt.AlignVCenter,
                       "No programme information")
        if nxt:
            p.setFont(font(12, QFont.Bold))
            p.setPen(QColor(C.faint))
            p.drawText(QRectF(x, 102, 44, 22), Qt.AlignLeft | Qt.AlignVCenter, "NEXT")
            p.setFont(font(14))
            p.setPen(QColor(C.dim))
            text = f"{_hm(nxt['start'])}   {nxt.get('title', '')}"
            text = p.fontMetrics().elidedText(text, Qt.ElideRight, int(right - x - 46))
            p.drawText(QRectF(x + 46, 101, right - x - 46, 24),
                       Qt.AlignLeft | Qt.AlignVCenter, text)


class _ChannelRowDelegate(QStyledItemDelegate):
    ROW_H = 76

    def __init__(self, panel):
        super().__init__(panel)
        self.panel = panel

    def sizeHint(self, option, index):
        return QSize(option.rect.width(), self.ROW_H)

    def paint(self, p, option, index):
        row = index.row()
        info = self.panel.info_for(row)
        r = QRectF(option.rect).adjusted(8, 3, -8, -3)
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        selected = bool(option.state & QStyle.State_Selected)
        hover = bool(option.state & QStyle.State_MouseOver)
        playing = row == self.panel.playing_row
        if selected:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(123, 91, 245, 70))
            p.drawRoundedRect(r, 12, 12)
            p.setBrush(QColor(C.cyan))
            p.drawRoundedRect(QRectF(r.x(), r.y() + 14, 4, r.height() - 28), 2, 2)
        elif hover:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 14))
            p.drawRoundedRect(r, 12, 12)
        _draw_logo(p, info.get("logo"), QRectF(r.x() + 14, r.y() + 9, 84, r.height() - 18),
                   info.get("name"))
        x = r.x() + 112
        right = r.right() - 14
        number = str(info.get("number") or "")
        p.setFont(font(15, QFont.Bold))
        nx = x
        if number:
            p.setPen(QColor(C.faint))
            p.drawText(QRectF(x, r.y() + 8, 60, 26), Qt.AlignLeft | Qt.AlignVCenter, number)
            nx = x + p.fontMetrics().horizontalAdvance(number) + 10
        p.setPen(QColor(C.paper))
        name = p.fontMetrics().elidedText(info.get("name") or "", Qt.ElideRight,
                                          int(right - nx - (48 if playing else 0)))
        p.drawText(QRectF(nx, r.y() + 8, right - nx, 26), Qt.AlignLeft | Qt.AlignVCenter, name)
        if playing:
            p.setFont(font(10, QFont.Bold))
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(C.onair))
            p.drawRoundedRect(QRectF(right - 40, r.y() + 13, 40, 17), 4, 4)
            p.setPen(QColor("white"))
            p.drawText(QRectF(right - 40, r.y() + 13, 40, 17), Qt.AlignCenter, "LIVE")
        now = info.get("now")
        p.setFont(font(13))
        if now:
            p.setPen(QColor(C.dim))
            text = p.fontMetrics().elidedText(
                f"{_hm(now['start'])}  {now.get('title', '')}", Qt.ElideRight, int(right - x))
            p.drawText(QRectF(x, r.y() + 34, right - x, 20), Qt.AlignLeft | Qt.AlignVCenter, text)
            bar = QRectF(x, r.y() + 58, right - x, 3)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 34))
            p.drawRoundedRect(bar, 1.5, 1.5)
            p.setBrush(QColor(C.cyan))
            p.drawRoundedRect(QRectF(bar.x(), bar.y(), bar.width() * _fraction(now), 3),
                              1.5, 1.5)
        else:
            p.setPen(QColor(C.faint))
            p.drawText(QRectF(x, r.y() + 34, right - x, 20), Qt.AlignLeft | Qt.AlignVCenter,
                       "No programme information")
        p.restore()


class ChannelListPanel(QFrame):
    """Slide-in channel list over the left of the picture, so you can see
    what's on elsewhere and switch without leaving the player."""

    chosen = Signal(int)
    closed = Signal()

    W = 500

    def __init__(self, parent=None):
        super().__init__(parent)
        self.hide()
        self._info_fn = None
        self._cache = {}
        self.playing_row = -1
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 26, 14, 18)
        lay.setSpacing(4)
        self.title = QLabel(self)
        self.title.setStyleSheet(f"color: {C.paper}; background: transparent;"
                                 "font-size: 22px; font-weight: 700; padding-left: 10px;")
        self.sub = QLabel(self)
        self.sub.setStyleSheet(f"color: {C.faint}; background: transparent;"
                               "font-size: 13px; padding-left: 10px;")
        lay.addWidget(self.title)
        lay.addWidget(self.sub)
        lay.addSpacing(10)
        self.list = QListWidget(self)
        self.list.setFrameShape(QFrame.NoFrame)
        self.list.setUniformItemSizes(True)
        self.list.setMouseTracking(True)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.list.setItemDelegate(_ChannelRowDelegate(self))
        self.list.setStyleSheet("QListWidget { background: transparent; outline: none; }"
                                "QListWidget::item { background: transparent; }")
        self.list.itemClicked.connect(lambda item: self._choose(self.list.row(item)))
        self.list.installEventFilter(self)
        lay.addWidget(self.list, 1)

    def paintEvent(self, event):
        p = QPainter(self)
        g = QLinearGradient(0, 0, self.width(), 0)
        g.setColorAt(0.0, QColor(12, 11, 17, 252))
        g.setColorAt(0.9, QColor(12, 11, 17, 248))
        g.setColorAt(1.0, QColor(12, 11, 17, 225))
        p.fillRect(self.rect(), g)
        p.end()

    def open(self, info_fn, count, current_row, title):
        self._info_fn = info_fn
        self._cache = {}
        self.playing_row = current_row
        self.title.setText("Channels")
        self.sub.setText(f"{title}  \u00b7  {count:,} channels" if title
                         else f"{count:,} channels")
        self.list.clear()
        for _ in range(count):
            self.list.addItem(QListWidgetItem())
        if 0 <= current_row < count:
            self.list.setCurrentRow(current_row)
            self.list.scrollToItem(self.list.item(current_row),
                                   QAbstractItemView.PositionAtCenter)
        self.show()
        self.raise_()
        self.list.setFocus(Qt.OtherFocusReason)

    def info_for(self, row):
        info = self._cache.get(row)
        if info is None:
            info = self._info_fn(row) if self._info_fn else {}
            self._cache[row] = info
        return info

    def logos_changed(self):
        # Re-ask for rows whose logo hadn't arrived yet.
        for row, info in list(self._cache.items()):
            if info.get("logo") is None:
                del self._cache[row]
        self.list.viewport().update()

    def close_panel(self):
        if self.isVisible():
            self.hide()
            self.closed.emit()

    def _choose(self, row):
        self.playing_row = row
        self.close_panel()
        self.chosen.emit(row)

    def eventFilter(self, obj, event):
        if obj is self.list and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Left, Qt.Key_Back):
                self.close_panel()
                return True
            if event.key() in (Qt.Key_Return, Qt.Key_Enter):
                row = self.list.currentRow()
                if row >= 0:
                    self._choose(row)
                return True
        return False


# ══════════════════════════════════════════════════════════════════
# The player screen
# ══════════════════════════════════════════════════════════════════
class StremioPlayerView(QWidget):
    back_requested = Signal()
    fullscreen_toggle_requested = Signal()
    play_pause_requested = Signal()
    retry_requested = Signal()
    # Live TV channel changing — the app owns the channel list, the view
    # just reports what was asked for.
    zap_requested = Signal(int)             # -1 previous, +1 next
    channel_chosen = Signal(int)            # row picked in the channel list
    channel_list_requested = Signal()
    last_channel_requested = Signal()
    info_requested = Signal()
    record_requested = Signal()             # R on a live channel
    progress = Signal(float, float)
    started = Signal()
    ended = Signal(str)
    render_failed = Signal(str)

    HIDE_DELAY_MS = 3000
    FADE_MS = 220
    TOP_H = 140
    BOTTOM_H = 200

    def __init__(self, parent=None, log_file=None):
        super().__init__(parent)
        self.setObjectName("PlayerScreen")
        # The app-wide sheet paints every QWidget in the page colour and
        # sizes every label; neither belongs on top of video.
        self.setStyleSheet("#PlayerScreen { background: black; }"
                           " #PlayerScreen QWidget { background: transparent; }")
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self._is_live = False
        self.live_rewind = True
        self._live_edge = 0.0
        self._lag = 0.0
        self._rewound = False
        self._paused = False
        self._scrubbing = False
        self._pos = 0.0
        self._dur = 0.0
        self._tracks = []
        self._volume = 100
        self._muted = False
        self._controls_visible = True

        self.video = MpvVideo(self, log_file=log_file)
        v = self.video
        v.position.connect(self._on_position)
        v.duration.connect(self._on_duration)
        v.pause_changed.connect(self._on_pause)
        v.volume_changed.connect(self._on_volume)
        v.mute_changed.connect(self._on_mute)
        v.buffering_changed.connect(self._on_buffering)
        v.cache_end_changed.connect(self._on_cache_end)
        v.tracks_changed.connect(self._on_tracks)
        v.started.connect(self._on_started)
        v.ended.connect(self.ended.emit)
        v.render_failed.connect(self.render_failed.emit)
        v.clicked.connect(self._on_video_click)
        v.double_clicked.connect(self._request_fullscreen)
        self.play_pause_requested.connect(v.toggle_pause)

        self._build_top()
        self._build_bottom()

        self.spinner = Spinner(self)
        self.spinner.hide()

        self.indicator = QLabel(self)
        self.indicator.setStyleSheet(_pill_style(size=17))
        self.indicator.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.indicator.hide()
        self._indicator_timer = QTimer(self)
        self._indicator_timer.setSingleShot(True)
        self._indicator_timer.setInterval(1300)
        self._indicator_timer.timeout.connect(self.indicator.hide)

        self.bubble = QLabel(self)
        self.bubble.setStyleSheet(_pill_style(size=14))
        self.bubble.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.bubble.hide()

        self.notice = _Notice(self)
        self.notice.back.connect(self.back_requested.emit)
        self.notice.retry.connect(self.retry_requested.emit)

        self.menu = TrackMenu(self)
        self.menu.chosen.connect(self._on_track_chosen)

        self.banner = ChannelBanner(self)
        self.channels = ChannelListPanel(self)
        self.channels.chosen.connect(self.channel_chosen.emit)
        self.channels.closed.connect(self._on_channels_closed)

        self._fades = []
        for w in (self.top, self.bottom):
            effect = QGraphicsOpacityEffect(w)
            effect.setOpacity(1.0)
            # Only switched on for the fade itself: an active effect
            # re-renders the whole bar off-screen on every video frame.
            effect.setEnabled(False)
            w.setGraphicsEffect(effect)
            anim = QPropertyAnimation(effect, b"opacity", self)
            anim.setDuration(self.FADE_MS)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.finished.connect(lambda w=w, e=effect: self._fade_done(w, e))
            self._fades.append((w, effect, anim))

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.setInterval(self.HIDE_DELAY_MS)
        self._hide_timer.timeout.connect(self._hide_controls)

        self._clock_timer = QTimer(self)
        self._clock_timer.setInterval(10_000)
        self._clock_timer.timeout.connect(self._tick_clock)
        self._clock_timer.start()
        self._tick_clock()

        QApplication.instance().installEventFilter(self)

    # ── construction ─────────────────────────────────────────────
    def _label(self, parent, size, weight=400, color=None):
        lab = QLabel(parent)
        lab.setStyleSheet(f"color: {color or C.paper}; background: transparent;"
                          f"font-size: {size}px; font-weight: {weight};")
        return lab

    def _live_pill(self, parent):
        pill = QLabel("\u25cf  LIVE", parent)
        pill.setStyleSheet(f"background: {C.onair}; color: white; border-radius: 6px;"
                           "padding: 4px 11px; font-size: 13px; font-weight: 800;"
                           "letter-spacing: 1px;")
        pill.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        pill.hide()
        return pill

    def _build_top(self):
        self.top = _Scrim("top", self)
        lay = QHBoxLayout(self.top)
        lay.setContentsMargins(26, 22, 36, 0)
        lay.setSpacing(12)
        self.back_btn = PlayerButton("back", self.top, 54, "Back  (Esc)")
        self.back_btn.clicked.connect(self.back_requested.emit)
        lay.addWidget(self.back_btn, 0, Qt.AlignTop)
        box = QVBoxLayout()
        box.setContentsMargins(0, 4, 0, 0)
        box.setSpacing(2)
        self.title_label = self._label(self.top, 24, 700)
        self.subtitle_label = self._label(self.top, 16, color="rgba(238,240,248,0.72)")
        box.addWidget(self.title_label)
        box.addWidget(self.subtitle_label)
        box.addStretch(1)
        lay.addLayout(box, 1)
        self.top_live = self._live_pill(self.top)
        lay.addWidget(self.top_live, 0, Qt.AlignTop)
        lay.addSpacing(14)
        self.clock = self._label(self.top, 22, 600)
        lay.addWidget(self.clock, 0, Qt.AlignTop)

    def _build_bottom(self):
        self.bottom = _Scrim("bottom", self)
        lay = QVBoxLayout(self.bottom)
        lay.setContentsMargins(30, 0, 30, 22)
        lay.setSpacing(2)
        lay.addStretch(1)

        self.seek_row = QWidget(self.bottom)
        sr = QHBoxLayout(self.seek_row)
        sr.setContentsMargins(6, 0, 6, 0)
        sr.setSpacing(12)
        self.pos_label = self._label(self.seek_row, 15, 600)
        self.dur_label = self._label(self.seek_row, 15, 600,
                                     "rgba(238,240,248,0.72)")
        for lab in (self.pos_label, self.dur_label):
            lab.setMinimumWidth(64)
        self.dur_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.seek = SeekBar(self.seek_row)
        self.seek.scrubbing.connect(self._on_scrubbing)
        self.seek.seek_committed.connect(self._on_seek_committed)
        self.seek.hover_time.connect(self._on_seek_hover)
        sr.addWidget(self.pos_label)
        sr.addWidget(self.seek, 1)
        sr.addWidget(self.dur_label)
        lay.addWidget(self.seek_row)

        row = QHBoxLayout()
        row.setSpacing(4)
        self.play_btn = PlayerButton("pause", self.bottom, 60, "Play / Pause  (Space)")
        self.play_btn.clicked.connect(self.play_pause_requested.emit)
        self.rew_btn = PlayerButton("rewind", self.bottom, 52, "Back 10 seconds  (\u2190)")
        self.rew_btn.clicked.connect(lambda: self._skip(-10))
        self.fwd_btn = PlayerButton("forward", self.bottom, 52, "Forward 10 seconds  (\u2192)")
        self.fwd_btn.clicked.connect(lambda: self._skip(10))
        self.mute_btn = PlayerButton("volume2", self.bottom, 52, "Mute  (M)")
        self.mute_btn.clicked.connect(self.video.toggle_mute)
        self.volume = VolumeSlider(self.bottom)
        self.volume.changed.connect(self._on_volume_dragged)
        self.list_btn = PlayerButton("list", self.bottom, 52, "Channels  (Enter)")
        self.list_btn.clicked.connect(self.channel_list_requested.emit)
        self.audio_btn = PlayerButton("audio", self.bottom, 52, "Audio")
        self.audio_btn.clicked.connect(lambda: self._toggle_menu("aid", self.audio_btn))
        self.subs_btn = PlayerButton("subtitles", self.bottom, 52, "Subtitles")
        self.subs_btn.clicked.connect(lambda: self._toggle_menu("sid", self.subs_btn))
        self.fs_btn = PlayerButton("fullscreen", self.bottom, 52, "Fullscreen  (F)")
        self.fs_btn.clicked.connect(self._request_fullscreen)
        for w in (self.play_btn, self.rew_btn, self.fwd_btn, self.mute_btn):
            row.addWidget(w, 0, Qt.AlignVCenter)
        row.addWidget(self.volume, 0, Qt.AlignVCenter)
        row.addStretch(1)
        for w in (self.list_btn, self.audio_btn, self.subs_btn, self.fs_btn):
            row.addWidget(w, 0, Qt.AlignVCenter)
        lay.addLayout(row)
        self.audio_btn.setEnabled(False)
        self.subs_btn.setEnabled(False)

    # ── layout ───────────────────────────────────────────────────
    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._place()

    def _place(self):
        w, h = self.width(), self.height()
        self.video.setGeometry(0, 0, w, h)
        self.top.setGeometry(0, 0, w, self.TOP_H)
        self.bottom.setGeometry(0, h - self.BOTTOM_H, w, self.BOTTOM_H)
        self.spinner.move((w - self.spinner.width()) // 2, (h - self.spinner.height()) // 2)
        if self.notice.isVisible():
            self.notice.move((w - self.notice.width()) // 2, (h - self.notice.height()) // 2)
        self._place_indicator()
        if self.menu.isVisible():
            self.menu.hide()
        self.banner.move(32, h - 118 - self.banner.height())
        self.channels.setGeometry(0, 0, min(ChannelListPanel.W, w), h)
        for widget in (self.top, self.bottom, self.spinner, self.indicator,
                       self.bubble, self.banner, self.notice, self.channels,
                       self.menu):
            widget.raise_()

    def _place_indicator(self):
        self.indicator.adjustSize()
        self.indicator.move((self.width() - self.indicator.width()) // 2, 96)

    def showEvent(self, event):
        super().showEvent(event)
        self._place()
        self.setFocus(Qt.OtherFocusReason)
        self.show_controls()

    def hideEvent(self, event):
        self.menu.hide()
        self.bubble.hide()
        super().hideEvent(event)

    # ── public API used by FluxTV ────────────────────────────────
    def set_now_playing(self, title, subtitle="", is_live=False):
        self._is_live = is_live
        self.title_label.setText(title)
        self.subtitle_label.setText(subtitle)
        self.subtitle_label.setVisible(bool(subtitle))
        self.top_live.setVisible(is_live)
        self.seek_row.setVisible(not is_live)
        # Live TV can be paused and rewound too (the last half hour or so is
        # kept), unless that's switched off in Settings.
        self.rew_btn.setVisible(not is_live or self.live_rewind)
        self.fwd_btn.setVisible(not is_live or self.live_rewind)
        self._live_edge = 0.0
        self._lag = 0.0
        self._rewound = False
        self.top_live.setText("")
        self._show_live_state()
        self.list_btn.setVisible(is_live)
        if not is_live:
            self.banner.hide()
            self.channels.close_panel()
        self._pos = self._dur = 0.0
        self.seek.reset()
        self.pos_label.setText("0:00")
        self.dur_label.setText("0:00")
        self.play_btn.set_kind("pause")
        self._tracks = []
        self.audio_btn.setEnabled(False)
        self.subs_btn.setEnabled(False)
        self.menu.hide()

    def play(self, url, **kwargs):
        self.notice.hide()
        self.video.play(url, **kwargs)
        self.show_controls()

    def stop_playback(self):
        self.menu.hide()
        self.notice.hide()
        self.spinner.hide()
        self.video.stop()

    def show_notice(self, title, detail="", buttons=True):
        self.spinner.hide()
        self.notice.present(title, detail, buttons)
        self._place()
        self.show_controls()

    def hide_notice(self):
        self.notice.hide()

    def show_indicator(self, text):
        self.indicator.setText(text)
        self._place_indicator()
        self.indicator.show()
        self.indicator.raise_()
        self._indicator_timer.start()

    def handle_escape(self):
        """Esc closes an open menu before it's allowed to leave the player."""
        if self.menu.isVisible():
            self.menu.hide()
            return True
        if self.channels.isVisible():
            self.channels.close_panel()
            return True
        return False

    # ── live TV channel changing ────────────────────────────────
    def show_banner(self, info):
        self.banner.present(info)

    def open_channel_list(self, info_fn, count, current_row, title=""):
        self.menu.hide()
        self.banner.hide()
        self._place()
        self.channels.open(info_fn, count, current_row, title)
        self.show_controls()
        self.top.hide()          # the list has its own heading

    def on_logo_ready(self, _url):
        self.logos_changed()

    def logos_changed(self):
        if self.channels.isVisible():
            self.channels.logos_changed()
        if self.banner.isVisible() and not (self.banner.info or {}).get("logo"):
            self.info_requested.emit()

    def _on_channels_closed(self):
        self.setFocus(Qt.OtherFocusReason)
        self.show_controls()

    def shutdown(self):
        QApplication.instance().removeEventFilter(self)
        self.video.shutdown()

    # ── controls visibility ──────────────────────────────────────
    def show_controls(self):
        self._controls_visible = True
        self._sync_fullscreen_icon()
        for w, effect, anim in self._fades:
            if w.isVisible() and effect.opacity() >= 0.99 and \
                    anim.state() != QPropertyAnimation.Running:
                continue
            anim.stop()
            w.show()
            effect.setEnabled(True)
            anim.setStartValue(effect.opacity())
            anim.setEndValue(1.0)
            anim.start()
        self._set_cursor_visible(True)
        self._hide_timer.start()

    def _fade_done(self, widget, effect):
        if effect.opacity() <= 0.01:
            widget.hide()
        elif effect.opacity() >= 0.99:
            effect.setEnabled(False)

    def _hide_controls(self):
        if (self._paused or self._scrubbing or self.menu.isVisible()
                or self.notice.isVisible() or self.channels.isVisible()
                or not self.isVisible()):
            return
        if self._pointer_on_controls():
            self._hide_timer.start()
            return
        self._controls_visible = False
        self.bubble.hide()
        for w, effect, anim in self._fades:
            anim.stop()
            effect.setEnabled(True)
            anim.setStartValue(effect.opacity())
            anim.setEndValue(0.0)
            anim.start()
        self._set_cursor_visible(False)

    def _pointer_on_controls(self):
        pos = self.mapFromGlobal(QCursor.pos())
        if not self.rect().contains(pos):
            return False
        return pos.y() >= self.height() - 130 or pos.y() <= 90

    def _set_cursor_visible(self, visible):
        cursor = Qt.ArrowCursor if visible else Qt.BlankCursor
        self.setCursor(cursor)
        self.video.setCursor(cursor)

    def _activity(self):
        if not self._controls_visible:
            self.show_controls()
        else:
            self._hide_timer.start()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.MouseMove and self.isVisible():
            self._activity()
        return False

    # ── video state → controls ───────────────────────────────────
    def _on_cache_end(self, end):
        self.seek.set_buffered(end)
        if self._is_live:
            self._live_edge = max(self._live_edge, end)
            self._show_live_state()        # keeps counting while paused

    def _behind_live(self):
        """Seconds behind live. Playing live normally sits a few seconds
        short of the downloaded edge (the player's safety buffer); that
        normal gap is measured and not counted."""
        if not self._live_edge:
            return 0.0
        gap = max(0.0, self._live_edge - self._pos)
        if not self._rewound:
            self._lag = gap
            return 0.0
        return max(0.0, gap - self._lag)

    def _show_live_state(self):
        """The LIVE pill becomes "2:30 BEHIND" after rewinding or pausing
        live TV; End (or ⏩ to the edge) goes back to live."""
        behind = self._behind_live()
        if self._rewound and behind < 2:
            self._rewound = False                   # caught back up
        text = f"●  {_fmt(behind)} BEHIND  ·  End = live" if behind >= 2 else "●  LIVE"
        if text != self.top_live.text():
            self.top_live.setText(text)
            colour = C.onair if behind < 2 else "#5A5670"
            self.top_live.setStyleSheet(
                f"background: {colour}; color: white; border-radius: 6px;"
                "padding: 4px 11px; font-size: 13px; font-weight: 800; letter-spacing: 1px;")
            self.top_live.adjustSize()

    def go_live(self):
        if self._is_live and self._live_edge:
            self.video.seek(max(0.0, self._live_edge - max(1.5, self._lag)))
            if self._paused:
                self.video.toggle_pause()
            self._rewound = False
            self.show_indicator("Live")

    def _on_position(self, pos):
        self._pos = pos
        if self._is_live:
            self._show_live_state()
        if not self._is_live and not self._scrubbing:
            self.seek.set_state(pos, self._dur)
            self.pos_label.setText(_fmt(pos))
        if self._dur > 0:
            self.progress.emit(pos, self._dur)

    def _on_duration(self, dur):
        self._dur = dur
        self.dur_label.setText(_fmt(dur))
        self.seek.set_state(self._pos, dur)

    def _on_pause(self, paused):
        self._paused = paused
        if paused and self._is_live and self.live_rewind:
            self._behind_live()
            self._rewound = True                    # pausing live = falling behind
        self.play_btn.set_kind("play" if paused else "pause")
        self.show_controls()

    def _on_volume(self, volume):
        self._volume = volume
        if not self.volume.is_dragging():
            self.volume.set_value(volume)
        self._sync_mute_icon()

    def _on_mute(self, muted):
        self._muted = muted
        self._sync_mute_icon()

    def _sync_mute_icon(self):
        if self._muted:
            kind = "mute"
        elif self._volume <= 0:
            kind = "volume0"
        elif self._volume < 50:
            kind = "volume1"
        else:
            kind = "volume2"
        self.mute_btn.set_kind(kind)

    def _on_buffering(self, busy):
        self.spinner.setVisible(busy and not self.notice.isVisible())
        if busy:
            self.spinner.raise_()

    def _on_tracks(self, tracks):
        self._tracks = tracks
        audio = [t for t in tracks if t.get("type") == "audio"]
        subs = [t for t in tracks if t.get("type") == "sub"]
        self.audio_btn.setEnabled(len(audio) > 1)
        self.subs_btn.setEnabled(bool(subs))

    def _on_started(self):
        self.notice.hide()
        self.started.emit()

    # ── user actions ─────────────────────────────────────────────
    def _on_video_click(self):
        if self.menu.isVisible():
            self.menu.hide()
            return
        if self.channels.isVisible():
            self.channels.close_panel()
            return
        self.play_pause_requested.emit()

    def _request_fullscreen(self):
        self.fullscreen_toggle_requested.emit()
        QTimer.singleShot(200, self._sync_fullscreen_icon)

    def _sync_fullscreen_icon(self):
        win = self.window()
        self.fs_btn.set_kind("fullscreen_exit" if win and win.isFullScreen()
                             else "fullscreen")

    def _skip(self, seconds):
        if self._is_live and not self.live_rewind:
            return
        if self._is_live and seconds > 0 and self._behind_live() <= seconds:
            self.go_live()
            return
        if self._is_live and seconds < 0:
            self._behind_live()                     # note the normal gap first
            self._rewound = True
        self.video.seek_relative(seconds)
        sign = "+" if seconds > 0 else "\u2212"
        self.show_indicator(f"{sign}{abs(seconds)}s")

    def _on_scrubbing(self, active):
        self._scrubbing = active
        if active:
            self.show_controls()

    def _on_seek_committed(self, seconds):
        self.pos_label.setText(_fmt(seconds))
        self.video.seek(seconds)
        self._hide_timer.start()

    def _on_seek_hover(self, seconds, x):
        if seconds < 0:
            self.bubble.hide()
            return
        self.bubble.setText(_fmt(seconds))
        self.bubble.adjustSize()
        origin = self.seek.mapTo(self, QPoint(x, 0))
        self.bubble.move(int(origin.x() - self.bubble.width() / 2),
                         origin.y() - self.bubble.height() - 6)
        self.bubble.show()
        self.bubble.raise_()

    def _on_volume_dragged(self, value):
        self.video.set_volume(value)
        if self._muted and value > 0:
            self.video.toggle_mute()

    def _change_volume(self, delta):
        value = max(0, min(100, self._volume + delta))
        self.video.set_volume(value)
        self.volume.set_value(value)
        self.show_indicator(f"Volume  {value}%")

    def _toggle_menu(self, kind, button):
        if self.menu.isVisible() and self.menu.kind == kind:
            self.menu.hide()
            return
        top_left = button.mapTo(self, QPoint(0, 0))
        right = min(self.width() - 20, top_left.x() + button.width() + 60)
        self.menu.open_for(kind, self._tracks, right, top_left.y() - 12,
                           max_h=int(self.height() * 0.6))
        self._hide_timer.stop()

    def _on_track_chosen(self, kind, track_id, label):
        self.video.set_track(kind, track_id)
        prefix = "Audio" if kind == "aid" else "Subtitles"
        self.show_indicator(f"{prefix}:  {label}")
        self._hide_timer.start()

    def _tick_clock(self):
        self.clock.setText(time.strftime("%H:%M"))

    # ── keyboard / wheel ─────────────────────────────────────────
    def keyPressEvent(self, event):
        key = event.key()
        if self._is_live and key in (Qt.Key_Up, Qt.Key_Down,
                                     Qt.Key_PageUp, Qt.Key_PageDown):
            # Channel changing, TiviMate-style: Up moves up the list.
            # The banner says where you're landing; the controls stay out
            # of the way so the picture change is what you see.
            self.zap_requested.emit(-1 if key in (Qt.Key_Up, Qt.Key_PageUp) else 1)
            return
        if self._is_live and key in (Qt.Key_Return, Qt.Key_Enter):
            self.channel_list_requested.emit()
            return
        if self._is_live and key == Qt.Key_Backspace:
            self.last_channel_requested.emit()
            return
        if self._is_live and key == Qt.Key_I:
            self.info_requested.emit()
            return
        if self._is_live and key == Qt.Key_R:
            self.record_requested.emit()
            return
        if self._is_live and key == Qt.Key_End:
            self.show_controls()
            self.go_live()
            return
        self.show_controls()
        if key == Qt.Key_Left:
            self._skip(-10)
        elif key == Qt.Key_Right:
            self._skip(10)
        elif key in (Qt.Key_Up, Qt.Key_Plus, Qt.Key_Equal):
            self._change_volume(5)
        elif key in (Qt.Key_Down, Qt.Key_Minus):
            self._change_volume(-5)
        elif key == Qt.Key_M:
            self.video.toggle_mute()
            self.show_indicator("Unmuted" if self._muted else "Muted")
        elif key == Qt.Key_F:
            self._request_fullscreen()
        else:
            super().keyPressEvent(event)

    def wheelEvent(self, event):
        self._change_volume(5 if event.angleDelta().y() > 0 else -5)
