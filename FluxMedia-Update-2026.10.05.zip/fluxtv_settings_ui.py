"""
Flux Media (FluxTV) — the Settings screen and the login screen.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QDialog, QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
import fluxtv_backup
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (LOGOS, PasswordField, _english_stamp, background, html_escape, logo_pixmap, show_dialog)


# ══════════════════════════════════════════════════════════════════
# Settings
# ══════════════════════════════════════════════════════════════════
class SettingsView(QWidget):
    """Playback, guide, favourites, and account — one screen, no dialogs
    beyond the file pickers backup/restore/import genuinely need."""

    refresh_requested = Signal()
    logout_requested = Signal()
    quit_requested = Signal()
    change_login_requested = Signal()
    epg_reload_requested = Signal(str)
    credentials_changed = Signal(str, str, str)
    install_addon_requested = Signal(str)
    stremio_login_requested = Signal(str, str)
    stremio_sync_requested = Signal()
    stremio_logout_requested = Signal()
    trakt_connect_requested = Signal(str, str)
    trakt_cancel_requested = Signal()
    trakt_sync_requested = Signal()
    trakt_disconnect_requested = Signal()
    remove_addon_requested = Signal(object)
    move_addon_requested = Signal(object, int)
    install_update_requested = Signal(str)
    undo_update_requested = Signal()
    restore_requested = Signal(str)
    check_updates_requested = Signal()
    online_update_requested = Signal(object)
    stremio_addons_requested = Signal()
    parental_changed = Signal()
    check_services_requested = Signal()

    def __init__(self, library, api, parent=None):
        super().__init__(parent)
        self.lib = library
        self.api = api

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        self.lay = QVBoxLayout(holder)
        self.lay.setContentsMargins(34, 22, 24, 30)
        self.lay.setSpacing(18)
        self.scroll.setWidget(holder)
        outer.addWidget(self.scroll)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(11)
        pip = QFrame(holder)
        pip.setFixedSize(4, 24)
        pip.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:0, y2:1,"
                          f" stop:0 {C.cyan}, stop:1 {C.violet}); border-radius: 2px;")
        pip.hide()
        title = QLabel("Settings", holder)
        title.setObjectName("ScreenTitle")
        title_row.addWidget(title)
        self.lay.addLayout(title_row)
        sub = QLabel("Playback, guide, favourites and account.", holder)
        sub.setObjectName("Muted")
        self.lay.addWidget(sub)

        self._build_health()
        self._build_playback()
        self._build_addons()
        self._build_stremio()
        self._build_trakt()
        self._build_guide()
        self._build_favourites()
        self._build_parental()
        self._build_youtube()
        self._build_details()
        self._build_account()
        self._build_backup()
        self._build_updates()
        self.lay.addStretch(1)

    # ── section helper ───────────────────────────────────────────
    def _section(self, title):
        panel = QFrame(self)
        panel.setObjectName("Panel")
        panel.setMaximumWidth(760)
        lay = QVBoxLayout(panel)
        lay.setContentsMargins(26, 22, 26, 22)
        lay.setSpacing(12)
        heading = QLabel(title, panel)
        heading.setObjectName("ShelfTitle")
        lay.addWidget(heading)
        rule = QFrame(panel)
        rule.setObjectName("Hairline")
        lay.addWidget(rule)
        self.lay.addWidget(panel)
        return lay

    @staticmethod
    def _row(parent_lay, label_text):
        row = QHBoxLayout()
        label = QLabel(label_text)
        label.setObjectName("Muted")
        label.setFixedWidth(150)
        row.addWidget(label)
        parent_lay.addLayout(row)
        return row

    def _slider_row(self, lay, label, key, low, high, step=1, suffix=""):
        row = self._row(lay, label)
        value = int(self.lib.settings.get(key, core.DEFAULT_SETTINGS[key]))
        slider = QSlider(Qt.Horizontal)
        slider.setRange(low, high)
        slider.setSingleStep(step)
        slider.setValue(value)
        slider.setFixedWidth(200)
        row.addWidget(slider)
        readout = QLabel(f"{value}{suffix}")
        readout.setObjectName("Mono")
        readout.setFixedWidth(56)
        row.addWidget(readout)
        row.addStretch(1)

        def changed(v):
            readout.setText(f"{v}{suffix}")
            self.lib.settings[key] = v
            core.save_settings(self.lib.settings)
        slider.valueChanged.connect(changed)

    def _check_row(self, lay, label, key):
        box = QCheckBox(label)
        box.setChecked(bool(self.lib.settings.get(key, core.DEFAULT_SETTINGS[key])))

        def changed(state):
            # Plain stateChanged(int) rather than the Qt 6.7+ only
            # checkStateChanged, so this keeps working on older Qt6 minors.
            self.lib.settings[key] = bool(state)
            core.save_settings(self.lib.settings)
        box.stateChanged.connect(changed)
        lay.addWidget(box)

    # ── sections ─────────────────────────────────────────────────
    def _build_playback(self):
        lay = self._section("Playback")
        self._slider_row(lay, "Buffer size", "cache_secs", 5, 120, suffix="s")
        self._slider_row(lay, "Max buffer", "demuxer_max_mb", 10, 200, 10, " MB")
        self._slider_row(lay, "Read-ahead", "readahead_secs", 5, 60, suffix="s")
        self._slider_row(lay, "Max restart retries", "max_retries", 1, 10)
        self._check_row(lay, "Retry dropped streams automatically", "auto_restart")
        self._check_row(lay, "Start MPV fullscreen", "fullscreen")
        self._check_row(lay, "Pause and rewind live TV (← → on a channel, End = back "
                             "to live)", "live_rewind")
        self._check_row(lay, "Turn on English subtitles automatically "
                             "(add-on films and series)", "subtitles_auto")
        self._check_row(lay, "Load provider logos on cards", "show_logos")
        self._check_row(lay, "Hardware-accelerated video decoding (VAAPI)",
                        "hardware_accel")
        rule = QFrame(self)
        rule.setObjectName("Hairline")
        lay.addWidget(rule)
        mpv_label = QLabel(f"MPV binary   {core.MPV_PATH}", self)
        mpv_label.setObjectName("Mono")
        lay.addWidget(mpv_label)

    def _build_addons(self):
        lay = self._section("Add-ons")
        hint = QLabel("Stremio add-ons, the same ones Stremio uses. Paste an add-on "
                      "link (in Stremio: Add-ons \u2192 the add-on \u2192 Share / copy link). "
                      "Links set up with your TorBox key stay on this computer.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.addon_rows = QVBoxLayout()
        self.addon_rows.setSpacing(8)
        lay.addLayout(self.addon_rows)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.addon_field = QLineEdit(self)
        self.addon_field.setPlaceholderText("https://\u2026/manifest.json")
        self.addon_field.returnPressed.connect(self._install_addon)
        row.addWidget(self.addon_field, 1)
        self.addon_btn = QPushButton("Install", self)
        self.addon_btn.setObjectName("Primary")
        self.addon_btn.setCursor(Qt.PointingHandCursor)
        self.addon_btn.clicked.connect(self._install_addon)
        row.addWidget(self.addon_btn)
        lay.addLayout(row)
        # A backup of all your Stremio add-ons (e.g. from Stremio's add-on
        # manager) is many lines; a one-line box would mangle it, so these
        # read the clipboard / a file directly.
        bulk = QHBoxLayout()
        bulk.setSpacing(10)
        paste_btn = QPushButton("Paste backup", self)
        paste_btn.setObjectName("Ghost")
        paste_btn.setCursor(Qt.PointingHandCursor)
        paste_btn.setToolTip("Install every add-on link on the clipboard")
        paste_btn.clicked.connect(self._paste_addons)
        bulk.addWidget(paste_btn)
        file_btn = QPushButton("Import file…", self)
        file_btn.setObjectName("Ghost")
        file_btn.setCursor(Qt.PointingHandCursor)
        file_btn.setToolTip("Install every add-on link in a backup file")
        file_btn.clicked.connect(self._import_addons_file)
        bulk.addWidget(file_btn)
        bulk.addStretch(1)
        lay.addLayout(bulk)
        self.addon_status = QLabel("", self)
        self.addon_status.setObjectName("Faint")
        self.addon_status.setWordWrap(True)
        lay.addWidget(self.addon_status)

    def set_addons(self, addons):
        while self.addon_rows.count():
            item = self.addon_rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for addon in addons:
            card = QFrame(self)
            card.setObjectName("EpisodeRow")
            cl = QHBoxLayout(card)
            cl.setContentsMargins(16, 10, 10, 10)
            text = QVBoxLayout()
            text.setSpacing(2)
            name = QLabel(f"{addon.name}  {addon.version}".strip(), card)
            name.setStyleSheet("font-size: 15px; font-weight: 700; background: transparent;")
            what = ", ".join(r for r in addon.resource_names() if r in ("catalog", "meta", "stream"))
            info = QLabel(f"{addon.host}   \u00b7   {what or 'other'}", card)
            info.setObjectName("Faint")
            text.addWidget(name)
            text.addWidget(info)
            cl.addLayout(text, 1)
            for arrow, delta, tip in (("\u25b2", -1, "Move up"), ("\u25bc", 1, "Move down")):
                b = QPushButton(arrow, card)
                b.setObjectName("Arrow")
                b.setFixedSize(34, 34)
                b.setCursor(Qt.PointingHandCursor)
                b.setToolTip(tip + " \u2014 higher add-ons' streams are listed first")
                b.clicked.connect(lambda _=False, a=addon, d=delta:
                                  self.move_addon_requested.emit(a, d))
                cl.addWidget(b)
            remove = QPushButton("Remove", card)
            remove.setObjectName("Ghost")
            remove.setCursor(Qt.PointingHandCursor)
            remove.clicked.connect(lambda _=False, a=addon: self.remove_addon_requested.emit(a))
            cl.addWidget(remove)
            self.addon_rows.addWidget(card)

    def _install_addon(self):
        text = self.addon_field.text().strip()
        if not text:
            return
        self.addon_btn.setEnabled(False)
        self.addon_status.setText("Installing\u2026")
        self.install_addon_requested.emit(text)

    def _build_stremio(self):
        lay = self._section("Stremio account")
        hint = QLabel("Bring your Stremio library and watch progress into Flux Media. Your "
                      "password is only sent to Stremio and isn't saved.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)

        self.st_login = QWidget(self)
        self.st_login.setObjectName("Clear")
        ll = QVBoxLayout(self.st_login)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(10)
        self.st_email = QLineEdit(self.st_login)
        self.st_email.setPlaceholderText("Stremio email")
        ll.addWidget(self.st_email)
        self.st_pwd = PasswordField(self.st_login)
        self.st_pwd.edit.setPlaceholderText("Stremio password")
        self.st_pwd.edit.returnPressed.connect(self._stremio_login)
        ll.addWidget(self.st_pwd)
        self.st_login_btn = QPushButton("Import library", self.st_login)
        self.st_login_btn.setObjectName("Primary")
        self.st_login_btn.setCursor(Qt.PointingHandCursor)
        self.st_login_btn.clicked.connect(self._stremio_login)
        ll.addWidget(self.st_login_btn, 0, Qt.AlignLeft)
        lay.addWidget(self.st_login)

        self.st_signed = QWidget(self)
        self.st_signed.setObjectName("Clear")
        sl = QHBoxLayout(self.st_signed)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(10)
        self.st_info = QLabel("", self.st_signed)
        self.st_info.setObjectName("Muted")
        self.st_info.setWordWrap(True)
        sl.addWidget(self.st_info, 1)
        self.st_sync_btn = QPushButton("Sync now", self.st_signed)
        self.st_sync_btn.setObjectName("Ghost")
        self.st_sync_btn.setCursor(Qt.PointingHandCursor)
        self.st_sync_btn.clicked.connect(self._stremio_sync)
        self.st_addons_btn = QPushButton("Import my add-ons", self.st_signed)
        self.st_addons_btn.setObjectName("Ghost")
        self.st_addons_btn.setCursor(Qt.PointingHandCursor)
        self.st_addons_btn.setToolTip("Adds the add-ons installed on your Stremio account "
                                      "(ones you already have are left as they are)")
        self.st_addons_btn.clicked.connect(self.stremio_addons_requested.emit)
        sl.addWidget(self.st_addons_btn)
        sl.addWidget(self.st_sync_btn)
        out_btn = QPushButton("Sign out", self.st_signed)
        out_btn.setObjectName("Ghost")
        out_btn.setCursor(Qt.PointingHandCursor)
        out_btn.clicked.connect(self.stremio_logout_requested.emit)
        sl.addWidget(out_btn)
        lay.addWidget(self.st_signed)

        self.st_status = QLabel("", self)
        self.st_status.setObjectName("Faint")
        self.st_status.setWordWrap(True)
        lay.addWidget(self.st_status)
        self.set_stremio_account(None)

    def set_stremio_account(self, account):
        self.st_login.setVisible(account is None)
        self.st_signed.setVisible(account is not None)
        if account:
            when = account.get("last_sync") or 0
            synced = _english_stamp(when) if when else "never"
            self.st_info.setText(f"Signed in as {account.get('email', '')}   \u00b7   "
                                 f"last synced {synced}")

    def _stremio_login(self):
        email, pwd = self.st_email.text().strip(), self.st_pwd.edit.text()
        if not email or not pwd:
            self.stremio_result(False, "Enter your Stremio email and password.")
            return
        self.st_login_btn.setEnabled(False)
        self.st_status.setStyleSheet("")
        self.st_status.setText("Signing in to Stremio and importing your library\u2026")
        self.stremio_login_requested.emit(email, pwd)

    def _stremio_sync(self):
        self.st_sync_btn.setEnabled(False)
        self.st_status.setStyleSheet("")
        self.st_status.setText("Syncing your Stremio library\u2026")
        self.stremio_sync_requested.emit()

    def stremio_result(self, ok, message):
        self.st_login_btn.setEnabled(True)
        self.st_sync_btn.setEnabled(True)
        self.st_status.setText(message)
        self.st_status.setStyleSheet(f"color: {C.ok if ok else C.onair};")
        if ok:
            self.st_pwd.edit.clear()

    def _build_trakt(self):
        lay = self._section("Trakt")
        intro = QLabel(
            "Tick off what you've watched and keep your Trakt history up to date "
            "automatically. Trakt needs a free API app of your own first:<br>"
            "1. Open <b>developer.trakt.tv/apps/new</b> and sign in with your "
            "normal Trakt account.<br>"
            "2. Name it <b>Flux Media</b>, set the Redirect URI to "
            "<b>urn:ietf:wg:oauth:2.0:oob</b>, and save it.<br>"
            "3. Paste its Client ID and Client Secret below, then Connect.", self)
        intro.setObjectName("Faint")
        intro.setWordWrap(True)
        intro.setTextFormat(Qt.RichText)
        lay.addWidget(intro)
        self.tr_intro = intro
        self._tr_manual = False

        # Easy connect: the app keys are already here (from an earlier
        # connection or a Trakt file), so it's just Connect + a code.
        self.tr_easy = QWidget(self)
        self.tr_easy.setObjectName("Clear")
        el = QVBoxLayout(self.tr_easy)
        el.setContentsMargins(0, 0, 0, 0)
        el.setSpacing(10)
        easy_hint = QLabel("Sign in with <b>your own</b> Trakt account: press Connect, then type "
                           "the code at <b>trakt.tv/activate</b> on your phone. Your watched "
                           "history comes across and everything you watch is added to it.",
                           self.tr_easy)
        easy_hint.setObjectName("Faint")
        easy_hint.setWordWrap(True)
        easy_hint.setTextFormat(Qt.RichText)
        el.addWidget(easy_hint)
        easy_row = QHBoxLayout()
        self.tr_easy_btn = QPushButton("Connect Trakt", self.tr_easy)
        self.tr_easy_btn.setObjectName("Primary")
        self.tr_easy_btn.setCursor(Qt.PointingHandCursor)
        self.tr_easy_btn.clicked.connect(self._trakt_easy_connect)
        easy_row.addWidget(self.tr_easy_btn)
        manual = QPushButton("Use different app keys", self.tr_easy)
        manual.setObjectName("Ghost")
        manual.setCursor(Qt.PointingHandCursor)
        manual.clicked.connect(self._trakt_manual)
        easy_row.addWidget(manual)
        easy_row.addStretch(1)
        el.addLayout(easy_row)
        lay.addWidget(self.tr_easy)

        self.tr_setup = QWidget(self)
        self.tr_setup.setObjectName("Clear")
        tl = QVBoxLayout(self.tr_setup)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(10)
        self.tr_id = QLineEdit(self.tr_setup)
        self.tr_id.setPlaceholderText("Client ID")
        tl.addWidget(self.tr_id)
        self.tr_secret = PasswordField(self.tr_setup)
        self.tr_secret.edit.setPlaceholderText("Client Secret")
        tl.addWidget(self.tr_secret)
        self.tr_connect_btn = QPushButton("Connect", self.tr_setup)
        self.tr_connect_btn.setObjectName("Primary")
        self.tr_connect_btn.setCursor(Qt.PointingHandCursor)
        self.tr_connect_btn.clicked.connect(self._trakt_connect)
        setup_row = QHBoxLayout()
        setup_row.addWidget(self.tr_connect_btn)
        load_file = QPushButton("Load Trakt file from another PC…", self.tr_setup)
        load_file.setObjectName("Ghost")
        load_file.setCursor(Qt.PointingHandCursor)
        load_file.clicked.connect(self._trakt_load_file)
        setup_row.addWidget(load_file)
        setup_row.addStretch(1)
        tl.addLayout(setup_row)
        lay.addWidget(self.tr_setup)

        self.tr_code_box = QWidget(self)
        self.tr_code_box.setObjectName("Clear")
        cl = QHBoxLayout(self.tr_code_box)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(14)
        self.tr_code = QLabel("", self.tr_code_box)
        self.tr_code.setStyleSheet(f"font-size: 30px; font-weight: 800; color: {C.paper};"
                                   "letter-spacing: 3px; background: transparent;")
        self.tr_code.setTextInteractionFlags(Qt.TextSelectableByMouse)
        cl.addWidget(self.tr_code)
        self.tr_code_hint = QLabel("", self.tr_code_box)
        self.tr_code_hint.setObjectName("Muted")
        self.tr_code_hint.setWordWrap(True)
        cl.addWidget(self.tr_code_hint, 1)
        cancel = QPushButton("Cancel", self.tr_code_box)
        cancel.setObjectName("Ghost")
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.clicked.connect(self.trakt_cancel_requested.emit)
        cl.addWidget(cancel)
        lay.addWidget(self.tr_code_box)

        self.tr_on = QWidget(self)
        self.tr_on.setObjectName("Clear")
        ol = QHBoxLayout(self.tr_on)
        ol.setContentsMargins(0, 0, 0, 0)
        ol.setSpacing(10)
        self.tr_info = QLabel("", self.tr_on)
        self.tr_info.setObjectName("Muted")
        self.tr_info.setWordWrap(True)
        ol.addWidget(self.tr_info, 1)
        self.tr_sync_btn = QPushButton("Sync now", self.tr_on)
        self.tr_sync_btn.setObjectName("Ghost")
        self.tr_sync_btn.setCursor(Qt.PointingHandCursor)
        self.tr_sync_btn.clicked.connect(self._trakt_sync)
        ol.addWidget(self.tr_sync_btn)
        share = QPushButton("Share with another PC…", self.tr_on)
        share.setObjectName("Ghost")
        share.setCursor(Qt.PointingHandCursor)
        share.setToolTip("Saves a small file so another PC can press Connect and sign in "
                         "with its own Trakt account — no developer steps.")
        share.clicked.connect(self._trakt_share_file)
        ol.addWidget(share)
        off = QPushButton("Disconnect", self.tr_on)
        off.setObjectName("Ghost")
        off.setCursor(Qt.PointingHandCursor)
        off.clicked.connect(self.trakt_disconnect_requested.emit)
        ol.addWidget(off)
        lay.addWidget(self.tr_on)
        self._check_row(lay, "Scrobble what I watch to Trakt", "trakt_scrobble")

        self.tr_status = QLabel("", self)
        self.tr_status.setObjectName("Faint")
        self.tr_status.setWordWrap(True)
        lay.addWidget(self.tr_status)
        self.set_trakt_state("off")

    def set_trakt_state(self, state, cfg=None, code=None, url=None):
        """state: "off" (not set up), "code" (waiting for approval), "on"."""
        easy = state == "off" and not self._tr_manual and fluxtv_trakt.app_keys() is not None
        self.tr_easy.setVisible(easy)
        self.tr_intro.setVisible(state == "off" and not easy)
        self.tr_easy_btn.setEnabled(True)
        self.tr_setup.setVisible(state == "off" and not easy)
        self.tr_code_box.setVisible(state == "code")
        self.tr_on.setVisible(state == "on")
        self.tr_connect_btn.setEnabled(True)
        if state == "code":
            self.tr_code.setText(code or "")
            self.tr_code_hint.setText(f"Go to {url or 'trakt.tv/activate'} on your phone or "
                                      "computer, enter this code and approve Flux Media. "
                                      "This page updates by itself.")
        if state == "on":
            when = fluxtv_trakt.last_synced()
            synced = _english_stamp(when) if when else "not yet"
            who = (cfg or {}).get("username") or "your account"
            self.tr_info.setText(f"Connected as {who}   \u00b7   watched history synced {synced}")

    def _trakt_connect(self):
        cid, secret = self.tr_id.text().strip(), self.tr_secret.edit.text().strip()
        if not cid or not secret:
            self.trakt_result(False, "Paste both the Client ID and the Client Secret.")
            return
        self.tr_connect_btn.setEnabled(False)
        self.tr_status.setStyleSheet("")
        self.tr_status.setText("Asking Trakt for a code\u2026")
        self.trakt_connect_requested.emit(cid, secret)

    def _trakt_easy_connect(self):
        keys = fluxtv_trakt.app_keys()
        if not keys:
            self._trakt_manual()
            return
        self.tr_easy_btn.setEnabled(False)
        self.tr_status.setStyleSheet("")
        self.tr_status.setText("Asking Trakt for a code…")
        self.trakt_connect_requested.emit(*keys)

    def _trakt_manual(self):
        self._tr_manual = True
        self.set_trakt_state("off")

    def _trakt_load_file(self):
        path = show_dialog(self, lambda: QFileDialog.getOpenFileName(
            self, "Choose the Flux Media Trakt file", os.path.expanduser("~"),
            "Flux Media Trakt file (*.json)")[0])
        if not path:
            return
        try:
            fluxtv_trakt.import_app_keys(path)
        except fluxtv_trakt.TraktError as error:
            self.trakt_result(False, str(error))
            return
        self._tr_manual = False
        self.set_trakt_state("off")
        self.trakt_result(True, "Trakt file loaded — now press Connect Trakt.")

    def _trakt_share_file(self):
        start = os.path.join(os.path.expanduser("~"), fluxtv_trakt.SHARE_NAME)
        path = show_dialog(self, lambda: QFileDialog.getSaveFileName(
            self, "Save the Flux Media Trakt file", start, "Flux Media Trakt file (*.json)")[0])
        if not path:
            return
        try:
            fluxtv_trakt.export_app_keys(path)
        except (fluxtv_trakt.TraktError, OSError) as error:
            self.trakt_result(False, str(error))
            return
        self.trakt_result(True, f"Saved {os.path.basename(path)}. Copy it to the other PC (USB stick "
                                "or Downloads) and choose “Load Trakt file” there. Keep it "
                                "private — don't post it online.")

    def _trakt_sync(self):
        self.tr_sync_btn.setEnabled(False)
        self.tr_status.setStyleSheet("")
        self.tr_status.setText("Syncing your Trakt history\u2026")
        self.trakt_sync_requested.emit()

    def trakt_result(self, ok, message):
        self.tr_connect_btn.setEnabled(True)
        self.tr_easy_btn.setEnabled(True)
        self.tr_sync_btn.setEnabled(True)
        self.tr_status.setText(message)
        self.tr_status.setStyleSheet(f"color: {C.ok if ok else C.onair};")

    def _paste_addons(self):
        text = QApplication.clipboard().text()
        if not text.strip():
            self.addon_result(False, "The clipboard is empty — copy your add-on backup first.")
            return
        self.addon_btn.setEnabled(False)
        self.addon_status.setText("Installing…")
        self.install_addon_requested.emit(text)

    def _import_addons_file(self):
        path, _ = show_dialog(self, lambda: QFileDialog.getOpenFileName(
            self, "Import add-on backup", os.path.expanduser("~"),
            "Backups (*.json *.txt);;All files (*)"))
        if not path:
            return
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError as error:
            self.addon_result(False, f"Couldn't read that file ({error}).")
            return
        self.addon_btn.setEnabled(False)
        self.addon_status.setText("Installing…")
        self.install_addon_requested.emit(text)

    def addon_result(self, ok, message):
        self.addon_btn.setEnabled(True)
        self.addon_status.setText(message)
        self.addon_status.setStyleSheet(f"color: {C.ok if ok else C.onair};")
        if ok:
            self.addon_field.clear()

    def _build_guide(self):
        lay = self._section("Programme guide")
        row = self._row(lay, "Custom XMLTV URL")
        self.epg_field = QLineEdit(self)
        self.epg_field.setText(self.lib.settings.get("epg_url", ""))
        row.addWidget(self.epg_field, 1)
        save_btn = QPushButton("Save and reload", self)
        save_btn.setObjectName("Ghost")
        save_btn.setCursor(Qt.PointingHandCursor)
        save_btn.clicked.connect(self._save_epg)
        row.addWidget(save_btn)
        hint = QLabel("Leave blank to use the provider's own guide.", self)
        hint.setObjectName("Faint")
        lay.addWidget(hint)

    def _save_epg(self):
        url = self.epg_field.text().strip()
        self.lib.settings["epg_url"] = url
        core.save_settings(self.lib.settings)
        self.epg_reload_requested.emit(url)

    def _build_favourites(self):
        lay = self._section("Favourites")
        total = sum(1 for v in self.lib.favs.values() if v.get("fav"))
        self.fav_count_label = QLabel(f"{total} channels starred", self)
        lay.addWidget(self.fav_count_label)

        row = QHBoxLayout()
        imp = QPushButton("Import from FredTV", self)
        imp.setObjectName("Primary")
        imp.setCursor(Qt.PointingHandCursor)
        imp.clicked.connect(self._import_otvf)
        row.addWidget(imp)
        backup = QPushButton("Back up", self)
        backup.setObjectName("Ghost")
        backup.setCursor(Qt.PointingHandCursor)
        backup.clicked.connect(self._backup)
        row.addWidget(backup)
        restore = QPushButton("Restore", self)
        restore.setObjectName("Ghost")
        restore.setCursor(Qt.PointingHandCursor)
        restore.clicked.connect(self._restore)
        row.addWidget(restore)
        row.addStretch(1)
        clear_favs = QPushButton("Clear all favourites", self)
        clear_favs.setObjectName("Danger")
        clear_favs.setCursor(Qt.PointingHandCursor)
        clear_favs.clicked.connect(self._clear_favourites)
        row.addWidget(clear_favs)
        lay.addLayout(row)

        hint = QLabel("A backup keeps your stars and watch history so you "
                     "can restore them on another machine.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)

        rule = QFrame(self)
        rule.setObjectName("Hairline")
        lay.addWidget(rule)
        clear_btn = QPushButton("Clear logo cache", self)
        clear_btn.setObjectName("Ghost")
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.clicked.connect(self._clear_logo_cache)
        lay.addWidget(clear_btn, 0, Qt.AlignLeft)

        self.status_label = QLabel("", self)
        self.status_label.setObjectName("Faint")
        lay.addWidget(self.status_label)

    def _import_otvf(self):
        path, _ = show_dialog(self, lambda: QFileDialog.getOpenFileName(
            self, "Select your FredTV .otvf file", "",
            "Favourites files (*.otvf *.json);;OTVF files (*.otvf);;"
            "JSON files (*.json);;All files (*)"))
        if not path:
            return
        try:
            count = core.import_otvf(path)
        except Exception as error:
            show_dialog(self, lambda error=error: QMessageBox.critical(
                self, "Import error", f"Could not import this file.\n{error}"))
            return
        self.lib.favs = core.load_favs()
        self.lib._invalidate_caches()
        total = sum(1 for v in self.lib.favs.values() if v.get("fav"))
        self.fav_count_label.setText(f"{total} channels starred")
        if count == 0:
            # A quiet status-bar line reading "Imported 0 favourites"
            # is easy to read as "nothing happened at all" — the file
            # dialog closing with no visible change looks the same either
            # way. Making this impossible to miss also makes it possible
            # to actually tell apart from a dialog-level problem: if this
            # box shows up, the file was read successfully and the import
            # genuinely ran — it just didn't recognise anything in it as
            # a favourited channel, which usually means the file's own
            # field names don't match what's expected here.
            show_dialog(self, lambda: QMessageBox.warning(
                self, "Nothing imported",
                "The file opened correctly, but nothing in it was "
                "recognised as a favourited channel.\n\n"
                "This reads a list of entries each needing a \"name\" and "
                "a \"favorite: true\" field — if FredTV's export uses "
                "different field names, that's why none matched."))
        self.status_label.setText(f"Imported {count} favourites.")

    def _clear_favourites(self):
        total_now = sum(1 for v in self.lib.favs.values() if v.get("fav"))
        if not total_now:
            self.status_label.setText("No favourites to clear.")
            return
        reply = show_dialog(self, lambda: QMessageBox.question(
            self, "Clear all favourites",
            f"Un-star all {total_now} favourited channels? This won't "
            "touch your watch history — just a clean slate before "
            "importing a new list, if that's what this is for."))
        if reply != QMessageBox.Yes:
            return
        cleared = core.clear_all_favourites()
        self.lib.favs = core.load_favs()
        self.lib._invalidate_caches()
        self.fav_count_label.setText("0 channels starred")
        self.status_label.setText(f"Cleared {cleared} favourites.")

    def _backup(self):
        path, _ = show_dialog(self, lambda: QFileDialog.getSaveFileName(
            self, "Back up Flux Media favourites", "FluxMedia_favourites_backup.json",
            "JSON files (*.json);;All files (*)"))
        if not path:
            return
        try:
            core.export_favourites_backup(path)
            self.status_label.setText("Favourites backed up.")
        except Exception as error:
            show_dialog(self, lambda error=error: QMessageBox.critical(
                self, "Backup error", f"Could not create the backup.\n{error}"))

    def _restore(self):
        path, _ = show_dialog(self, lambda: QFileDialog.getOpenFileName(
            self, "Restore Flux Media favourites", "",
            "Favourites files (*.json *.otvf);;JSON files (*.json);;"
            "OTVF files (*.otvf);;All files (*)"))
        if not path:
            return
        try:
            core.import_favourites_backup(path)
        except Exception as error:
            show_dialog(self, lambda error=error: QMessageBox.critical(
                self, "Restore error", f"Could not restore this backup.\n{error}"))
            return
        self.lib.favs = core.load_favs()
        self.lib._invalidate_caches()
        total = sum(1 for v in self.lib.favs.values() if v.get("fav"))
        self.fav_count_label.setText(f"{total} channels starred")
        self.status_label.setText(f"Restored {total} favourites.")

    def _clear_logo_cache(self):
        import shutil as _shutil
        try:
            _shutil.rmtree(core.LOGO_CACHE, ignore_errors=True)
            os.makedirs(core.LOGO_CACHE, exist_ok=True)
            LOGOS.clear()
            self.status_label.setText("Logo cache cleared.")
        except Exception as error:
            show_dialog(self, lambda error=error: QMessageBox.critical(
                self, "Error", f"Could not clear the logo cache.\n{error}"))

    def _build_youtube(self):
        lay = self._section("YouTube (Music)")
        hint = QLabel("If songs keep failing with \u201cconfirm you're not a bot\u201d, sign in to "
                      "YouTube in one of your web browsers on this computer and choose it here "
                      "\u2014 Flux Media will use that login. Flux Media already retries other "
                      "ways first, so most people never need this.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        row = self._row(lay, "Use login from")
        from PySide6.QtWidgets import QComboBox
        self.yt_browser = QComboBox(self)
        for label, key in (("Off", ""), ("Firefox", "firefox"), ("Chrome", "chrome"),
                           ("Chromium", "chromium"), ("Edge", "edge"), ("Brave", "brave")):
            self.yt_browser.addItem(label, key)
        current = self.lib.settings.get("yt_cookie_browser", "")
        self.yt_browser.setCurrentIndex(max(0, self.yt_browser.findData(current)))

        def changed(_i):
            key = self.yt_browser.currentData() or ""
            self.lib.settings["yt_cookie_browser"] = key
            core.save_settings(self.lib.settings)
            fluxtv_youtube.set_cookie_browser(key)
        self.yt_browser.currentIndexChanged.connect(changed)
        row.addWidget(self.yt_browser)
        row.addStretch(1)

    def _build_details(self):
        lay = self._section("Film & series details")
        hint = QLabel("IMDb ratings, awards, cast and trailers come free. Two optional free "
                      "keys add more: a TMDB key adds cast photos (themoviedb.org → "
                      "Settings → API), an OMDb key adds Rotten Tomatoes and Metacritic "
                      "scores (omdbapi.com/apikey.aspx).", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        for label, key in (("TMDB key", "tmdb_key"), ("OMDb key", "omdb_key")):
            row = self._row(lay, label)
            field = QLineEdit(str(self.lib.settings.get(key, "")), self)
            field.setEchoMode(QLineEdit.PasswordEchoOnEdit)   # not shown on the TV
            field.setPlaceholderText("optional")

            def save(field=field, key=key):
                text = field.text().strip()
                if text != self.lib.settings.get(key, ""):
                    self.lib.settings[key] = text
                    core.save_settings(self.lib.settings)
            field.editingFinished.connect(save)
            row.addWidget(field, 1)

    def _build_health(self):
        lay = self._section("Check services")
        row = QHBoxLayout()
        hint = QLabel("Something not working? This checks your provider, the guide, each "
                      "add-on, Stremio, Trakt, YouTube and radio, and says which one it is.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        row.addWidget(hint, 1)
        self.check_btn = QPushButton("Check now", self)
        self.check_btn.setObjectName("Primary")
        self.check_btn.setCursor(Qt.PointingHandCursor)
        self.check_btn.clicked.connect(self._check_clicked)
        row.addWidget(self.check_btn, 0, Qt.AlignTop)
        lay.addLayout(row)
        self.health_box = QVBoxLayout()
        self.health_box.setSpacing(4)
        lay.addLayout(self.health_box)

    def _check_clicked(self):
        self.check_btn.setEnabled(False)
        self.check_btn.setText("Checking…")
        self.check_services_requested.emit()

    def show_health(self, results):
        while self.health_box.count():
            item = self.health_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for name, ok, detail in results:
            mark = "✓" if ok else "✗"
            line = QLabel(f"<span style='color:{C.ok if ok else C.onair}; font-weight:800'>"
                          f"{mark}</span>&nbsp;&nbsp;<b>{html_escape(name)}</b>"
                          f"&nbsp;&nbsp;<span style='color:{C.dim}'>{html_escape(detail)}</span>", self)
            line.setTextFormat(Qt.RichText)
            line.setWordWrap(True)
            self.health_box.addWidget(line)
        self.check_btn.setEnabled(True)
        self.check_btn.setText("Check again")

    def _build_parental(self):
        lay = self._section("Parental lock")
        self.parental_state = QLabel("", self)
        lay.addWidget(self.parental_state)
        hint = QLabel("With a PIN set, adult categories (and channels, films and series in "
                      "them) are hidden everywhere \u2014 Home, Live TV, the Guide, search. "
                      "Enter the PIN to show them until Flux Media is closed.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        row = QHBoxLayout()
        self.pin_buttons = {}
        for key, text, name in (("set", "Set a PIN", "Primary"), ("unlock", "Unlock", "Primary"),
                                ("lock", "Lock again", "Primary"), ("change", "Change PIN", "Ghost"),
                                ("remove", "Remove PIN", "Ghost")):
            btn = QPushButton(text, self)
            btn.setObjectName(name)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self._parental_action(k))
            row.addWidget(btn)
            self.pin_buttons[key] = btn
        row.addStretch(1)
        lay.addLayout(row)
        words_row = self._row(lay, "Also hide")
        self.lock_words_field = QLineEdit(str(self.lib.settings.get("parental_words", "")), self)
        self.lock_words_field.setPlaceholderText("other words, comma-separated (e.g. horror, late night)")
        self.lock_words_field.editingFinished.connect(self._save_lock_words)
        words_row.addWidget(self.lock_words_field, 1)
        self._sync_parental()

    def _sync_parental(self):
        has_pin = bool(self.lib.settings.get("parental_pin"))
        locked = self.lib.parental_locked()
        self.parental_state.setText(
            "Off \u2014 no PIN set." if not has_pin else
            "On \u2014 adult categories are hidden." if locked else
            "Unlocked until Flux Media is closed.")
        self.pin_buttons["set"].setVisible(not has_pin)
        self.pin_buttons["unlock"].setVisible(has_pin and locked)
        self.pin_buttons["lock"].setVisible(has_pin and not locked)
        self.pin_buttons["change"].setVisible(has_pin)
        self.pin_buttons["remove"].setVisible(has_pin)

    def _ask_pin(self, title, label):
        dialog = QInputDialog(self)
        dialog.setWindowTitle(title)
        dialog.setLabelText(label)
        dialog.setTextEchoMode(QLineEdit.Password)
        return dialog.textValue().strip() if dialog.exec() else None

    def _parental_action(self, action):
        settings = self.lib.settings
        if action in ("unlock", "change", "remove"):
            pin = self._ask_pin("Parental lock", "Enter your PIN:")
            if pin is None:
                return
            if not core.check_parental_pin(settings, pin):
                QMessageBox.warning(self, "Parental lock", "That PIN isn't right.")
                return
        if action in ("set", "change"):
            new = self._ask_pin("Parental lock", "Choose a PIN (at least 4 digits):")
            if new is None:
                return
            if len(new) < 4 or not new.isdigit():
                QMessageBox.warning(self, "Parental lock", "Use at least 4 digits, numbers only.")
                return
            again = self._ask_pin("Parental lock", "Type the same PIN again:")
            if again != new:
                QMessageBox.warning(self, "Parental lock", "The two PINs didn't match.")
                return
            core.set_parental_pin(settings, new)
            self.lib.set_unlocked(False)
        elif action == "remove":
            core.set_parental_pin(settings, None)
            self.lib.set_unlocked(False)
        elif action == "unlock":
            self.lib.set_unlocked(True)
        elif action == "lock":
            self.lib.set_unlocked(False)
        self._sync_parental()
        self.parental_changed.emit()

    def _save_lock_words(self):
        text = self.lock_words_field.text().strip()
        if text != str(self.lib.settings.get("parental_words", "")):
            self.lib.settings["parental_words"] = text
            core.save_settings(self.lib.settings)
            self.lib.lock_changed()
            self.parental_changed.emit()

    def _build_backup(self):
        lay = self._section("Backup & restore")
        hint = QLabel("One file with everything that's yours: provider login, add-ons, favourites, "
                      "playlists, radio stations, watch history and the Stremio / Trakt sign-ins. "
                      "Use it to move to a new PC or to undo a mistake. It contains your passwords "
                      "and keys \u2014 keep it private. (Flux Media also keeps a weekly copy by itself.)",
                      self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        row = QHBoxLayout()
        make = QPushButton("Make a backup\u2026", self)
        make.setObjectName("Primary")
        make.setCursor(Qt.PointingHandCursor)
        make.clicked.connect(self._make_backup)
        row.addWidget(make)
        restore = QPushButton("Restore from a backup\u2026", self)
        restore.setObjectName("Ghost")
        restore.setCursor(Qt.PointingHandCursor)
        restore.clicked.connect(self._pick_restore)
        row.addWidget(restore)
        row.addStretch(1)
        lay.addLayout(row)
        self.backup_result = QLabel("", self)
        self.backup_result.setWordWrap(True)
        self.backup_result.hide()
        lay.addWidget(self.backup_result)

    def backup_message(self, ok, text):
        self.backup_result.setText(text)
        self.backup_result.setStyleSheet(f"color: {C.ok if ok else C.onair};")
        self.backup_result.show()

    def _make_backup(self):
        start = os.path.join(os.path.expanduser("~"), "Documents")
        if not os.path.isdir(start):
            start = os.path.expanduser("~")
        folder = QFileDialog.getExistingDirectory(self, "Where should the backup go?", start)
        if not folder:
            return
        try:
            path = fluxtv_backup.make_backup(folder)
        except (fluxtv_backup.BackupError, OSError) as error:
            self.backup_message(False, f"Backup not made: {error}")
            return
        self.backup_message(True, f"Backup saved: {path}")

    def _pick_restore(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose a Flux Media backup", os.path.expanduser("~"),
            "Flux Media backup (*.fmbackup);;All files (*)")
        if not path:
            return
        try:
            made, what = fluxtv_backup.summary(path)
        except fluxtv_backup.BackupError as error:
            self.backup_message(False, str(error))
            return
        answer = QMessageBox.question(
            self, "Restore backup",
            f"Restore the backup from {made}?\n\nIt brings back: {what}.\n\n"
            "What's here now is saved first, and Flux Media restarts afterwards.")
        if answer == QMessageBox.Yes:
            self.restore_requested.emit(path)

    def _build_updates(self):
        lay = self._section("Updates")
        self.version_label = QLabel(f"Flux Media  {fluxtv_update.VERSION}", self)
        lay.addWidget(self.version_label)
        hint = QLabel("Got an update file (FluxMedia-Update-….zip)? Put it in your "
                      "Downloads folder and it shows up here, or choose it with "
                      "“Install update file…”. Your settings, logins and "
                      "history are kept, and “Undo last update” puts the previous "
                      "version back.", self)
        hint.setObjectName("Faint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        row = QHBoxLayout()
        self.found_update_btn = QPushButton("", self)
        self.found_update_btn.setObjectName("Primary")
        self.found_update_btn.setCursor(Qt.PointingHandCursor)
        self.found_update_btn.clicked.connect(
            lambda: self._found_update and self.install_update_requested.emit(self._found_update))
        self.found_update_btn.hide()
        row.addWidget(self.found_update_btn)
        pick = QPushButton("Install update file…", self)
        pick.setObjectName("Ghost")
        pick.setCursor(Qt.PointingHandCursor)
        pick.clicked.connect(self._pick_update)
        row.addWidget(pick)
        self.undo_update_btn = QPushButton("Undo last update", self)
        self.undo_update_btn.setObjectName("Ghost")
        self.undo_update_btn.setCursor(Qt.PointingHandCursor)
        self.undo_update_btn.clicked.connect(self.undo_update_requested.emit)
        row.addWidget(self.undo_update_btn)
        row.addStretch(1)
        lay.addLayout(row)
        online = QHBoxLayout()
        self.check_btn_updates = QPushButton("Check for updates", self)
        self.check_btn_updates.setObjectName("Ghost")
        self.check_btn_updates.setCursor(Qt.PointingHandCursor)
        self.check_btn_updates.clicked.connect(self.check_updates_requested.emit)
        online.addWidget(self.check_btn_updates)
        self.online_btn = QPushButton("", self)
        self.online_btn.setObjectName("Primary")
        self.online_btn.setCursor(Qt.PointingHandCursor)
        self.online_btn.clicked.connect(lambda: self._online and self.online_update_requested.emit(self._online))
        self.online_btn.hide()
        online.addWidget(self.online_btn)
        online.addStretch(1)
        lay.addLayout(online)
        self._online = None
        feed_row = self._row(lay, "Update source")
        self.feed_field = QLineEdit(str(self.lib.settings.get("update_feed", fluxtv_update.DEFAULT_FEED)), self)
        self.feed_field.setPlaceholderText("where updates are published, e.g. github:name/flux-media")
        self.feed_field.editingFinished.connect(self._save_feed)
        feed_row.addWidget(self.feed_field, 1)
        self.update_result = QLabel("", self)
        self.update_result.setWordWrap(True)
        self.update_result.hide()
        lay.addWidget(self.update_result)
        self._found_update = None
        self.refresh_updates()

    def refresh_updates(self):
        """Look in Downloads / Desktop for a newer update file."""
        best = None
        for folder in (os.path.join(os.path.expanduser("~"), "Downloads"),
                       os.path.join(os.path.expanduser("~"), "Desktop")):
            try:
                names = os.listdir(folder)
            except OSError:
                continue
            for name in names:
                if name.startswith("FluxMedia-Update-") and name.endswith(".zip"):
                    version = name[len("FluxMedia-Update-"):-4]
                    if fluxtv_update.is_newer(version) and (
                            best is None or fluxtv_update._version_key(version) >
                            fluxtv_update._version_key(best[0])):
                        best = (version, os.path.join(folder, name))
        self._found_update = best[1] if best else None
        if best:
            self.found_update_btn.setText(f"Install update {best[0]}")
        self.found_update_btn.setVisible(bool(best))
        self.undo_update_btn.setEnabled(bool(fluxtv_update.backups()))

    def _save_feed(self):
        text = self.feed_field.text().strip()
        if text != self.lib.settings.get("update_feed", fluxtv_update.DEFAULT_FEED):
            self.lib.settings["update_feed"] = text
            core.save_settings(self.lib.settings)

    def show_online_update(self, info):
        """info: a newer published update, or None (up to date)."""
        self._online = info
        if info:
            self.online_btn.setText(f"Download and install {info['version']}")
            note = f"Update {info['version']} is available."
            if info.get("notes"):
                note += "\n" + info["notes"]
            self.update_message(True, note)
        self.online_btn.setVisible(bool(info))

    def _pick_update(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose a Flux Media update", os.path.expanduser("~"),
            "Flux Media update (FluxMedia-Update-*.zip);;Zip files (*.zip)")
        if path:
            self.install_update_requested.emit(path)

    def update_message(self, ok, text):
        self.update_result.setText(text)
        self.update_result.setStyleSheet(f"color: {C.ok if ok else C.onair};")
        self.update_result.show()
        self.refresh_updates()

    def _build_account(self):
        lay = self._section("Account")
        row = self._row(lay, "Server URL")
        self.server_field = QLineEdit(self.api.server)
        row.addWidget(self.server_field, 1)

        row2 = self._row(lay, "Username")
        self.user_field = QLineEdit(self.api.username)
        row2.addWidget(self.user_field, 1)

        row3 = self._row(lay, "Password")
        self.pwd_field = PasswordField(self)
        self.pwd_field.setText(self.api.password)
        row3.addWidget(self.pwd_field, 1)

        btn_row = QHBoxLayout()
        save = QPushButton("Save changes", self)
        save.setObjectName("Primary")
        save.setCursor(Qt.PointingHandCursor)
        save.clicked.connect(self._apply_credentials)
        btn_row.addWidget(save)
        refresh = QPushButton("Refresh provider", self)
        refresh.setObjectName("Ghost")
        refresh.setCursor(Qt.PointingHandCursor)
        refresh.clicked.connect(self.refresh_requested.emit)
        btn_row.addWidget(refresh)
        change = QPushButton("Change login", self)
        change.setObjectName("Ghost")
        change.setCursor(Qt.PointingHandCursor)
        change.clicked.connect(self.change_login_requested.emit)
        btn_row.addWidget(change)
        btn_row.addStretch(1)
        quit_btn = QPushButton("Quit Flux Media", self)
        quit_btn.setObjectName("Ghost")
        quit_btn.setCursor(Qt.PointingHandCursor)
        quit_btn.clicked.connect(self.quit_requested.emit)
        btn_row.addWidget(quit_btn)
        lay.addLayout(btn_row)

        rule = QFrame(self)
        rule.setObjectName("Hairline")
        lay.addWidget(rule)
        signout = QPushButton("Sign out and forget these details", self)
        signout.setObjectName("Danger")
        signout.setCursor(Qt.PointingHandCursor)
        signout.clicked.connect(self.logout_requested.emit)
        lay.addWidget(signout, 0, Qt.AlignLeft)

    def _apply_credentials(self):
        server = self.server_field.text().strip()
        user = self.user_field.text().strip()
        pwd = self.pwd_field.text().strip()
        if not server or not user or not pwd:
            show_dialog(self, lambda: QMessageBox.warning(
                self, "Missing fields", "Please fill in all fields."))
            return
        self.credentials_changed.emit(server, user, pwd)


# ══════════════════════════════════════════════════════════════════
# Login
# ══════════════════════════════════════════════════════════════════
class LoginView(QWidget):
    """One window: this view is replaced in place by the app on success."""

    signed_in = Signal(object)

    def __init__(self, prefill=None, parent=None):
        super().__init__(parent)
        self.prefill = prefill or {}

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 18, 0)

        # FluxTV starts fullscreen, so the login screen needs its own way
        # out — the same fullscreen/close pair as the main top bar.
        chrome = QHBoxLayout()
        chrome.setContentsMargins(0, 26, 0, 0)
        chrome.addStretch(1)
        fs_btn = ChromeIconButton("expand", self, tip="Toggle fullscreen (F11)")
        fs_btn.clicked.connect(self._toggle_fullscreen)
        chrome.addWidget(fs_btn)
        close_btn = ChromeIconButton("close", self, danger=True, tip="Close Flux Media")
        close_btn.clicked.connect(lambda: self.window().close())
        chrome.addWidget(close_btn)
        outer.addLayout(chrome)
        outer.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        column = QVBoxLayout()
        column.setSpacing(18)

        brand = QHBoxLayout()
        brand.setSpacing(14)
        brand.addStretch(1)
        logo_pix = logo_pixmap(132)
        if not logo_pix.isNull():
            logo_lbl = QLabel(self)
            logo_lbl.setPixmap(logo_pix)
            logo_lbl.setFixedSize(132, 132)
            logo_lbl.setToolTip("Flux Media")
            brand.addWidget(logo_lbl)
        else:
            mark = QLabel("Flux Media", self)
            mark.setObjectName("Wordmark")
            mark.setFont(font(28, QFont.Bold))
            brand.addWidget(mark, 0, Qt.AlignVCenter)
        brand.addStretch(1)
        column.addLayout(brand)

        panel = QFrame(self)
        panel.setObjectName("Panel")
        panel.setFixedWidth(420)
        form = QVBoxLayout(panel)
        form.setContentsMargins(36, 32, 36, 32)
        form.setSpacing(6)

        head = QLabel("Welcome", panel)
        head.setObjectName("LoginTitle")
        form.addWidget(head)
        sub = QLabel("Sign in with your provider details.", panel)
        sub.setObjectName("Muted")
        form.addWidget(sub)
        form.addSpacing(18)

        def field(label):
            tag = QLabel(label, panel)
            tag.setObjectName("Muted")
            form.addWidget(tag)
            edit = QLineEdit(panel)
            form.addWidget(edit)
            form.addSpacing(10)
            return edit

        self.server = field("Server")
        self.server.setPlaceholderText("http://provider.com:8080")
        self.server.setText(self.prefill.get("server", ""))
        self.user = field("Username")
        self.user.setText(self.prefill.get("username", ""))

        tag = QLabel("Password", panel)
        tag.setObjectName("Muted")
        form.addWidget(tag)
        self.pwd_field = PasswordField(panel)
        self.pwd_field.setText(self.prefill.get("password", ""))
        self.password = self.pwd_field.edit
        form.addWidget(self.pwd_field)
        form.addSpacing(18)

        self.status = QLabel("", panel)
        self.status.setObjectName("Faint")
        self.status.setWordWrap(True)
        form.addWidget(self.status)
        form.addSpacing(6)

        self.button = QPushButton("Sign in", panel)
        self.button.setObjectName("Primary")
        self.button.setCursor(Qt.PointingHandCursor)
        self.button.clicked.connect(self.attempt)
        form.addWidget(self.button)
        form.addSpacing(8)
        restore = QPushButton("Moving from another PC? Restore a backup\u2026", panel)
        restore.setObjectName("Ghost")
        restore.setCursor(Qt.PointingHandCursor)
        restore.clicked.connect(self._restore_backup)
        form.addWidget(restore)

        column.addWidget(panel)
        row.addLayout(column)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)

        self.password.returnPressed.connect(self.attempt)
        self.server.returnPressed.connect(self.attempt)
        self.user.returnPressed.connect(self.attempt)
        self.server.setFocus()

    def _toggle_fullscreen(self):
        win = self.window()
        win.showNormal() if win.isFullScreen() else win.showFullScreen()

    def _restore_backup(self):
        """New PC: bring everything (login included) across from a backup."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose a Flux Media backup", os.path.expanduser("~"),
            "Flux Media backup (*.fmbackup);;All files (*)")
        if not path:
            return
        try:
            made, what = fluxtv_backup.summary(path)
            if QMessageBox.question(self, "Restore backup",
                                    f"Restore the backup from {made}?\n\nIt brings back: {what}.") \
                    != QMessageBox.Yes:
                return
            fluxtv_backup.restore_backup(path)
        except (fluxtv_backup.BackupError, OSError) as error:
            self.status.setText(str(error))
            self.status.setStyleSheet(f"color: {C.onair};")
            return
        self.status.setText("Restored \u2014 starting Flux Media\u2026")
        win = self.window()
        if hasattr(win, "restart_app"):
            QTimer.singleShot(800, win.restart_app)

    def attempt(self):
        server = self.server.text().strip()
        user = self.user.text().strip()
        pwd = self.password.text().strip()
        if not server or not user or not pwd:
            self.status.setText("Enter a server, username and password.")
            self.status.setStyleSheet(f"color: {C.onair};")
            return
        self.button.setText("Signing in\u2026")
        self.button.setEnabled(False)
        self.status.setStyleSheet(f"color: {C.dim};")
        self.status.setText("Checking the connection\u2026")

        api = core.XtreamAPI(server, user, pwd)
        background(api.test_connection,
                   lambda result: self._finish(result, api, server, user, pwd))

    def _finish(self, result, api, server, user, pwd):
        ok, detail = result
        if not ok:
            self.button.setText("Sign in")
            self.button.setEnabled(True)
            self.status.setStyleSheet(f"color: {C.onair};")
            self.status.setText(f"Could not connect. {str(detail)[:180]}")
            return
        try:
            core.save_credentials(server, user, pwd)
        except Exception:
            pass
        self.signed_in.emit(api)


class SetupWizard(QDialog):
    """First run on a new install: a few friendly, skippable steps.
    Stremio (brings the add-ons and library across), a parental PIN, and
    some tips. Shown once; Settings has all of it afterwards too."""

    stremio_requested = Signal(str, str)
    pin_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Welcome to Flux Media")
        self.setModal(True)
        self.setMinimumSize(760, 520)
        self.setObjectName("Panel")
        self.setStyleSheet(f"QDialog#Panel {{ background: {C.panel}; border: 1px solid {C.hairline_hi};"
                           " border-radius: 18px; }")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(40, 34, 40, 30)
        outer.setSpacing(14)
        top = QHBoxLayout()
        pix = logo_pixmap(84)
        if not pix.isNull():
            logo = QLabel(self)
            logo.setPixmap(pix)
            top.addWidget(logo)
        top.addSpacing(10)
        self.step_label = QLabel("", self)
        self.step_label.setObjectName("Muted")
        top.addWidget(self.step_label, 0, Qt.AlignBottom)
        top.addStretch(1)
        outer.addLayout(top)
        self.pages = QStackedWidget(self)
        self.pages.setObjectName("Clear")
        self.pages.setStyleSheet("background: transparent;")
        outer.addWidget(self.pages, 1)
        nav = QHBoxLayout()
        self.skip_btn = QPushButton("Skip", self)
        self.skip_btn.setObjectName("Ghost")
        self.skip_btn.setCursor(Qt.PointingHandCursor)
        self.skip_btn.clicked.connect(self._next)
        nav.addWidget(self.skip_btn)
        nav.addStretch(1)
        self.next_btn = QPushButton("Next  \u203a", self)
        self.next_btn.setObjectName("Primary")
        self.next_btn.setCursor(Qt.PointingHandCursor)
        self.next_btn.clicked.connect(self._next)
        nav.addWidget(self.next_btn)
        outer.addLayout(nav)

        self._page("Welcome to Flux Media",
                   "Your TV, films, series, music and radio \u2014 all in one place.\n\n"
                   "A couple of quick, optional steps and you're watching. Everything here can "
                   "be changed later in Settings.")

        st = self._page("Films & series from Stremio  (optional)",
                        "Use Stremio? Sign in once and your add-ons (like Debridio or Torrentio) "
                        "and your library come straight across \u2014 nothing to copy.\n"
                        "Your password is only sent to Stremio, never saved.")
        self.st_email = QLineEdit(self)
        self.st_email.setPlaceholderText("Stremio email")
        self.st_pwd = QLineEdit(self)
        self.st_pwd.setPlaceholderText("Stremio password")
        self.st_pwd.setEchoMode(QLineEdit.Password)
        st.addWidget(self.st_email)
        st.addWidget(self.st_pwd)
        go = QPushButton("Sign in and bring my add-ons", self)
        go.setObjectName("Primary")
        go.setCursor(Qt.PointingHandCursor)
        go.clicked.connect(self._stremio)
        self.st_go = go
        st.addWidget(go, 0, Qt.AlignLeft)
        self.st_result = QLabel("", self)
        self.st_result.setWordWrap(True)
        st.addWidget(self.st_result)

        pin = self._page("Parental PIN  (optional)",
                         "Got kids using this TV? Set a PIN and adult channels and categories stay "
                         "hidden until it's entered.")
        pin_btn = QPushButton("Set a PIN", self)
        pin_btn.setObjectName("Primary")
        pin_btn.setCursor(Qt.PointingHandCursor)
        pin_btn.clicked.connect(self.pin_requested.emit)
        pin.addWidget(pin_btn, 0, Qt.AlignLeft)
        self.pin_result = QLabel("", self)
        pin.addWidget(self.pin_result)

        self._page("You're all set",
                   "\u2022  The bar on the left takes you everywhere: Home, Live TV, Guide, Films, "
                   "Series, Debrid, Music and Favourites.\n"
                   "\u2022  Search at the top works on every page.\n"
                   "\u2022  Music has YouTube songs and Kiwi radio \u2014 George FM, The Rock and more.\n"
                   "\u2022  Something not working? Settings \u2192 Check services.\n"
                   "\u2022  Settings \u2192 Backup & restore keeps everything safe.")
        self._show(0)

    def _page(self, title, text):
        page = QWidget(self)
        page.setObjectName("Clear")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 10, 0, 0)
        lay.setSpacing(12)
        head = QLabel(title, page)
        head.setObjectName("ScreenTitle")
        head.setWordWrap(True)
        lay.addWidget(head)
        body = QLabel(text, page)
        body.setObjectName("Muted")
        body.setWordWrap(True)
        lay.addWidget(body)
        holder = QVBoxLayout()
        holder.setSpacing(10)
        lay.addLayout(holder)
        lay.addStretch(1)
        self.pages.addWidget(page)
        return holder

    def _show(self, index):
        self.pages.setCurrentIndex(index)
        last = index == self.pages.count() - 1
        self.step_label.setText(f"Step {index + 1} of {self.pages.count()}")
        self.next_btn.setText("Start watching" if last else "Next  \u203a")
        self.skip_btn.setVisible(0 < index < self.pages.count() - 1)

    def _next(self):
        index = self.pages.currentIndex()
        if index >= self.pages.count() - 1:
            self.accept()
        else:
            self._show(index + 1)

    def _stremio(self):
        email, pwd = self.st_email.text().strip(), self.st_pwd.text()
        if not email or not pwd:
            self.stremio_result(False, "Enter your Stremio email and password.")
            return
        self.st_go.setEnabled(False)
        self.stremio_result(True, "Signing in and bringing your add-ons across\u2026")
        self.stremio_requested.emit(email, pwd)

    def stremio_result(self, ok, text):
        self.st_result.setText(text)
        self.st_result.setStyleSheet(f"color: {C.ok if ok else C.onair};")
        self.st_go.setEnabled(True)
        if ok and not text.endswith("\u2026"):
            self.st_pwd.clear()

    def pin_result_text(self, text):
        self.pin_result.setText(text)
