#!/usr/bin/env python3
"""
FluxTV — engine.

Everything in this module was moved out of iptv.py verbatim. The Xtream
connection, credential storage, favourites, EPG parsing and the library
cache are the implementations that are already proven to work against a
live provider; they are not re-implemented here, only relocated so that a
new presentation layer can sit on top of them.

Nothing in this file imports a GUI toolkit. That is the point: the UI is
replaceable, this is not.
"""

import gzip
import hashlib
import json
import os
import pickle
import platform
import re
import shutil
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from io import BytesIO

import requests

try:
    import keyring
    HAS_KEYRING = True
except ImportError:
    HAS_KEYRING = False



# ── Paths ──────────────────────────────────────────────────────
if platform.system() == "Windows":
    APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "JPsIPTVPlayer")
else:
    APP_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "jps-iptv-player")
CONFIG_FILE = os.path.join(APP_DIR, "config.json")
FAVS_FILE = os.path.join(APP_DIR, "favourites.json")
LOGO_CACHE = os.path.join(APP_DIR, "logos")
MPV_LOG_FILE = os.path.join(APP_DIR, "mpv.log")
LIBRARY_CACHE_FILE = os.path.join(APP_DIR, "library_cache.json.gz")
# The pre-FluxTV player kept a login and favourites in ~/.iptv_player*.json.
# They're deliberately NOT read any more: the move-over happened long ago,
# and importing them made a "fresh" install on any computer that once ran
# the old player sign straight in as that person with their history —
# re-merged on every start, so it couldn't even be cleared.
os.makedirs(LOGO_CACHE, exist_ok=True)

DEFAULT_SETTINGS = {
    "trakt_scrobble": True,
    # Preferred audio languages, in order (mpv --alang); English first.
    "audio_lang": "en,eng,english",
    # Subtitles from add-ons (OpenSubtitles etc.): always offered in the
    # player's subtitle menu; switched on by themselves only if this is set.
    "subtitles_auto": False,
    # Keep the last half hour or so of a live channel (on disk) so it can be
    # paused and rewound.
    "live_rewind": True,
    "cache_secs": 30,
    "demuxer_max_mb": 50,
    "readahead_secs": 20,
    "auto_restart": True,
    "max_retries": 3,
    "fullscreen": True,
    "stream_format": "ts",
    "epg_url": "",
    "show_logos": True,
    # Hardware-accelerated decoding (VAAPI on Linux) has actually been
    # active this whole time via MPV's own auto-detection — this
    # setting doesn't turn on a new feature, it just gives explicit,
    # visible control over something that was already happening
    # implicitly, with a real fallback to software decoding if hardware
    # decoding is ever the cause of a playback glitch on a given
    # machine. Defaults to True so existing behaviour doesn't change
    # for anyone until they actually touch this switch.
    "hardware_accel": True,
}
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
SOURCES_FILE  = os.path.join(APP_DIR, "sources.json")
IPTV_HEADERS = {
    "User-Agent": "IPTV Smarters/1.0 Dalvik/2.1.0 (Linux; Android 7.1)",
    "Accept":     "application/json, text/plain, */*",
}

def _write_json(path, data):
    """Write user data atomically; restrict permissions on POSIX systems."""
    temp_path = path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)
    if platform.system() != "Windows":
        os.chmod(temp_path, 0o600)
    os.replace(temp_path, path)

def _registered_mpv_paths():
    """mpv.exe locations from Windows' installed-programs list. The winget
    package installs to "C:\\Program Files\\MPV Player", which a fixed list
    of guesses missed."""
    paths = []
    try:
        import winreg
    except ImportError:
        return paths
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            root = winreg.OpenKey(hive, r"Software\Microsoft\Windows\CurrentVersion\Uninstall")
        except OSError:
            continue
        for i in range(winreg.QueryInfoKey(root)[0]):
            try:
                with winreg.OpenKey(root, winreg.EnumKey(root, i)) as app:
                    name = winreg.QueryValueEx(app, "DisplayName")[0]
                    where = winreg.QueryValueEx(app, "InstallLocation")[0]
            except OSError:
                continue
            if "mpv" in str(name).lower() and where:
                paths.append(os.path.join(where, "mpv.exe"))
    return paths


def find_mpv():
    if platform.system() == "Windows":
        for path in [r"C:\mpv\mpv.exe",
                     r"C:\Program Files\MPV Player\mpv.exe",
                     r"C:\Program Files\mpv\mpv.exe",
                     os.path.join(os.path.dirname(os.path.abspath(__file__)), "mpv.exe"),
                     *_registered_mpv_paths()]:
            if os.path.exists(path):
                return path
        return shutil.which("mpv.exe") or "mpv.exe"
    return shutil.which("mpv") or "mpv"


MPV_PATH = find_mpv()


def time_greeting():
    h = datetime.now().hour
    if h < 12:  return "Good morning"
    if h < 18:  return "Good afternoon"
    return "Good evening"


# ── Credentials ────────────────────────────────────────────────

def save_credentials(server, username, password):
    """Save the login in FluxTV's own config file (owner-only on Linux).

    This used to go in the desktop keyring, but on setups where the
    keyring isn't unlocked at login (auto-login, most TV boxes) that made
    Linux ask for the keyring password every time FluxTV started — and
    sources.json already keeps the same password in a file anyway.
    """
    _write_json(CONFIG_FILE, {"server": server, "username": username,
                              "password": password})


def _password_from_sources(server, username):
    try:
        with open(SOURCES_FILE, encoding="utf-8") as f:
            sources = json.load(f)
    except Exception:
        return None
    server = (server or "").rstrip("/")
    for src in sources if isinstance(sources, list) else []:
        if ((src.get("server") or "").rstrip("/") == server
                and src.get("username") == username and src.get("password")):
            return src["password"]
    return None


def load_credentials():
    path = CONFIG_FILE
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as file:
            data = json.load(file)
    except Exception:
        return None
    if not data.get("password") and data.get("keyring_account"):
        # Older builds kept the password in the keyring. Move it into the
        # config file once, taking it from sources.json where possible so
        # the keyring (and its unlock prompt) isn't touched at all.
        password = _password_from_sources(data.get("server"), data.get("username"))
        if not password and HAS_KEYRING:
            try:
                password = keyring.get_password("JPsIPTVPlayer", data["keyring_account"])
            except Exception:
                password = None
        if password:
            data["password"] = password
            data.pop("keyring_account", None)
            try:
                _write_json(CONFIG_FILE, data)
            except Exception:
                pass
    return data if data.get("password") else None


def clear_credentials():
    """Forget the saved login."""
    if os.path.exists(CONFIG_FILE):
        os.remove(CONFIG_FILE)


# ── Favourites ─────────────────────────────────────────────────

def load_favs():
    try:
        with open(FAVS_FILE, encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}

def save_favs(favs):
    _write_json(FAVS_FILE, favs)

# ── Watch progress (movies / episodes) ───────────────────────────
# Resume position tracking. Live channels aren't part of this — "resume"
# doesn't mean anything for a live stream, only for on-demand content.
WATCH_PROGRESS_FILE = os.path.join(APP_DIR, "watch_progress.json")

def load_watch_progress():
    if not os.path.exists(WATCH_PROGRESS_FILE):
        return {}
    try:
        with open(WATCH_PROGRESS_FILE, encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}

def save_watch_progress(progress):
    _write_json(WATCH_PROGRESS_FILE, progress)

def vod_key(item):
    return f"vod:{item.get('stream_id')}"

def episode_key(ep):
    return f"episode:{ep.get('id')}"

def watch_progress_fraction(entry):
    """Fraction watched (0..1), or 0 if duration is unknown/zero."""
    try:
        duration = float(entry.get("duration") or 0)
        position = float(entry.get("position") or 0)
        return max(0.0, min(1.0, position / duration)) if duration > 0 else 0.0
    except (TypeError, ValueError):
        return 0.0

def series_continue_entry(series_id, progress):
    """The most recently-updated in-progress episode for a series, or None.

    Lets a series tile or its detail page offer "Resume S2 E4" without
    waiting on a fresh episode-list fetch — each stored episode entry
    carries enough of its own metadata (series_id, season, episode_num,
    stream id) to resume directly.
    """
    candidates = [v for v in progress.values()
                 if v.get("kind") == "episode"
                 and str(v.get("series_id")) == str(series_id)
                 and 0.02 < watch_progress_fraction(v) < 0.92]
    if not candidates:
        return None
    return max(candidates, key=lambda v: v.get("updated", 0))

def _load_favourites_file(path):
    """Read a favourites file and classify its shape: "fluxtv" for a
    JSON object (a complete FluxTV backup) or "otvf" for a JSON array
    (a FredTV export). Raises ValueError for anything else."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        return "fluxtv", data
    if isinstance(data, list):
        return "otvf", data
    raise ValueError(
        "This doesn't look like either a Flux Media backup or a FredTV "
        ".otvf export — the file's contents aren't in a shape either "
        "one recognises.")

def _apply_favourites_file(kind, data):
    """Store whichever kind of favourites file this was. Shared by both
    import_favourites_backup() and import_otvf() — see the note on
    import_favourites_backup() for why they both accept either format.
    Returns the number of favourited channels on record afterward."""
    if kind == "fluxtv":
        save_favs(data)
        return sum(1 for v in data.values() if v.get("fav"))
    favs = load_favs()
    imported = 0
    for item in data:
        name = item.get("name", "")
        if item.get("favorite") and name:
            favs[name] = {"fav": True, "last_watched": item.get("last_watched")}
            imported += 1
    save_favs(favs)
    return imported

def export_favourites_backup(path):
    """Write the complete FluxTV favourites/recent-watched database to JSON."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(load_favs(), f, indent=2, ensure_ascii=False)

def import_favourites_backup(path):
    """Restore favourites from a file — a complete FluxTV backup, or
    just as well a FredTV .otvf export.

    "Back up / Restore" and "Import from FredTV" in Settings both call
    this exact same function underneath: which of the two buttons
    someone clicks and which of the two file formats they actually have
    in hand don't always match — the buttons sit right next to each
    other in the same row, an easy mix-up (confirmed: this exact
    scenario, .otvf file via the Restore button, is what previously
    raised "not a valid FluxTV favourites file" here). Rather than
    reject a mismatch, this detects the real format and handles either
    one correctly regardless of which button led here. Returns the
    number of favourited channels on record after the restore/import.
    """
    kind, data = _load_favourites_file(path)
    return _apply_favourites_file(kind, data)

def import_otvf(path):
    """Import favourites from a FredTV .otvf export — or, just as well,
    a FluxTV backup file, for the same reason import_favourites_backup()
    accepts either. Returns the number of favourites now on record.
    """
    kind, data = _load_favourites_file(path)
    return _apply_favourites_file(kind, data)

def clear_all_favourites():
    """Un-star every currently-starred channel.

    Deliberately narrower than wiping the whole favourites file: entries
    here also carry "last_watched" timestamps for Continue Watching, and
    starting over with a fresh favourites list (the usual reason to want
    this at all — e.g. importing a new curated .otvf over the top of an
    old one) has nothing to do with wanting that history gone too. Only
    the "fav" flag is cleared; everything else about each entry stays.
    Returns the number of channels un-starred.
    """
    favs = load_favs()
    cleared = 0
    for entry in favs.values():
        if entry.get("fav"):
            entry["fav"] = False
            cleared += 1
    if cleared:
        save_favs(favs)
    return cleared

# ── Logo cache ─────────────────────────────────────────────────

def logo_cache_path(url):
    return os.path.join(LOGO_CACHE, hashlib.sha256(url.encode()).hexdigest() + ".png")

_IMAGE_MAGIC = (bytes([0xFF, 0xD8, 0xFF]),                      # JPEG
                bytes([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),  # PNG
                b"GIF8")


def is_svg(data):
    head = data[:2048].lstrip(b"\xef\xbb\xbf \t\r\n").lower()
    return head.startswith(b"<svg") or (head.startswith(b"<?xml") and b"<svg" in head)


def looks_like_image(data):
    if any(data.startswith(m) for m in _IMAGE_MAGIC):
        return True
    if is_svg(data):                     # vector logos (Rova's station logos)
        return True
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return True
    return data[4:12] in (b"ftypavif", b"ftypheic")


def fetch_logo_bytes(url):
    """Network half of the logo pipeline. Used by iptv.py's LogoStore
    (the Qt presentation layer) — not a leftover fluxtv_theme module,
    which was the Tkinter build's design system and no longer exists."""
    response = requests.get(url, timeout=10, headers=IPTV_HEADERS)
    response.raise_for_status()
    data = response.content
    # Only ever cache real pictures: an error page saved here would be
    # shown in place of the artwork from then on.
    if not looks_like_image(data):
        raise ValueError("not an image")
    return data

def _parse_xmltv_time(value):
    """Convert XMLTV's compact timestamp format to an aware UTC datetime."""
    value = (value or "").strip()
    if value.endswith("Z"):
        value = value[:-1] + " +0000"
    try:
        return datetime.strptime(value, "%Y%m%d%H%M%S %z").astimezone(timezone.utc)
    except ValueError:
        return None

def parse_xmltv(xml_data):
    """Return current/next programmes indexed by XMLTV channel id.

    Programmes that finished more than an hour ago are dropped as they're
    read — guides often carry days of history nothing here ever shows.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
    programmes = {}
    try:
        for _, element in ET.iterparse(BytesIO(xml_data), events=("end",)):
            if element.tag != "programme":
                continue
            start = _parse_xmltv_time(element.get("start"))
            stop = _parse_xmltv_time(element.get("stop"))
            title = element.findtext("title", default="Programme")
            channel_id = element.get("channel")
            if channel_id and start and stop and stop > cutoff:
                entry = {"start": start, "stop": stop, "title": title.strip()}
                programmes.setdefault(channel_id, []).append(entry)
            element.clear()
    except ET.ParseError as error:
        raise ValueError(f"Invalid XMLTV guide: {error}") from error

    for channel_programmes in programmes.values():
        channel_programmes.sort(key=lambda item: item["start"])
    return programmes

# ── Programme guide cache ──────────────────────────────────────
# The guide is by far the biggest thing FluxTV downloads (often tens of
# MB of XML) and was the only thing never kept on disk, so every launch
# waited on a full download + parse before any now/next appeared. It's
# stored already parsed, as a pickle (it holds datetimes, and loads far
# faster than re-parsing XML), in a file named for account + guide source.
EPG_CACHE_MAX_AGE = 6 * 3600          # older than this: re-download on launch


def _epg_cache_file(server, username, source):
    key = hashlib.sha256(f"{server.rstrip('/')}\0{username}\0{source or ''}"
                         .encode()).hexdigest()[:16]
    return os.path.join(APP_DIR, f"epg_cache_{key}.pickle")


def epg_cache_age(server, username, source):
    """Seconds since the guide cache was written, or None if there isn't one."""
    try:
        return time.time() - os.path.getmtime(_epg_cache_file(server, username, source))
    except OSError:
        return None


def load_epg_cache(server, username, source):
    try:
        with open(_epg_cache_file(server, username, source), "rb") as f:
            epg = pickle.load(f)
    except Exception:
        return {}
    if not isinstance(epg, dict):
        return {}
    # Drop programmes that have already finished — they only cost memory.
    cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
    for key in list(epg):
        entries = [e for e in epg[key] if e["stop"] > cutoff]
        if entries:
            epg[key] = entries
        else:
            del epg[key]
    return epg


def save_epg_cache(server, username, source, epg):
    if not epg:
        return
    path = _epg_cache_file(server, username, source)
    try:
        temp = path + ".tmp"
        with open(temp, "wb") as f:
            pickle.dump(epg, f, protocol=pickle.HIGHEST_PROTOCOL)
        if platform.system() != "Windows":
            os.chmod(temp, 0o600)
        os.replace(temp, path)
    except Exception:
        pass


# ── Local library cache ────────────────────────────────────────

def _cache_key(server, username):
    return hashlib.sha256(f"{server.rstrip('/')}\0{username}".encode()).hexdigest()

def load_library_cache(server, username):
    try:
        if not os.path.exists(LIBRARY_CACHE_FILE):
            return None
        with gzip.open(LIBRARY_CACHE_FILE, "rt", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("key") != _cache_key(server, username):
            return None
        return data
    except Exception:
        return None

def save_library_cache(server, username, categories, channels):
    try:
        payload = {
            "key": _cache_key(server, username),
            "saved_at": time.time(),
            "categories": categories or [],
            "channels": channels or [],
        }
        temp = LIBRARY_CACHE_FILE + ".tmp"
        with gzip.open(temp, "wt", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"))
        if platform.system() != "Windows":
            os.chmod(temp, 0o600)
        os.replace(temp, LIBRARY_CACHE_FILE)
    except Exception:
        pass

# VOD and series get their own cache files, same shape and access pattern
# as the live-channel library cache above — so Movies and Series can
# paint instantly from disk on launch instead of waiting on the provider,
# exactly like Live TV already does.
VOD_CACHE_FILE = os.path.join(APP_DIR, "vod_cache.json.gz")
SERIES_CACHE_FILE = os.path.join(APP_DIR, "series_cache.json.gz")

def load_vod_cache(server, username):
    try:
        if not os.path.exists(VOD_CACHE_FILE):
            return None
        with gzip.open(VOD_CACHE_FILE, "rt", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("key") != _cache_key(server, username):
            return None
        return data
    except Exception:
        return None

def save_vod_cache(server, username, categories, vod_channels):
    try:
        payload = {
            "key": _cache_key(server, username),
            "saved_at": time.time(),
            "categories": categories or [],
            "vod_channels": vod_channels or [],
        }
        temp = VOD_CACHE_FILE + ".tmp"
        with gzip.open(temp, "wt", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"))
        if platform.system() != "Windows":
            os.chmod(temp, 0o600)
        os.replace(temp, VOD_CACHE_FILE)
    except Exception:
        pass

def load_series_cache(server, username):
    try:
        if not os.path.exists(SERIES_CACHE_FILE):
            return None
        with gzip.open(SERIES_CACHE_FILE, "rt", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("key") != _cache_key(server, username):
            return None
        return data
    except Exception:
        return None

def save_series_cache(server, username, categories, series_list):
    try:
        payload = {
            "key": _cache_key(server, username),
            "saved_at": time.time(),
            "categories": categories or [],
            "series_list": series_list or [],
        }
        temp = SERIES_CACHE_FILE + ".tmp"
        with gzip.open(temp, "wt", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"))
        if platform.system() != "Windows":
            os.chmod(temp, 0o600)
        os.replace(temp, SERIES_CACHE_FILE)
    except Exception:
        pass


# ── API ────────────────────────────────────────────────────────

class XtreamAPI:
    # Mimic a standard Xtream Codes client so providers don't block us
    HEADERS = {
        "User-Agent": "IPTV Smarters/1.0 Dalvik/2.1.0 (Linux; Android 7.1)",
        "Accept":     "application/json, text/plain, */*",
    }

    def __init__(self, server, username, password):
        self.server   = server.rstrip("/")
        self.username = username
        self.password = password
        self._session = requests.Session()
        self._session.headers.update(self.HEADERS)

    def test_connection(self):
        try:
            r = self._session.get(f"{self.server}/player_api.php",
                             params={"username": self.username,
                                     "password": self.password}, timeout=10)
            r.raise_for_status()
            data = r.json()
            # Accept any valid JSON response that isn't an explicit auth failure
            if isinstance(data, dict):
                # Some providers return user_info, others return server_info
                # Reject only explicit auth failures
                if data.get("user_info", {}).get("auth") == 0:
                    return False, "Authentication failed"
                if data.get("auth") == 0:
                    return False, "Authentication failed"
                return True, data
            return False, "Unexpected response from server"
        except requests.exceptions.ConnectionError as e:
            return False, f"Cannot reach server: {e}"
        except requests.exceptions.Timeout:
            return False, "Server timed out — check your server URL"
        except (requests.RequestException, ValueError) as e:
            return False, str(e)

    def _get(self, action, timeout=15, category_id=None):
        params = {"username": self.username, "password": self.password, "action": action}
        if category_id is not None:
            params["category_id"] = category_id
        response = self._session.get(f"{self.server}/player_api.php", params=params, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, list):
            raise ValueError("Server returned an unexpected response.")
        return data

    def get_categories(self):
        try:
            return self._get("get_live_categories", timeout=10)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch categories: {e}") from e

    def get_channels(self, category_id=None):
        try:
            return self._get("get_live_streams", category_id=category_id)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch channels: {e}") from e

    def get_stream_url(self, stream_id):
        return f"{self.server}/live/{self.username}/{self.password}/{stream_id}.ts"

    # ── catch-up (provider TV archive) ───────────────────────────
    @staticmethod
    def has_catchup(channel):
        """The provider keeps recent programmes of this channel."""
        try:
            return int(channel.get("tv_archive") or 0) == 1 and                 int(channel.get("tv_archive_duration") or 0) > 0
        except (TypeError, ValueError):
            return False

    def server_offset(self):
        """How far the provider's clock is from UTC. Catch-up links use the
        server's local time; worked out from the time it reports, so no
        time-zone database is needed."""
        if getattr(self, "_offset", None) is not None:
            return self._offset
        offset = timedelta(0)
        try:
            r = self._session.get(f"{self.server}/player_api.php",
                                  params={"username": self.username,
                                          "password": self.password}, timeout=10)
            info = (r.json() or {}).get("server_info") or {}
            stamp = int(info.get("timestamp_now"))
            local = datetime.strptime(str(info.get("time_now")), "%Y-%m-%d %H:%M:%S")
            raw = local - datetime.fromtimestamp(stamp, timezone.utc).replace(tzinfo=None)
            quarter = round(raw.total_seconds() / 900) * 900   # zones are whole quarter hours
            offset = timedelta(seconds=quarter)
        except (requests.RequestException, ValueError, TypeError, AttributeError):
            pass
        self._offset = offset
        return offset

    def catchup_url(self, stream_id, start_utc, minutes):
        local = start_utc.astimezone(timezone.utc).replace(tzinfo=None) + self.server_offset()
        return (f"{self.server}/timeshift/{self.username}/{self.password}/"
                f"{max(1, int(minutes))}/{local:%Y-%m-%d:%H-%M}/{stream_id}.ts")

    def get_catchup_listings(self, stream_id):
        """The channel's programmes from the provider, past days included:
        [{"start", "stop" (UTC datetimes), "title", "description",
        "archive": recorded and watchable}], oldest first."""
        import base64

        def text(value):
            try:
                return base64.b64decode(value or "").decode("utf-8", "replace").strip()
            except (ValueError, TypeError):
                return str(value or "")
        r = self._session.get(f"{self.server}/player_api.php",
                              params={"username": self.username, "password": self.password,
                                      "action": "get_simple_data_table",
                                      "stream_id": stream_id}, timeout=20)
        r.raise_for_status()
        data = r.json()
        rows = data.get("epg_listings") if isinstance(data, dict) else None
        out = []
        for row in rows or []:
            try:
                start = datetime.fromtimestamp(int(row["start_timestamp"]), timezone.utc)
                stop = datetime.fromtimestamp(int(row["stop_timestamp"]), timezone.utc)
            except (KeyError, TypeError, ValueError):
                continue
            out.append({"start": start, "stop": stop, "title": text(row.get("title")) or "Programme",
                        "description": text(row.get("description")),
                        "archive": str(row.get("has_archive", "0")) == "1"})
        out.sort(key=lambda e: e["start"])
        return out

    def get_xmltv(self, custom_url=None):
        """Download the provider XMLTV guide, or an optional custom URL."""
        url = custom_url or f"{self.server}/xmltv.php"
        params = {} if custom_url else {"username": self.username, "password": self.password}
        t0 = time.monotonic()
        response = self._session.get(url, params=params, timeout=60)
        response.raise_for_status()
        data = response.content
        t1 = time.monotonic()
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data)
        epg = parse_xmltv(data)
        # Printed to the terminal so a slow guide can be pinned on the
        # provider (download) or on this machine (parse).
        print(f"[EPG] downloaded {len(response.content) / 1e6:.1f} MB in "
              f"{t1 - t0:.1f}s, parsed {len(epg):,} channels in "
              f"{time.monotonic() - t1:.1f}s", file=sys.stderr)
        return epg

    def get_vod_categories(self):
        try:
            return self._get("get_vod_categories", timeout=10)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch VOD categories: {e}") from e

    def get_vod_streams(self, category_id=None):
        try:
            return self._get("get_vod_streams", category_id=category_id)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch VOD streams: {e}") from e

    def get_vod_info(self, vod_id):
        try:
            params = {"username": self.username, "password": self.password,
                      "action": "get_vod_info", "vod_id": vod_id}
            r = self._session.get(f"{self.server}/player_api.php", params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception:
            return {}

    def get_series_categories(self):
        try:
            return self._get("get_series_categories", timeout=10)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch series categories: {e}") from e

    def get_series(self, category_id=None):
        try:
            return self._get("get_series", category_id=category_id)
        except (requests.RequestException, ValueError) as e:
            raise RuntimeError(f"Could not fetch series: {e}") from e

    def get_series_info(self, series_id):
        try:
            params = {"username": self.username, "password": self.password,
                      "action": "get_series_info", "series_id": series_id}
            r = self._session.get(f"{self.server}/player_api.php", params=params, timeout=15)
            r.raise_for_status()
            return r.json()
        except Exception:
            return {}

    def get_vod_url(self, stream_id, container_extension="mp4"):
        return f"{self.server}/movie/{self.username}/{self.password}/{stream_id}.{container_extension}"

    def get_episode_url(self, stream_id, container_extension="mp4"):
        return f"{self.server}/series/{self.username}/{self.password}/{stream_id}.{container_extension}"


# ══════════════════════════════════════════════════════════════
# LOGIN SCREEN
# ══════════════════════════════════════════════════════════════

def load_sources():
    """Return list of saved provider sources [{name, server, username, password}]"""
    if os.path.exists(SOURCES_FILE):
        try:
            with open(SOURCES_FILE, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except Exception:
            pass
    # Migrate existing single credential as first source
    creds = load_credentials()
    if creds and creds.get("server"):
        return [{"name": "My Provider",
                 "server":   creds["server"],
                 "username": creds.get("username",""),
                 "password": creds.get("password","")}]
    return []

def save_sources(sources):
    _write_json(SOURCES_FILE, sources)

def load_settings():
    settings = dict(DEFAULT_SETTINGS)
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, encoding="utf-8") as file:
                data = json.load(file)
            if isinstance(data, dict):
                settings.update(data)
    except Exception:
        pass
    return settings

def save_settings(settings):
    _write_json(SETTINGS_FILE, settings)

# ══════════════════════════════════════════════════════════════
# MAIN PLAYER
# ══════════════════════════════════════════════════════════════



# ══════════════════════════════════════════════════════════════════
# Parental lock
# ══════════════════════════════════════════════════════════════════
# Categories (and channels / titles) whose names contain any of these are
# hidden while a parental PIN is set and the app hasn't been unlocked.
LOCK_WORDS = ("adult", "xxx", "18+", "porn", "erotic", "for adults", "playboy",
              "hustler", "brazzers", "sex")


def pin_hash(pin, salt):
    return hashlib.sha256(f"{salt}:{pin}".encode("utf-8")).hexdigest()


def set_parental_pin(settings, pin):
    """Store a PIN (as a salted hash, never the PIN itself); None removes it."""
    if not pin:
        settings.pop("parental_pin", None)
        settings.pop("parental_salt", None)
    else:
        salt = os.urandom(8).hex()
        settings["parental_salt"] = salt
        settings["parental_pin"] = pin_hash(pin, salt)
    save_settings(settings)


def check_parental_pin(settings, pin):
    stored = settings.get("parental_pin")
    return bool(stored) and pin_hash(pin or "", settings.get("parental_salt", "")) == stored


def _locked_list(name, cats_name=None):
    """A Library list that hides locked things while the lock is on. The
    same filtered list object is handed out until the source list or the
    lock changes (screens use that identity to know nothing changed)."""
    def get(self):
        raw = self._raw.get(name, [])
        if not self.parental_locked():
            return raw
        cats_raw = self._raw.get(cats_name, []) if cats_name else []
        key = (id(raw), len(raw), id(cats_raw), self._lock_version)
        hit = self._filtered.get(name)
        if hit and hit[0] == key:
            return hit[1]
        words = self.lock_words()

        def bad(text):
            text = (text or "").lower()
            return any(w in text for w in words)
        if cats_name is None:                       # a category list
            out = [c for c in raw if not bad(c.get("category_name"))]
        else:
            blocked = {str(c.get("category_id")) for c in cats_raw if bad(c.get("category_name"))}
            out = [i for i in raw if str(i.get("category_id")) not in blocked
                   and not bad(i.get("name"))]
        self._filtered[name] = (key, out)
        return out

    def set(self, value):
        self._raw[name] = value if value is not None else []
    return property(get, set)


class Library:
    """Channel, favourite and EPG state, with no reference to any widget.

    The methods below are the ones lifted unchanged out of IPTVPlayer: they
    never touched Tk, so they move across as-is and the new UI calls exactly
    the same code the working build calls.
    """

    categories = _locked_list("categories")
    all_channels = _locked_list("all_channels", "categories")
    vod_categories = _locked_list("vod_categories")
    vod_channels = _locked_list("vod_channels", "vod_categories")
    series_categories = _locked_list("series_categories")
    series_list = _locked_list("series_list", "series_categories")

    def __init__(self, api, settings=None):
        self._raw = {}
        self._filtered = {}
        self._lock_version = 0
        self._unlocked = False
        self.api = api
        self.settings = settings if settings is not None else load_settings()
        self.favs = load_favs()
        self.epg = {}
        self.categories = []
        self.channels = []
        self.all_channels = []
        self.vod_categories = []
        self.series_categories = []
        self.vod_channels = []
        self.series_list = []
        self._fav_cache = None
        self._recent_cache = None


    # ── parental lock ────────────────────────────────────────────
    def parental_locked(self):
        return bool(self.settings.get("parental_pin")) and not self._unlocked

    def lock_words(self):
        extra = [w.strip().lower() for w in
                 str(self.settings.get("parental_words", "")).split(",") if w.strip()]
        return tuple(LOCK_WORDS) + tuple(extra)

    def set_unlocked(self, unlocked):
        self._unlocked = bool(unlocked)
        self.lock_changed()

    def lock_changed(self):
        """The PIN, the words or the unlocked state changed: lists re-filter."""
        self._lock_version += 1
        self._filtered.clear()
        self._fav_cache = None
        self._recent_cache = None

    def _fav_key(self, ch):
        return f"{self.api.server}|{ch.get('stream_id', '')}"

    def _fav_data(self, ch):
        return self.favs.get(self._fav_key(ch), self.favs.get(ch.get("name", ""), {}))

    def _is_fav(self, ch):
        return bool(self._fav_data(ch).get("fav", False))

    def _toggle_fav(self, ch):
        """Flip a channel's favourite state and persist it.

        Pure data — the presentation layer decides how to react (which
        cards to repaint, what status text to show), so this doesn't call
        back into any UI method the way the original widget-bound version
        did.
        """
        key = self._fav_key(ch)
        entry = self.favs.setdefault(key, {})
        entry["fav"] = not self._is_fav(ch)
        save_favs(self.favs)
        self._invalidate_user_caches()

    @staticmethod
    def _normalise(s):
        """Strip punctuation/spaces/case for fuzzy EPG matching."""
        return re.sub(r"[^a-z0-9]", "", (s or "").lower())

    def _invalidate_caches(self):
        """Clear all pre-computed channel lists so they rebuild on next access."""
        self._fav_cache    = None
        self._recent_cache = None
        for name in ("Sports", "News", "Kids"):
            try: delattr(self, f"_col_{name}")
            except AttributeError: pass

    def _invalidate_user_caches(self):
        """Clear only what per-person activity can change: the favourites
        list and the recently-watched list.

        The Sports / News / Kids collections are derived purely from the
        channel and category data — playing a channel or starring one
        can't alter them — so throwing them away on every play (which the
        full _invalidate_caches() did) just forced a rescan of the entire
        channel list the next time Home or Sport was shown. With a
        library in the tens of thousands that's a few hundred
        milliseconds of blocked UI at exactly the moment someone leaves
        the player. The full version stays for when the channel data
        itself actually changes (a library load or refresh).
        """
        self._fav_cache    = None
        self._recent_cache = None

    def _fav_channels(self):
        """Cached list of favourite channels — only rescans when cache is None."""
        if getattr(self, "_fav_cache", None) is not None:
            return self._fav_cache
        fav_keys = {k for k, v in self.favs.items() if v.get("fav")}
        self._fav_cache = [c for c in self.all_channels
                           if self._fav_key(c) in fav_keys
                           or c.get("name", "") in fav_keys]
        return self._fav_cache

    def _recent_channels(self):
        """Cached recently-watched list — only rescans when cache is None."""
        if getattr(self, "_recent_cache", None) is not None:
            return self._recent_cache
        # Build a lookup dict first so we don't call _fav_data 42k times
        fav_lookup = {}
        for ch in self.all_channels:
            key  = self._fav_key(ch)
            data = self.favs.get(key) or self.favs.get(ch.get("name", ""), {})
            stamp = data.get("last_watched")
            if stamp:
                try:
                    fav_lookup[float(stamp)] = ch
                except (TypeError, ValueError):
                    pass
        watched = sorted(fav_lookup.items(), reverse=True)
        self._recent_cache = [ch for _, ch in watched]
        return self._recent_cache

    def _collection(self, name):
        cache_key = f"_col_{name}"
        cached = getattr(self, cache_key, None)
        if cached is not None:
            return cached
        keywords = {
            "Sports": ("sport", "football", "soccer", "rugby", "cricket",
                       "f1", "tennis", "golf", "basket", "baseball"),
            "News":   ("news", "cnn", "bbc news", "sky news", "al jazeera",
                       "bloomberg", "fox news"),
            "Kids":   ("kids", "cartoon", "disney", "nick", "nickelodeon",
                       "baby", "junior", "cbeebies"),
        }.get(name, ())
        if not keywords:
            return []
        cat_names = {str(c.get("category_id")): (c.get("category_name") or "").lower()
                     for c in self.categories}
        result = [c for c in self.all_channels if any(
            w in f"{cat_names.get(str(c.get('category_id','')),'')} {(c.get('name') or '').lower()}"
            for w in keywords)]
        setattr(self, cache_key, result)
        return result

    # ── EPG ────────────────────────────────────────────────────
    # ── EPG fuzzy matching ────────────────────────────────────

    def _epg_entries_for(self, key):
        if not key:
            return []
        return self.epg.get(key, [])

    def _epg_index(self):
        """Normalised-name -> EPG key lookup, plus the (key, normalised)
        pairs the prefix fallback walks, built once per EPG load.

        The original matcher re-normalised every EPG key with a regex,
        for every channel, on every lookup. That's fine for the couple of
        dozen cards on screen; it is not fine for a guide that has to
        resolve programme data for thousands of channels. Rebuilt only
        when the EPG dict itself changes (different object or size).
        """
        stamp = (id(self.epg), len(self.epg))
        if getattr(self, "_epg_idx_stamp", None) != stamp:
            idx, pairs = {}, []
            for k in self.epg:
                n = self._normalise(k)
                pairs.append((k, n))
                # first key wins, exactly as the old linear scan did
                if n and n not in idx:
                    idx[n] = k
            self._epg_idx = idx
            self._epg_pairs = pairs
            self._epg_idx_stamp = stamp
            self._epg_prefix_memo = {}
        return self._epg_idx

    def _epg_quick_key(self, ch):
        """The cheap steps of the match — exact provider fields, exact
        name, normalised name — all dictionary lookups. Returns None if
        none of those hit. Enough on its own to answer "does this channel
        have any guide data at all", which is what bulk filtering needs."""
        if not self.epg:
            return None
        # 1. Exact fields the provider supplies
        for field in ("epg_channel_id", "epg_id"):
            v = ch.get(field)
            if v and v in self.epg:
                return v
        # 2. Exact channel name
        name = ch.get("name", "")
        if name in self.epg:
            return name
        # 3. Normalised name match
        norm = self._normalise(name)
        if norm:
            return self._epg_index().get(norm)
        return None

    def _epg_fuzzy_key(self, ch):
        """Find the best EPG key for a channel using progressively looser matching."""
        if not self.epg:
            return None
        key = self._epg_quick_key(ch)
        if key is not None:
            return key
        # 4. Prefix match (handles trailing HD/SD/+1 variants). The only
        # slow step, so the result — including "no match" — is remembered
        # per channel name until the EPG changes.
        self._epg_index()
        name = ch.get("name", "")
        memo = self._epg_prefix_memo
        if name in memo:
            return memo[name]
        norm = self._normalise(name)
        result = None
        if norm and len(norm) >= 4:
            for k, kn in self._epg_pairs:
                if kn.startswith(norm[:max(4, len(norm)-3)]) or norm.startswith(kn[:max(4, len(kn)-3)]):
                    result = k
                    break
        memo[name] = result
        return result

    def _epg_listing(self, ch):
        if not self.epg:
            return []
        now = datetime.now(timezone.utc)
        key = self._epg_fuzzy_key(ch)
        if not key:
            return []
        entries = self.epg.get(key, [])
        if not entries:
            return []
        # entries are sorted by start time (parse_xmltv guarantees this),
        # so once the currently-airing one is found by index, whatever
        # comes right after it in the list IS the next programme. The
        # previous version filtered separately for "current" (start<=now
        # <stop) and "upcoming" (start>now) and returned current[:2] —
        # but the show immediately following the live one always fails
        # the "current" test by definition (it hasn't started yet), so
        # that slice could only ever hold more than one entry if the
        # guide had genuinely overlapping listings. In practice "Next"
        # stayed blank for the entire duration of whatever was airing.
        for i, item in enumerate(entries):
            if item["start"] <= now < item["stop"]:
                return entries[i:i + 2]
        upcoming = [x for x in entries if x["start"] > now]
        if upcoming:
            return upcoming[:1]
        return []

    def _epg_range(self, ch, window_start, window_end):
        """All programmes for a channel that overlap [window_start,
        window_end) at all — unlike _epg_listing() (current + next
        only, for the card view), this is for the full Guide timeline,
        which needs everything visible across a multi-hour window.
        """
        if not self.epg:
            return []
        key = self._epg_fuzzy_key(ch)
        if not key:
            return []
        entries = self.epg.get(key, [])
        return [e for e in entries
                if e["stop"] > window_start and e["start"] < window_end]

    def _programme_text(self, ch):
        listing = self._epg_listing(ch)
        return listing[0]["title"] if listing else "Live now"
