#!/usr/bin/env python3
"""
Flux Media (FluxTV) — back up and restore everything that's yours.

One file (a zip named "FluxMedia-Backup-<date>.fmbackup") with the login,
settings, add-ons, favourites, playlists, radio stations, watch history,
progress and the Stremio / Trakt sign-ins. Caches (guide, posters, channel
lists) aren't included — they download again by themselves.

The file holds passwords and keys, so it should be kept private (the
Settings screen says so).

Restoring first saves the current state to backups/before-restore-<time>,
so a restore can itself be undone, then the app restarts.
"""

from __future__ import annotations

import json
import os
import shutil
import time
import zipfile

from fluxtv_core import APP_DIR

APP = "Flux Media"
FORMAT = 1
# What counts as "yours" (everything else in the folder can be rebuilt).
FILES = ("config.json", "settings.json", "favourites.json", "addons.json", "sources.json",
         "watch_progress.json", "watched.json", "music_playlists.json", "music_history.json",
         "radio_favourites.json", "radio_history.json", "recordings.json",
         "stremio_account.json", "stremio_library.json", "trakt.json", "trakt_app.json")
BACKUP_DIR = os.path.join(APP_DIR, "backups")


class BackupError(Exception):
    pass


def make_backup(folder):
    """Write a backup into `folder`; returns its path."""
    os.makedirs(folder, exist_ok=True)
    stamp = time.strftime("%Y-%m-%d %H.%M")
    path = os.path.join(folder, f"FluxMedia-Backup-{stamp}.fmbackup")
    included = [n for n in FILES if os.path.isfile(os.path.join(APP_DIR, n))]
    if not included:
        raise BackupError("There's nothing to back up yet.")
    manifest = {"app": APP, "format": FORMAT, "made": stamp, "files": included}
    temp = path + ".tmp"
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=1))
        for name in included:
            zf.write(os.path.join(APP_DIR, name), name)
    os.replace(temp, path)
    try:
        os.chmod(path, 0o600)          # it holds passwords and keys
    except OSError:
        pass
    return path


def read_backup(path):
    """(manifest, {name: bytes}) after checking it's a Flux Media backup."""
    try:
        zf = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile):
        raise BackupError("That isn't a Flux Media backup file.")
    with zf:
        try:
            manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        except (KeyError, ValueError):
            raise BackupError("That isn't a Flux Media backup file.")
        if manifest.get("app") != APP:
            raise BackupError("That isn't a Flux Media backup file.")
        files = {}
        for name in manifest.get("files", []):
            if name not in FILES:
                continue                   # only ever our own known files
            try:
                data = zf.read(name)
                json.loads(data.decode("utf-8"))      # each must be valid JSON
            except (KeyError, ValueError):
                raise BackupError(f"The backup is damaged ({name}).")
            files[name] = data
    if not files:
        raise BackupError("The backup is empty.")
    return manifest, files


def restore_backup(path):
    """Put a backup in place (the current state is kept first). Returns the
    backup's date."""
    manifest, files = read_backup(path)
    keep = os.path.join(BACKUP_DIR, "before-restore-" + time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(keep, exist_ok=True)
    for name in FILES:
        current = os.path.join(APP_DIR, name)
        if os.path.isfile(current):
            shutil.copy2(current, os.path.join(keep, name))
    for name, data in files.items():
        target = os.path.join(APP_DIR, name)
        with open(target + ".tmp", "wb") as f:
            f.write(data)
        os.replace(target + ".tmp", target)
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
    return manifest.get("made", "")


def summary(path):
    """A short "what's in it" line for the confirm dialog."""
    manifest, files = read_backup(path)
    labels = {"config.json": "provider login", "addons.json": "add-ons",
              "favourites.json": "favourites", "music_playlists.json": "playlists",
              "radio_favourites.json": "radio stations", "watch_progress.json": "watch progress",
              "stremio_account.json": "Stremio sign-in", "trakt.json": "Trakt sign-in", "trakt_app.json": "Trakt app keys",
              "settings.json": "settings"}
    parts = [labels[n] for n in files if n in labels]
    return manifest.get("made", ""), ", ".join(parts)
