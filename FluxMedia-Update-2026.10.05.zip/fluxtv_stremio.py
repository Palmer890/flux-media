#!/usr/bin/env python3
"""
FluxTV — import a Stremio account's library and watch progress.

Uses the same api.strem.io calls Stremio's own web app makes: "login" for
a session key, then "datastoreGet" on the libraryItem collection. These
aren't a published API, so they could change; nothing else in FluxTV
depends on this module.

The password is only sent to Stremio, never stored. The session key
(authKey) is kept, owner-only, so "Sync now" works without asking again.
"""

from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime

import requests

import fluxtv_core as core

API = "https://api.strem.io/api/"
ACCOUNT_FILE = os.path.join(core.APP_DIR, "stremio_account.json")
LIBRARY_FILE = os.path.join(core.APP_DIR, "stremio_library.json")

_session = requests.Session()
_session.headers["User-Agent"] = "FluxTV/1.0"


class StremioError(Exception):
    pass


def _call(method, payload):
    try:
        r = _session.post(API + method, json=payload, timeout=30)
        r.raise_for_status()
        data = r.json()
    except (requests.RequestException, ValueError) as error:
        raise StremioError(f"Couldn't reach Stremio ({error.__class__.__name__}).")
    if isinstance(data, dict) and data.get("error"):
        message = (data["error"] or {}).get("message") or "Stremio refused the request."
        raise StremioError(message)
    return data.get("result") if isinstance(data, dict) else None


# ── account ──────────────────────────────────────────────────────
def load_account():
    try:
        with open(ACCOUNT_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if data.get("authKey") else None
    except (OSError, ValueError):
        return None


def login(email, password):
    result = _call("login", {"type": "Login", "email": email.strip(),
                             "password": password, "facebook": False})
    key = (result or {}).get("authKey")
    if not key:
        raise StremioError("Stremio didn't return a session.")
    account = {"authKey": key, "email": email.strip(), "last_sync": 0}
    core._write_json(ACCOUNT_FILE, account)
    return account


def logout():
    account = load_account()
    if account:
        try:
            _call("logout", {"type": "Logout", "authKey": account["authKey"]})
        except StremioError:
            pass
    for path in (ACCOUNT_FILE, LIBRARY_FILE):
        try:
            os.remove(path)
        except OSError:
            pass


# ── library ──────────────────────────────────────────────────────
def _stamp(value):
    """Stremio dates: ISO strings, but Stremio's newer apps (phone, v5)
    write any number of fraction digits ("…:15.123456789Z"), which older
    Pythons' fromisoformat rejects; those titles then sorted as oldest.
    Also accepts epoch numbers and {"$date": …}."""
    if isinstance(value, dict):
        value = value.get("$date")
    if not value:
        return 0
    if isinstance(value, (int, float)):
        return int(value / 1000 if value > 1e11 else value)
    m = re.match(r"(\d{4}-\d\d-\d\d)[T ](\d\d:\d\d(?::\d\d)?)(?:\.\d+)?\s*(Z|[+-]\d\d:?\d\d)?",
                 str(value).strip())
    if not m:
        return 0
    zone = m.group(3) or "Z"
    zone = "+00:00" if zone == "Z" else (zone if ":" in zone else zone[:3] + ":" + zone[3:])
    clock = m.group(2) if m.group(2).count(":") == 2 else m.group(2) + ":00"
    try:
        return int(datetime.fromisoformat(f"{m.group(1)}T{clock}{zone}").timestamp())
    except ValueError:
        return 0


def load_library():
    try:
        with open(LIBRARY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def sync():
    """Fetch the library, save it, and merge Stremio's watch progress into
    FluxTV's resume points. Returns (library_count, resumed_count)."""
    account = load_account()
    if not account:
        raise StremioError("Not signed in to Stremio.")
    items = _call("datastoreGet", {"authKey": account["authKey"],
                                   "collection": "libraryItem", "ids": [], "all": True})
    if not isinstance(items, list):
        raise StremioError("Stremio sent back something unexpected.")

    library, seen = [], set()
    watched_films = []
    for it in items:
        st = it.get("state") if isinstance(it, dict) else None
        if isinstance(st, dict) and it.get("type") == "movie" and                 (st.get("flaggedWatched") or st.get("timesWatched")):
            watched_films.append(it.get("_id"))
    for it in items:
        if not isinstance(it, dict) or not it.get("_id") or it.get("removed") or it.get("temp"):
            continue
        if it.get("type") not in ("movie", "series") or it["_id"] in seen:
            continue
        seen.add(it["_id"])
        library.append({"id": it["_id"], "type": it["type"], "name": it.get("name", ""),
                        "poster": it.get("poster") or "",
                        "added": _stamp(it.get("_ctime")),
                        "modified": _stamp(it.get("_mtime"))})
    library.sort(key=lambda i: i["modified"], reverse=True)
    core._write_json(LIBRARY_FILE, library)

    if watched_films:
        import fluxtv_trakt
        fluxtv_trakt.add_watched(movies=watched_films)
    resumed = _merge_progress(items)
    account["last_sync"] = int(time.time())
    core._write_json(ACCOUNT_FILE, account)
    return len(library), resumed


def _merge_progress(items):
    """Stremio keeps one "state" per library item: where you are in the
    film, or which episode (video_id "tt123:3:5") and where in it. Each
    becomes a FluxTV resume point unless FluxTV already has a newer one."""
    progress = core.load_watch_progress()
    changed = 0
    for it in items:
        if not isinstance(it, dict) or it.get("type") not in ("movie", "series"):
            continue
        st = it.get("state") or {}
        offset, duration = st.get("timeOffset") or 0, st.get("duration") or 0
        if offset <= 0 or duration <= 0:
            continue
        position, length = offset / 1000.0, duration / 1000.0
        if not 0.02 < position / length < 0.92:
            continue
        updated = _stamp(st.get("lastWatched")) or _stamp(it.get("_mtime"))
        entry = {"position": position, "duration": length, "updated": updated,
                 "kind": "addon", "addon_type": it["type"], "show": it.get("name", ""),
                 "poster": it.get("poster") or "", "source": "stremio"}
        if it["type"] == "movie":
            vid = it["_id"]
            entry.update({"title": it.get("name", ""), "addon_id": vid})
        else:
            vid = st.get("video_id") or ""
            parts = vid.split(":")
            if len(parts) < 3:
                continue
            try:
                season, episode = int(parts[-2]), int(parts[-1])
            except ValueError:
                continue
            entry.update({"title": f"{it.get('name', '')} — S{season} E{episode}",
                          "addon_id": vid, "series_id": it["_id"],
                          "season": season, "episode_num": episode})
        key = f"addon:{vid}"
        mine = progress.get(key)
        if mine and mine.get("updated", 0) >= updated:
            continue
        progress[key] = entry
        changed += 1
    if changed:
        core.save_watch_progress(progress)
    return changed


def continue_watching(limit=20):
    """Titles part-way through (from Stremio or watched in FluxTV), newest
    first, one entry per film / per series: [(type, meta, fraction, text)]."""
    progress = core.load_watch_progress()
    best = {}
    for entry in progress.values():
        if entry.get("kind") != "addon":
            continue
        fraction = core.watch_progress_fraction(entry)
        if not 0.02 < fraction < 0.92:
            continue
        title_id = entry.get("series_id") or entry.get("addon_id")
        if not title_id:
            continue
        if title_id not in best or entry.get("updated", 0) > best[title_id].get("updated", 0):
            best[title_id] = entry
    rows = []
    for title_id, e in sorted(best.items(), key=lambda kv: kv[1].get("updated", 0), reverse=True):
        type_ = e.get("addon_type") or ("series" if e.get("series_id") else "movie")
        meta = {"id": title_id, "type": type_, "name": e.get("show") or e.get("title", ""),
                "poster": e.get("poster") or ""}
        if type_ == "series" and e.get("season") is not None:
            text = f"Continue • S{e['season']} E{e.get('episode_num')}"
        else:
            text = "Continue watching"
        rows.append((type_, meta, core.watch_progress_fraction(e), text))
    return rows[:limit]


# ── add-ons ──────────────────────────────────────────────────────
def get_addons():
    """The add-on links installed on the Stremio account, in Stremio's
    order (what Stremio's own apps sync between devices). Skips Stremio's
    built-in local-only add-ons, which only work inside Stremio itself."""
    account = load_account()
    if not account:
        raise StremioError("Not signed in to Stremio.")
    result = _call("addonCollectionGet", {"type": "AddonCollectionGet",
                                          "authKey": account["authKey"], "update": True})
    addons = (result or {}).get("addons") if isinstance(result, dict) else None
    urls = []
    for a in addons or []:
        url = (a or {}).get("transportUrl") or ""
        if not url.startswith(("http://", "https://")):
            continue
        if "127.0.0.1" in url or "localhost" in url:
            continue
        if url not in urls:
            urls.append(url)
    return urls
