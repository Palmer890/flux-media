#!/usr/bin/env python3
"""
Flux Media (FluxTV) — live radio.

Stations come from Radio Browser (radio-browser.info), a free community
directory of ~50,000 stations, no account needed. Stations play through the
same sound-only player as music; most send the current song's title
("icy" metadata), which mpv passes on.

George FM and its digital channels are listed there with direct streams
(MediaWorks' own servers / StreamTheWorld), so they play here exactly as in
the Rova app.
"""

from __future__ import annotations

import json
import os
import random
import threading
import time

import requests

from fluxtv_core import APP_DIR, _write_json

FAVOURITES_FILE = os.path.join(APP_DIR, "radio_favourites.json")
HISTORY_FILE = os.path.join(APP_DIR, "radio_history.json")
POPULAR_CACHE = os.path.join(APP_DIR, "radio_popular.json")
POPULAR_MAX_AGE = 24 * 3600

SERVERS = ["https://de1.api.radio-browser.info", "https://de2.api.radio-browser.info",
           "https://fi1.api.radio-browser.info", "https://all.api.radio-browser.info"]
_session = requests.Session()
_session.headers["User-Agent"] = "FluxMedia/1.0"
_lock = threading.Lock()


class RadioError(Exception):
    pass


# The ones a George FM fan wants from day one; shown until "Your stations"
# has anything else in it (they can be removed like any other).
STARTERS = [
    {"name": "George FM", "url": "https://mediaworks.streamguys1.com/george_net_icy",
     "logo": "", "country": "NZ", "tags": "dance,house,electronic"},
    {"name": "George FM - Club Classics",
     "url": "https://playerservices.streamtheworld.com/api/livestream-redirect/GEORGEFM_CC_S01.aac",
     "logo": "", "country": "NZ", "tags": "club classics"},
    {"name": "George FM - DnB",
     "url": "https://playerservices.streamtheworld.com/api/livestream-redirect/GEORGE_DNB_S01.aac",
     "logo": "", "country": "NZ", "tags": "drum and bass"},
]


def _api(path, params=None, timeout=12):
    servers = SERVERS[:-1]
    random.shuffle(servers)
    last = None
    for host in servers + SERVERS[-1:]:
        try:
            r = _session.get(host + path, params=params, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except (requests.RequestException, ValueError) as error:
            last = error
    raise RadioError(f"Couldn't reach the radio directory ({last.__class__.__name__}).")


def station(raw):
    """A Radio Browser entry -> the track-like dict the music player uses."""
    url = raw.get("url_resolved") or raw.get("url") or ""
    if not url.startswith(("http://", "https://")):
        return None
    country = raw.get("countrycode") or raw.get("country") or ""
    return _as_track({"uuid": raw.get("stationuuid") or "", "name": (raw.get("name") or "").strip(),
                      "url": url, "logo": raw.get("favicon") or "", "country": country,
                      "tags": raw.get("tags") or "", "codec": raw.get("codec") or "",
                      "bitrate": raw.get("bitrate") or 0})


def _as_track(st):
    tags = ", ".join(t.strip() for t in (st.get("tags") or "").split(",")[:2] if t.strip())
    sub = "  ·  ".join(filter(None, ["Live radio", st.get("country", ""), tags]))
    known = ROVA_BY_URL.get(st["url"]) if "ROVA_BY_URL" in globals() else None
    if known:
        st = dict(st, logo=known["logo"] or st.get("logo") or "")
    return {"kind": "radio", "id": "radio:" + (st.get("uuid") or st["url"]),
            "art": (known or {}).get("art", ""), "art_logo": (known or {}).get("art_logo", False),
            "uuid": st.get("uuid") or "", "url": st["url"], "title": st["name"],
            "name": st["name"], "channel": sub, "thumb": st.get("logo") or "",
            "logo": st.get("logo") or "", "country": st.get("country", ""),
            "tags": st.get("tags") or "", "live": True, "duration": 0}


def _dedupe(stations):
    seen, out = set(), []
    for s in stations:
        key = (s["name"].lower(), s["url"].split("?")[0])
        if s and key not in seen:
            seen.add(key)
            out.append(s)
    return out


def search(query, limit=30):
    query = " ".join((query or "").split())
    if not query:
        return []
    data = _api("/json/stations/search", {"name": query, "limit": limit * 2, "order": "votes",
                                          "reverse": "true", "hidebroken": "true"})
    found = [station(d) for d in data if isinstance(d, dict)]
    return _dedupe([s for s in found if s])[:limit]


def popular(country="NZ", limit=40):
    """The country's most played stations, kept for a day."""
    try:
        with open(POPULAR_CACHE, encoding="utf-8") as f:
            cached = json.load(f)
        if cached.get("country") == country and time.time() - cached.get("saved", 0) < POPULAR_MAX_AGE:
            return cached["stations"]
    except (OSError, ValueError, AttributeError, KeyError):
        pass
    data = _api("/json/stations/search", {"countrycode": country, "limit": limit * 2,
                                          "order": "clickcount", "reverse": "true",
                                          "hidebroken": "true"})
    found = _dedupe([s for s in (station(d) for d in data if isinstance(d, dict)) if s])[:limit]
    _write_json(POPULAR_CACHE, {"saved": time.time(), "country": country, "stations": found})
    return found


def count_click(track):
    """Radio Browser asks players to report a play (it ranks stations)."""
    if track.get("uuid"):
        try:
            _session.get(f"{SERVERS[-1]}/json/url/{track['uuid']}", timeout=6)
        except requests.RequestException:
            pass


# ── your stations ─────────────────────────────────────────────────
_KEEP = ("kind", "id", "uuid", "url", "title", "name", "channel", "thumb", "logo", "art", "art_logo",
         "country", "tags", "live", "duration")


def with_artwork(track):
    """Saved stations get today's logo and big picture when we know them."""
    known = ROVA_BY_URL.get(track.get("url"))
    if known:
        track = dict(track, art=known["art"], art_logo=known.get("art_logo", False))
        if known["logo"]:
            track.update(logo=known["logo"], thumb=known["logo"])
    return track


def load_favourites():
    try:
        with open(FAVOURITES_FILE, encoding="utf-8") as f:
            data = json.load(f)
        items = [s for s in data if isinstance(s, dict) and s.get("url")] if isinstance(data, list) else []
    except (OSError, ValueError):
        items = [_as_track(s) for s in STARTERS]
    return [with_artwork(s) for s in items]


def is_favourite(track):
    return any(s["id"] == track.get("id") for s in load_favourites())


def add_favourite(track):
    with _lock:
        items = [s for s in load_favourites() if s["id"] != track["id"]]
        items.insert(0, {k: track.get(k) for k in _KEEP})
        _write_json(FAVOURITES_FILE, items)


def remove_favourite(track):
    with _lock:
        _write_json(FAVOURITES_FILE, [s for s in load_favourites() if s["id"] != track.get("id")])


def fill_logos(stations):
    """The starter George FM entries have no logo; borrow the directory's.
    Returns True if any were filled in (and saved)."""
    missing = [s for s in stations if not s.get("logo")]
    if not missing:
        return False
    changed = False
    for s in missing:
        try:
            hits = search(s["name"], limit=5)
        except RadioError:
            return changed
        same = next((h for h in hits if h["name"].lower() == s["name"].lower() and h.get("logo")), None)
        if same:
            s["logo"] = s["thumb"] = same["logo"]
            changed = True
    if changed:
        with _lock:
            _write_json(FAVOURITES_FILE, stations)
    return changed


def add_history(track):
    try:
        with open(HISTORY_FILE, encoding="utf-8") as f:
            items = json.load(f)
        items = items if isinstance(items, list) else []
    except (OSError, ValueError):
        items = []
    items = [{k: track.get(k) for k in _KEEP}] + [s for s in items if s.get("id") != track.get("id")]
    _write_json(HISTORY_FILE, items[:30])


# ── Rova stations ─────────────────────────────────────────────────
# The stations in the Rova app (and other Kiwi ones it carries), with the
# same streams it uses, Rova's own logos (vector SVG, sharp at any size) and,
# where Rova has one, the station's big branded picture for the full-screen
# Now Playing view.
ROVA = [
    {"name": 'The Rock', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/rock_net_icy', "tags": 'rock',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/6siD4en5zEb91k3qbuCVuX/f9dee5d779827bacf03655be8d130b48/Station_Rock_logo_red_v2.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/5TqT60sQrwyHSHloUp2D2/0735c1bd35cab913109182a30c3339c1/rock-background-logo.jpg?w=1920&fm=jpg&q=85'},
    {"name": 'The Edge', "url": 'https://mediaworks.streamguys1.com/edge_net_icy', "tags": 'hits',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/3JxliNewTztFQOIfomWczI/7e5618613f5488f3d476ec2a45b94334/edge_orange_web_station_logo.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/21NuDtteZ8SMIIf0YKExf9/37ef1a9d6f646d93718cc0fd544e3ae3/EDG-generic-background-orange-purple-fade.jpg?w=1920&fm=jpg&q=85'},
    {"name": 'The Breeze', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/breeze_net_icy', "tags": 'easy listening',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/4tjqTj4wwXGISDEy9BgXjK/9b177bc2a557966cda14930eb2dabb4b/BRZ-WHT-Web-Logo-Station.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/1Wt6SF7odTtkGFK3JUGERk/8c30993ffe097842bf0ccb7cdadb7fb4/Breeze-1920x1080.jpg?w=1920&fm=jpg&q=85'},
    {"name": 'Breeze Classic', "url": 'https://mediaworks.streamguys1.com/breeze_classic_net_icy', "tags": 'classic hits',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/7cdf4cpL3qLvqAmJqXUfus/2c9a9c052c1a1f37ddb051b6fedf19cb/BZC-MINT-Web-Logo-Station.svg',
     "art": ''},
    {"name": 'The Sound', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/sound_net_icy', "tags": 'classic rock',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/5q0DzIHBpdyxALhXpfAWfF/39f1207391035a8d3720b5737beaa704/Website_Logo_-_Sound_colour.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/6UAK9Uv2GlSzUjShgAKhXH/6be84e571e523163f73a3164f5bc057f/sound_logo_new_landscape.png?w=1920&fm=jpg&q=85'},
    {"name": 'More FM', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/more_net_icy', "tags": 'hits',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/43FvRvV4mKOhI3GsFSOMZ9/c67cafe5df614ac0abe972f9adcfaf56/switcher-logo-morefm.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/3b7r2vpyeiIcM2krNloONz/000d38e8721fe47e66e9064ceb6d7658/MFM-2025-Logo.png?w=1920&fm=jpg&q=85'},
    {"name": 'Magic', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/magic_net_icy', "tags": 'oldies',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/2KYrIjTIZo33qFqznmyRmS/50775fe3ef13a475584bc45de772a84f/Station_Magic_Logo.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/7u8rJhbCm7uxTvdpA5q9TH/123ca53a7a951724cbfaf0bc0b1319b4/MAG-Web-logo-1920x1080.png?w=1920&fm=jpg&q=85'},
    {"name": 'Mai FM', "art_logo": True, "url": 'https://mediaworks.streamguys1.com/mai_net_icy', "tags": 'hip hop, r&b',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/54lX7DxFHJn6oZal1emmVD/6b274110ffba2cc4308ec36e64c8ff68/Mai_Web-Logo.svg',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/33CbGqB9Wtt5ZdX3svED7e/d6ea2792fefee1a63b1df113dda9c9c9/Mai-logo-1920x1080.jpg?w=1920&fm=jpg&q=85'},
    {"name": 'George FM', "url": 'https://mediaworks.streamguys1.com/george_net_icy', "tags": 'dance, house',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/7m1QDg1ret36TEpNiJbDwU/f9c390ef8299e079104006b07e9e95fa/web-station-george.svg',
     "art": ''},
    {"name": 'George FM - Latest Bangers', "art_logo": True, "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/GEORGEFRESHHITS_S01.aac', "tags": 'dance',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/6kYCr49AIFrqBnXRbmHo5M/d8f64b4efeb114d188ce0599d44257c1/lates_bangers_new_new.png?w=800',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/2lKwZf2ICwKLS6wVqI8NGb/ad4296db0061606d812b174ea5386f94/george_latest_hero.png?w=1920&fm=jpg&q=85'},
    {"name": 'George FM - Club Classics', "art_logo": True, "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/GEORGEFM_CC_S01.aac', "tags": 'club classics',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/1hs2ejFCmf8irHi0j8KmZn/1c10053daace384f82288a7b85c22095/Club_Classics_1080x1080.png?w=800',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/6oLorNAs5NYclPwkheK7I2/8ae149cdb0c01f08e2247749ffef9e3c/club_classics_hero.png?w=1920&fm=jpg&q=85'},
    {"name": 'George FM - DnB', "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/GEORGE_DNB_S01.aac', "tags": 'drum and bass',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/2CBBxwPWsAwKU0bjzHM8y1/76fd3e4bab34449b2dff2d2adc719e1d/GRG_George_FM_DnB_Hundy_600x600px.png?w=800',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/5T6RM72xFz6Jve8MbCRyUm/c0c264f5021091ff83f8a36a1b64fd8c/George-DNB-16x9.png?w=1920&fm=jpg&q=85'},
    {"name": 'George FM - Chillsville', "art_logo": True, "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/CHILLSVILLE_S01.aac', "tags": 'chill',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/6fBl7Yr0fvCSKEDkPOFJT7/346791405202f33f8316c8d0001f9659/chillsville_boby_armor_sqaure.png?w=800',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/61yn4PuBeKMAYKidSc5U45/73e7c62a50483e22f57b9a548ee8405b/RVA_GRG_Chillsville_1100x620.png?w=1920&fm=jpg&q=85'},
    {"name": 'George FM - Cocktail Hour', "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/COCKTAILHOUR_S01AAC.aac', "tags": 'lounge',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/308P6uWsXoijQkQbMBTsGV/8a6cca4fc65e97c504a99a8ec44536bb/GRG_RVA_CocktailHour_600x600_1_.png?w=800',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/1nVCkRfVsXzdXh01HClwIE/8d466f0cd4ef277693de0335a1f57239/Cocktail-Hour-16x9__1_.png?w=1920&fm=jpg&q=85'},
    {"name": 'Channel X', "url": 'https://mediaworks.streamguys1.com/chx_net_icy', "tags": 'alternative',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/28nYxhv6C2d4VXcnsVNnvZ/d4b40bf98dae616ff345302f162db28c/Station_Channel-X_Logo.svg',
     "art": ''},
    {"name": 'Rova Chill Hop', "url": 'https://playerservices.streamtheworld.com/api/livestream-redirect/ROVA_CHILLHOP_S01AAC.aac', "tags": 'chill hop',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/2PzsFrZYA30YKP1yexsm9m/2469f8b676cc4ffb5c3e6ca326022bad/chill_hop_new_hero.png?w=1920&fm=jpg&q=85',
     "art": 'https://images.ctfassets.net/r65x6q43xsmv/2PzsFrZYA30YKP1yexsm9m/2469f8b676cc4ffb5c3e6ca326022bad/chill_hop_new_hero.png?w=1920&fm=jpg&q=85'},
    {"name": 'Humm', "url": 'https://mediaworks.streamguys1.com/humm_net_icy', "tags": 'bollywood',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/5eOEqLh5fwka1FvZrcuewe/33ce80ec633cecab75c37a3aeabd8c87/Humm_Website_Logo.svg',
     "art": ''},
    {"name": 'Anthemz', "url": 'https://mediaworks.streamguys1.com/anthemz-chc-high_icy', "tags": 'anthems',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/6LKnL5mmxi74kxWskD8j9l/5347f58964a0131f85fc9eb7bff81227/ANTHEMZ_logo_White.svg',
     "art": ''},
    {"name": 'Sport Nation', "url": 'https://sen.streamguys1.com/SENZ-AAC/playlist.m3u8', "tags": 'sport talk',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/k1SCazT4pcngU4keRQm10/18608eaf5768fe61225f0cb343b4d87c/web-station-sports-nation.svg',
     "art": ''},
    {"name": 'RNZ National', "url": 'http://radionz-ice.streamguys.com/National_aac128', "tags": 'news, talk',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/4jgrliL8niMf6IOOspPTA8/8d3fdaf7c3ec51c86e79f77e221b6a41/RNZ-316x216.svg',
     "art": ''},
    {"name": 'RNZ Concert', "url": 'http://radionz-ice.streamguys.com/Concert_aac128', "tags": 'classical',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/30QQO1mtmsVuwSBrcOmTvP/06dbb260c4caeb9e2633d0c57e030947/RNZ-Concert-316x216.svg',
     "art": ''},
    {"name": 'RNZ Pacific', "url": 'http://radionz-ice.streamguys.com/international_aac64', "tags": 'pacific news',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/15IC2r2eO3FiWZAl6pSvO6/26d8f1fb30327c93d5a273e70b1fbab2/RNZ-Pacific-316x216.svg',
     "art": ''},
    {"name": 'Wellington Access Radio', "url": 'https://live.accessmedia.nz/Wellington.stream/playlist.m3u8', "tags": 'community',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/5JC2OxEQKa1Onb9NGIzqfK/ce1b338c447dc2d8f15342059a5e9fc7/switcher-logo-Wellington_Access_Radio.svg',
     "art": ''},
    {"name": 'Beach FM', "url": 'http://s8.myradiostream.com:58408/', "tags": 'local',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/3Oy8bzOzeCwLpmKWqwQMRg/fe03cadc084f5540c87600293dcc914e/beachfm-logo-white.svg',
     "art": ''},
    {"name": 'BurgerFuel Radio', "url": 'https://s3.radio.co/s9909bd65f/listen', "tags": 'indie',
     "logo": 'https://images.ctfassets.net/r65x6q43xsmv/3Pu2qK3cNwGq9ixLz40x72/0f28d80ddbe6b90d5e8655f0f41df5c8/web-station-BurgerFuel.svg',
     "art": ''},
]
ROVA_BY_URL = {s["url"]: s for s in ROVA}


def rova_stations():
    return [_as_track({"uuid": "", "name": s["name"], "url": s["url"], "logo": s["logo"],
                       "country": "NZ", "tags": s["tags"]}) for s in ROVA]
