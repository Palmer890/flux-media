#!/usr/bin/env python3
"""
FluxTV — visual language for the Qt presentation layer.

Palette sampled directly from the FluxTV app icon: a deep navy-violet
ground with the icon's own two poles as the signal colours — cyan for
every interactive/functional accent (buttons, focus, progress, active
state), violet held in reserve for brand moments (the primary CTA's
gradient, hero glow) rather than scattered across every small UI signal,
so "cyan" still reads as one consistent "the app is talking to you" cue.
"""

from PySide6.QtGui import QFont, QFontDatabase


class C:
    # Stremio 5's palette (stremio-web src/App/styles.less): a near-black
    # ground, a single violet accent for anything interactive or
    # selected, and surfaces that are just white at a few percent over
    # the ground rather than distinct coloured panels.
    void        = "#08070C"   # deepest backdrop
    ink         = "#0C0B11"   # page — their --primary-background-color
    panel       = "#0F0D20"   # menus, modals — their --modal-background-color
    card        = "#17161E"   # tile surface (ground + ~5% white overlay)
    card_hi     = "#211F2B"   # tile, pointer over it
    plate       = "#131219"   # recessed well / input
    hairline    = "#24222E"
    hairline_hi = "#3A3748"

    paper       = "#E6E6E9"   # primary text — white at 90%
    dim         = "#A09FA8"
    faint       = "#6B6978"

    # The names are historical (the palette used to be cyan/violet);
    # every "cyan" is now Stremio's primary accent violet so existing
    # call sites all pick up the one accent colour.
    cyan        = "#7B5BF5"   # their --primary-accent-color
    cyan_hi     = "#9D85FF"
    on_cyan     = "#FFFFFF"
    violet      = "#6242E0"
    violet_hi   = "#B39DFF"

    onair       = "#E5484D"   # live / on-air red
    ok          = "#22B365"   # their --secondary-accent-color (green)
    gold        = "#F6C700"   # their --tertiary-accent-color


#: One grotesque, resolved per platform. Hierarchy comes from size and
#: weight, not from mixing typefaces.
UI_STACK = ("Plus Jakarta Sans", "Inter", "Segoe UI Variable Text", "Segoe UI", "SF Pro Text",
            "Helvetica Neue", "Ubuntu", "Noto Sans", "DejaVu Sans")

#: Tabular figures, used only where digits must align (EPG clock times).
MONO_STACK = ("JetBrains Mono", "Cascadia Mono", "Consolas", "SF Mono",
              "Menlo", "Ubuntu Mono", "DejaVu Sans Mono")

UI_FAMILY = "Sans Serif"
MONO_FAMILY = "Monospace"


def _load_bundled_fonts():
    """Register any .ttf/.otf in a "fonts" folder next to the app, so a
    font like Plus Jakarta Sans can ship with FluxTV instead of having to
    be installed system-wide."""
    import os
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
    if not os.path.isdir(folder):
        return
    for name in sorted(os.listdir(folder)):
        if name.lower().endswith((".ttf", ".otf")):
            QFontDatabase.addApplicationFont(os.path.join(folder, name))


def resolve_fonts():
    global UI_FAMILY, MONO_FAMILY
    _load_bundled_fonts()
    have = {f.lower() for f in QFontDatabase.families()}
    for stack, name in ((UI_STACK, "UI_FAMILY"), (MONO_STACK, "MONO_FAMILY")):
        for candidate in stack:
            if candidate.lower() in have:
                globals()[name] = candidate
                break
    return UI_FAMILY, MONO_FAMILY


def font(size, weight=QFont.Normal, mono=False):
    f = QFont(MONO_FAMILY if mono else UI_FAMILY)
    f.setPixelSize(size)
    f.setWeight(weight)
    return f


# Card geometry. A 16:9 well reads as a screen; the text block below it is
# a fixed height so every tile in a shelf aligns regardless of title length.
CARD_W = 268
WELL_H = 150
# +14 over the original 104 to give the larger EPG text (now/next/time)
# room to breathe rather than crowd the bottom of the tile.
CARD_H = WELL_H + 118

POSTER_W = 200
POSTER_H = int(POSTER_W * 1.44) + 78


QSS = f"""
QWidget {{
    background: {C.ink};
    color: {C.paper};
    font-family: "{{ui}}";
    font-size: 14px;
}}

/* Labels must not paint the page colour when they sit on a card. */
QLabel {{ background: transparent; }}
/* Plain layout containers that must not paint the page colour over a card. */
QWidget#Clear {{ background: transparent; }}
QFrame#Hairline {{ background: {C.hairline}; }}

/* ── chrome ──────────────────────────────────────────────────── */
#TopBar {{
    background: {C.ink};
}}
#NavRail {{
    background: {C.ink};
}}
#Wordmark {{
    font-size: 19px;
    font-weight: 700;
    color: {C.paper};
}}
#TallyBar {{
    background: {C.cyan};
    border-radius: 2px;
}}
#NavButton {{
    background: transparent;
    border: none;
    border-bottom: 2px solid transparent;
    color: {C.dim};
    padding: 8px 2px;
    font-size: 19px;
}}
#NavButton:hover {{
    color: {C.paper};
}}
#NavButton[active="true"] {{
    color: {C.paper};
    font-weight: 700;
    border-bottom: 2px solid {C.cyan};
}}
#IconButton {{
    background: transparent;
    border: none;
    color: {C.dim};
    font-size: 21px;
    padding: 4px 8px;
    border-radius: 6px;
}}
#IconButton:hover {{
    color: {C.paper};
    background: {C.card};
}}
/* Close button gets the universal red-on-hover treatment every OS
   window's own close control uses, so it reads as "closes the app"
   at a glance rather than blending in with the other icon buttons. */
#CloseButton {{
    background: transparent;
    border: none;
    color: {C.dim};
    font-size: 21px;
    padding: 4px 8px;
    border-radius: 6px;
}}
#CloseButton:hover {{
    color: white;
    background: {C.onair};
}}
#ConnStatus {{
    color: {C.dim};
    font-size: 13px;
}}

/* ── headings ────────────────────────────────────────────────── */
#Greeting {{
    font-size: 30px;
    font-weight: 700;
    color: {C.paper};
}}
#ShelfTitle {{
    font-size: 22px;
    font-weight: 600;
    color: {C.paper};
}}
#ShelfCount {{
    font-family: "{{mono}}";
    font-size: 12px;
    color: {C.faint};
}}
#Muted {{ color: {C.dim}; }}
#Faint {{ color: {C.faint}; font-size: 13px; }}
#Mono  {{ font-family: "{{mono}}"; font-size: 12px; color: {C.faint}; }}

/* ── cards ───────────────────────────────────────────────────── */
/* Stremio-style tiles: no box around the whole card — the artwork
   sits on its own rounded tile and the text reads straight off the
   page. Hover/focus draws a white ring around the tile (the "hot"
   property, set from code, since QSS can't restyle a child on a
   parent's hover). */
#Card {{
    background: transparent;
    border: none;
}}
#CardWell, #PosterWell {{
    background: {C.card};
    border: none;
    border-radius: 12px;
}}
#HotRing {{
    background: transparent;
    border: 2px solid rgba(255, 255, 255, 0.92);
    border-radius: 12px;
}}
#CardTitle {{
    font-size: 17px;
    font-weight: 600;
    color: {C.paper};
    background: transparent;
}}
#CardNow {{
    font-size: 16px;
    color: {C.dim};
    background: transparent;
}}
#CardNext {{
    font-size: 14px;
    color: {C.faint};
    background: transparent;
}}
#CardTime {{
    font-family: "{{mono}}";
    font-size: 15px;
    color: {C.faint};
    background: transparent;
}}
#Monogram {{
    font-size: 30px;
    font-weight: 700;
    color: {C.hairline_hi};
    background: transparent;
}}
#OnAir {{
    color: {C.onair};
    font-size: 11px;
    font-weight: 700;
    background: transparent;
}}
#Badge {{
    background: {C.void};
    color: {C.cyan};
    font-size: 11px;
    font-weight: 700;
    border-radius: 4px;
    padding: 2px 7px;
}}
#Star {{
    background: transparent;
    border: none;
    color: {C.faint};
    font-size: 16px;
}}
#Star[on="true"] {{ color: {C.cyan}; }}
#Star:hover {{ color: {C.paper}; }}

/* Progress through the current programme. */
QProgressBar#Epg {{
    background: {C.hairline};
    border: none;
    border-radius: 2px;
    max-height: 3px;
    min-height: 3px;
}}
QProgressBar#Epg::chunk {{
    background: {C.cyan};
    border-radius: 2px;
}}

/* Focus overlay: the card's actions only appear once it has focus. */
#Overlay {{
    background: rgba(12, 11, 17, 0.72);
    border-radius: 12px;
}}

/* ── buttons ─────────────────────────────────────────────────── */
#Primary {{
    background: {C.cyan};
    color: {C.on_cyan};
    border: none;
    border-radius: 10px;
    padding: 11px 22px;
    font-size: 14px;
    font-weight: 700;
}}
#Primary:hover  {{ background: {C.cyan_hi}; }}
#Primary:pressed {{ padding-top: 12px; padding-bottom: 10px; }}

#Ghost {{
    background: rgba(255, 255, 255, 0.08);
    color: {C.paper};
    border: none;
    border-radius: 10px;
    padding: 10px 18px;
    font-size: 14px;
    font-weight: 700;
}}
#Ghost:hover {{ background: rgba(255, 255, 255, 0.16); }}

#Danger {{
    background: #2A1618;
    color: #F08A8A;
    border: 1px solid #4A2327;
    border-radius: 8px;
    padding: 10px 18px;
    font-weight: 700;
}}
#Danger:hover {{ background: #3A1D20; }}

#Arrow {{
    background: rgba(255, 255, 255, 0.06);
    color: {C.paper};
    border: none;
    border-radius: 16px;
    font-size: 15px;
    font-weight: 700;
}}
#Arrow:hover {{ background: rgba(255, 255, 255, 0.16); }}
#Arrow:disabled {{ color: {C.hairline_hi}; background: transparent; }}

/* ── inputs ──────────────────────────────────────────────────── */
QLineEdit {{
    background: {C.plate};
    color: {C.paper};
    border: 2px solid {C.hairline};
    border-radius: 8px;
    padding: 11px 13px;
    selection-background-color: {C.cyan};
    selection-color: {C.on_cyan};
}}
QLineEdit:focus {{ border: 2px solid {C.cyan}; }}
QLineEdit::placeholder {{ color: {C.faint}; }}

/* Stremio's search: a pill of faint white over the page, outlined in
   white only while focused. */
#SearchWrap {{
    background: rgba(255, 255, 255, 0.06);
    border: 2px solid transparent;
    border-radius: 23px;
}}
#SearchWrap[focused="true"] {{ border: 2px solid rgba(255, 255, 255, 0.85); }}
#SearchField {{
    background: transparent;
    border: none;
    padding: 8px 4px;
    font-size: 16px;
}}
#SearchField:focus {{ border: none; }}

/* Password field with a reveal toggle, the way a streaming app does it. */
#PwdWrap {{
    background: {C.plate};
    border: 2px solid {C.hairline};
    border-radius: 8px;
}}
#PwdWrap[focused="true"] {{ border: 2px solid {C.cyan}; }}
#PwdField {{
    background: transparent;
    border: none;
    padding: 9px 2px;
}}
#PwdField:focus {{ border: none; }}
#Eye {{
    background: transparent;
    border: none;
    color: {C.faint};
    font-size: 15px;
    padding: 0 4px;
}}
#Eye:hover {{ color: {C.paper}; }}
#Eye[on="true"] {{ color: {C.cyan}; }}

#Panel {{
    background: {C.card};
    border: 1px solid {C.hairline};
    border-radius: 14px;
}}
#Hairline {{ background: {C.hairline}; max-height: 1px; min-height: 1px; }}

/* ── scrolling ───────────────────────────────────────────────── */
QScrollArea {{ background: transparent; border: none; }}
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {C.hairline};
    border-radius: 5px;
    min-height: 40px;
}}
QScrollBar::handle:vertical:hover {{ background: {C.hairline_hi}; }}
QScrollBar::add-line, QScrollBar::sub-line,
QScrollBar::add-page, QScrollBar::sub-page {{
    background: none; border: none; height: 0; width: 0;
}}
QScrollBar:horizontal {{ height: 0px; background: transparent; }}

/* ── filter chip menu ───────────────────────────────────────────── */
QMenu {{
    background: {C.card};
    color: {C.paper};
    border: 1px solid {C.hairline};
    border-radius: 8px;
    padding: 6px;
    menu-scrollable: 1;
}}
QMenu::item {{
    padding: 7px 14px;
    border-radius: 5px;
}}
QMenu::item:selected {{
    background: {C.cyan};
    color: {C.on_cyan};
}}
QMenu::separator {{
    height: 1px;
    background: {C.hairline};
    margin: 5px 4px;
}}

/* ── slider (Settings > Playback) ───────────────────────────────── */
QSlider {{ background: transparent; }}
QSlider::groove:horizontal {{
    height: 4px;
    background: {C.plate};
    border-radius: 2px;
}}
QSlider::sub-page:horizontal {{
    height: 4px;
    background: {C.cyan};
    border-radius: 2px;
}}
QSlider::add-page:horizontal {{
    height: 4px;
    background: {C.plate};
    border-radius: 2px;
}}
QSlider::handle:horizontal {{
    background: {C.paper};
    width: 15px;
    height: 15px;
    margin: -6px 0;
    border-radius: 7px;
}}
QSlider::handle:horizontal:hover {{ background: {C.cyan_hi}; }}

/* ── checkbox (Settings) ─────────────────────────────────────────── */
QCheckBox {{
    spacing: 9px;
    color: {C.dim};
    background: transparent;
}}
QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid {C.hairline_hi};
    background: {C.plate};
}}
QCheckBox::indicator:checked {{
    background: {C.cyan};
    border: 1px solid {C.cyan};
    image: none;
}}
QCheckBox::indicator:hover {{ border-color: {C.cyan}; }}

/* ── poster card (Movies / Series) ──────────────────────────────── */
#PosterWell {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 #191D40, stop:0.6 {C.plate}, stop:1 #0C0E20);
    border-top-left-radius: 11px;
    border-top-right-radius: 11px;
}}
#PosterBadge {{
    background: {C.void};
    color: {C.cyan};
    font-size: 11px;
    font-weight: 700;
    border-radius: 4px;
    padding: 2px 7px;
}}
#PosterRating {{
    background: {C.void};
    color: {C.gold};
    font-size: 11px;
    font-weight: 700;
    border-radius: 4px;
    padding: 2px 7px;
}}

/* ── grid screens (Live TV / Movies / Series / Favourites) ──────── */
#ScreenTitle {{
    font-size: 28px;
    font-weight: 700;
    color: {C.paper};
}}

/* ── TV Guide ─────────────────────────────────────────────────── */
#GuideSidebar {{
    background: transparent;
    border: none;
    border-right: 1px solid {C.hairline};
}}
#GuideTimeline {{
    background: transparent;
}}
#GuideCatchup {{
    background: rgba(123, 91, 245, 0.18);
    color: {C.violet_hi};
    border: 1px solid rgba(123, 91, 245, 0.45);
    border-radius: 10px;
    font-size: 18px;
    font-weight: 800;
}}
#GuideCatchup:hover {{ background: {C.cyan}; color: white; }}

#GuideChannelName {{
    font-size: 15px;
    font-weight: 600;
    color: {C.paper};
    background: transparent;
    text-align: left;
    padding-left: 6px;
    border: none;
    border-bottom: 1px solid {C.hairline};
    border-radius: 0;
}}
#GuideChannelName:hover {{
    color: {C.cyan_hi};
    background: {C.card};
}}
#GuideNoData {{
    font-size: 13px;
    color: {C.faint};
    background: transparent;
}}
#GuideEmpty {{
    font-size: 16px;
    color: {C.dim};
    background: transparent;
    padding: 18px 4px;
}}
#GuideMode {{
    background: rgba(255, 255, 255, 0.06);
    color: {C.dim};
    border: none;
    border-radius: 16px;
    padding: 8px 18px;
    font-size: 14px;
    font-weight: 600;
}}
#GuideMode:hover {{
    background: rgba(255, 255, 255, 0.14);
    color: {C.paper};
}}
#GuideMode:checked {{
    background: {C.cyan};
    color: {C.on_cyan};
    border: 1px solid transparent;
}}
#GuideRuler {{
    background: {C.ink};
    border-bottom: 1px solid {C.hairline};
}}
#GuideRulerLabel {{
    font-family: "{{mono}}";
    font-size: 12px;
    color: {C.dim};
    background: transparent;
}}
#GuideRow {{
    background: transparent;
    border-bottom: 1px solid {C.hairline};
}}
#GuideBlock {{
    background: {C.card};
    color: {C.dim};
    border: none;
    border-radius: 6px;
    text-align: left;
    padding-left: 8px;
    font-size: 13px;
}}
#GuideBlock:hover {{
    background: {C.card_hi};
    color: {C.paper};
}}
#GuideBlockAiring {{
    background: {C.cyan};
    color: {C.on_cyan};
    border: none;
    border-radius: 6px;
    text-align: left;
    padding-left: 8px;
    font-size: 13px;
    font-weight: 700;
}}
#GuideBlockAiring:hover {{
    background: {C.cyan_hi};
}}
#GuideNowLine {{
    background: {C.onair};
}}
#EpisodeRow {{
    background: {C.card};
    border-radius: 8px;
}}
#EpisodeRow:hover {{ background: {C.card_hi}; }}
#SeasonLabel {{
    font-size: 15px;
    font-weight: 700;
    color: {C.paper};
}}


/* ── detail pages (movies / series) ──────────────────────────── */
#MiniPlayer {{
    background: {C.panel};
    border-top: 1px solid {C.hairline_hi};
}}

#NowTitle {{
    font-size: 34px;
    font-weight: 800;
    color: {C.paper};
    background: transparent;
}}

#HeroTitle {{
    font-size: 46px;
    font-weight: 800;
    color: {C.paper};
    background: transparent;
}}
#HeroFacts {{
    font-size: 16px;
    font-weight: 600;
    color: {C.paper};
    background: transparent;
}}
#HeroGenres {{
    font-size: 15px;
    color: {C.dim};
    background: transparent;
}}
#HeroPlot {{
    font-size: 17px;
    color: rgba(230, 230, 233, 0.88);
    background: transparent;
}}
#HeroCredits {{
    font-size: 14px;
    color: {C.dim};
    background: transparent;
}}
#HeroPlay {{
    background: {C.cyan};
    color: white;
    border: none;
    border-radius: 14px;
    padding: 15px 34px;
    font-size: 17px;
    font-weight: 700;
}}
#HeroPlay:hover {{ background: {C.cyan_hi}; }}
#HeroPlay:disabled {{ background: rgba(123, 91, 245, 0.35); color: rgba(255,255,255,0.6); }}
#HeroGhost {{
    background: rgba(255, 255, 255, 0.10);
    color: {C.paper};
    border: none;
    border-radius: 14px;
    padding: 15px 26px;
    font-size: 16px;
    font-weight: 700;
}}
#HeroGhost:hover {{ background: rgba(255, 255, 255, 0.20); }}
#BannerTitle {{
    font-size: 38px;
    font-weight: 800;
    color: {C.paper};
    background: transparent;
}}
#LoginTitle {{
    font-size: 26px;
    font-weight: 800;
    color: {C.paper};
}}
#SeeAll {{
    background: rgba(255, 255, 255, 0.06);
    color: {C.dim};
    border: none;
    border-radius: 15px;
    padding: 6px 14px;
    font-size: 14px;
    font-weight: 600;
}}
#SeeAll:hover {{ background: rgba(255, 255, 255, 0.14); color: {C.paper}; }}
#HeroTag {{
    background: rgba(123, 91, 245, 0.9);
    color: white;
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1px;
}}
#EpisodePanel {{
    background: rgba(12, 11, 17, 0.80);
    border-left: 1px solid rgba(255, 255, 255, 0.06);
}}
#PanelHeading {{
    font-size: 22px;
    font-weight: 700;
    color: {C.paper};
    background: transparent;
    padding-left: 4px;
}}

/* ── in-app player ───────────────────────────────────────────── */
#PlayerScreen {{
    background: black;
}}
/* The ONE unified control panel — fully opaque (no rgba, no alpha at
   all). Proven to render correctly on this app's embedded-video setup;
   a fully transparent version of this same panel did not render at
   all, since alpha-blending against a natively embedded video surface
   needs a compositing window manager that isn't reliably there. */
#PlayerPanel {{
    background: {C.void};
    border: 1px solid {C.hairline};
    border-radius: 14px;
}}
#PlayerTitle {{
    color: {C.paper};
    font-size: 22px;
    font-weight: 700;
    background: transparent;
}}
#PlayerSub {{
    color: {C.dim};
    font-size: 18px;
    background: transparent;
}}
#PlayerBtn {{
    background: transparent;
    border: none;
    color: {C.paper};
    font-size: 15px;
    border-radius: 15px;
    padding: 5px;
}}
#PlayerBtn:hover {{
    background: rgba(255,255,255,0.10);
    color: {C.cyan_hi};
}}
#PlayerBtnBig {{
    background: rgba(255,255,255,0.10);
    border: none;
    color: {C.paper};
    font-size: 17px;
    border-radius: 17px;
    padding: 6px;
}}
#PlayerBtnBig:hover {{
    background: rgba(255,255,255,0.18);
    color: {C.cyan_hi};
}}
#PlayerTime {{
    font-family: "{{mono}}";
    font-size: 17px;
    color: {C.dim};
    background: transparent;
}}
#LiveBadge {{
    background: {C.onair};
    color: white;
    font-size: 15px;
    font-weight: 700;
    border-radius: 4px;
    padding: 4px 10px;
}}

QSlider#PlayerSeek::groove:horizontal {{
    height: 3px;
    background: #9096AC;
    border-radius: 1px;
}}
QSlider#PlayerSeek::sub-page:horizontal {{
    height: 4px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {C.cyan}, stop:1 {C.violet});
    border-radius: 2px;
}}
QSlider#PlayerSeek::add-page:horizontal {{
    height: 3px;
    background: #9096AC;
    border-radius: 1px;
}}
QSlider#PlayerSeek::handle:horizontal {{
    background: {C.paper};
    width: 12px;
    height: 12px;
    margin: -5px 0;
    border-radius: 6px;
}}
QSlider#PlayerSeek::handle:horizontal:hover {{
    background: {C.cyan_hi};
}}

QSlider#PlayerVolume::groove:horizontal {{
    height: 3px;
    background: #9096AC;
    border-radius: 1px;
}}
QSlider#PlayerVolume::sub-page:horizontal {{
    height: 3px;
    background: {C.paper};
    border-radius: 1px;
}}
QSlider#PlayerVolume::handle:horizontal {{
    background: {C.paper};
    width: 10px;
    height: 10px;
    margin: -4px 0;
    border-radius: 5px;
}}

QToolTip {{
    background: {C.card};
    color: {C.paper};
    border: 1px solid {C.hairline};
    padding: 5px 8px;
}}
"""


def stylesheet():
    ui, mono = resolve_fonts()
    return QSS.replace("{ui}", ui).replace("{mono}", mono)
