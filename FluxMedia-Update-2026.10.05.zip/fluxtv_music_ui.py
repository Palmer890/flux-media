"""
Flux Media (FluxTV) — Music: YouTube songs and radio, Now Playing, playlists, the mini player.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QSize, QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QRadialGradient, QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (LOGOS, LazyGrid, PosterShelf, _arrow_direction, _format_hms, _rounded, _set_hot, _soft_blur, background, monogram)


# ══════════════════════════════════════════════════════════════════
# Music (YouTube)
# ══════════════════════════════════════════════════════════════════
VIDEO_W, VIDEO_ART_H = 304, 171


VIDEO_H = VIDEO_ART_H + 70


def _duration_text(track):
    if track.get("live"):
        return "LIVE"
    return _format_hms(track.get("duration")) if track.get("duration") else ""


class VideoCard(QFrame):
    """A YouTube tile: 16:9 thumbnail with its length, title, channel.
    Right-click, the keyboard's Menu key (or M), or the \u22ef button on
    the tile open its menu: play next, add to queue, add to a playlist."""

    opened = Signal(object)
    menu_requested = Signal(object, QPoint)

    def __init__(self, track, parent=None):
        super().__init__(parent)
        self.item = track
        self.setObjectName("Card")
        self.setFixedSize(VIDEO_W, VIDEO_H)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setCursor(Qt.PointingHandCursor)
        self._nav_container = None
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.well = QFrame(self)
        self.well.setObjectName("PosterWell")
        self.well.setFixedHeight(VIDEO_ART_H)
        self.art = QLabel(self.well)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setText("♫")
        self.art.setFixedSize(VIDEO_W, VIDEO_ART_H)
        for text, left in ((track.get("_badge") or "", True), (_duration_text(track), False)):
            if not text:
                continue
            badge = QLabel(text, self.well)
            badge.setObjectName("PosterBadge")
            badge.adjustSize()
            badge.move(10 if left else VIDEO_W - badge.width() - 10,
                       10 if left else VIDEO_ART_H - badge.height() - 10)
            badge.raise_()
        root.addWidget(self.well)
        body = QVBoxLayout()
        body.setContentsMargins(4, 10, 4, 8)
        body.setSpacing(3)
        for text, name in ((track.get("title", ""), "CardTitle"),
                           (track.get("channel", ""), "CardNow")):
            label = QLabel(self)
            label.setObjectName(name)
            label.ensurePolished()
            label.setText(label.fontMetrics().elidedText(text, Qt.ElideRight, VIDEO_W - 12))
            body.addWidget(label)
        body.addStretch(1)
        root.addLayout(body)
        self.more = QPushButton("\u22ef", self.well)
        self.more.setObjectName("Arrow")
        self.more.setFixedSize(40, 32)
        self.more.setCursor(Qt.PointingHandCursor)
        self.more.setFocusPolicy(Qt.NoFocus)
        self.more.setToolTip("Play next, add to queue or a playlist")
        self.more.move(VIDEO_W - 50, 10)
        self.more.clicked.connect(lambda: self.menu_requested.emit(
            self.item, self.more.mapToGlobal(QPoint(0, self.more.height()))))
        self.more.hide()
        radio = track.get("kind") == "radio"
        if radio:
            self.art.setText(monogram(track.get("title", "")))
        self._mode = "contain" if radio else "cover"
        self._box = (VIDEO_W - 60, VIDEO_ART_H - 44) if radio else (VIDEO_W, VIDEO_ART_H)
        self._art_url = track.get("thumb") or ""
        LOGOS.ready.connect(self._logo_ready)
        if self._art_url:
            pix = LOGOS.get(self._art_url, self._box, mode=self._mode)
            if pix:
                self._apply(pix)
            else:
                LOGOS.request(self._art_url, self._box, mode=self._mode)

    def _apply(self, pix):
        self.art.setPixmap(_rounded(pix, 12) if self._mode == "cover" else pix)
        self.art.setText("")

    @Slot(str)
    def _logo_ready(self, url):
        if url == self._art_url:
            pix = LOGOS.get(url, self._box, mode=self._mode)
            if pix:
                self._apply(pix)

    def _hot(self, on):
        _set_hot(self.well, on)
        self.more.setVisible(on and self.item.get("_menu", True))

    def enterEvent(self, event):
        super().enterEvent(event)
        self._hot(True)

    def leaveEvent(self, event):
        super().leaveEvent(event)
        if not self.hasFocus():
            self._hot(False)

    def focusInEvent(self, event):
        super().focusInEvent(event)
        self._hot(True)

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        self._hot(self.underMouse())

    def mouseReleaseEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        self.setFocus(Qt.MouseFocusReason)
        self.opened.emit(self.item)

    def contextMenuEvent(self, event):
        self.menu_requested.emit(self.item, event.globalPos())

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.opened.emit(self.item)
            return
        if event.key() in (Qt.Key_Menu, Qt.Key_M):
            self.menu_requested.emit(self.item, self.mapToGlobal(QPoint(40, 60)))
            return
        direction = _arrow_direction(event)
        if direction and self._nav_container is not None:
            target = self._nav_container.nav_neighbor(self, direction)
            if target is not None:
                target.setFocus(Qt.OtherFocusReason)
                return
        super().keyPressEvent(event)


class VideoShelf(PosterShelf):
    """A sideways row of YouTube tiles; says which one was picked."""

    opened_at = Signal(int)
    menu_at = Signal(int, QPoint)
    SHELF_CARD_W, SHELF_CARD_H = VIDEO_W, VIDEO_H
    MAX = 40

    def _build(self, count):
        end = min(len(self._metas), self._built + count)
        for i in range(self._built, end):
            card = VideoCard(self._metas[i])
            card.opened.connect(lambda _t, i=i: self.opened_at.emit(i))
            card.menu_requested.connect(lambda _t, pos, i=i: self.menu_at.emit(i, pos))
            self._lay.insertWidget(self._lay.count() - 1, card)
        self._built = end


def _tidy_song_title(title):
    """Stations' "now playing" text, tidied: George FM sends every title
    twice ("Artist - Song - Artist - Song")."""
    import html
    title = " ".join(html.unescape(str(title)).split()).strip(" -")
    parts = title.split(" - ")
    half = len(parts) // 2
    if len(parts) % 2 == 0 and half and parts[:half] == parts[half:]:
        title = " - ".join(parts[:half])
    return title


class MusicController(QObject):
    """The music queue and its playback. Listen mode plays through a
    second, window-less mpv (sound only); Watch mode hands each video to
    the normal player through watch_cb and is told when it ends. Either
    way the queue keeps itself topped up from YouTube's Mix, so the music
    never runs out."""

    track_changed = Signal(object)        # the track dict, or None when stopped
    position = Signal(float, float)       # seconds, duration
    paused = Signal(bool)
    queue_changed = Signal()
    state = Signal(str, str)              # loading / playing / error / skip / stopped, text
    song_title = Signal(str)              # a radio station's "now playing", as it changes
    _prop = Signal(str, object)

    LINK_LIFE = 3 * 3600                  # YouTube links last ~6h

    def __init__(self, parent=None):
        super().__init__(parent)
        self.queue = []
        self.index = -1
        self.mode = "listen"
        self.watch_cb = None              # (track, links, start_seconds)
        self.stopped = True
        self._player = None
        self._gen = 0
        self._links = {}
        self._skips = []
        self._skipped = set()
        self._seen_ids = set()
        self._extending = False
        self._want_next = False
        self._fails = 0
        self._active = False
        self._seen_running = False
        self._idle = True
        self._pos = 0.0
        self._dur = 0.0
        self._paused = False
        self._prop.connect(self._on_prop, Qt.QueuedConnection)

    # ── state ──────────────────────────────────────────────────
    @property
    def current(self):
        return self.queue[self.index] if 0 <= self.index < len(self.queue) else None

    def up_next(self, count=12):
        return list(enumerate(self.queue))[self.index + 1:self.index + 1 + count]

    def is_playing_sound(self):
        return not self.stopped and self.mode == "listen"

    @property
    def is_radio(self):
        return (self.current or {}).get("kind") == "radio"

    # ── the sound-only player ──────────────────────────────────
    def _audio(self):
        if self._player is None:
            if not fluxtv_player.AVAILABLE:
                raise RuntimeError("sound-only playback needs libmpv")
            import locale
            locale.setlocale(locale.LC_NUMERIC, "C")
            p = fluxtv_player.mpv.MPV(vid="no", audio_display="no", idle="yes",
                                      keep_open="no", ytdl=False, osc=False,
                                      input_default_bindings=False,
                                      input_vo_keyboard=False,
                                      audio_client_name="Flux Media",
                                      **fluxtv_player.tls_options())
            for name in ("time-pos", "duration", "pause", "idle-active", "metadata"):
                p.observe_property(name, lambda n, v: self._prop.emit(n, v))
            self._player = p
        return self._player

    def _audio_cmd(self, *args):
        if self._player is not None:
            try:
                self._player.command(*args)
            except Exception:
                pass

    def shutdown(self):
        self._active = False
        if self._player is not None:
            try:
                self._player.terminate()
            except Exception:
                pass
            self._player = None

    # ── playing ────────────────────────────────────────────────
    def play_tracks(self, tracks, index=0, mode=None):
        if mode:
            self.mode = mode
        if tracks and tracks[0].get("kind") == "radio":
            self.mode = "listen"                # radio is sound only
        self.queue = [dict(t) for t in tracks]
        self.index = max(0, min(index, len(self.queue) - 1))
        self._seen_ids = {t["id"] for t in self.queue}
        self._fails = 0
        self.queue_changed.emit()
        self._play_current()

    def _play_current(self, start=0):
        track = self.current
        if track is None:
            self.stop()
            return
        self._gen += 1
        gen = self._gen
        self.stopped = False
        self._want_next = False
        self._skips, self._skipped = [], set()
        self._pos, self._dur = 0.0, float(track.get("duration") or 0)
        if self._active:
            # Pause, not stop: a "stop" makes mpv report going idle, which
            # can arrive after the next song has started and look like
            # that one failing.
            self._active = False
            self._set_audio("pause", True)
        self.now_title = ""
        self.track_changed.emit(track)
        self.state.emit("loading", "")
        if track.get("kind") == "radio":
            links = {"url": track["url"], "audio": "", "user_agent": "FluxMedia/1.0",
                     "live": True, "resolved": time.time()}
            self._start(gen, track, links, 0)
            background(lambda: fluxtv_radio.count_click(track), lambda _r: None, lambda _e: None)
            self.queue_changed.emit()
            return
        mode = self.mode
        links = self._links.get((track["id"], mode))
        if links and time.time() - links["resolved"] < self.LINK_LIFE:
            self._start(gen, track, links, start)
        else:
            background(lambda: fluxtv_youtube.resolve(track["id"], mode),
                       lambda found: self._resolved(gen, track, mode, found, start),
                       lambda error: self._failed(gen, track, error))
        background(lambda: fluxtv_youtube.skip_segments(track["id"]),
                   lambda segs: self._set_skips(gen, segs), lambda _e: None)
        self._maybe_extend()
        self.queue_changed.emit()

    def _set_skips(self, gen, segments):
        if gen == self._gen:
            self._skips = segments

    def _resolved(self, gen, track, mode, links, start):
        self._links[(track["id"], mode)] = links
        if gen == self._gen:
            self._start(gen, track, links, start)

    def _start(self, gen, track, links, start):
        for key in ("title", "channel"):
            track[key] = track.get(key) or links.get(key) or ""
        track["live"] = links.get("live", track.get("live"))
        if links.get("duration"):
            track["duration"] = links["duration"]
            self._dur = float(links["duration"])
        if self.mode == "watch":
            if self.watch_cb:
                self.watch_cb(track, links, start)
            self.state.emit("playing", "")
            self._played(track)
        else:
            try:
                p = self._audio()
                p["user-agent"] = links.get("user_agent") or "Mozilla/5.0"
                p["start"] = str(int(start)) if start else "none"
                p["pause"] = False
                self._active = True
                self._seen_running = False      # set by the new song's first position
                p.command("loadfile", links["url"], "replace")
                QTimer.singleShot(30_000, lambda: self._check_started(gen))
            except Exception as error:
                self._active = False
                self.state.emit("error", f"Couldn't start sound-only playback ({error}). "
                                         "Switch to Watch to play the videos instead.")
                self.stopped = True
                return
        self._prefetch_next()

    def _check_started(self, gen):
        if gen == self._gen and self._active and self._pos == 0.0 and self.mode == "listen":
            self._active = False
            self._failed(gen, self.current, "it didn't start")

    def _set_audio(self, key, value):
        if self._player is not None:
            try:
                self._player[key] = value
            except Exception:
                pass

    def _played(self, track):
        try:
            if track.get("kind") == "radio":
                fluxtv_radio.add_history(track)
            else:
                fluxtv_youtube.add_history(track)
        except OSError:
            pass

    def _failed(self, gen, track, error):
        if gen != self._gen:
            return
        self._active = False
        self._fails += 1
        name = (track or {}).get("title") or "this one"
        if (track or {}).get("kind") == "radio":
            # A station that won't play: say so, don't hop to another one.
            self.state.emit("error", f"Couldn't play {name}: {error}")
            self.stopped = True
            return
        if self._fails >= 3:
            self.state.emit("error", f"Couldn't play “{name}”: {error}")
            self.stopped = True
            return
        self.state.emit("error", f"Skipping “{name}” — {error}")
        QTimer.singleShot(1800, lambda: gen == self._gen and self.next())

    def _prefetch_next(self):
        if self.index + 1 >= len(self.queue) or \
                self.queue[self.index + 1].get("kind") == "radio":
            return
        track, mode = self.queue[self.index + 1], self.mode
        have = self._links.get((track["id"], mode))
        if have and time.time() - have["resolved"] < self.LINK_LIFE:
            return

        def keep(links):
            self._links[(track["id"], mode)] = links
        background(lambda: fluxtv_youtube.resolve(track["id"], mode), keep, lambda _e: None)

    def _maybe_extend(self):
        """Top the queue up from the Mix of what's playing, like YouTube's
        autoplay, whenever fewer than five songs are left."""
        if self._extending or len(self.queue) - self.index > 5 or self.current is None \
                or self.is_radio:
            return
        self._extending = True
        seed = self.current["id"]

        def done(tracks):
            self._extending = False
            fresh = [dict(t, _auto=True) for t in tracks if t["id"] not in self._seen_ids]
            self._seen_ids.update(t["id"] for t in fresh)
            self.queue.extend(fresh)
            self.queue_changed.emit()
            if fresh:
                self._prefetch_next()
            if self._want_next:
                self.next()

        def failed(_error):
            self._extending = False
            if self._want_next:
                self._want_next = False
                self.stop()
        background(lambda: fluxtv_youtube.mix(seed), done, failed)

    # ── editing the queue ──────────────────────────────────────
    def play_next(self, tracks):
        """Straight after the current song."""
        fresh = [dict(t, _auto=False) for t in tracks]
        self.queue[self.index + 1:self.index + 1] = fresh
        self._seen_ids.update(t["id"] for t in fresh)
        self.queue_changed.emit()
        self._prefetch_next()

    def add_to_queue(self, tracks):
        """After anything already queued, but before the songs the Mix
        filled in, so your picks come first."""
        fresh = [dict(t, _auto=False) for t in tracks]
        at = next((i for i in range(self.index + 1, len(self.queue))
                   if self.queue[i].get("_auto")), len(self.queue))
        self.queue[at:at] = fresh
        self._seen_ids.update(t["id"] for t in fresh)
        self.queue_changed.emit()
        if at == self.index + 1:
            self._prefetch_next()

    def remove_at(self, index):
        if self.index < index < len(self.queue):
            del self.queue[index]
            self.queue_changed.emit()

    # ── controls ───────────────────────────────────────────────
    def next(self):
        if self.index + 1 < len(self.queue):
            self.index += 1
            self._play_current()
        elif self._extending:
            self._want_next = True
        else:
            self.stop()

    def previous(self):
        if self.mode == "listen" and self._pos > 5 and not self.is_radio:
            self.seek(0)
        elif self.index > 0:
            self.index -= 1
            self._play_current()

    def jump(self, index):
        if 0 <= index < len(self.queue):
            self.index = index
            self._play_current()

    def toggle_pause(self):
        if self._active:
            self._audio_cmd("cycle", "pause")

    def seek(self, seconds):
        if self._active:
            self._audio_cmd("seek", f"{max(0.0, seconds):.2f}", "absolute")

    def seek_relative(self, delta):
        if self._active:
            self._audio_cmd("seek", str(delta), "relative")

    def stop(self):
        self._gen += 1
        self._active = False
        self._audio_cmd("stop")
        self.stopped = True
        self._pos = self._dur = 0.0
        self.track_changed.emit(None)
        self.state.emit("stopped", "")

    def switch_to_watch(self):
        """Now Playing's "Watch the video": same song, same place."""
        if self.current is None or self.is_radio:
            return
        start = self._pos if self.mode == "listen" else 0
        self.mode = "watch"
        self._play_current(start=max(0, start - 1))

    # ── Watch mode: the app's player reports back ──────────────
    def on_watch_ended(self, reason):
        if self.mode != "watch" or self.stopped:
            return
        if reason == "eof":
            self._fails = 0
            self.next()
        else:
            self._failed(self._gen, self.current, "the video stopped loading")

    def watch_stopped(self):
        if self.mode == "watch" and not self.stopped:
            self.stop()

    def skip_target(self, position):
        """Where to jump if `position` is inside a SponsorBlock segment
        (the talking bits of a music video, plugs, intros)."""
        for i, (start, end) in enumerate(self._skips):
            if start <= position < end - 0.5 and i not in self._skipped:
                self._skipped.add(i)
                return end
        return None

    # ── mpv thread → here ──────────────────────────────────────
    def _on_prop(self, name, value):
        number = isinstance(value, (int, float)) and not isinstance(value, bool)
        if name == "time-pos":
            if not (number and self._active):
                return
            self._seen_running = True
            if self._pos == 0.0 and value > 0:
                self._fails = 0
                self.state.emit("playing", "")
                self._played(self.current or {})
            self._pos = float(value)
            target = self.skip_target(self._pos)
            if target is not None:
                if self._dur and target >= self._dur - 1:
                    self.next()
                    return
                self.seek(target)
                self.state.emit("skip", "Skipped the non-music part")
            self.position.emit(self._pos, self._dur)
        elif name == "duration" and number and self._active:
            self._dur = float(value)
        elif name == "pause" and isinstance(value, bool):
            self._paused = value
            self.paused.emit(value)
        elif name == "metadata":
            if self.is_radio and isinstance(value, dict):
                title = value.get("icy-title") or value.get("StreamTitle") or \
                    value.get("title") or ""
                title = _tidy_song_title(title)
                if title and title != getattr(self, "now_title", ""):
                    self.now_title = title
                    self.song_title.emit(title)
        elif name == "idle-active":
            self._idle = bool(value)
            if not self._active:
                return
            if not self._idle:
                self._seen_running = True
            elif self._seen_running and self.is_radio:
                # Live streams drop now and then: reconnect to the station.
                self._active = False
                gen = self._gen
                self._fails += 1
                if self._fails > 4:
                    self._failed(gen, self.current, "the station keeps dropping out")
                    return
                self.state.emit("error", "Station dropped out \u2014 reconnecting\u2026")
                QTimer.singleShot(2000, lambda: gen == self._gen and self._play_current())
            elif self._seen_running:
                self._active = False
                if self._dur <= 0 or self._pos >= self._dur - 5:
                    self.next()
                else:
                    self._failed(self._gen, self.current, "the stream stopped")


class MusicView(QWidget):
    """The Music page: search results, or rows of recently played, this
    week's chart and a Mix of the last song played."""

    play_requested = Signal(list, int)        # tracks, index to start at
    open_now_playing = Signal()
    mode_changed = Signal(str)
    menu_requested = Signal(object, QPoint, str)   # track, where, context
    open_playlist = Signal(str)
    new_playlist = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.loaded = False
        self.loading = False
        self.shelves = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)
        head = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(4)
        title = QLabel("Music", self)
        title.setObjectName("ScreenTitle")
        col.addWidget(title)
        self.subtitle = QLabel("Search above for any song, artist or music video — "
                               "straight from YouTube, no adverts.", self)
        self.subtitle.setObjectName("Muted")
        self.subtitle.setWordWrap(True)
        col.addWidget(self.subtitle)
        head.addLayout(col, 1)
        head.addSpacing(24)
        new_btn = QPushButton("+  New playlist", self)
        new_btn.setObjectName("Ghost")
        new_btn.setCursor(Qt.PointingHandCursor)
        new_btn.setToolTip("Make a playlist, or paste a YouTube playlist link to save it")
        new_btn.clicked.connect(self.new_playlist.emit)
        head.addWidget(new_btn, 0, Qt.AlignVCenter)
        head.addSpacing(24)
        label = QLabel("Play as", self)
        label.setObjectName("Muted")
        head.addWidget(label, 0, Qt.AlignVCenter)
        head.addSpacing(8)
        self.mode_btns = {}
        for key, text in (("listen", "♫  Listen"), ("watch", "▶  Watch")):
            btn = QPushButton(text, self)
            btn.setObjectName("GuideMode")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self._pick_mode(k))
            head.addWidget(btn, 0, Qt.AlignVCenter)
            self.mode_btns[key] = btn
        lay.addLayout(head)
        lay.addSpacing(12)
        self.now_btn = QPushButton("", self)
        self.now_btn.setObjectName("Ghost")
        self.now_btn.setCursor(Qt.PointingHandCursor)
        self.now_btn.clicked.connect(self.open_now_playing.emit)
        self.now_btn.hide()
        lay.addWidget(self.now_btn, 0, Qt.AlignLeft)
        self.status = QLabel("", self)
        self.status.setObjectName("Muted")
        self.status.setWordWrap(True)
        self.status.hide()
        lay.addWidget(self.status)
        lay.addSpacing(6)

        self.stack = QStackedWidget(self)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        self.holder = holder
        self.rows = QVBoxLayout(holder)
        self.rows.setContentsMargins(0, 8, 0, 40)
        self.rows.setSpacing(34)
        self.rows.addStretch(1)
        self.scroll.setWidget(holder)
        self.stack.addWidget(self.scroll)
        results = QWidget()
        rl = QVBoxLayout(results)
        rl.setContentsMargins(0, 8, 0, 0)
        rl.setSpacing(12)
        self.results_title = QLabel("", results)
        self.results_title.setObjectName("ShelfTitle")
        rl.addWidget(self.results_title)
        self.radio_results = QVBoxLayout()
        self.radio_results.setContentsMargins(0, 0, 0, 0)
        rl.addLayout(self.radio_results)
        self.grid = LazyGrid(self._make_card, card_w=VIDEO_W, parent=results)
        rl.addWidget(self.grid, 1)
        self.stack.addWidget(results)
        lay.addWidget(self.stack, 1)
        self.query = ""
        self.set_mode("listen")

    # ── mode ───────────────────────────────────────────────────
    def set_mode(self, mode):
        for key, btn in self.mode_btns.items():
            btn.setChecked(key == mode)

    def _pick_mode(self, mode):
        self.set_mode(mode)
        self.mode_changed.emit(mode)

    # ── status / now playing ───────────────────────────────────
    def show_status(self, text):
        self.status.setText(text)
        self.status.setVisible(bool(text))

    def set_now_playing(self, track):
        if track:
            self.now_btn.setText(f"♫  Now playing:  {track.get('title', '')}   ›")
        self.now_btn.setVisible(bool(track))

    # ── home rows ──────────────────────────────────────────────
    def set_rows(self, rows):
        """rows: [(title, tracks, "queue" | "single" | "radio" | "playlists")]
        — a "queue" row plays on from the picked song through the row;
        "single" plays the song and then its Mix. Rows that haven't changed
        are kept as they are (no rebuilding, no jump in scroll position)."""
        self.loading = False
        self.loaded = True
        old = dict(zip(getattr(self, "_row_keys", []), self.shelves))
        keys, shelves = [], []
        for title, tracks, how in rows:
            if not tracks:
                continue
            key = (title, how, tuple((t.get("id"), t.get("title"), t.get("channel"),
                                      t.get("thumb"), t.get("_badge")) for t in tracks))
            shelf = old.pop(key, None) or self._make_shelf(title, tracks, how)
            keys.append(key)
            shelves.append(shelf)
        for shelf in old.values():
            shelf.setParent(None)
            shelf.deleteLater()
        for shelf in shelves:
            self.rows.removeWidget(shelf)
        for shelf in shelves:
            self.rows.insertWidget(self.rows.count() - 1, shelf)
            shelf.show()
        self.shelves, self._row_keys = shelves, keys

    def _make_shelf(self, title, tracks, how):
        shelf = VideoShelf(title, tracks)
        if how == "playlists":
            shelf.opened_at.connect(
                lambda i, tracks=tracks: self.open_playlist.emit(tracks[i]["id"]))
        elif how == "radio":
            # Back / Next on Now Playing flip through the row's stations.
            shelf.opened_at.connect(
                lambda i, tracks=tracks: self.play_requested.emit(list(tracks), i))
            shelf.menu_at.connect(
                lambda i, pos, tracks=tracks: self.menu_requested.emit(tracks[i], pos, "radio"))
        else:
            shelf.opened_at.connect(
                lambda i, tracks=tracks, how=how:
                self.play_requested.emit(list(tracks[i:]) if how == "queue" else [tracks[i]], 0))
            shelf.menu_at.connect(
                lambda i, pos, tracks=tracks: self.menu_requested.emit(tracks[i], pos, "row"))
        return shelf

    # ── search ─────────────────────────────────────────────────
    def _make_card(self, track):
        card = VideoCard(track)
        card.opened.connect(lambda t: self.play_requested.emit([t], 0))
        card.menu_requested.connect(lambda t, pos: self.menu_requested.emit(t, pos, "search"))
        return card

    def show_results(self, query, tracks):
        """tracks None = still searching."""
        if tracks is None or query != self.query:
            self.show_radio_results(query, [])
        self.query = query
        self.stack.setCurrentIndex(1)
        if tracks is None:
            self.results_title.setText(f"Searching YouTube for “{query}”…")
            self.grid.set_items([], "")
            return
        self.results_title.setText(f"Results for “{query}”")
        self.grid.set_items(tracks, f"Nothing found for “{query}”.")
        self.grid.verticalScrollBar().setValue(0)

    def show_radio_results(self, query, stations):
        """Matching radio stations, as a row above the songs."""
        if query != self.query and stations:
            return
        while self.radio_results.count():
            item = self.radio_results.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if stations:
            shelf = VideoShelf("Radio stations", stations)
            shelf.opened_at.connect(lambda i: self.play_requested.emit(list(stations), i))
            shelf.menu_at.connect(
                lambda i, pos: self.menu_requested.emit(stations[i], pos, "radio"))
            self.radio_results.addWidget(shelf)

    def clear_search(self):
        self.query = ""
        self.stack.setCurrentIndex(0)


class _UpNextRow(QFrame):
    """One song in Now Playing's "Up next" list."""

    clicked = Signal()
    menu_requested = Signal(QPoint)
    THUMB = (128, 72)

    def __init__(self, track, parent=None):
        super().__init__(parent)
        self.setObjectName("EpisodeRow")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(14)
        self.art = QLabel(self)
        self.art.setFixedSize(*self.THUMB)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setText("♫")
        lay.addWidget(self.art)
        col = QVBoxLayout()
        col.setSpacing(2)
        for text, name in ((track.get("title", ""), "CardTitle"),
                           ("   ".join(filter(None, [track.get("channel", ""),
                                                     _duration_text(track)])), "CardNow")):
            label = QLabel(text, self)
            label.setObjectName(name)
            label.setWordWrap(name == "CardTitle")
            label.setMaximumHeight(46 if name == "CardTitle" else 22)
            col.addWidget(label)
        col.addStretch(1)
        lay.addLayout(col, 1)
        self._url = track.get("thumb") or ""
        self._mode = "contain" if track.get("kind") == "radio" else "cover"
        LOGOS.ready.connect(self._logo_ready)
        pix = LOGOS.get(self._url, self.THUMB, mode=self._mode) if self._url else None
        if pix:
            self._apply(pix)
        elif self._url:
            LOGOS.request(self._url, self.THUMB, mode=self._mode)

    def _apply(self, pix):
        self.art.setPixmap(_rounded(pix, 8))
        self.art.setText("")

    @Slot(str)
    def _logo_ready(self, url):
        if url == self._url:
            pix = LOGOS.get(url, self.THUMB, mode=self._mode)
            if pix:
                self._apply(pix)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()

    def contextMenuEvent(self, event):
        self.menu_requested.emit(event.globalPos())

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.clicked.emit()
            return
        if event.key() in (Qt.Key_Menu, Qt.Key_M):
            self.menu_requested.emit(self.mapToGlobal(QPoint(40, 30)))
            return
        super().keyPressEvent(event)


class NowPlayingView(QWidget):
    """Full-screen "Now playing" for Listen mode: big artwork over a
    blurred copy of it, the song, a progress bar, controls and what's
    up next. Keys: Space pause, ←/→ 10s, N / P next / previous."""

    back = Signal()
    add_current = Signal(QPoint)          # "+ Playlist" for the song playing
    save_queue = Signal()                 # "Save as playlist" for Up next
    upnext_menu = Signal(int, QPoint)     # queue index, where

    ART = (768, 432)

    def __init__(self, music, parent=None):
        super().__init__(parent)
        self.music = music
        self._bg = None
        self._art_url = ""
        self._art_mode = "cover"
        self._dragging = False
        self.setFocusPolicy(Qt.StrongFocus)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(48, 24, 48, 32)
        outer.setSpacing(0)
        top = QHBoxLayout()
        back_btn = QPushButton("‹  Music", self)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.setFocusPolicy(Qt.NoFocus)
        back_btn.clicked.connect(self.back.emit)
        top.addWidget(back_btn)
        top.addStretch(1)
        outer.addLayout(top)
        outer.addSpacing(20)

        body = QHBoxLayout()
        body.setSpacing(48)
        left = QVBoxLayout()
        left.setSpacing(0)
        left.addStretch(0)                  # pushes everything down for radio
        self.left_lay = left
        self.art = QLabel(self)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setText("♫")
        self.art.setFixedSize(*self.ART)
        left.addWidget(self.art)
        left.addSpacing(24)
        self.title = QLabel("", self)
        self.title.setObjectName("NowTitle")
        self.title.setWordWrap(True)
        self.title.setMaximumWidth(self.ART[0])
        self.title.ensurePolished()
        self.title.setMaximumHeight(self.title.fontMetrics().lineSpacing() * 2 + 6)
        left.addWidget(self.title)
        left.addSpacing(4)
        self.channel = QLabel("", self)
        self.channel.setObjectName("Muted")
        left.addWidget(self.channel)
        left.addSpacing(18)
        bar = QHBoxLayout()
        bar.setSpacing(12)
        self.elapsed = QLabel("0:00", self)
        self.elapsed.setObjectName("Muted")
        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.setRange(0, 1000)
        self.slider.setFocusPolicy(Qt.NoFocus)
        self.slider.sliderPressed.connect(lambda: setattr(self, "_dragging", True))
        self.slider.sliderReleased.connect(self._seek_released)
        self.total = QLabel("", self)
        self.total.setObjectName("Muted")
        bar.addWidget(self.elapsed)
        bar.addWidget(self.slider, 1)
        bar.addWidget(self.total)
        holder = QWidget(self)
        holder.setObjectName("Clear")
        holder.setLayout(bar)
        holder.setFixedWidth(self.ART[0])
        self.bar_holder = holder
        left.addWidget(holder)
        left.addSpacing(16)
        controls = QHBoxLayout()
        controls.setSpacing(12)
        self.prev_btn = QPushButton("◀◀  Back", self)
        self.play_btn = QPushButton("❚❚  Pause", self)
        self.next_btn = QPushButton("Next  ▶▶", self)
        self.watch_btn = QPushButton("▶  Watch the video", self)
        self.stop_btn = QPushButton("■  Stop", self)
        for btn, name, fn in ((self.prev_btn, "Ghost", music.previous),
                              (self.play_btn, "Primary", music.toggle_pause),
                              (self.stop_btn, "Ghost", self._stop),
                              (self.next_btn, "Ghost", music.next),
                              (self.watch_btn, "Ghost", music.switch_to_watch)):
            btn.setObjectName(name)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFocusPolicy(Qt.NoFocus)
            btn.clicked.connect(lambda _=False, f=fn: f())
            controls.addWidget(btn)
            if btn is self.next_btn:
                controls.addSpacing(18)
        self.add_btn = QPushButton("+  Playlist", self)
        self.add_btn.setObjectName("Ghost")
        self.add_btn.setCursor(Qt.PointingHandCursor)
        self.add_btn.setFocusPolicy(Qt.NoFocus)
        self.add_btn.clicked.connect(lambda: self.add_current.emit(
            self.add_btn.mapToGlobal(QPoint(0, self.add_btn.height()))))
        controls.addWidget(self.add_btn)
        controls.addStretch(1)
        left.addLayout(controls)
        left.addSpacing(12)
        self.note = QLabel("", self)
        self.note.setObjectName("Muted")
        self.note.setWordWrap(True)
        self.note.setMaximumWidth(self.ART[0])
        left.addWidget(self.note)
        left.addStretch(1)
        body.addLayout(left, 0)

        right = QVBoxLayout()
        right.setSpacing(10)
        up_head = QHBoxLayout()
        up = QLabel("Up next", self)
        up.setObjectName("ShelfTitle")
        self.up_label = up
        up_head.addWidget(up)
        up_head.addStretch(1)
        save = QPushButton("Save as playlist", self)
        save.setObjectName("Ghost")
        save.setCursor(Qt.PointingHandCursor)
        save.setFocusPolicy(Qt.NoFocus)
        save.clicked.connect(self.save_queue.emit)
        self.save_btn = save
        up_head.addWidget(save)
        right.addLayout(up_head)
        self.up_scroll = QScrollArea(self)
        self.up_scroll.setWidgetResizable(True)
        self.up_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        up_holder = QWidget()
        up_holder.setObjectName("Clear")
        self.up_lay = QVBoxLayout(up_holder)
        self.up_lay.setContentsMargins(0, 0, 0, 0)
        self.up_lay.setSpacing(6)
        self.up_lay.addStretch(1)
        self.up_scroll.setWidget(up_holder)
        right.addWidget(self.up_scroll, 1)
        self.right_col = QWidget(self)
        self.right_col.setObjectName("Clear")
        self.right_col.setLayout(right)
        body.addWidget(self.right_col, 1)
        outer.addLayout(body, 1)
        self._radio = False
        self._hero = None
        self._hero_url = ""

        self._note_timer = QTimer(self)
        self._note_timer.setSingleShot(True)
        self._note_timer.timeout.connect(lambda: self.note.setText(""))
        LOGOS.ready.connect(self._logo_ready)
        music.track_changed.connect(self.set_track)
        music.position.connect(self.set_position)
        music.paused.connect(self.set_paused)
        music.queue_changed.connect(self.refresh_queue)
        music.state.connect(self.set_state)
        music.song_title.connect(self.set_song)

    # ── content ────────────────────────────────────────────────
    def set_track(self, track):
        if not track:
            self.title.setText("Nothing playing")
            self.channel.setText("Pick a song on the Music page.")
            self.slider.setValue(0)
            self.elapsed.setText("0:00")
            self.total.setText("")
            return
        radio = track.get("kind") == "radio"
        self.title.setText(track.get("title", ""))
        self.channel.setText(track.get("channel", ""))
        self.total.setText(_duration_text(track))
        self.elapsed.setText("0:00")
        self.slider.setValue(0)
        self.bar_holder.setVisible(not radio)
        for btn in (self.watch_btn, self.add_btn, self.save_btn):
            btn.setVisible(not radio)
        self.prev_btn.setText("\u25c0\u25c0  Station" if radio else "\u25c0\u25c0  Back")
        self.next_btn.setText("Station  \u25b6\u25b6" if radio else "Next  \u25b6\u25b6")
        self.up_label.setText("Other stations" if radio else "Up next")
        self.set_paused(False)
        self._art_mode = "contain" if radio else "cover"
        self._art_url = track.get("thumb") or ""
        self._hero = None
        self._hero_url = (track.get("art") or "") if radio else ""
        # The big picture already shows the logo: no second copy on top.
        self.art.setVisible(not (radio and self._hero_url and track.get("art_logo")))
        self._set_radio_layout(radio)
        if self._hero_url:
            self._logo_ready(self._hero_url)
            if LOGOS.get(self._hero_url, self.HERO, mode="cover") is None:
                LOGOS.request(self._hero_url, self.HERO, mode="cover", priority=9)
        self.art.setPixmap(QPixmap())
        self.art.setText(monogram(track.get("title", "")) if radio else "\u266b")
        self._bg = None
        self.update()
        if self._art_url:
            self._logo_ready(self._art_url)
            if LOGOS.get(self._art_url, self._art_box(), mode=self._art_mode) is None:
                LOGOS.request(self._art_url, self._art_box(), mode=self._art_mode, priority=8)

    HERO = (1920, 1080)

    def _art_box(self):
        # Station logos (often vector) drawn whole inside a generous frame.
        return (800, 450) if self._art_mode == "contain" else self.ART

    def _set_radio_layout(self, on):
        """Radio fills the page: the station's big picture behind
        everything, and the logo, name, song and controls bottom left. No
        list of other stations (Station \u25c0\u25c0 / \u25b6\u25b6 flip through them)."""
        self._radio = on
        self.right_col.setVisible(not on)
        self.left_lay.setStretch(0, 1 if on else 0)
        self.left_lay.setStretch(self.left_lay.count() - 1, 0 if on else 1)
        self._fit_art()

    def _stop(self):
        """Stop the music altogether (no mini bar left behind) and go back
        to the Music page."""
        self.music.stop()
        self.back.emit()

    def set_song(self, title):
        """A radio station's current song."""
        self.channel.setText(f"\u266b  {title}")

    @Slot(str)
    def _logo_ready(self, url):
        if url and url == self._hero_url:
            pix = LOGOS.get(url, self.HERO, mode="cover")
            if pix:
                self._hero = pix
                self.update()
            if url != self._art_url:
                return
        if url != self._art_url:
            return
        pix = LOGOS.get(url, self._art_box(), mode=self._art_mode)
        if pix:
            box = self.art.size()
            if self._art_mode == "contain":
                box = box * 0.8
            fit = pix.scaled(box, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.art.setPixmap(_rounded(fit, 16) if self._art_mode == "cover" else fit)
            self.art.setText("")
            self._bg = _soft_blur(pix, 24)
            self.update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit_art()

    def _fit_art(self):
        if self._radio:
            # With the big picture behind, the logo is a neat badge; without
            # one, the logo itself is the picture.
            if self._hero_url:
                w, h = 460, 200
            else:
                w = int(max(320, min(self.width() * 0.5, 960)))
                h = int(w * 9 / 16)
            if self.art.size() != QSize(w, h):
                self.art.setFixedSize(w, h)
                for widget in (self.title, self.note):
                    widget.setMaximumWidth(max(w, 720))
                if self._art_url:
                    self._logo_ready(self._art_url)
            return
        # The artwork takes whatever height the rest of the column leaves
        # (big on a TV, smaller on a laptop) so nothing overlaps.
        h = max(180, min(self.ART[1], self.height() - 430))
        w = int(h * 16 / 9)
        room = int((self.width() - 144) * 0.58)          # leave the Up next column its space
        if w > room > 0:
            w = max(240, room)
            h = int(w * 9 / 16)
        if self.art.width() != w:
            self.art.setFixedSize(w, h)
            for widget in (self.title, self.note):
                widget.setMaximumWidth(max(w, 560))
            self.bar_holder.setFixedWidth(max(w, 560))
            if self._art_url:
                self._logo_ready(self._art_url)

    def set_position(self, position, duration):
        if duration > 0:
            self.total.setText(_format_hms(duration))
            if not self._dragging:
                self.slider.setValue(int(position / duration * 1000))
        self.elapsed.setText(_format_hms(position))

    def set_paused(self, paused):
        self.play_btn.setText("▶  Play" if paused else "❚❚  Pause")

    def set_state(self, state, text):
        if state == "loading":
            self.note.setText("Loading…")
        elif state == "playing":
            self.note.setText("")
        elif state in ("error", "skip"):
            self.note.setText(text)
            if state == "skip":
                self._note_timer.start(4000)
        elif state == "stopped":
            self.note.setText("")
        listen = self.music.mode == "listen"
        for btn in (self.play_btn, self.watch_btn):
            btn.setEnabled(listen and state != "stopped")

    def refresh_queue(self):
        while self.up_lay.count() > 1:
            item = self.up_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for i, track in self.music.up_next(15):
            row = _UpNextRow(track)
            row.clicked.connect(lambda i=i: self.music.jump(i))
            row.menu_requested.connect(lambda pos, i=i: self.upnext_menu.emit(i, pos))
            self.up_lay.insertWidget(self.up_lay.count() - 1, row)

    def _seek_released(self):
        self._dragging = False
        duration = self.music._dur
        if duration > 0:
            self.music.seek(self.slider.value() / 1000 * duration)

    # ── look and keys ──────────────────────────────────────────
    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(C.ink))
        if self._radio and self._hero is not None:
            # The station's own picture, full screen, darkened where the
            # text sits (top for the back button, bottom for the details).
            target = self.rect()
            pix = self._hero.scaled(target.size(), Qt.KeepAspectRatioByExpanding,
                                    Qt.SmoothTransformation)
            p.drawPixmap((target.width() - pix.width()) // 2,
                         (target.height() - pix.height()) // 2, pix)
            shade = QLinearGradient(0, 0, 0, target.height())
            shade.setColorAt(0.0, QColor(8, 7, 12, 150))
            shade.setColorAt(0.22, QColor(8, 7, 12, 0))
            shade.setColorAt(0.45, QColor(8, 7, 12, 30))
            shade.setColorAt(1.0, QColor(8, 7, 12, 238))
            p.fillRect(target, shade)
            p.end()
            return
        if self._radio:
            # No big picture for this station: a soft neon glow behind its logo.
            target = self.rect()
            for x, y, r, col in ((0.25, 0.35, 0.65, QColor(123, 91, 245, 110)),
                                 (0.80, 0.70, 0.55, QColor(232, 60, 245, 70)),
                                 (0.55, 0.10, 0.45, QColor(34, 211, 255, 45))):
                glow = QRadialGradient(target.width() * x, target.height() * y,
                                       max(target.width(), target.height()) * r)
                glow.setColorAt(0, col)
                glow.setColorAt(1, QColor(0, 0, 0, 0))
                p.fillRect(target, glow)
            shade = QLinearGradient(0, 0, 0, target.height())
            shade.setColorAt(0.5, QColor(8, 7, 12, 0))
            shade.setColorAt(1.0, QColor(8, 7, 12, 200))
            p.fillRect(target, shade)
            p.end()
            return
        if self._bg is not None:
            target = self.rect()
            pix = self._bg.scaled(target.size(), Qt.KeepAspectRatioByExpanding,
                                  Qt.SmoothTransformation)
            p.setOpacity(0.55)
            p.drawPixmap((target.width() - pix.width()) // 2,
                         (target.height() - pix.height()) // 2, pix)
            p.setOpacity(1.0)
            shade = QLinearGradient(0, 0, 0, target.height())
            shade.setColorAt(0, QColor(12, 11, 17, 150))
            shade.setColorAt(1, QColor(12, 11, 17, 235))
            p.fillRect(target, shade)
        p.end()

    def keyPressEvent(self, event):
        key = event.key()
        if key in (Qt.Key_Left, Qt.Key_Right):
            self.music.seek_relative(10 if key == Qt.Key_Right else -10)
        elif key in (Qt.Key_N, Qt.Key_MediaNext):
            self.music.next()
        elif key in (Qt.Key_P, Qt.Key_MediaPrevious):
            self.music.previous()
        elif key in (Qt.Key_MediaPlay, Qt.Key_MediaPause, Qt.Key_MediaTogglePlayPause):
            self.music.toggle_pause()
        elif key == Qt.Key_W:
            self.music.switch_to_watch()
        elif key == Qt.Key_Backspace:
            self.back.emit()
        else:
            super().keyPressEvent(event)
            return
        event.accept()


class PlaylistView(QWidget):
    """One of your playlists: play it, shuffle it, rename, delete, and
    the songs in it (click one to play the playlist from there)."""

    back = Signal()
    play_requested = Signal(list, int)
    menu_requested = Signal(object, QPoint, str)
    rename_requested = Signal(str)
    delete_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pid = None
        self.tracks = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)
        top = QHBoxLayout()
        back_btn = QPushButton("\u2039  Music", self)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back.emit)
        top.addWidget(back_btn)
        top.addStretch(1)
        lay.addLayout(top)
        lay.addSpacing(10)
        self.title = QLabel("", self)
        self.title.setObjectName("ScreenTitle")
        lay.addWidget(self.title)
        self.subtitle = QLabel("", self)
        self.subtitle.setObjectName("Muted")
        lay.addWidget(self.subtitle)
        lay.addSpacing(12)
        row = QHBoxLayout()
        row.setSpacing(10)
        for text, name, fn in (("\u25b6  Play", "Primary", lambda: self._play(False)),
                               ("Shuffle", "Ghost", lambda: self._play(True)),
                               ("Rename", "Ghost", lambda: self.rename_requested.emit(self.pid)),
                               ("Delete", "Ghost", lambda: self.delete_requested.emit(self.pid))):
            btn = QPushButton(text, self)
            btn.setObjectName(name)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, f=fn: f())
            row.addWidget(btn)
        row.addStretch(1)
        lay.addLayout(row)
        lay.addSpacing(16)
        self.grid = LazyGrid(self._make_card, card_w=VIDEO_W, parent=self)
        lay.addWidget(self.grid, 1)

    def _make_card(self, track):
        card = VideoCard(track)
        card.opened.connect(lambda t: self.play_requested.emit(
            self.tracks, next((i for i, x in enumerate(self.tracks) if x["id"] == t["id"]), 0)))
        card.menu_requested.connect(
            lambda t, pos: self.menu_requested.emit(t, pos, f"playlist:{self.pid}"))
        return card

    def show_playlist(self, playlist):
        self.pid = playlist["id"]
        self.tracks = list(playlist.get("tracks") or [])
        self.title.setText(playlist.get("name", ""))
        total = sum(t.get("duration") or 0 for t in self.tracks)
        n = len(self.tracks)
        self.subtitle.setText(f"{n} song{'s' if n != 1 else ''}" +
                              (f"  \u00b7  {_format_hms(total)}" if total else ""))
        self.grid.set_items(self.tracks, "This playlist is empty \u2014 add songs with the "
                                         "\u22ef button on any song.")
        self.grid.verticalScrollBar().setValue(0)

    def _play(self, shuffle):
        if not self.tracks:
            return
        tracks = list(self.tracks)
        if shuffle:
            random.shuffle(tracks)
        self.play_requested.emit(tracks, 0)


class MiniPlayer(QFrame):
    """The bar along the bottom while music plays and you're elsewhere in
    the app: what's playing, back / pause / next, and a way back to Now
    Playing (click the bar)."""

    open_requested = Signal()
    THUMB = (112, 63)

    def __init__(self, music, parent=None):
        super().__init__(parent)
        self.music = music
        self.setObjectName("MiniPlayer")
        self.setFixedHeight(84)
        self.setCursor(Qt.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(24, 10, 24, 10)
        lay.setSpacing(16)
        self.art = QLabel(self)
        self.art.setObjectName("Monogram")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.setFixedSize(*self.THUMB)
        lay.addWidget(self.art)
        col = QVBoxLayout()
        col.setSpacing(3)
        self.title = QLabel("", self)
        self.title.setObjectName("CardTitle")
        self.channel = QLabel("", self)
        self.channel.setObjectName("CardNow")
        self.bar = QProgressBar(self)
        self.bar.setObjectName("Epg")
        self.bar.setTextVisible(False)
        self.bar.setRange(0, 1000)
        self.bar.setFixedHeight(3)
        col.addWidget(self.title)
        col.addWidget(self.channel)
        col.addSpacing(4)
        col.addWidget(self.bar)
        lay.addLayout(col, 1)
        self.buttons = []
        for text, name, fn, tip in (("\u25c0\u25c0", "Ghost", music.previous, "Back"),
                                    ("\u275a\u275a", "Primary", music.toggle_pause, "Pause"),
                                    ("\u25b6\u25b6", "Ghost", music.next, "Next"),
                                    ("\u2715", "Ghost", music.stop, "Stop the music")):
            btn = QPushButton(text, self)
            btn.setObjectName(name)
            btn.setFixedWidth(64)
            btn.setToolTip(tip)
            btn.setFocusPolicy(Qt.NoFocus)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, f=fn: f())
            lay.addWidget(btn)
            self.buttons.append(btn)
        self.play_btn = self.buttons[1]
        self._url = ""
        self._mode = "cover"
        music.song_title.connect(lambda t: self.channel.setText(f"\u266b  {t}"))
        LOGOS.ready.connect(self._logo_ready)
        music.track_changed.connect(self.set_track)
        music.position.connect(self.set_position)
        music.paused.connect(lambda p: self.play_btn.setText("\u25b6" if p else "\u275a\u275a"))

    def set_track(self, track):
        if not track:
            return
        radio = track.get("kind") == "radio"
        fm = self.title.fontMetrics()
        self.title.setText(fm.elidedText(track.get("title", ""), Qt.ElideRight, 640))
        self.channel.setText(track.get("channel", ""))
        self.bar.setValue(0)
        self.bar.setVisible(not radio)
        self._mode = "contain" if radio else "cover"
        self._url = track.get("thumb") or ""
        self.art.setPixmap(QPixmap())
        self.art.setText(monogram(track.get("title", "")) if radio else "\u266b")
        if self._url:
            self._logo_ready(self._url)
            if LOGOS.get(self._url, self.THUMB, mode=self._mode) is None:
                LOGOS.request(self._url, self.THUMB, mode=self._mode, priority=6)

    @Slot(str)
    def _logo_ready(self, url):
        if url == self._url:
            pix = LOGOS.get(url, self.THUMB, mode=self._mode)
            if pix:
                self.art.setPixmap(_rounded(pix, 8) if self._mode == "cover" else pix)
                self.art.setText("")

    def set_position(self, position, duration):
        if duration > 0:
            self.bar.setValue(int(position / duration * 1000))

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.open_requested.emit()
