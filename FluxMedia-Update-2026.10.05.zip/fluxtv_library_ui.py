"""
Flux Media (FluxTV) — Live TV / film / series grids, detail pages, Discover and add-on titles.

Split out of iptv.py unchanged.
"""
from __future__ import annotations

import os
import json
import random
import platform
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial

from PySide6.QtCore import (QEvent, QEventLoop, QObject, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QRunnable, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QCursor, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QFileDialog, QFrame,
                               QInputDialog,
                               QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QScrollArea,
                               QSizePolicy, QSlider, QStackedWidget, QVBoxLayout,
                               QWidget)

import fluxtv_core as core
import fluxtv_addons
import fluxtv_player
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube
import fluxtv_radio
import fluxtv_update
import fluxtv_record
import fluxtv_health
from fluxtv_icons import ChromeIconButton, IconGlyph, NavRailButton
from fluxtv_style import (C, CARD_H, CARD_W, POSTER_H, POSTER_W, WELL_H,
                          font, stylesheet)
from fluxtv_ui_base import (CategoryFilter, ChannelCard, LOGOS, LazyGrid, PosterCard, PosterShelf, _Backdrop, _clean_year, _first_url, _format_hms, _meta_year, addon_hero_picks, html_escape)
from fluxtv_home_ui import (HeroBanner)


# ══════════════════════════════════════════════════════════════════
# Channel grid screen (Live TV / Favourites)
# ══════════════════════════════════════════════════════════════════
class ChannelGridScreen(QWidget):
    """Title, optional category filter, searchable grid of ChannelCard."""

    activated = Signal(object)
    selected = Signal(object)
    fav_toggled = Signal(object)

    def __init__(self, title, subtitle, library, show_categories=True,
                 parent=None):
        super().__init__(parent)
        self.lib = library
        self.all_items = []
        self.query = ""

        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(11)
        pip = QFrame(self)
        pip.setFixedSize(4, 24)
        pip.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:0, y2:1,"
                          f" stop:0 {C.cyan}, stop:1 {C.violet}); border-radius: 2px;")
        pip.hide()
        self.title_label = QLabel(title, self)
        self.title_label.setObjectName("ScreenTitle")
        title_row.addWidget(self.title_label)
        lay.addLayout(title_row)
        self.subtitle_label = QLabel(subtitle, self)
        self.subtitle_label.setObjectName("Muted")
        lay.addWidget(self.subtitle_label)
        lay.addSpacing(14)

        if show_categories:
            filter_row = QHBoxLayout()
            self.filter_chip = CategoryFilter("All categories", self)
            self.filter_chip.changed.connect(self._on_category)
            filter_row.addWidget(self.filter_chip)
            filter_row.addStretch(1)
            lay.addLayout(filter_row)
            lay.addSpacing(10)
        else:
            self.filter_chip = None

        self.category_id = None
        self.grid = LazyGrid(self._make_card, parent=self)
        lay.addWidget(self.grid, 1)

    def _make_card(self, channel):
        card = ChannelCard(channel, self.lib)
        card.activated.connect(self.activated.emit)
        card.selected.connect(self.selected.emit)
        card.fav_toggled.connect(self.fav_toggled.emit)
        return card

    def set_categories(self, categories):
        if self.filter_chip:
            self.filter_chip.set_categories(categories)

    def set_channels(self, channels, empty_text="No channels found."):
        # Coming back to the screen with the same channels: keep the tiles
        # and just refresh them. Rebuilding every tile on each visit was
        # most of the wait when switching here from Music.
        sig = [c.get("stream_id") for c in channels]
        if sig == getattr(self, "_sig", None) and empty_text == self._empty_text \
                and self.grid.cards:
            self.grid.refresh_cards()
            return
        self._sig = sig
        self.all_items = list(channels)
        self._empty_text = empty_text
        self._apply()

    def set_query(self, query):
        self.query = (query or "").strip().lower()
        self._apply()

    def _on_category(self, cid, _label):
        self.category_id = cid
        self._apply()

    def _apply(self):
        items = self.all_items
        if self.category_id:
            items = [c for c in items
                    if str(c.get("category_id", "")) == self.category_id]
        if self.query:
            items = [c for c in items
                    if self.query in (c.get("name") or "").lower()]
        self.grid.set_items(items, self._empty_text)

    def refresh_cards(self):
        self.grid.refresh_cards()

    def mark_on_air(self, channel):
        key = self.lib._fav_key(channel) if channel else None
        for card in self.grid.cards:
            card.set_on_air(key is not None
                            and self.lib._fav_key(card.channel) == key)


# ══════════════════════════════════════════════════════════════════
# Poster grid screen (Movies / Series)
# ══════════════════════════════════════════════════════════════════
class PosterGridScreen(QWidget):
    """Title, genre filter, searchable grid of PosterCard.

    Three mutually exclusive states share the same space: the grid, a
    loading message, and an error message with a Retry button. Unlike
    Live TV (which always has cached channels to fall back on), Movies and
    Series have nothing to show until the provider answers, so a failed
    fetch must be visible and recoverable rather than a silent, permanent
    "Loading…".
    """

    activated = Signal(object)
    opened = Signal(object)
    retry_requested = Signal()

    def __init__(self, title, subtitle, action_label, parent=None):
        super().__init__(parent)
        self.action_label = action_label
        self.all_items = []
        self.query = ""
        self.genre_id = None
        self._progress = {}

        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(11)
        pip = QFrame(self)
        pip.setFixedSize(4, 24)
        pip.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:0, y2:1,"
                          f" stop:0 {C.cyan}, stop:1 {C.violet}); border-radius: 2px;")
        pip.hide()
        self.title_label = QLabel(title, self)
        self.title_label.setObjectName("ScreenTitle")
        title_row.addWidget(self.title_label)
        lay.addLayout(title_row)
        self.subtitle_label = QLabel(subtitle, self)
        self.subtitle_label.setObjectName("Muted")
        lay.addWidget(self.subtitle_label)
        lay.addSpacing(14)

        filter_row = QHBoxLayout()
        self.filter_chip = CategoryFilter("All genres", self)
        self.filter_chip.changed.connect(self._on_genre)
        filter_row.addWidget(self.filter_chip)
        filter_row.addStretch(1)
        lay.addLayout(filter_row)
        lay.addSpacing(10)

        self.grid = LazyGrid(self._make_card, card_w=POSTER_W, parent=self)
        lay.addWidget(self.grid, 1)

        self.state_wrap = QWidget(self)
        state_lay = QVBoxLayout(self.state_wrap)
        state_lay.setAlignment(Qt.AlignCenter)
        state_lay.setSpacing(14)
        self.state_label = QLabel("", self.state_wrap)
        self.state_label.setObjectName("Muted")
        self.state_label.setAlignment(Qt.AlignCenter)
        self.state_label.setWordWrap(True)
        self.state_label.setMaximumWidth(520)
        state_lay.addWidget(self.state_label, 0, Qt.AlignHCenter)
        self.retry_btn = QPushButton("Retry", self.state_wrap)
        self.retry_btn.setObjectName("Ghost")
        self.retry_btn.setCursor(Qt.PointingHandCursor)
        self.retry_btn.clicked.connect(self.retry_requested.emit)
        self.retry_btn.hide()
        state_lay.addWidget(self.retry_btn, 0, Qt.AlignHCenter)
        self.state_wrap.hide()
        lay.addWidget(self.state_wrap, 1)

    def _make_card(self, item):
        year = item.get("year", "")
        genre = item.get("genre", "")
        rating = item.get("rating", "")
        seasons = item.get("num_seasons", "")
        name = item.get("name", "Unknown")
        progress_fraction = None
        continue_text = None
        if seasons:
            meta = "   ".join(filter(None, [genre,
                              f"\u2605 {rating}" if rating else ""]))
            badge = f"{seasons} season{'' if str(seasons) == '1' else 's'}"
            entry = core.series_continue_entry(item.get("series_id"),
                                               self._progress)
            if entry:
                progress_fraction = core.watch_progress_fraction(entry)
                season = entry.get("season")
                ep_num = entry.get("episode_num")
                if season and ep_num:
                    continue_text = f"Continue \u2022 S{season} E{ep_num}"
                else:
                    continue_text = "Continue watching"
        else:
            meta = "   ".join(filter(None, [str(year), genre]))
            badge = f"\u2605 {rating}" if rating else ""
            entry = self._progress.get(core.vod_key(item))
            if entry:
                fraction = core.watch_progress_fraction(entry)
                if 0.02 < fraction < 0.92:
                    progress_fraction = fraction
        art_url = item.get("stream_icon") or item.get("cover") or ""
        card = PosterCard(item, name, meta, badge, art_url, self.action_label,
                          progress_fraction=progress_fraction,
                          continue_text=continue_text)
        card.activated.connect(self.activated.emit)
        card.opened.connect(self.opened.emit)
        return card

    def set_loading(self, state):
        if state:
            self.state_label.setText("Loading\u2026")
            self.retry_btn.hide()
            self.state_wrap.show()
            self.grid.hide()
        else:
            self.state_wrap.hide()
            self.grid.show()

    def show_error(self, message):
        """A failed fetch is shown here, with a way to try again — never
        left as a silent, permanent 'Loading…'."""
        self.state_label.setText(message)
        self.retry_btn.show()
        self.state_wrap.show()
        self.grid.hide()

    def set_categories(self, categories):
        self.filter_chip.set_categories(categories)

    def set_items(self, items, empty_text="Nothing found."):
        progress = core.load_watch_progress()
        # Back on the page with the same titles and nothing newly watched:
        # keep the posters as they are instead of rebuilding them.
        sig = (id(items), len(items), empty_text)
        if sig == getattr(self, "_sig", None) and progress == self._progress and self.grid.cards:
            return
        self._sig = sig
        self.all_items = list(items)
        self._empty_text = empty_text
        self._progress = progress
        self._apply()

    def set_query(self, query):
        self.query = (query or "").strip().lower()
        self._apply()

    def _on_genre(self, gid, _label):
        self.genre_id = gid
        self._apply()

    def _has_progress(self, item):
        if item.get("num_seasons"):
            return core.series_continue_entry(
                item.get("series_id"), self._progress) is not None
        entry = self._progress.get(core.vod_key(item))
        return entry is not None and 0.02 < core.watch_progress_fraction(entry) < 0.92

    def _apply(self):
        items = self.all_items
        if self.genre_id:
            items = [i for i in items
                    if str(i.get("category_id", "")) == self.genre_id]
        if self.query:
            items = [i for i in items
                    if self.query in (i.get("name") or "").lower()]
        if self._progress:
            # In-progress titles float to the top — a lightweight
            # "Continue Watching" without a separate shelf to maintain.
            items = sorted(items, key=lambda i: not self._has_progress(i))
        self.grid.set_items(items, self._empty_text)


class _EpisodeRow(QWidget):
    """One episode in a series' episode panel: thumbnail, number and
    title, runtime, a two-line synopsis and how far you've watched."""

    clicked = Signal(dict)
    H = 112
    THUMB = (176, 99)

    def __init__(self, ep, fraction=0.0, parent=None, watched=False):
        super().__init__(parent)
        self.ep = ep
        self.fraction = fraction
        self.watched = watched
        self._hover = False
        self.setFixedHeight(self.H)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        info = ep.get("info") or {}
        if not isinstance(info, dict):
            info = {}
        self.info = info
        self.thumb_url = info.get("movie_image") or ""
        if self.thumb_url:
            if LOGOS.get(self.thumb_url, self.THUMB, mode="cover") is None:
                LOGOS.request(self.thumb_url, self.THUMB, mode="cover", priority=5)
            LOGOS.ready.connect(self._on_ready)

    @Slot(str)
    def _on_ready(self, url):
        if url == self.thumb_url:
            self.update()

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit(self.ep)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self._hover:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 16))
            p.drawRoundedRect(QRectF(self.rect()).adjusted(2, 2, -2, -2), 12, 12)
        tw, th = self.THUMB
        thumb = QRectF(12, (self.H - th) / 2, tw, th)
        path = QPainterPath()
        path.addRoundedRect(thumb, 8, 8)
        p.save()
        p.setClipPath(path)
        pix = LOGOS.get(self.thumb_url, self.THUMB, mode="cover") if self.thumb_url else None
        if pix is not None:
            p.drawPixmap(thumb, pix, QRectF(pix.rect()))
        else:
            p.fillRect(thumb, QColor(C.card))
            p.setPen(QColor(C.faint))
            p.setFont(font(20, QFont.Bold))
            p.drawText(thumb, Qt.AlignCenter, f"E{self.ep.get('episode_num', '?')}")
        if self._hover:
            p.fillRect(thumb, QColor(0, 0, 0, 90))
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 235))
            c = thumb.center()
            tri = QPainterPath(QPointF(c.x() - 8, c.y() - 11))
            tri.lineTo(QPointF(c.x() + 12, c.y()))
            tri.lineTo(QPointF(c.x() - 8, c.y() + 11))
            tri.closeSubpath()
            p.drawPath(tri)
        if self.fraction > 0:
            bar = QRectF(thumb.x(), thumb.bottom() - 4, thumb.width(), 4)
            p.fillRect(bar, QColor(0, 0, 0, 150))
            p.fillRect(QRectF(bar.x(), bar.y(), bar.width() * min(1.0, self.fraction), 4),
                       QColor(C.cyan))
        if self.watched:
            # Watched (Trakt, Stremio or finished here): a tick in the corner.
            p.fillRect(thumb, QColor(0, 0, 0, 70))
            c = QPointF(thumb.right() - 16, thumb.top() + 16)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(C.ok))
            p.drawEllipse(c, 11, 11)
            p.setPen(QPen(QColor("white"), 2.4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            tick = QPainterPath(QPointF(c.x() - 5, c.y()))
            tick.lineTo(QPointF(c.x() - 1.5, c.y() + 3.5))
            tick.lineTo(QPointF(c.x() + 5, c.y() - 3.5))
            p.setBrush(Qt.NoBrush)
            p.drawPath(tick)
        p.restore()

        x = thumb.right() + 16
        right = self.width() - 14
        num = self.ep.get("episode_num", "")
        title = self.ep.get("title") or f"Episode {num}"
        # Providers often send "Show - S01E03 - Title"; keep just the title.
        if " - " in title and title.count(" - ") >= 2:
            title = title.split(" - ", 2)[-1]
        p.setFont(font(15, QFont.DemiBold))
        p.setPen(QColor(C.paper))
        head = p.fontMetrics().elidedText(f"{num}.  {title}", Qt.ElideRight, int(right - x))
        p.drawText(QRectF(x, 12, right - x, 22), Qt.AlignLeft | Qt.AlignVCenter, head)

        bits = []
        duration = self.info.get("duration") or ""
        if duration:
            bits.append(str(duration)[:8].lstrip("0:") or str(duration))
        aired = _clean_year(self.info.get("releasedate"), self.info.get("air_date"))
        if self.info.get("releasedate"):
            bits.append(str(self.info.get("releasedate"))[:10])
        elif aired:
            bits.append(aired)
        if self.watched:
            bits.append("\u2713 Watched")
        elif self.fraction > 0:
            bits.append(f"{int(self.fraction * 100)}% watched")
        p.setFont(font(12))
        p.setPen(QColor(C.faint))
        p.drawText(QRectF(x, 36, right - x, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   "   ·   ".join(bits))

        plot = (self.info.get("plot") or "").strip()
        if plot:
            p.setFont(font(13))
            p.setPen(QColor(C.dim))
            rect = QRectF(x, 58, right - x, 40)
            fm = p.fontMetrics()
            # Two lines at most, ellipsis on the second.
            words, lines, line = plot.split(), [], ""
            for word in words:
                trial = f"{line} {word}".strip()
                if fm.horizontalAdvance(trial) <= rect.width():
                    line = trial
                    continue
                lines.append(line)
                line = word
                if len(lines) == 2:
                    break
            if len(lines) < 2 and line:
                lines.append(line)
            if len(lines) == 2 and len(" ".join(lines)) < len(plot):
                lines[1] = fm.elidedText(lines[1] + " …", Qt.ElideRight, int(rect.width()))
            for i, text in enumerate(lines[:2]):
                p.drawText(QRectF(x, 58 + i * 19, right - x, 19),
                           Qt.AlignLeft | Qt.AlignVCenter, text)
        p.end()


class CastChip(QWidget):
    """One cast member on a detail page: a round photo (or initials),
    the name and who they play."""

    BOX = 74

    def __init__(self, person, parent=None):
        super().__init__(parent)
        self.person = person
        self.setFixedSize(112, 132)
        self.setToolTip(person.get("name", "") + (
            f" as {person['character']}" if person.get("character") else ""))
        self._photo = person.get("photo") or ""
        if self._photo:
            LOGOS.ready.connect(self._ready)
            LOGOS.request(self._photo, (self.BOX, self.BOX), "cover", priority=5)

    def _ready(self, url):
        if url == self._photo:
            self.update()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        x = (self.width() - self.BOX) / 2
        circle = QPainterPath()
        circle.addEllipse(QRectF(x, 2, self.BOX, self.BOX))
        pix = LOGOS.get(self._photo, (self.BOX, self.BOX), "cover") if self._photo else None
        if pix is not None and not pix.isNull():
            p.setClipPath(circle)
            p.drawPixmap(int(x), 2, pix)
            p.setClipping(False)
        else:
            p.fillPath(circle, QColor(255, 255, 255, 28))
            initials = "".join(w[0] for w in self.person.get("name", "?").split()[:2]).upper()
            p.setPen(QColor(C.paper))
            p.setFont(font(20, QFont.DemiBold))
            p.drawText(QRectF(x, 2, self.BOX, self.BOX), Qt.AlignCenter, initials)
        p.setPen(QPen(QColor(255, 255, 255, 50), 1.5))
        p.drawPath(circle)
        p.setPen(QColor(C.paper))
        p.setFont(font(11, QFont.DemiBold))
        fm = p.fontMetrics()
        name = fm.elidedText(self.person.get("name", ""), Qt.ElideRight, self.width() - 4)
        p.drawText(QRectF(0, self.BOX + 8, self.width(), 18), Qt.AlignHCenter, name)
        if self.person.get("character"):
            p.setPen(QColor(C.faint))
            p.setFont(font(10))
            fm = p.fontMetrics()
            role = fm.elidedText(self.person["character"], Qt.ElideRight, self.width() - 4)
            p.drawText(QRectF(0, self.BOX + 27, self.width(), 18), Qt.AlignHCenter, role)
        p.end()


def _badge(text, colour, label):
    return (f"<span style='color:{colour}; font-weight:800'>{label}</span>"
            f"&nbsp;<span style='color:{C.paper}; font-weight:700'>{text}</span>")


class MetaDetailView(QWidget):
    """Shared Stremio-style detail page: backdrop, big title, facts,
    plot, credits and a row of actions. Movies and series build on it."""

    back = Signal()
    trailer_requested = Signal(str, str)     # YouTube id (or link), title
    link_requested = Signal()                # the "other copy" button (see set_link)

    def __init__(self, back_label, with_panel=False, parent=None):
        super().__init__(parent)
        self.setObjectName("MetaDetail")
        # Plain containers must not paint the page colour over the
        # backdrop; buttons keep their own styles.
        self.setStyleSheet("QWidget#Clear { background: transparent; }")
        self.backdrop = _Backdrop(self)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.info = QWidget(self)
        self.info.setObjectName("Clear")
        il = QVBoxLayout(self.info)
        il.setContentsMargins(52, 24, 40, 48)
        il.setSpacing(12)

        back_btn = QPushButton(f"‹  {back_label}", self.info)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back.emit)
        il.addWidget(back_btn, 0, Qt.AlignLeft)
        il.addStretch(1)

        self.title_label = QLabel("", self.info)
        self.title_label.setObjectName("HeroTitle")
        self.title_label.setWordWrap(True)
        self.title_label.setMaximumWidth(820)
        il.addWidget(self.title_label)

        self.facts_label = QLabel("", self.info)
        self.facts_label.setObjectName("HeroFacts")
        self.facts_label.setTextFormat(Qt.RichText)
        il.addWidget(self.facts_label)

        self.ratings_label = QLabel("", self.info)
        self.ratings_label.setObjectName("HeroFacts")
        self.ratings_label.setTextFormat(Qt.RichText)
        self.ratings_label.hide()
        il.addWidget(self.ratings_label)

        self.genre_label = QLabel("", self.info)
        self.genre_label.setObjectName("HeroGenres")
        il.addWidget(self.genre_label)

        self.plot_label = QLabel("", self.info)
        self.plot_label.setObjectName("HeroPlot")
        self.plot_label.setWordWrap(True)
        self.plot_label.setMaximumWidth(720)
        il.addWidget(self.plot_label)

        self.credits_label = QLabel("", self.info)
        self.credits_label.setObjectName("HeroCredits")
        self.credits_label.setWordWrap(True)
        self.credits_label.setMaximumWidth(720)
        self.credits_label.setTextFormat(Qt.RichText)
        il.addWidget(self.credits_label)

        self.awards_label = QLabel("", self.info)
        self.awards_label.setObjectName("HeroCredits")
        self.awards_label.setWordWrap(True)
        self.awards_label.setMaximumWidth(720)
        self.awards_label.setTextFormat(Qt.RichText)
        self.awards_label.hide()
        il.addWidget(self.awards_label)

        self.cast_row = QWidget(self.info)
        self.cast_row.setObjectName("Clear")
        self.cast_lay = QHBoxLayout(self.cast_row)
        self.cast_lay.setContentsMargins(0, 4, 0, 0)
        self.cast_lay.setSpacing(4)
        self.cast_lay.addStretch(1)
        self.cast_row.hide()
        il.addWidget(self.cast_row)

        il.addSpacing(10)
        self.actions = QHBoxLayout()
        self.actions.setSpacing(12)
        self.primary_btn = QPushButton("▶  Play", self.info)
        self.primary_btn.setObjectName("HeroPlay")
        self.primary_btn.setCursor(Qt.PointingHandCursor)
        self.actions.addWidget(self.primary_btn)
        self.secondary_btn = QPushButton("", self.info)
        self.secondary_btn.setObjectName("HeroGhost")
        self.secondary_btn.setCursor(Qt.PointingHandCursor)
        self.secondary_btn.hide()
        self.actions.addWidget(self.secondary_btn)
        self.trailer_btn = QPushButton("Trailer", self.info)
        self.trailer_btn.setObjectName("HeroGhost")
        self.trailer_btn.setCursor(Qt.PointingHandCursor)
        self.trailer_btn.clicked.connect(self._open_trailer)
        self.trailer_btn.hide()
        self.actions.addWidget(self.trailer_btn)
        self.link_btn = QPushButton("", self.info)
        self.link_btn.setObjectName("HeroGhost")
        self.link_btn.setCursor(Qt.PointingHandCursor)
        self.link_btn.clicked.connect(self.link_requested.emit)
        self.link_btn.hide()
        self.actions.addWidget(self.link_btn)
        self.actions.addStretch(1)
        il.addLayout(self.actions)
        root.addWidget(self.info, 1)

        self.panel = None
        if with_panel:
            self.panel = QFrame(self)
            self.panel.setObjectName("EpisodePanel")
            self.panel.setFixedWidth(560)
            root.addWidget(self.panel)
        self._trailer = ""
        self._facts = ("", "", "", "")
        self.details_for = None              # which title apply_details() may fill

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.backdrop.setGeometry(self.rect())
        self.backdrop.lower()

    def showEvent(self, event):
        super().showEvent(event)
        self.backdrop.setGeometry(self.rect())
        self.backdrop.lower()

    # ── shared pieces ───────────────────────────────────────────
    def _set_facts(self, year="", runtime="", rating="", extra=""):
        self._facts = (year, runtime, rating, extra)
        parts = []
        if rating and self.ratings_label.isHidden():
            try:
                rating = f"{float(rating):.1f}"
            except (TypeError, ValueError):
                pass
            parts.append(f"<span style='color:{C.gold}; font-weight:700'>"
                         f"★ {rating}</span>")
        for bit in (year, runtime, extra):
            if bit:
                parts.append(str(bit))
        sep = f"<span style='color:{C.faint}'>&nbsp;&nbsp;•&nbsp;&nbsp;</span>"
        self.facts_label.setText(sep.join(parts))
        self.facts_label.setVisible(bool(parts))

    def _set_plot(self, plot):
        plot = " ".join((plot or "").split())
        if len(plot) > 460:
            plot = plot[:460].rsplit(" ", 1)[0] + "…"
        self.plot_label.setText(plot)
        self.plot_label.setVisible(bool(plot))

    def _set_genres(self, genre):
        genre = (genre or "").replace(" / ", ", ").replace("/", ", ")
        self.genre_label.setText(genre)
        self.genre_label.setVisible(bool(genre))

    def _set_credits(self, director="", cast=""):
        if not self.cast_row.isHidden():
            return                      # apply_details() has the fuller credits
        rows = []
        if director:
            rows.append(f"<span style='color:{C.faint}'>Director</span>&nbsp;&nbsp;{director}")
        if cast:
            names = [c.strip() for c in str(cast).split(",") if c.strip()][:5]
            rows.append(f"<span style='color:{C.faint}'>Cast</span>&nbsp;&nbsp;"
                        + ", ".join(names))
        self.credits_label.setText("<br>".join(rows))
        self.credits_label.setVisible(bool(rows))

    def _set_trailer(self, code):
        code = (code or "").strip()
        self._trailer = code
        self.trailer_btn.setVisible(bool(code))

    def _open_trailer(self):
        if self._trailer:
            self.trailer_requested.emit(self._trailer, self.title_label.text())

    # ── richer details (fluxtv_details) ─────────────────────────
    def reset_details(self, key=None):
        """A new title: clear the extras until its details arrive."""
        self.details_for = key
        self.ratings_label.hide()
        self.awards_label.hide()
        self.cast_row.hide()
        self.set_link("")
        while self.cast_lay.count() > 1:
            item = self.cast_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def set_link(self, text):
        """The extra button: "More sources" on a provider film, "Play from
        your provider" on a Debrid one. Empty hides it."""
        self.link_btn.setText(text)
        self.link_btn.setVisible(bool(text))

    def apply_details(self, key, d):
        """Ratings, awards, cast and trailer from fluxtv_details.details()."""
        if not d or key != self.details_for:
            return                                  # a reply for a page we've left
        badges = []
        if d.get("imdb_rating"):
            badges.append(_badge(f"{d['imdb_rating']}", "#F5C518", "IMDb"))
        if d.get("rt"):
            try:
                fresh = int(str(d["rt"]).rstrip("%")) >= 60
            except ValueError:
                fresh = True
            badges.append(_badge(d["rt"], "#FA320A", "\U0001F345" if fresh else "\U0001F922"))
        if d.get("metacritic"):
            badges.append(_badge(d["metacritic"], "#66CC33", "Metacritic"))
        sep = "&nbsp;&nbsp;&nbsp;&nbsp;"
        self.ratings_label.setText(sep.join(badges))
        self.ratings_label.setVisible(bool(badges))
        self._set_facts(*self._facts)               # the ★ moves into the ratings row
        awards = d.get("awards") or ""
        if awards:
            self.awards_label.setText(f"<span style='color:{C.gold}'>\U0001F3C6</span>&nbsp;&nbsp;"
                                      + html_escape(awards))
        self.awards_label.setVisible(bool(awards))
        if not self._trailer and d.get("trailers"):
            self._set_trailer(d["trailers"][0])
        if not self.backdrop._url and d.get("background"):
            self.backdrop.load(d["background"], self.backdrop._fallback_url or d.get("poster", ""))
        if not self.plot_label.text() and d.get("plot"):
            self._set_plot(d["plot"])
        cast = d.get("cast") or []
        director = ", ".join(d.get("director") or [])
        writers = ", ".join((d.get("writers") or [])[:3])
        if cast:
            while self.cast_lay.count() > 1:
                item = self.cast_lay.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            for i, person in enumerate(cast[:7]):
                self.cast_lay.insertWidget(i, CastChip(person, self.cast_row))
            self.cast_row.show()
            rows = []
            if director:
                rows.append(f"<span style='color:{C.faint}'>Director</span>&nbsp;&nbsp;"
                            + html_escape(director))
            if writers:
                rows.append(f"<span style='color:{C.faint}'>Writers</span>&nbsp;&nbsp;"
                            + html_escape(writers))
            self.credits_label.setText("<br>".join(rows))
            self.credits_label.setVisible(bool(rows))
        elif director and not self.credits_label.text():
            self._set_credits(director)


class MovieDetailView(MetaDetailView):
    """A film's page. Usable straight away from the grid item (title,
    year, rating, resume state); get_vod_info() then fills in the plot,
    runtime, credits, trailer and backdrop."""

    play_movie = Signal(dict)

    def __init__(self, parent=None):
        super().__init__("Back", with_panel=False, parent=parent)
        self.movie = None
        self.primary_btn.clicked.connect(self._play)
        self.secondary_btn.setText("Start over")
        self.secondary_btn.clicked.connect(self._play_from_start)

    def show_movie(self, item):
        self.movie = item
        self.reset_details(("vod", item.get("stream_id")))
        self.title_label.setText(item.get("name", "Unknown"))
        self._year = _clean_year(item.get("year"), item.get("releasedate"))
        self._rating = item.get("rating") or ""
        self._set_facts(self._year, "", self._rating)
        self._set_genres(item.get("genre", ""))
        self._set_plot(item.get("plot", ""))
        self._set_credits()
        self._set_trailer("")
        poster = item.get("stream_icon") or item.get("cover") or ""
        self.backdrop.load(_first_url(item.get("backdrop_path")), poster)
        self._refresh_buttons()

    def _refresh_buttons(self):
        entry = core.load_watch_progress().get(core.vod_key(self.movie))
        fraction = core.watch_progress_fraction(entry) if entry else 0.0
        if entry and 0.02 < fraction < 0.92:
            self.primary_btn.setText(
                f"▶  Resume from {_format_hms(entry.get('position', 0))}")
            self.secondary_btn.show()
        else:
            self.primary_btn.setText("▶  Play")
            self.secondary_btn.hide()

    def showEvent(self, event):
        super().showEvent(event)
        if self.movie:
            self._refresh_buttons()

    def show_info(self, info):
        """Fills in the detail once get_vod_info() returns."""
        if not self.movie:
            return
        info = info or {}
        movie_data = info.get("movie_data") or {}
        if movie_data.get("stream_id") and \
                str(movie_data.get("stream_id")) != str(self.movie.get("stream_id")):
            return                      # a reply for a film we've since left
        data = info.get("info") or {}
        if not isinstance(data, dict):
            return
        runtime = data.get("duration") or ""
        if runtime and runtime.count(":") == 2:
            h, m, _s = (int(x) if x.isdigit() else 0 for x in runtime.split(":"))
            runtime = f"{h}h {m}m" if h else f"{m}m"
        year = self._year or _clean_year(data.get("releasedate"), data.get("release_date"))
        rating = self._rating or data.get("rating") or ""
        self._set_facts(year, runtime, rating, data.get("country", ""))
        if data.get("genre"):
            self._set_genres(data.get("genre"))
        plot = data.get("plot") or data.get("description") or ""
        if plot:
            self._set_plot(plot)
        self._set_credits(data.get("director", ""),
                          data.get("cast") or data.get("actors") or "")
        if data.get("youtube_trailer"):           # don't wipe one the details found
            self._set_trailer(data.get("youtube_trailer"))
        backdrop = _first_url(data.get("backdrop_path"))
        if backdrop:
            poster = data.get("movie_image") or self.movie.get("stream_icon") or ""
            self.backdrop.load(backdrop, poster)

    def _play(self):
        if self.movie:
            self.play_movie.emit(self.movie)

    def _play_from_start(self):
        if not self.movie:
            return
        data = core.load_watch_progress()
        data.pop(core.vod_key(self.movie), None)
        core.save_watch_progress(data)
        self.play_movie.emit(self.movie)


class SeasonPicker(QWidget):
    """Season selector for an episode panel: pill tabs when a show has
    only a few seasons, a "Season 3 \u25be" drop-down when it has more —
    a row of tabs for 20 seasons ran off the edge of the panel, where a
    mouse wheel couldn't reach them."""

    chosen = Signal(object)
    MAX_TABS = 5

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Clear")
        self.setFixedHeight(44)
        self._lay = QHBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(8)
        self._lay.addStretch(1)
        self._tabs = {}
        self._labels = {}
        self._drop = None

    def clear(self):
        for btn in self._tabs.values():
            btn.deleteLater()
        self._tabs = {}
        if self._drop is not None:
            self._drop.deleteLater()
            self._drop = None

    def set_seasons(self, seasons):
        """seasons: [(key, label)] in display order."""
        self.clear()
        self._labels = dict(seasons)
        if len(seasons) <= self.MAX_TABS:
            for key, label in seasons:
                btn = QPushButton(label, self)
                btn.setObjectName("GuideMode")
                btn.setCheckable(True)
                btn.setCursor(Qt.PointingHandCursor)
                btn.clicked.connect(lambda _=False, k=key: self.chosen.emit(k))
                self._lay.insertWidget(self._lay.count() - 1, btn)
                self._tabs[key] = btn
            return
        self._drop = QPushButton("", self)
        self._drop.setObjectName("GuideMode")
        self._drop.setCheckable(True)
        self._drop.setChecked(True)
        self._drop.setCursor(Qt.PointingHandCursor)
        menu = QMenu(self._drop)
        for key, label in seasons:
            menu.addAction(label, lambda k=key: self.chosen.emit(k))
        self._drop.clicked.connect(lambda: (self._drop.setChecked(True),
                                            menu.exec(self._drop.mapToGlobal(
                                                QPoint(0, self._drop.height() + 4)))))
        self._lay.insertWidget(0, self._drop)

    def set_current(self, key):
        for k, btn in self._tabs.items():
            btn.setChecked(k == key)
        if self._drop is not None:
            self._drop.setText(f"{self._labels.get(key, key)}  \u25be")


class SeriesDetailView(MetaDetailView):
    """A series' page: details and backdrop on the left, and on the
    right Stremio's episode panel — season tabs over a list of episodes
    with thumbnails, synopses and watched progress."""

    play_episode = Signal(dict, object)   # episode, series item

    def __init__(self, parent=None):
        super().__init__("Back", with_panel=True, parent=parent)
        self.series = None
        self._progress = {}
        self._continue_entry = None
        self._seasons = {}
        self._season_btns = {}
        self._first_episode = None
        self.primary_btn.clicked.connect(self._primary)

        pl = QVBoxLayout(self.panel)
        pl.setContentsMargins(18, 22, 12, 12)
        pl.setSpacing(12)
        head = QLabel("Episodes", self.panel)
        head.setObjectName("PanelHeading")
        pl.addWidget(head)

        self.picker = SeasonPicker(self.panel)
        self.picker.chosen.connect(self._select_season)
        pl.addWidget(self.picker)

        self.status_label = QLabel("Loading episodes…", self.panel)
        self.status_label.setObjectName("Muted")
        self.status_label.setWordWrap(True)
        pl.addWidget(self.status_label)

        self.ep_scroll = QScrollArea(self.panel)
        self.ep_scroll.setObjectName("Clear")
        self.ep_scroll.setWidgetResizable(True)
        self.ep_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.ep_scroll.viewport().setObjectName("Clear")
        ep_holder = QWidget()
        ep_holder.setObjectName("Clear")
        self.ep_list = QVBoxLayout(ep_holder)
        self.ep_list.setContentsMargins(0, 0, 6, 0)
        self.ep_list.setSpacing(2)
        self.ep_list.addStretch(1)
        self.ep_scroll.setWidget(ep_holder)
        pl.addWidget(self.ep_scroll, 1)

    def show_series(self, item):
        self.series = item
        self.reset_details(("series", item.get("series_id")))
        self._progress = core.load_watch_progress()
        self._seasons = {}
        self._first_episode = None
        self.title_label.setText(item.get("name", "Unknown"))
        seasons = item.get("num_seasons")
        extra = f"{seasons} season{'' if str(seasons) == '1' else 's'}" if seasons else ""
        self._year = _clean_year(item.get("year"), item.get("releaseDate"),
                                 item.get("release_date"))
        self._set_facts(self._year, "", item.get("rating", ""), extra)
        self._set_genres(item.get("genre", ""))
        self._set_plot(item.get("plot", ""))
        self._set_credits(item.get("director", ""), item.get("cast", ""))
        self._set_trailer(item.get("youtube_trailer", ""))
        self.backdrop.load(_first_url(item.get("backdrop_path")), item.get("cover", ""))

        self._continue_entry = core.series_continue_entry(item.get("series_id"),
                                                          self._progress)
        if self._continue_entry:
            s, e = self._continue_entry.get("season"), self._continue_entry.get("episode_num")
            self.primary_btn.setText(f"▶  Resume S{s} E{e}" if s and e else "▶  Resume")
            self.primary_btn.setEnabled(True)
        else:
            self.primary_btn.setText("▶  Play")
            self.primary_btn.setEnabled(False)      # until the episode list is in

        self._clear_chips()
        self._clear_episodes()
        self.status_label.setText("Loading episodes…")
        self.status_label.show()

    def _clear_chips(self):
        (getattr(self, "picker", None) or self.chips).clear()

    def _clear_episodes(self):
        while self.ep_list.count() > 1:
            child = self.ep_list.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def show_episodes(self, info):
        info = info or {}
        meta = info.get("info") or {}
        if isinstance(meta, dict) and meta:
            if meta.get("plot") and not self.plot_label.text():
                self._set_plot(meta.get("plot"))
            if meta.get("cast") or meta.get("director"):
                self._set_credits(meta.get("director", ""), meta.get("cast", ""))
            if meta.get("genre") and not self.genre_label.text():
                self._set_genres(meta.get("genre"))
            if meta.get("youtube_trailer"):
                self._set_trailer(meta.get("youtube_trailer"))
            backdrop = _first_url(meta.get("backdrop_path"))
            if backdrop:
                self.backdrop.load(backdrop, meta.get("cover") or self.series.get("cover", ""))
        episodes = info.get("episodes") or {}
        if isinstance(episodes, list):             # some panels send a flat list
            grouped = {}
            for ep in episodes:
                grouped.setdefault(str(ep.get("season", 1)), []).append(ep)
            episodes = grouped
        if not episodes:
            self.status_label.setText("No episode information is available for this series.")
            return
        self.status_label.hide()
        self._seasons = {str(k): v for k, v in episodes.items() if v}
        order = sorted(self._seasons, key=lambda s: (len(s), s))
        count = len(order)
        self._set_facts(self._year, "", self.series.get("rating", ""),
                        f"{count} season{'' if count == 1 else 's'}")
        self.picker.set_seasons([(season, f"Season {season}") for season in order])
        first_season = order[0]
        eps = self._seasons[first_season]
        self._first_episode = {**eps[0], "season": eps[0].get("season") or first_season}
        if not self._continue_entry:
            self.primary_btn.setText(f"▶  Play S{first_season} "
                                     f"E{self._first_episode.get('episode_num', 1)}")
            self.primary_btn.setEnabled(True)
        start = str(self._continue_entry.get("season")) if self._continue_entry else first_season
        self._select_season(start if start in self._seasons else first_season)

    def _select_season(self, season):
        self.picker.set_current(season)
        self._clear_episodes()
        for ep in self._seasons.get(season, []):
            ep = {**ep, "season": ep.get("season") or season}
            entry = self._progress.get(core.episode_key(ep))
            fraction = core.watch_progress_fraction(entry) if entry else 0.0
            row = _EpisodeRow(ep, fraction if 0.02 < fraction < 0.92 else 0.0)
            row.clicked.connect(self._play)
            self.ep_list.insertWidget(self.ep_list.count() - 1, row)
        self.ep_scroll.verticalScrollBar().setValue(0)

    def _primary(self):
        if self._continue_entry:
            entry = self._continue_entry
            self.play_episode.emit({"id": entry.get("stream_id"),
                                    "container_extension": entry.get("container_extension", "mp4"),
                                    "title": entry.get("title"),
                                    "episode_num": entry.get("episode_num"),
                                    "season": entry.get("season")}, self.series)
        elif self._first_episode:
            self.play_episode.emit(self._first_episode, self.series)

    def _play(self, ep):
        self.play_episode.emit(ep, self.series)


class DiscoverView(QWidget):
    """Stremio-style Discover: a featured banner and rows from the
    catalogs of every installed add-on (Cinemeta's Popular / Featured
    films and series by default)."""

    open_item = Signal(str, dict)          # "movie" / "series", add-on meta
    see_all_library = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.loaded = False
        self.loading = False
        self.shelves = []
        self._catalog_rows = []
        self._continue = []
        self._library = []
        self._search_query = None
        # Called each time Discover is shown, so the Continue-watching row
        # reflects anything just watched; set by the app.
        self.library_provider = None
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        self.holder = holder
        self.lay = QVBoxLayout(holder)
        self.lay.setContentsMargins(34, 26, 24, 40)
        self.lay.setSpacing(34)
        self.scroll.setWidget(holder)
        outer.addWidget(self.scroll)

        self.hero = HeroBanner(holder)
        self.hero.open_item.connect(self._from_hero)
        self.hero.play_item.connect(self._from_hero)
        self.lay.addWidget(self.hero)
        self.status = QLabel("", holder)
        self.status.setObjectName("Muted")
        self.status.setWordWrap(True)
        self.lay.addWidget(self.status)
        self.rows = QVBoxLayout()
        self.rows.setSpacing(34)
        self.lay.addLayout(self.rows)
        self.lay.addStretch(1)

    def _from_hero(self, kind, item):
        meta = item.get("_meta") or {}
        self.open_item.emit(kind.split(":", 1)[-1], meta)

    def set_loading(self, text):
        self.loading = True
        self.status.setText(text)
        self.status.show()

    def show_error(self, text):
        self.loading = False
        self.status.setText(text)
        self.status.show()

    def invalidate(self):
        self.loaded = False

    def invalidate_watched(self):
        """Watched ticks changed (Trakt sync): redraw the rows if shown."""
        if self.loaded:
            self._render()

    def showEvent(self, event):
        super().showEvent(event)
        if self.library_provider:
            self.set_library(*self.library_provider())

    def set_library(self, continue_rows, library):
        """continue_rows: [(type, meta, fraction, text)]; library: Stremio
        library items. Re-renders only if something changed."""
        key = ([(m["id"], round(f, 3)) for _t, m, f, _x in continue_rows],
               [i["id"] for i in library])
        if key == getattr(self, "_library_key", None):
            return
        self._library_key = key
        self._continue, self._library = continue_rows, library
        if self.loaded:
            self._render()

    def show_rows(self, rows):
        self.loading = False
        self._catalog_rows = rows
        self._render()

    # ── search: rows from add-on catalogs that take a search term ──
    def _clear_shelves(self):
        for shelf in self.shelves:
            shelf.setParent(None)
            shelf.deleteLater()
        self.shelves = []
        self._pending_rows = []

    def _fit_height(self):
        self.lay.invalidate()
        self.lay.activate()
        self.holder.setMinimumHeight(self.lay.totalMinimumSize().height())

    def begin_search(self, query, slots):
        if self._search_query is None:
            self._hero_hidden = self.hero.isHidden()
        self._search_query = query
        self._search_rows = [None] * slots
        self._search_left = slots
        self._render_token = getattr(self, "_render_token", 0) + 1   # stop staged rows
        self._clear_shelves()
        self.hero.hide()
        self.status.setText(f"Searching your add-ons for “{query}”…" if slots else
                            "None of your add-ons can search. Cinemeta (installed by default) "
                            "or the TMDB add-on can — add one in Settings → Add-ons.")
        self.status.show()
        self.scroll.verticalScrollBar().setValue(0)
        self._fit_height()

    def add_search_result(self, query, index, row):
        if query != self._search_query or index >= len(self._search_rows):
            return                          # an answer for an older search
        self._search_rows[index] = row or ()
        self._search_left -= 1
        self._clear_shelves()
        for r in self._search_rows:
            if r:
                self._add_catalog_shelf(*r).show()
        if self.shelves:
            self.status.hide()
        elif self._search_left <= 0:
            self.status.setText(f"Nothing found for “{query}” in your add-ons.")
            self.status.show()
        self._fit_height()

    def end_search(self):
        if self._search_query is None:
            return
        self._search_query = None
        self._clear_shelves()
        self.status.hide()
        self.hero.setHidden(getattr(self, "_hero_hidden", False))
        if self._catalog_rows or self._library or self._continue:
            self._render()

    def _add_catalog_shelf(self, title, type_, metas):
        shelf = PosterShelf(title, metas)
        shelf.opened.connect(lambda meta, t=type_: self.open_item.emit(meta.get("type") or t, meta))
        self.rows.addWidget(shelf)
        self.shelves.append(shelf)
        return shelf

    def _add_more_rows(self, token):
        if token != getattr(self, "_render_token", 0) or not self._pending_rows:
            return                          # re-rendered since, or all done
        title, type_, metas = self._pending_rows.pop(0)
        self._add_catalog_shelf(title, type_, metas).show()
        self.lay.invalidate()
        self.lay.activate()
        self.holder.setMinimumHeight(self.lay.totalMinimumSize().height())
        QTimer.singleShot(0, lambda: self._add_more_rows(token))

    def _render(self):
        if self._search_query is not None:
            return                          # search results on screen; redrawn after
        rows = self._catalog_rows
        for shelf in self.shelves:
            shelf.setParent(None)
            shelf.deleteLater()
        self.shelves = []
        library_shelves = []
        if self._continue:
            metas = [m for _t, m, _f, _x in self._continue]
            progress = {m["id"]: (f, x) for _t, m, f, x in self._continue}
            library_shelves.append(("Continue watching", metas, progress))
        if self._library:
            library_shelves.append(("My Stremio library", self._library, None))
        for title, metas, progress in library_shelves:
            shelf = PosterShelf(title, metas, progress=progress,
                                see_all=self.see_all_library.emit
                                if title == "My Stremio library" else None)
            shelf.opened.connect(lambda meta: self.open_item.emit(meta.get("type") or "movie", meta))
            self.rows.addWidget(shelf)
            self.shelves.append(shelf)
        if not rows and not library_shelves:
            self.show_error("None of your add-ons have catalogs to show. Add some in "
                            "Settings → Add-ons (Cinemeta gives you Popular films and series).")
            return
        self.status.hide()
        self.hero.set_items(addon_hero_picks(rows))
        # The banner and the first rows now; the rest a moment later, so
        # the top of the screen is up without waiting for rows below it.
        first = max(0, 2 - len(library_shelves))
        for title, type_, metas in rows[:first]:
            self._add_catalog_shelf(title, type_, metas)
        self._pending_rows = list(rows[first:])
        self._render_token = getattr(self, "_render_token", 0) + 1
        QTimer.singleShot(0, lambda tok=self._render_token: self._add_more_rows(tok))
        self.loaded = True
        # Size the page to its rows now: left to the scroll area, rows
        # added after it was shown were squeezed on top of each other.
        for shelf in self.shelves:
            shelf.show()
        self.lay.invalidate()
        self.lay.activate()
        self.holder.setMinimumHeight(self.lay.totalMinimumSize().height())


class LibraryView(QWidget):
    """Every title in the Stremio library as a grid, Stremio-style, with
    All / Films / Series filters and newest-first or A\u2013Z ordering."""

    open_item = Signal(str, dict)
    back = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items = []
        self.kind = None
        self.order = "recent"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(34, 22, 24, 0)
        lay.setSpacing(4)
        top = QHBoxLayout()
        back_btn = QPushButton("\u2039  Debrid", self)
        back_btn.setObjectName("Ghost")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back.emit)
        top.addWidget(back_btn)
        top.addStretch(1)
        lay.addLayout(top)
        lay.addSpacing(10)
        self.title = QLabel("My Stremio library", self)
        self.title.setObjectName("ScreenTitle")
        lay.addWidget(self.title)
        self.subtitle = QLabel("", self)
        self.subtitle.setObjectName("Muted")
        lay.addWidget(self.subtitle)
        lay.addSpacing(12)
        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.kind_btns = {}
        for key, label in ((None, "All"), ("movie", "Films"), ("series", "Series")):
            btn = QPushButton(label, self)
            btn.setObjectName("GuideMode")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self._set_kind(k))
            chips.addWidget(btn)
            self.kind_btns[key] = btn
        chips.addSpacing(18)
        self.order_btns = {}
        for key, label in (("recent", "Recently added"), ("az", "A\u2013Z")):
            btn = QPushButton(label, self)
            btn.setObjectName("GuideMode")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self._set_order(k))
            chips.addWidget(btn)
            self.order_btns[key] = btn
        chips.addStretch(1)
        lay.addLayout(chips)
        lay.addSpacing(10)
        self.grid = LazyGrid(self._make_card, card_w=POSTER_W, parent=self)
        lay.addWidget(self.grid, 1)
        self._sync_buttons()

    def _make_card(self, item):
        line = "Series" if item.get("type") == "series" else "Film"
        watched = item.get("type") == "movie" and item.get("id") in fluxtv_trakt.watched_sets()[0]
        card = PosterCard(item, item.get("name", ""), line, "\u2713 Watched" if watched else "",
                          item.get("poster") or "",
                          "\u25b6  Watch")
        card.opened.connect(lambda it: self.open_item.emit(it.get("type") or "movie", it))
        card.activated.connect(lambda it: self.open_item.emit(it.get("type") or "movie", it))
        return card

    def set_items(self, items):
        self.items = list(items)
        self._apply()

    def _set_kind(self, kind):
        self.kind = kind
        self._apply()

    def _set_order(self, order):
        self.order = order
        self._apply()

    def _sync_buttons(self):
        for k, b in self.kind_btns.items():
            b.setChecked(k == self.kind)
        for k, b in self.order_btns.items():
            b.setChecked(k == self.order)

    def _apply(self):
        self._sync_buttons()
        items = [i for i in self.items if not self.kind or i.get("type") == self.kind]
        if self.order == "az":
            items.sort(key=lambda i: (i.get("name") or "").lower())
        films = sum(1 for i in self.items if i.get("type") == "movie")
        self.subtitle.setText(f"{len(self.items):,} titles  \u00b7  {films:,} films, "
                              f"{len(self.items) - films:,} series")
        self.grid.set_items(items, "Nothing here yet \u2014 sync your Stremio library in Settings.")
        self.grid.verticalScrollBar().setValue(0)


def _best_stream(streams):
    """What Play starts: a stream from the top add-on in the user's order
    that returned anything (Debridio before Torrentio if that's the
    order), its first cached one if it marks them, otherwise its first.
    Picking "first cached anywhere" jumped to Torrentio, whose [TB+]
    marks are easy to spot, over add-ons that label cached files
    differently."""
    if not streams:
        return None
    top = streams[0]["addon"]
    mine = [x for x in streams if x["addon"] == top]
    return next((x for x in mine if x["cached"]), mine[0])


class _StreamRow(QWidget):
    """One playable source in the streams panel: quality, HDR/DV tags,
    size, whether it's already cached on the debrid service, and the
    add-on's own description lines (usually the file name)."""

    clicked = Signal(dict)
    H = 96

    def __init__(self, stream, parent=None):
        super().__init__(parent)
        self.stream = stream
        self._hover = False
        self.setFixedHeight(self.H)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit(self.stream)

    def paintEvent(self, event):
        s = self.stream
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        card = QRectF(self.rect()).adjusted(2, 3, -2, -3)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 26 if self._hover else 12))
        p.drawRoundedRect(card, 12, 12)

        # Quality block on the left.
        q = QRectF(card.x() + 12, card.y() + 12, 72, card.height() - 24)
        p.setBrush(QColor(C.cyan) if s["rank"] >= 4 else QColor(255, 255, 255, 30))
        p.drawRoundedRect(q, 10, 10)
        p.setPen(QColor("white"))
        p.setFont(font(17 if len(s["quality"] or "") <= 4 else 14, QFont.Bold))
        p.drawText(q.adjusted(0, -10 if s["cached"] else 0, 0, 0), Qt.AlignCenter,
                   s["quality"] or "SD")
        if s["cached"]:
            p.setFont(font(11, QFont.Bold))
            p.setPen(QColor("white") if s["rank"] >= 4 else QColor(C.ok))
            p.drawText(q.adjusted(0, 26, 0, 0), Qt.AlignCenter, "⚡ Cached")

        x = q.right() + 14
        right = card.right() - 14
        # Line 1: add-on label, tags, size.
        p.setFont(font(14, QFont.DemiBold))
        p.setPen(QColor(C.paper))
        size = s["size"]
        sw = 0
        if size:
            p.setFont(font(13, QFont.DemiBold))
            sw = p.fontMetrics().horizontalAdvance(size) + 4
            p.setPen(QColor(C.dim))
            p.drawText(QRectF(right - sw, card.y() + 10, sw, 22), Qt.AlignRight | Qt.AlignVCenter, size)
        p.setFont(font(14, QFont.DemiBold))
        p.setPen(QColor(C.paper))
        label = p.fontMetrics().elidedText(s["label"], Qt.ElideRight, int((right - sw - x) * 0.55))
        p.drawText(QRectF(x, card.y() + 10, right - x, 22), Qt.AlignLeft | Qt.AlignVCenter, label)
        tx = x + p.fontMetrics().horizontalAdvance(label) + 10
        p.setFont(font(10, QFont.Bold))
        for tag in s["tags"]:
            tw = p.fontMetrics().horizontalAdvance(tag) + 12
            if tx + tw > right - sw - 6:
                break
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(C.gold) if tag in ("DV", "HDR10+", "HDR") else QColor(255, 255, 255, 40))
            p.drawRoundedRect(QRectF(tx, card.y() + 13, tw, 16), 4, 4)
            p.setPen(QColor("#111") if tag in ("DV", "HDR10+", "HDR") else QColor(C.paper))
            p.drawText(QRectF(tx, card.y() + 13, tw, 16), Qt.AlignCenter, tag)
            tx += tw + 6
        # Lines 2-3: the add-on's description (file name, seeders, source).
        p.setFont(font(12))
        lines = s["lines"] or [s["filename"]]
        for i, text in enumerate(lines[:2]):
            p.setPen(QColor(C.dim if i == 0 else C.faint))
            text = p.fontMetrics().elidedText(text, Qt.ElideRight, int(right - x))
            p.drawText(QRectF(x, card.y() + 36 + i * 19, right - x, 18),
                       Qt.AlignLeft | Qt.AlignVCenter, text)
        if not s["cached"]:
            p.setFont(font(11))
            p.setPen(QColor(C.faint))
            p.drawText(QRectF(x, card.bottom() - 20, right - x, 16), Qt.AlignLeft | Qt.AlignVCenter,
                       "Not cached — may take a while to start")
        p.end()


class AddonDetailView(MetaDetailView):
    """A film or series from the add-ons. Details come from the meta
    add-on (Cinemeta); the right-hand panel lists streams from the stream
    add-ons (Torrentio, Debridio...). For a series the panel shows the
    episodes first, then the streams for the episode picked."""

    streams_requested = Signal(str, str, bool)      # type, stream id, auto-play
    play_stream = Signal(dict, dict)                # stream, playback context

    def __init__(self, parent=None):
        super().__init__("Back", with_panel=True, parent=parent)
        self.meta = {}
        self.type = "movie"
        self._ctx = None
        self._streams = []
        self._auto = False
        self._seasons = {}
        self._season_btns = {}
        self._season = None
        self.primary_btn.clicked.connect(self._primary)

        pl = QVBoxLayout(self.panel)
        pl.setContentsMargins(18, 22, 12, 12)
        pl.setSpacing(10)
        head = QHBoxLayout()
        head.setSpacing(8)
        self.panel_back = QPushButton("‹  Episodes", self.panel)
        self.panel_back.setObjectName("Ghost")
        self.panel_back.setCursor(Qt.PointingHandCursor)
        self.panel_back.clicked.connect(self._back_to_episodes)
        self.panel_back.hide()
        head.addWidget(self.panel_back)
        self.panel_title = QLabel("Streams", self.panel)
        self.panel_title.setObjectName("PanelHeading")
        head.addWidget(self.panel_title, 1)
        pl.addLayout(head)
        self.panel_sub = QLabel("", self.panel)
        self.panel_sub.setObjectName("Muted")
        self.panel_sub.setWordWrap(True)
        pl.addWidget(self.panel_sub)

        self.chips = SeasonPicker(self.panel)
        self.chips.chosen.connect(self._select_season)
        pl.addWidget(self.chips)

        self.status_label = QLabel("", self.panel)
        self.status_label.setObjectName("Muted")
        self.status_label.setWordWrap(True)
        pl.addWidget(self.status_label)

        self.list_scroll = QScrollArea(self.panel)
        self.list_scroll.setObjectName("Clear")
        self.list_scroll.setWidgetResizable(True)
        self.list_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list_scroll.viewport().setObjectName("Clear")
        holder = QWidget()
        holder.setObjectName("Clear")
        self.list_lay = QVBoxLayout(holder)
        self.list_lay.setContentsMargins(0, 0, 6, 0)
        self.list_lay.setSpacing(4)
        self.list_lay.addStretch(1)
        self.list_scroll.setWidget(holder)
        pl.addWidget(self.list_scroll, 1)

    # ── filling the page ────────────────────────────────────────
    def _fill(self, meta):
        self.title_label.setText(meta.get("name", ""))
        runtime = meta.get("runtime") or ""
        extra = ""
        if self.type == "series":
            seasons = {v.get("season") for v in meta.get("videos") or [] if v.get("season")}
            if seasons:
                extra = f"{len(seasons)} season{'' if len(seasons) == 1 else 's'}"
        if self.type == "movie" and meta.get("id") in fluxtv_trakt.watched_sets()[0]:
            extra = "\u2713 Watched"
        self._set_facts(_meta_year(meta), runtime, meta.get("imdbRating") or "", extra)
        genres = meta.get("genres") or meta.get("genre") or []
        self._set_genres(", ".join(genres) if isinstance(genres, list) else str(genres))
        self._set_plot(meta.get("description") or "")
        director = meta.get("director") or []
        cast = meta.get("cast") or []
        self._set_credits(", ".join(director) if isinstance(director, list) else director,
                          ", ".join(cast) if isinstance(cast, list) else cast)
        trailer = next((t.get("source") for t in meta.get("trailers") or []
                        if isinstance(t, dict) and t.get("source")), "")
        self._set_trailer(trailer)
        self.backdrop.load(meta.get("background") or "", meta.get("poster") or "")

    def show_stub(self, type_, meta):
        """Straight away, from the catalog entry; show_meta() fills in the
        rest when the full details arrive."""
        self.type = "series" if type_ == "series" else "movie"
        self.meta = meta
        self.reset_details(("addon", meta.get("id")))
        self._ctx = None
        self._streams = []
        self._auto = False
        self._seasons = {}
        self._fill(meta)
        self._clear_list()
        self._clear_chips()
        self.panel_back.hide()
        self.chips.setVisible(self.type == "series")
        self.primary_btn.setEnabled(False)
        if self.type == "movie":
            self.panel_title.setText("Streams")
            self.panel_sub.setText("")
            self._ctx = {"id": meta.get("id", ""), "type": "movie",
                         "poster": meta.get("poster") or "",
                         "title": meta.get("name", ""), "name": meta.get("name", ""),
                         "subtitle": "   ".join(filter(None, [_meta_year(meta)]))}
            self._refresh_primary()
            self._request_streams(auto=False)
        else:
            self.panel_title.setText("Episodes")
            self.panel_sub.setText("")
            self.status_label.setText("Loading episodes…")
            self.status_label.show()
            self.primary_btn.setText("▶  Play")

    def show_meta(self, meta):
        if not meta or meta.get("id") != self.meta.get("id"):
            return                                  # a reply for a page we've left
        self.meta = {**self.meta, **meta}
        self._fill(self.meta)
        if self.type != "series":
            # Titles from catalogs like the TMDB add-on have ids such as
            # "tmdb:603"; stream add-ons want the IMDb id, which the meta
            # gives as defaultVideoId (Stremio does exactly this).
            vid = (meta.get("behaviorHints") or {}).get("defaultVideoId") or meta.get("imdb_id")
            if vid and self._ctx and vid != self._ctx["id"]:
                self._ctx["id"] = vid
                self._request_streams(auto=False)
            return
        seasons = {}
        for v in meta.get("videos") or []:
            if isinstance(v, dict) and v.get("id") and v.get("episode") is not None:
                seasons.setdefault(int(v.get("season") or 0), []).append(v)
        for eps in seasons.values():
            eps.sort(key=lambda v: v.get("episode") or 0)
        self._seasons = seasons
        if not seasons:
            self.status_label.setText("No episode list is available for this series.")
            return
        self.status_label.hide()
        order = sorted(seasons, key=lambda s: (s == 0, s))   # specials last
        self.chips.set_seasons([(season, "Specials" if season == 0 else f"Season {season}")
                                for season in order])
        entry = self._continue_entry()
        if entry:
            start = entry.get("season")
        else:
            up_next = self._next_unwatched()
            start = up_next.get("season") if up_next else order[0]
        self._select_season(start if start in seasons else order[0])
        self._refresh_primary()

    # ── series: episodes ────────────────────────────────────────
    def _continue_entry(self):
        sid = self.meta.get("id")
        best = None
        for v in core.load_watch_progress().values():
            if v.get("kind") == "addon" and v.get("series_id") == sid and \
                    0.02 < core.watch_progress_fraction(v) < 0.92:
                if not best or v.get("updated", 0) > best.get("updated", 0):
                    best = v
        return best

    def _episode_dict(self, v):
        return {"episode_num": v.get("episode"), "season": v.get("season"),
                "title": v.get("name") or v.get("title") or f"Episode {v.get('episode')}",
                "info": {"movie_image": v.get("thumbnail") or "",
                         "plot": v.get("overview") or v.get("description") or "",
                         "releasedate": (v.get("released") or "")[:10]},
                "_video": v}

    def _select_season(self, season):
        self._season = season
        self.chips.set_current(season)
        self._clear_list()
        progress = core.load_watch_progress()
        _films, watched_eps = fluxtv_trakt.watched_sets()
        for v in self._seasons.get(season, []):
            entry = progress.get(f"addon:{v['id']}")
            fraction = core.watch_progress_fraction(entry) if entry else 0.0
            row = _EpisodeRow(self._episode_dict(v), fraction if 0.02 < fraction < 0.92 else 0.0,
                              watched=v["id"] in watched_eps)
            row.clicked.connect(lambda ep: self._open_episode(ep["_video"]))
            self.list_lay.insertWidget(self.list_lay.count() - 1, row)
        self.list_scroll.verticalScrollBar().setValue(0)

    def _open_episode(self, video, auto=False):
        s, e = video.get("season"), video.get("episode")
        name = video.get("name") or video.get("title") or ""
        show = self.meta.get("name", "")
        self._ctx = {"id": video["id"], "type": "series", "series_id": self.meta.get("id"),
                     "poster": self.meta.get("poster") or "",
                     "season": s, "episode": e, "name": show,
                     "title": f"{show} — S{s} E{e}" + (f"  {name}" if name else ""),
                     "subtitle": name or f"Season {s}"}
        self.panel_title.setText("Streams")
        self.panel_sub.setText(f"Season {s}, episode {e}" + (f" · {name}" if name else ""))
        self.panel_back.show()
        self.chips.hide()
        self._request_streams(auto)

    def _back_to_episodes(self):
        self.panel_back.hide()
        self.panel_title.setText("Episodes")
        self.panel_sub.setText("")
        self.chips.show()
        self.status_label.hide()
        self._select_season(self._season)

    # ── streams ────────────────────────────────────────────────
    def _request_streams(self, auto):
        self._auto = auto
        self._streams = []
        self._clear_list()
        self.status_label.setText("Finding streams from your add-ons…")
        self.status_label.show()
        self.streams_requested.emit(self._ctx["type"], self._ctx["id"], auto)

    def show_streams(self, stream_id, streams, problems, auto):
        if not self._ctx or stream_id != self._ctx["id"]:
            return
        self._streams = streams
        self._clear_list()
        note = "  ".join(problems)
        if not streams:
            self.status_label.setText(
                (note + "\n\n" if note else "") +
                "No playable streams found. Stream add-ons such as Torrentio or "
                "Debridio (set up with your TorBox key) can be added in Settings → Add-ons.")
            self.status_label.show()
        else:
            cached = sum(1 for s in streams if s["cached"])
            per = {}
            for s in streams:
                per[s["addon"]] = per.get(s["addon"], 0) + 1
            summary = (f"{len(streams)} streams, {cached} cached  ·  " +
                       ", ".join(f"{name} {n}" for name, n in per.items()))
            self.status_label.setText(summary + (f"  ·  {note}" if note else ""))
            self.status_label.show()
            for s in streams:
                row = _StreamRow(s)
                row.clicked.connect(self._play)
                self.list_lay.insertWidget(self.list_lay.count() - 1, row)
            self.list_scroll.verticalScrollBar().setValue(0)
        self._refresh_primary()
        if auto and streams:
            self._play(_best_stream(streams))

    def _play(self, stream):
        if self._ctx:
            self.play_stream.emit(stream, dict(self._ctx))

    def _primary(self):
        if self.type == "movie":
            if self._streams:
                self._play(_best_stream(self._streams))
            else:
                self._request_streams(auto=True)
            return
        entry = self._continue_entry()
        target = None
        if entry:
            for eps in self._seasons.values():
                for v in eps:
                    if v["id"] == entry.get("addon_id"):
                        target = v
        if target is None:
            target = self._next_unwatched()
            if target is None:
                return
        self._open_episode(target, auto=True)

    def _next_unwatched(self):
        """What Play should start, like Stremio's "next episode": the
        episode after the furthest one watched (specials aside), or the
        first episode if none have been. Skipping ahead a season and
        leaving a gap behind doesn't drag Play back to the gap."""
        watched = fluxtv_trakt.watched_sets()[1]
        regular = [v for s in sorted(x for x in self._seasons if x) for v in self._seasons[s]]
        if not regular:
            specials = self._seasons.get(0) or []
            return specials[0] if specials else None
        last = max((i for i, v in enumerate(regular) if v["id"] in watched), default=-1)
        return regular[last + 1] if last + 1 < len(regular) else regular[0]

    def _refresh_primary(self):
        if self.type == "movie":
            key = f"addon:{self.meta.get('id', '')}"
            entry = core.load_watch_progress().get(key)
            fraction = core.watch_progress_fraction(entry) if entry else 0.0
            if entry and 0.02 < fraction < 0.92:
                self.primary_btn.setText(f"▶  Resume from {_format_hms(entry.get('position', 0))}")
            else:
                self.primary_btn.setText("▶  Play")
            self.primary_btn.setEnabled(True)
            return
        if not self._seasons:
            return
        entry = self._continue_entry()
        if entry and entry.get("season") is not None:
            self.primary_btn.setText(f"▶  Resume S{entry['season']} E{entry.get('episode_num')}")
        else:
            first = self._next_unwatched()
            self.primary_btn.setText(f"▶  Play S{first.get('season')} E{first.get('episode')}")
        self.primary_btn.setEnabled(True)

    def showEvent(self, event):
        super().showEvent(event)
        if self.meta:
            self._refresh_primary()

    # ── helpers ─────────────────────────────────────────────────
    def _clear_list(self):
        while self.list_lay.count() > 1:
            child = self.list_lay.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def _clear_chips(self):
        (getattr(self, "picker", None) or self.chips).clear()
