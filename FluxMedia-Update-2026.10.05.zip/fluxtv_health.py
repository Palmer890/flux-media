#!/usr/bin/env python3
"""
Flux Media (FluxTV) — "Check services": is everything Flux Media depends on
answering? Each check returns (name, ok, detail). Run on a worker thread;
every check has its own short timeout so one dead service can't hold up
the rest.

Several of these aren't official, stable APIs (Stremio's account API,
YouTube via yt-dlp, the radio streams), so when something stops working
this says which one, instead of the app just looking broken.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import requests

import fluxtv_addons
import fluxtv_radio
import fluxtv_stremio
import fluxtv_trakt
import fluxtv_youtube


def _provider(api):
    ok, data = api.test_connection()
    if not ok:
        return "IPTV provider", False, str(data)
    info = (data or {}).get("user_info") or {}
    bits = []
    status = info.get("status")
    if status and status.lower() != "active":
        return "IPTV provider", False, f"account status: {status}"
    try:
        exp = int(info.get("exp_date") or 0)
        if exp:
            days = (exp - time.time()) / 86400
            when = datetime.fromtimestamp(exp)
            month = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
                     "Nov", "Dec")[when.month - 1]
            bits.append(f"subscription ends {when.day} {month} {when.year}"
                        + (f" (in {int(days)} days)" if days < 31 else ""))
            if days < 0:
                return "IPTV provider", False, "subscription has expired"
    except (TypeError, ValueError):
        pass
    if info.get("max_connections"):
        bits.append(f"{info.get('active_cons', '?')} of {info['max_connections']} streams in use")
    return "IPTV provider", True, "  ·  ".join(bits) or "signed in"


def _guide(lib):
    n = len(getattr(lib, "epg", {}) or {})
    if n:
        return "TV guide", True, f"{n:,} channels with programme information"
    return "TV guide", False, "not loaded yet (it downloads in the background after start-up)"


def _addon(addon):
    try:
        fluxtv_addons.fetch_manifest(addon.url)
        return f"Add-on: {addon.name}", True, "answering"
    except Exception as error:
        return f"Add-on: {addon.name}", False, f"not answering ({error.__class__.__name__})"


def _stremio():
    account = fluxtv_stremio.load_account()
    if not account:
        return None
    try:
        fluxtv_stremio._call("getUser", {"authKey": account["authKey"]})
        return "Stremio account", True, f"signed in as {account.get('email', '')}"
    except Exception as error:
        return "Stremio account", False, str(error)


def _trakt():
    if not fluxtv_trakt.connected():
        return None
    try:
        cfg = fluxtv_trakt._fresh_cfg()
        r = fluxtv_trakt._request("GET", "/users/settings", cfg)
        if r.status_code == 200:
            name = (r.json().get("user") or {}).get("username", "")
            return "Trakt", True, f"connected as {name}" if name else "connected"
        return "Trakt", False, f"Trakt answered {r.status_code}"
    except Exception as error:
        return "Trakt", False, str(error)


def _youtube():
    if not fluxtv_youtube.available():
        return "YouTube (Music)", False, "not set up yet — open Music once"
    try:
        found = fluxtv_youtube.search("official music video", limit=3)
        v = ".".join(str(x) for x in (fluxtv_youtube.version() or ()))
        return ("YouTube (Music)", bool(found),
                f"working  ·  yt-dlp {v}" if found else "search returned nothing")
    except Exception as error:
        return "YouTube (Music)", False, str(error)


def _radio():
    try:
        fluxtv_radio.search("george fm", limit=1)
        r = requests.get(fluxtv_radio.ROVA[0]["url"], stream=True, timeout=8,
                         headers={"User-Agent": "FluxMedia/1.0"})
        r.close()
        return ("Radio", r.status_code == 200,
                "directory and Rova streams answering" if r.status_code == 200
                else f"Rova streams answered {r.status_code}")
    except Exception as error:
        return "Radio", False, f"not answering ({error.__class__.__name__})"


def check_all(api, lib, addons):
    """[(name, ok, detail)] for everything, in a fixed order."""
    jobs = [lambda: _provider(api), lambda: _guide(lib)]
    jobs += [lambda a=a: _addon(a) for a in addons]
    jobs += [_stremio, _trakt, _youtube, _radio]

    def run(job):
        try:
            return job()
        except Exception as error:                       # never let one check break the list
            return "Check", False, str(error)
    with ThreadPoolExecutor(max_workers=8) as pool:
        return [r for r in pool.map(run, jobs) if r]
