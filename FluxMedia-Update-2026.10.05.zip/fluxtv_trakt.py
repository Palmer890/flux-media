#!/usr/bin/env python3
"""
FluxTV — Trakt (trakt.tv) and the "what have I watched" list.

Trakt only lets apps in through an API app of their own, so the user
creates one (free, developer.trakt.tv/apps) and pastes its Client ID
and Client Secret into Settings. Sign-in is Trakt's device flow: FluxTV
shows a short code, the user approves it at trakt.tv/activate.

Once connected:
  * watched history (films, and episodes as "tt123:3:5") is pulled down,
  * whatever is played from add-ons is scrobbled live (start / pause /
    stop with progress), so it lands in the Trakt history automatically.

The watched list FluxTV shows is the union of Trakt's history, what the
Stremio import says was watched, and anything finished in FluxTV itself.
"""

from __future__ import annotations

import json
import os
import threading
import time

import requests

import fluxtv_core as core

API = "https://api.trakt.tv"
CONFIG_FILE = os.path.join(core.APP_DIR, "trakt.json")
WATCHED_FILE = os.path.join(core.APP_DIR, "watched.json")
APP_SETUP_URL = "https://developer.trakt.tv/apps/new"  # moved from trakt.tv/oauth/applications
REDIRECT = "urn:ietf:wg:oauth:2.0:oob"

_session = requests.Session()
_lock = threading.Lock()


class TraktError(Exception):
    pass


# ── config ───────────────────────────────────────────────────────
def load():
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def connected():
    cfg = load()
    return bool(cfg and cfg.get("access_token"))


def _save(cfg):
    core._write_json(CONFIG_FILE, cfg)


def _headers(cfg, auth=True):
    h = {"Content-Type": "application/json", "trakt-api-version": "2",
         "trakt-api-key": cfg["client_id"], "User-Agent": "FluxTV/1.0"}
    if auth:
        h["Authorization"] = f"Bearer {cfg['access_token']}"
    return h


def _request(method, path, cfg, auth=True, **kw):
    try:
        r = _session.request(method, API + path, headers=_headers(cfg, auth), timeout=25, **kw)
    except requests.RequestException as error:
        raise TraktError(f"Couldn't reach Trakt ({error.__class__.__name__}).")
    return r


# ── sign-in (device flow) ────────────────────────────────────────
def start_device(client_id, client_secret):
    """Returns {"user_code", "verification_url", "device_code", "interval",
    "expires_in"}; the user enters user_code at verification_url."""
    cfg = {"client_id": client_id.strip(), "client_secret": client_secret.strip()}
    r = _request("POST", "/oauth/device/code", cfg, auth=False,
                 json={"client_id": cfg["client_id"]})
    if r.status_code in (401, 403):
        raise TraktError("Trakt didn't accept that Client ID — check it was copied whole.")
    if r.status_code != 200:
        raise TraktError(f"Trakt said {r.status_code} when asked for a code.")
    _save(cfg)
    return r.json()


def poll_device(device_code):
    """One check of the device sign-in: "pending", "slow_down", or the
    connected config. Raises TraktError when it can't succeed any more."""
    cfg = load() or {}
    r = _request("POST", "/oauth/device/token", cfg, auth=False,
                 json={"code": device_code, "client_id": cfg.get("client_id"),
                       "client_secret": cfg.get("client_secret")})
    if r.status_code == 200:
        tokens = r.json()
        cfg.update(access_token=tokens["access_token"], refresh_token=tokens["refresh_token"],
                   expires_at=int(tokens.get("created_at", time.time())) + int(tokens.get("expires_in", 0)))
        _save(cfg)
        try:
            me = _request("GET", "/users/settings", cfg)
            if me.status_code == 200:
                cfg["username"] = (me.json().get("user") or {}).get("username", "")
                _save(cfg)
        except TraktError:
            pass
        return cfg
    if r.status_code == 400:
        return "pending"
    if r.status_code == 429:
        return "slow_down"
    messages = {404: "That code isn't valid any more.", 409: "That code was already used.",
                410: "The code expired — press Connect to get a new one.",
                418: "The request was declined on Trakt.",
                401: "Trakt didn't accept the Client Secret — check it was copied whole."}
    raise TraktError(messages.get(r.status_code, f"Trakt said {r.status_code}."))


def _fresh_cfg():
    """The config with a valid access token, refreshing it if needed."""
    cfg = load()
    if not cfg or not cfg.get("access_token"):
        raise TraktError("Not connected to Trakt.")
    if cfg.get("expires_at", 0) - time.time() < 24 * 3600:
        r = _request("POST", "/oauth/token", cfg, auth=False, json={
            "refresh_token": cfg["refresh_token"], "client_id": cfg["client_id"],
            "client_secret": cfg["client_secret"], "redirect_uri": REDIRECT,
            "grant_type": "refresh_token"})
        if r.status_code == 200:
            t = r.json()
            cfg.update(access_token=t["access_token"], refresh_token=t["refresh_token"],
                       expires_at=int(t.get("created_at", time.time())) + int(t.get("expires_in", 0)))
            _save(cfg)
        elif r.status_code in (400, 401):
            raise TraktError("Trakt sign-in expired — disconnect and connect again.")
    return cfg


def disconnect():
    cfg = load()
    if cfg and cfg.get("client_id") and cfg.get("client_secret"):
        _save_app_keys(cfg["client_id"], cfg["client_secret"])   # next person: just Connect
    if cfg and cfg.get("access_token"):
        try:
            _request("POST", "/oauth/revoke", cfg, auth=False, json={
                "token": cfg["access_token"], "client_id": cfg["client_id"],
                "client_secret": cfg["client_secret"]})
        except TraktError:
            pass
    try:
        os.remove(CONFIG_FILE)
    except OSError:
        pass


# ── watched list ─────────────────────────────────────────────────
_cache = {"mtime": None, "sets": (set(), set())}


def _read_watched():
    try:
        with open(WATCHED_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return {"movies": list(d.get("movies") or []), "episodes": list(d.get("episodes") or []),
                "synced": d.get("synced", 0)}
    except (OSError, ValueError):
        return {"movies": [], "episodes": [], "synced": 0}


def _write_watched(d):
    core._write_json(WATCHED_FILE, d)


def watched_sets():
    """(watched film ids, watched episode ids "tt123:3:5"), cached until the
    file changes."""
    try:
        mtime = os.path.getmtime(WATCHED_FILE)
    except OSError:
        return set(), set()
    if _cache["mtime"] != mtime:
        d = _read_watched()
        _cache.update(mtime=mtime, sets=(set(d["movies"]), set(d["episodes"])))
    return _cache["sets"]


def add_watched(movies=(), episodes=()):
    with _lock:
        d = _read_watched()
        m, e = set(d["movies"]), set(d["episodes"])
        before = len(m) + len(e)
        m.update(x for x in movies if x)
        e.update(x for x in episodes if x)
        if len(m) + len(e) != before:
            d.update(movies=sorted(m), episodes=sorted(e))
            _write_watched(d)


def sync_watched():
    """Pull the full Trakt watched history into the watched list.
    Returns (films, episodes) counted from Trakt."""
    cfg = _fresh_cfg()
    movies, episodes = [], []
    r = _request("GET", "/sync/watched/movies", cfg)
    if r.status_code != 200:
        raise TraktError(f"Trakt said {r.status_code} for watched films.")
    for item in r.json():
        imdb = ((item.get("movie") or {}).get("ids") or {}).get("imdb")
        if imdb:
            movies.append(imdb)
    r = _request("GET", "/sync/watched/shows", cfg)
    if r.status_code != 200:
        raise TraktError(f"Trakt said {r.status_code} for watched shows.")
    for item in r.json():
        imdb = ((item.get("show") or {}).get("ids") or {}).get("imdb")
        if not imdb:
            continue
        for season in item.get("seasons") or []:
            for ep in season.get("episodes") or []:
                if ep.get("plays", 1):
                    episodes.append(f"{imdb}:{season.get('number')}:{ep.get('number')}")
    add_watched(movies, episodes)
    with _lock:
        d = _read_watched()
        d["synced"] = int(time.time())
        _write_watched(d)
    return len(movies), len(episodes)


def last_synced():
    return _read_watched().get("synced", 0)


# ── scrobbling ───────────────────────────────────────────────────
def scrobble(action, meta, progress):
    """action: "start" | "pause" | "stop"; meta: the playback session's
    extra_meta for add-on content (has addon_type, addon_id, series_id,
    season, episode_num); progress: 0-100. Trakt itself marks a "stop"
    at 80% or more as watched."""
    cfg = _fresh_cfg()
    progress = round(max(0.0, min(100.0, float(progress))), 2)
    if meta.get("addon_type") == "series" and meta.get("series_id"):
        body = {"show": {"ids": {"imdb": meta["series_id"]}},
                "episode": {"season": int(meta.get("season") or 0),
                            "number": int(meta.get("episode_num") or 0)},
                "progress": progress}
    else:
        body = {"movie": {"ids": {"imdb": meta.get("addon_id")}}, "progress": progress}
    r = _request("POST", f"/scrobble/{action}", cfg, json=body)
    if r.status_code not in (200, 201, 409):     # 409: same scrobble just sent
        raise TraktError(f"Trakt said {r.status_code} to the {action} scrobble.")
    if action == "stop" and progress >= 80:
        if "episode" in body:
            add_watched(episodes=[f"{meta['series_id']}:{body['episode']['season']}:"
                                  f"{body['episode']['number']}"])
        else:
            add_watched(movies=[meta.get("addon_id")])


# ── easy connect (like Stremio: press Connect, approve, done) ────
# Trakt only talks to registered apps, so Flux Media needs one API app's
# keys. Once one PC has them they can be passed on as a small file, and
# everyone after that just presses Connect and signs in with their OWN
# Trakt account. The keys aren't a login; they only identify the app.
APP_FILE = os.path.join(core.APP_DIR, "trakt_app.json")
SHARE_NAME = "FluxMedia-Trakt-App.json"
_HERE = os.path.dirname(os.path.abspath(__file__))


def _read_keys(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return None
    cid = str(d.get("client_id") or d.get("trakt_client_id") or "").strip()
    secret = str(d.get("client_secret") or d.get("trakt_client_secret") or "").strip()
    return (cid, secret) if cid and secret else None


def app_keys():
    """(client_id, client_secret) Flux Media can connect with, or None."""
    for path in (CONFIG_FILE, APP_FILE, os.path.join(_HERE, "trakt_app.json"),
                 os.path.join(_HERE, SHARE_NAME)):
        keys = _read_keys(path)
        if keys:
            return keys
    return None


def _save_app_keys(cid, secret):
    core._write_json(APP_FILE, {"client_id": cid, "client_secret": secret})


def export_app_keys(path):
    keys = app_keys()
    if not keys:
        raise TraktError("There are no Trakt app keys on this PC to share.")
    core._write_json(path, {"app": "Flux Media", "trakt_client_id": keys[0],
                            "trakt_client_secret": keys[1]})


def import_app_keys(path):
    keys = _read_keys(path)
    if not keys:
        raise TraktError("That isn't a Flux Media Trakt file.")
    _save_app_keys(*keys)
    return keys
